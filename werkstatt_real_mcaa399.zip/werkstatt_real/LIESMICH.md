# UNIQUANT – Erkennungswerkstatt V4.1 am echten Bestand (MCAA Inv. 399)

Stand 2026-11-17.

- **Plan:** vor dem Laden der Abbildung festgelegt; `plan_real_v41.json`, SHA-256 `ee18130a…af8c`.
- **Annotation:** eingefroren, bevor die Farbfassung angesehen wurde; `annotation_grau.json`, SHA-256 `7685fc6b…4136`. Ergänzungen zum Vorgehen stehen in `annotation_protokoll.md`.

## Material

Agostino u. a. 2021, Heritage 4(3):100, Abb. 1, CC BY 4.0. Bezogen von pub.mdpi-res.com; 2887 × 1868 px, SHA-256 `78682469…d10e`.

Zehn Miniaturen; bei Tafel (a) zählt nur die Miniatur, nicht die Textseite.

## Vorgehen

1. Aus der Farbdatei wurde programmgesteuert eine Graustufenfassung erzeugt. Ausschnitte, Polygone und Klassen wurden nur an dieser Fassung gezeichnet (Annotation: Claude).
2. Die Annotation wurde mit Prüfsumme eingefroren. Erst danach wurde das Projekt mit der Farbfassung als Bild gebaut (`projekt_bauen.py`).
3. Gerechnet hat die Werkstatt V4.1 unverändert im Browser (Chrome for Testing 153, `set_content`, alle Netzabrufe gesperrt). Es gab keine Skriptfehler und keinen Netzabruf.
4. Erfasst sind 44 Flächen: 31 Gewand, 8 Architektur, 5 Fels. Gewand kommt in allen 10 Szenen vor, Architektur in 6, Fels nur in 3.

## Ergebnis (ohne Marge; jede Szene einmal zurückgehalten, 10 Durchgänge)

| Variante | richtig | ausgeglichen | Gewand | Architektur | Fels |
|---|---|---|---|---|---|
| Mehrheitsregel | 31/44 | 0,333 | 1,00 | 0,00 | 0,00 |
| A Kontur + Lage | 31/44 | 0,656 | 0,74 | 0,63 | 0,60 |
| C nur Farbe | 28/44 | 0,531 | 0,74 | 0,25 | 0,60 |
| B skaliert | 32/44 | 0,660 | 0,81 | 0,38 | 0,80 |
| B (V4.0) | 32/44 | 0,666 | 0,77 | 0,63 | 0,60 |

Farb-Umordnung innerhalb der Szenen (99 Züge):

| Größe | beobachtet | Mittel der Umordnungen | mindestens so hoch |
|---|---|---|---|
| B − A | +0,005 | −0,045 | 28 von 99 |
| C | 0,531 | 0,334 | 3 von 99 |

**Urteil nach Plan: „kein Hinweis“** (B − A ≤ 0,02 und 28 ≥ 20 Umordnungen). Farbe allein trägt Information über die Klasse (C liegt über dem Zufall, 3 von 99). Zu Kontur und Lage fügt sie in diesem Bestand aber nichts hinzu.

## Grenzen

- **Kleine Zahlen:** Fels umfasst 5 Flächen aus 3 Szenen, Architektur 8. Eine einzige Fläche verschiebt das Klassenmittel um 0,04 bis 0,07.
  - Kleine Farbeffekte sind damit nicht auszuschließen. Die Regel „kein Hinweis“ heißt nicht „kein Effekt“.
  - Die Umordnungskontrolle ist ausdrücklich explorativ.
- **Annotation durch das Modell:** Die Polygone sind grob. Architektur ist oft als Rechteck oder Dreieck gezeichnet, Gewänder mit vielen Ecken.
  - Ein Teil der Leistung von A kann deshalb aus dem Zeichenstil kommen und nicht aus der gemalten Form.
  - Eine zweite, unabhängige Annotation fehlt.
- **Lage:** Sie ist Teil von A. Bildkonventionen (Architektur oben, Gewänder in der Mitte) können A tragen; getrennt geprüft ist das nicht.
- **Bildquelle:** Zeitschriftenabbildung in mäßiger Auflösung, Farbwiedergabe unkalibriert, eine Handschrift.
- **Fragestellung:** Die Objektklasse ist nicht die Hierarchiefrage des Farbatlas, und Bildschirmfarbe ist keine Pigmentbestimmung.

## Dateien

| Datei | Inhalt |
|---|---|
| `plan_real_v41.json`, `.sha256` | Plan |
| `annotation_grau.json`, `annotation_protokoll.md`, `annotation_eingefroren.sha256` | Annotation |
| `projekt_mcaa399_grau.json` | Werkstatt-Projekt mit eingebettetem Bild (CC BY 4.0, Quelle im Bildeintrag). Lässt sich in der Werkstatt öffnen, prüfen und korrigieren. |
| `ergebnis_real.json`, `ausgabe/szenentest.json`, `ausgabe/farbkontrolle.json`, `ausgabe/szenentest.png` | Ergebnisse |
| `skripte/projekt_bauen.py`, `skripte/lauf_browser.py` | Skripte |

## Quelle

A. Agostino u. a., On the Hierarchical Use of Colourants in a 15th Century Book of Hours, Heritage 4(3) (2021) 100, doi:10.3390/heritage4030100, CC BY 4.0.
