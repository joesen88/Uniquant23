"""Baut aus der eingefrorenen Graustufen-Annotation ein Werkstatt-Projekt mit der Farbfassung als Bild.
Aufruf: python3 -I projekt_bauen.py STARTPROJEKT ANNOTATION BILD_PNG AUSGABE_JSON"""
import sys, json, hashlib, base64
from PIL import Image
start, ann, bild, aus = sys.argv[1:5]
P = json.load(open(start, encoding='utf-8'))
A = json.load(open(ann, encoding='utf-8'))
raw = open(bild, 'rb').read()
W, H = Image.open(bild).size
sha = hashlib.sha256(raw).hexdigest()
img_id = 'IMG_AGOSTINO_F01'
P['images'] = {img_id: {'name': 'heritage-04-00100-g001.png', 'width': W, 'height': H, 'sha256': sha,
                        'origin': 'Agostino et al. 2021, Heritage 4(3):100, Fig. 1, CC BY 4.0; pub.mdpi-res.com',
                        'data_url': 'data:image/png;base64,' + base64.b64encode(raw).decode()}}
szenen = {s['id']: s for s in P['scenes']}
P['regions'] = []
for k, s in A['szenen'].items():
    px0, py0 = A['panels'][k][0], A['panels'][k][1]
    cx0, cy0, cx1, cy1 = s['crop']
    sc = szenen[s['scene_id']]
    sc['image_id'] = img_id
    sc['crop'] = [round((px0 + cx0) / W, 7), round((py0 + cy0) / H, 7), round((cx1 - cx0) / W, 7), round((cy1 - cy0) / H, 7)]
    sc['crop_confirmed'] = True
    sc['inventory_complete'] = True
    for r in s['regionen']:
        pts = [[round(min(1, max(0, (x - cx0) / (cx1 - cx0))), 7), round(min(1, max(0, (y - cy0) / (cy1 - cy0))), 7)] for x, y in r['points']]
        P['regions'].append({'id': 'R_' + r['id'], 'scene_id': s['scene_id'], 'points': pts, 'holes': [], 'label': r['label'],
                             'reviewed': True, 'exclude': False, 'layer': 'unknown', 'note': r['note'],
                             'origin': 'claude_annotation_graustufen', 'material_link': None})
P['project_id'] = 'MCAA399_V41_GRAU'
P['title'] = 'Inv. 399 — Graustufen-Annotation (Claude), Farbfassung als Bild'
json.dump(P, open(aus, 'w', encoding='utf-8'), ensure_ascii=False)
print('Bild', W, H, sha, '| Szenen', len(A['szenen']), '| Regionen', len(P['regions']))
