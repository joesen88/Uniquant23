"""Führt den Szenentest der Werkstatt V4.1 im Browser auf einem Projekt aus (set_content, Netz gesperrt).
Aufruf: python3 lauf_browser.py WERKSTATT_HTML PROJEKT_JSON AUSGABEORDNER"""
import sys, json, asyncio, os
from pathlib import Path
from playwright.async_api import async_playwright
html, proj, aus = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
aus.mkdir(parents=True, exist_ok=True)
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path=os.environ.get('CHROMIUM', '/usr/bin/google-chrome'), headless=True, args=['--no-sandbox'])
        page = await b.new_page(viewport={'width': 1580, 'height': 1060})
        errors, requests = [], []
        page.on('pageerror', lambda e: errors.append(str(e))); page.on('request', lambda r: requests.append(r.url))
        page.on('dialog', lambda d: d.accept())
        await page.route('**/*', lambda r: r.abort())
        await page.set_content(html.read_text(), wait_until='load')
        await page.wait_for_function('window.UQReady === true')
        P = json.loads(proj.read_text())
        await page.evaluate('p=>UQApp.setProject(p)', P)
        rep = await page.evaluate('UQApp.runTest()')
        if rep is None:
            txt = await page.locator('body').inner_text()
            (aus / 'fehler.txt').write_text(txt[:5000]); raise SystemExit('runTest lieferte null')
        (aus / 'szenentest.json').write_text(json.dumps(rep, ensure_ascii=False, indent=1))
        await page.locator('[data-tab="test"]').click()
        await page.locator('#runShuffle').click()
        await page.wait_for_function('UQApp.getShuffle() !== null', timeout=600000)
        sh = await page.evaluate('UQApp.getShuffle()')
        (aus / 'farbkontrolle.json').write_text(json.dumps(sh, ensure_ascii=False, indent=1))
        await page.locator('#toast').evaluate("el=>el.classList.add('hidden')")
        await page.screenshot(path=str(aus / 'szenentest.png'), full_page=True)
        print(json.dumps({'fehler': errors, 'netzabrufe': len(requests)}))
        await b.close()
asyncio.run(main())
