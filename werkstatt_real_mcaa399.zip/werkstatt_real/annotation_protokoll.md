# Annotationsprotokoll (Ergänzung zum Plan, vor Abschluss der Annotation festgehalten)

Stand 2026-11-17, nach Ansicht nur von Tafel (b) in Graustufen.

- Gewand: die sichtbare Kleidung einer Figur als eine Fläche (Mantel und Kleid zusammen, wenn sie in Graustufen nicht sicher trennbar sind), ohne Gesicht, Hände und Heiligenschein. Präzisierung von „ein zusammenhängendes Kleidungsstück“.
- Fels: deutlich abgegrenzte Fels- und Hügelformationen im Vorder- und Mittelgrund. Flacher Boden, Wiesen und ferne Landschaft werden nicht erfasst.
- Architektur: Bauteile (Wände, Dächer, Pfosten, Bögen, Fliesenböden, Bänke aus Stein).
- Nicht erfasst: Himmel, Heiligenscheine, Tiere, Gegenstände, Textilbehänge, Rahmen und Randschmuck.
- Polygone in Pixelkoordinaten der Tafel (Graustufen), daraus normierte Koordinaten im Szenenausschnitt.
- Szenenausschnitt: das gemalte Bildfeld innerhalb des Rahmens; bei (a) nur die Miniatur, nicht die Textseite.
