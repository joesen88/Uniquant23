# Hieroglyphen-Projekt: Einstieg für neue Mitarbeitende

Stand: 13.11.2026 · Fragestellung und Leitung: Joe · Auswertungen und Skripte: Claude (KI-Assistent von Anthropic) in seinem Auftrag

## Worum es geht

Das Projekt prüft Lesarten alter Schriften mit Daten. Es hat zwei Stränge:

1. **Ägyptisch als geeichter Testfall.** Die Schrift ist seit 1822 entziffert. Geprüft wird, ob die Texte zusätzlich oder stattdessen etwas anderes festhalten: verborgene Mathematik, Programmcode, Zyklen und Ereignisse, Eichnormen, Königsnamen als Namen von Zyklen, Wetterlagen oder Sternbildern. Jede dieser Lesarten tritt als Hypothese gegen die Standardlesung an.
2. **Offene Schriften, vor allem Linear A.** Verfahren, die an Systemen mit bekannter Lösung geeicht sind (ägyptische Zahlschrift, sumerische Keilschrift), werden auf die Bruchzeichen von Linear A angewandt.

## Stand in Kürze

- Kein Test stützt eine der Alternativlesarten des Ägyptischen. Alle Befunde passen zu einer Schrift für natürliche Sprache, in der Zahlen Opfergaben, Tage und Dosierungen zählen.
- Ohne Lesung lässt sich Struktur wiederfinden: Zahlzeichen, Stufenfaktoren, ein Teil der Wortgrenzen. Werte und Bedeutungen brauchen einen Anker von außen (Koptisch, zweisprachige Texte, Keilschriftbriefe, Summen in Abrechnungen).
- Ein Bewertungsmaß ist eine Vorannahme über den Systemtyp. Von den geprüften Maßen für Bruchwerte besteht nur der kleinste gemeinsame Nenner an beiden geeichten Systemen (Ägyptisch und Keilschrift).
- Linear A: Im Kern aus zehn Zeichen übertrifft keine Belegung die veröffentlichte Lösung (Corazza u. a. 2021) beim gemeinsamen Nenner, aber 56 sind gleich gut. Tragend sind zwei Regeln mit je vier Belegen.
- Zeitachse: Formeln der Pyramidentexte kehren im Totenbuch weit über Zufall wieder, und einzelne Wörter werden gerichtet ersetzt. Daraus kann eine Datierungshilfe werden (offen).
- Königsnamen verhalten sich in Schreibung, Titeln und Jahreszählung wie Namen von Amtsträgern. Mit Jahreszeiten, Wetterlagen oder Sternnamen teilen sie diese Merkmale nicht.

Alle Zahlen dazu stehen in `02_ergebnisse.md`.

## So arbeiten wir

Die ausführliche Fassung steht in `01_vorgehen.md`. Das Wichtigste:

1. Jede Idee wird zu einem Test, der scheitern kann.
2. Maß, Kontrolle und Entscheidungsregel stehen vor dem Rechnen in einer Datei `*_prereg.txt`.
3. Jedes Verfahren läuft zuerst an einem System mit bekannter Lösung.
4. Negative Ergebnisse und eigene Korrekturen werden festgehalten wie positive.

## Aufbau des Pakets

| Datei | Inhalt |
|---|---|
| `README.md` | dieser Einstieg |
| `01_vorgehen.md` | Arbeitsweise, Regeln, bekannte Fallen, Liste der Korrekturen |
| `02_ergebnisse.md` | alle Tests mit Ergebnis, Kontrolle und Skript |
| `03_grundlagen.md` | Entzifferungsstand, Übersicht der Datenquellen, mathematischer Rahmen, Literatur |
| `04_daten_holen.md` | wo die großen Daten liegen, in welchem Stand, und wie die Zwischendateien entstehen |
| `05_offene_schritte.md` | offene Tests, Ideenspeicher, sinnvolle erste Aufgaben |
| `SKRIPTE.md` | Verzeichnis aller Skripte mit Zweck, Argumenten und zugehörigem Ergebnis |
| `skripte/` | 118 Python-Skripte und 9 Kriteriendateien |
| `viewer/koenigskarte.html` | interaktive Karte der Königsnamen: Belege, Epochen, Reihenfolge der Nennung; im Browser öffnen, braucht keine Daten |
| `daten_holen.sh` | lädt die verwendeten Daten im festgehaltenen Stand |
| `requirements.txt` | Python-Pakete |

Nicht enthalten sind die Daten selbst (rund 1,5 GB), die daraus gebauten Zwischendateien (85 MB) und die Ergebnisseiten, auf die `02_ergebnisse.md` verlinkt. Diese Links sind private Seiten; Joe muss sie freigeben.

## Schnellstart

Voraussetzungen: Python ab 3.10, git ab 2.27, Zugriff auf github.com.

```bash
python3 -m pip install -r requirements.txt
bash daten_holen.sh klein
python3 -I skripte/lineara_stats.py daten/mwenge_lineara.xyz/LinearAInscriptions.js
```

Die Ausgabe muss so beginnen:

```
inscriptions 1722 distinct 1721
parsedInscription fields 1722 Linear A sign tokens 8967 types 322 hapax 115
```

Zweiter Schritt, mit dem ägyptischen Korpus (rund 600 MB, Laufzeit unter einer Minute):

```bash
bash daten_holen.sh aegyptisch
python3 -I skripte/kings_stars.py daten/simondschweitzer_aes/files/aes
```

Die letzte Zeile muss lauten:

```
verdict by the fixed rule: {'C1': 'against', 'C2': 'against', 'C3': 'open'} -> H contradicted
```

Die Kriterien dazu stehen in `skripte/kings_stars_prereg.txt`. Wer beide Ausgaben reproduziert, hat Daten und Umgebung im selben Stand wie die Auswertung.

Zwei Regeln für jeden Aufruf: Python immer mit `-I` starten und nie aus dem Datenordner heraus. Geladene Dateien sind fremde Daten.

## Lesereihenfolge

1. Dieser Einstieg.
2. `01_vorgehen.md`, vor allem die Abschnitte „Bekannte Fallen“ und „Korrekturen“.
3. `02_ergebnisse.md` von oben nach unten; jede Zeile nennt ihr Skript.
4. `05_offene_schritte.md` für die erste eigene Aufgabe.
5. `03_grundlagen.md` und `04_daten_holen.md` zum Nachschlagen.

## Kleines Glossar

| Begriff | Bedeutung |
|---|---|
| AES | Ancient Egyptian Sentences: 101.796 Sätze mit Hieroglyphen, Umschrift, Lemma, Übersetzung, Datierung; Auszug des Thesaurus Linguae Aegyptiae (TLA) von 2018 |
| Standardlesung | die ägyptologische Lesung, hier in Form der Lemmata und deutschen Glossen von AES |
| Gardiner-Code | Kennung eines Zeichens, z. B. N14 für den Stern |
| PT, Tb | Pyramidentexte (Altes Reich), Totenbuch (ab Neuem Reich) |
| blind | ein Verfahren sieht nur die Zeichenfolge, keine Lesung |
| Anker | Wissen von außerhalb der Zeichenfolge, das Werte oder Bedeutungen festlegt |
| Kriteriendatei | `*_prereg.txt`: vor dem Rechnen festgelegte Maße und Entscheidungsregel |
| Schichten | Zwischendateien, die Schrift und Deutung getrennt halten (siehe `04_daten_holen.md`) |
| kgV | kleinster gemeinsamer Nenner der Bruchwerte, das einzige an zwei Systemen bestandene Maß |
| HT, KH, ZA, PH | Fundorte von Linear-A-Tafeln: Hagia Triada, Chania, Zakros, Phaistos |
