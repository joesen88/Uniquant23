#!/usr/bin/env bash
# Holt die im Projekt verwendeten Daten in den Ordner daten/, jeweils in genau dem Stand der Auswertung (12./13.11.2026).
# Aufruf:  bash daten_holen.sh klein        Linear A, Unikemet, Koptisch, Textnamen (rund 15 MB)
#          bash daten_holen.sh aegyptisch   dazu AES, Ramses, JSesh (rund 600 MB)
#          bash daten_holen.sh alles        dazu Vergleichskorpora und Keilschrift (rund 1,5 GB)
# Zweites Argument: Zielordner (Vorgabe: daten). Braucht git ab 2.27 und Zugriff auf github.com.
# Geladen wird nur, was die Skripte lesen (sparse checkout). Die Daten sind fremde Dateien: Skripte nie aus dem
# Datenordner heraus starten, Python immer mit -I aufrufen.
set -euo pipefail
STUFE=${1:-klein}; ZIEL=${2:-daten}
case "$STUFE" in klein) STUFEN="klein";; aegyptisch) STUFEN="klein aegyptisch";; alles) STUFEN="klein aegyptisch alles";; *) echo "Stufe: klein | aegyptisch | alles"; exit 1;; esac
hole() {  # Stufe Name Adresse Stand Pfadmuster...
  local stufe=$1 name=$2 url=$3 stand=$4; shift 4
  case " $STUFEN " in *" $stufe "*) ;; *) return 0;; esac
  if [ ! -d "$ZIEL/$name/.git" ]; then git clone --quiet --filter=blob:none --no-checkout "$url" "$ZIEL/$name"; fi
  git -C "$ZIEL/$name" sparse-checkout set --no-cone "$@"
  git -C "$ZIEL/$name" checkout --quiet "$stand"
  echo "ok  $name  $(du -sh "$ZIEL/$name" | cut -f1)"
}
mkdir -p "$ZIEL"
hole klein mwenge_lineara.xyz https://github.com/mwenge/lineara.xyz 9c81beba669a4ffec3f5b29d4e7748d02c060eff '/LinearAInscriptions.js' '/commentary/HT34.html'
hole klein unicode-org_unicodetools https://github.com/unicode-org/unicodetools 2f97de762e1b69149a7bc389a7fa19488dcf7af6 '/unicodetools/data/ucd/16.0.0/Unikemet.txt' '/unicodetools/data/ucd/17.0.0/Unikemet.txt' '/unicodetools/data/ucd/18.0.0/Unikemet.txt' '/unicodetools/data/ucd/dev/Unikemet.txt'
hole klein KELLIA_dictionary https://github.com/KELLIA/dictionary f365e2d239bd12b6897f3a761487e40d384b2b24 '/data/egyptian_etymologies.tab'
hole klein simondschweitzer_aed-tei https://github.com/simondschweitzer/aed-tei 462c722e0323e05641aea2eee8cdf1e27303d939 '/concordance_name_text_id.csv'
hole klein j-luo93_NeuroDecipher https://github.com/j-luo93/NeuroDecipher 480bad2487820e3737fecfdd108214efa769e34b '/data/'
hole aegyptisch simondschweitzer_aes https://github.com/simondschweitzer/aes 35276d2527cca1a055e31ed5f6683e777717170f '/files/aes/'
hole aegyptisch MaReTEgyptologists_TranslitModels https://github.com/MaReTEgyptologists/TranslitModels c612a91407bddf8d546beedaf46edd5190a67eef '/Output/ModifiedSources/' '/Output/WordLists/'
hole aegyptisch rosmord_jsesh https://github.com/rosmord/jsesh d16d8a9a4893780bc1ab2b49c1f973e772915fef '/jsesh/src/main/resources/jsesh/glyphs/resources/signs_description.xml' '/jseshGlyphs/src/main/resources/jseshGlyphs/'
hole alles christos-c_bible-corpus https://github.com/christos-c/bible-corpus 44e5fca1bfb369a5da2ee23ebc6f421c88489c5c '/bibles/German.xml' '/bibles/Latin.xml' '/bibles/Hebrew.xml' '/bibles/Greek.xml' '/bibles/English.xml' '/bibles/Arabic.xml' '/bibles/Coptic-NT.xml' '/bibles/Chinese.xml' '/bibles/Chinese-tok.xml'
hole alles cltk_lat_text_latin_library https://github.com/cltk/lat_text_latin_library 76229acaf02efd1964ac32009408a90b6f279758 '/*'
hole alles UniversalDependencies_UD_Latin-ITTB https://github.com/UniversalDependencies/UD_Latin-ITTB 16cc97fce6969cdec628544c57194938281fbcdf '/*.conllu'
hole alles UniversalDependencies_UD_Latin-PROIEL https://github.com/UniversalDependencies/UD_Latin-PROIEL 56e6e8c8f6b1c6388dba17c807a9da19f6141b23 '/*.conllu'
hole alles UniversalDependencies_UD_Latin-Perseus https://github.com/UniversalDependencies/UD_Latin-Perseus 63aba6ffd132ea5c0f453cad901bbd4547e1e70a '/*.conllu'
hole alles PerseusDL_canonical-greekLit https://github.com/PerseusDL/canonical-greekLit cae36e967c83d5b5ccd4d604a1f9ce4ba4fa4354 '/data/tlg0059/'
hole alles cplusplus_draft https://github.com/cplusplus/draft ab4b978e6fe44d3591758db789de9f3c59770f26 '/source/basic.tex' '/source/lex.tex' '/source/statements.tex' '/source/std.tex'
hole alles cdli-gh_data https://github.com/cdli-gh/data 228da1bd5012f372abe6acb69411dad9001fd8cf '/cdliatf_unblocked.atf' '/cdli_catalogue_*of4.csv'
hole alles KashiwaByte_ancient-egyptian-hieroglyphs-classification https://github.com/KashiwaByte/ancient-egyptian-hieroglyphs-classification bd580280582cb7db063d348fec67cb91ff1562f4 '/prepared_data.zip'
echo "fertig: Stufe $STUFE in $ZIEL"
