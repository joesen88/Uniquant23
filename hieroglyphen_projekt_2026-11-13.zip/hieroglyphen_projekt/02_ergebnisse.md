> Stand: Ergebnis-Tab des Projektdokuments, Revision 29 vom 13.11.2026. Skriptnamen beziehen sich auf den Ordner `skripte/`. Links auf claude.ai/artifact sind private Seiten und nur nach Freigabe durch Joe erreichbar.

# Testergebnisse vom 12.11.2026

2026-11-12 · Joe

Kein Test stützt die Lesart der Hieroglyphen als verborgene Mathematik, Programmcode oder Frequenzkarte. Alle Befunde passen zu einer Schrift für natürliche Sprache, in der Zahlen Opfergaben, Tage und Dosierungen zählen. Jedes Verfahren wurde an Sprachen oder Zahlsystemen mit bekannter Lösung geprüft.

## Schrift und Zeichen

Die Zeichenverteilung entspricht einer Gebrauchsschrift mit kleinem Kern und breitem Rand. Seltene Zeichen sind Schreibvarianten, keine Schlüsselzeichen.

### Texte nach Schwierigkeit und Thema

- **Ergebnis:** 3.305 von 13.026 Texten bewertet (88,5 % der Wörter). Am einfachsten sind Verwaltungsarchive (Median −0,54), am schwierigsten Felsinschriften (+0,65). Inhaltswort-Cluster treffen die Gattung zu 80 %.
- **Kontrolle:** Zufallsbasis 27 %
- **Skript:** `structure_final.py`

### Drei Zeichenklassen (Pyramidentexte mit Literatur, mit Medizin, Rest)

- **Ergebnis:** 99,4 bis 99,7 % der Zeichenvorkommen liegen in der Klasse „auch in Literatur“. Die beiden Sonderklassen machen zusammen 0,6 % (Pyramidentexte) und 0,3 % (Ritualpapyri) aus.
- **Kontrolle:** Zwei Hälften derselben Gattung unterscheiden sich ebenso stark (0,23 bis 0,54 %)
- **Skript:** `sign_classes.py`, `sign_keyness.py`

### Seltene Zeichen (71 Zeichen, 364 Vorkommen in den Ritualpapyri)

- **Ergebnis:** 291 von 364 Vorkommen stehen in Wörtern, die sonst ohne das Zeichen geschrieben werden. 44 von 71 Zeichen hängen an genau einem Wort, 43 kommen höchstens zweimal vor. Im Umkreis von ±5 Zeichen erreichen sie 3,2 % des Textes.
- **Kontrolle:** Die Parallelfassungen von PT 273–274 ersetzen sie durch gewöhnliche Zeichen
- **Skript:** `rare_signs.py`, Seite [Hieroglyphen-Randzeichen](https://claude.ai/artifact/UGfTcFRmZ3A6qHA5PPxjsb)

### Latein als Vergleich

- **Ergebnis:** Dieselbe Dreiteilung auf Wortebene: Vulgata 88,7 / 1,4 / 9,9 %, Pyramidentexte 90,8 / 1,2 / 7,9 %. Eigennamen stellen 43 und 42 % der Restklasse.
- **Kontrolle:** gleiche Regel auf 112.391 lateinische Wörter
- **Skript:** `latin_control.py`

### 3×3 und 3×3×3 Untergruppen

- **Ergebnis:** Von 27 Zellen sind effektiv 8,8 (Pyramidentexte) und 7,2 (Vulgata) besetzt. Die Achsen sind nicht unabhängig.
- **Kontrolle:** Rauschen 0,0005 bis 0,001 (Jensen-Shannon)
- **Skript:** `subgroups.py`, `grid27.py`

### Zwei Skalen (Kern und Rand)

- **Ergebnis:** Die Zeichenhäufigkeit bricht bei Rang 212 (95 % Abdeckung): Steigung −1,08 davor, −3,32 danach. Die Wörter der Pyramidentexte brechen bei Rang 121, die der Vulgata bei Rang 369.
- **Kontrolle:** Teiler 10 oder 13 ändern nur die Klassenbreite, nicht den Bruch
- **Skript:** `zipf_profile.py`, `sign_structure.py`

### Mehr als 24 Buchstaben?

- **Ergebnis:** Die 24 häufigsten Zeichen schreiben 39,2 % der Wörter vollständig, für 90 % braucht man 248 Zeichen. 71 Zeichen kommen in mindestens 1 % der Schreibungen vor.
- **Kontrolle:** Koptisch: 24 griechische und 7 zusätzliche Buchstaben
- **Skript:** `letters.py`

## Sprachvergleich und Lesart

Die Zeichenfolge verhält sich wie geschriebene Sprache mit fester Leserichtung, nicht wie Programmcode oder ein periodisches Signal.

### Informationsgehalt im Sprachvergleich (7.926 Bibelverse)

- **Ergebnis:** Bits je Vers: Hebräisch 182, Arabisch 189, Koptisch 201, Latein 202, Englisch 204, Griechisch 217, Deutsch 222. Ägyptische Sätze tragen 117,7 Bits, ihre deutsche Übersetzung 127,7.
- **Kontrolle:** Zeichensummen finden den Parallelvers in 0,05 bis 0,15 % der Fälle (Zufall 0,013 %)
- **Skript:** `parallel_info.py`

### Namen als Anker

- **Ergebnis:** Eindeutige Zuordnung mit 1 Namen in 48 %, mit 3 Namen in 84 %, mit 5 Namen in 95 % der Fälle. Hebräische Buchstabenwerte aus 132 Namenspaaren: 25 von 25 richtig.
- **Kontrolle:** Anker zwischen Latein und den anderen Sprachen sind zu 61 bis 76 % Namen (Basis 10 %)
- **Skript:** `parallel_info.py`, `direction2.py`

### Koptisch-Test (1.185 Lemmata, 237 zurückgehalten)

- **Ergebnis:** 21 von 22 Konsonantenzeichen erhalten den erwarteten koptischen Buchstaben. Mit 24 Lautzeichen auf ungesehenen Wörtern: Trefferquote 52,1 %, Genauigkeit 77,6 %.
- **Kontrolle:** vertauschte Zuordnung: F1 0,155
- **Skript:** `coptic_align.py`, `coptic_decode.py`

### Leserichtung

- **Ergebnis:** 675 von 675 Texten bevorzugen die überlieferte Richtung (im Mittel 2,15 Bits). Richtungswechsel alle 10 bis 100 Zeichen verschlechtern die Kompression von 4,20 auf 4,72 bis 5,36 Bits je Zeichen.
- **Kontrolle:** Eine vollständig gespiegelte Folge ist statistisch gleichwertig (4,197 gegen 4,198)
- **Skript:** `direction.py`, `direction2.py`

### Blinde Segmentierung

- **Ergebnis:** 94,6 % der statistisch festen Zeichenverbindungen liegen innerhalb eines edierten Wortes. Grenz-F1: Ägyptisch 0,59 (Zufall 0,43), Hebräisch 0,61, Arabisch 0,65, Latein 0,68, Deutsch 0,71, Chinesisch 0,80.
- **Kontrolle:** sechs Sprachen mit bekannter Worttrennung
- **Skript:** `blind_seg.py`, `blind_units.py`, `blind_extra.py`

### Gattungsprofile

- **Ergebnis:** Gattung in einer ungesehenen Sprache: 22 von 24 richtig. Die Pyramidentexte liegen am nächsten bei „Ritualvorschrift“ (Abstand 0,87), dann „Bauanleitung“ (1,83).
- **Kontrolle:** jeweils eine Sprache zurückgehalten
- **Skript:** `genre_profiles.py`, `genre_keywords.py`

### C++ als Vergleich

- **Ergebnis:** Im Code gehören 64,8 % der Tokens zu geschlossenen Klassen. Klammern machen 20,4 % aus und reichen bis Tiefe 8.
- **Kontrolle:** Sprachstandard: 82 Schlüsselwörter, 58 Operatoren
- **Skript:** `cpp_categories.py`

### Verschachtelung

- **Ergebnis:** Blinder Klammertest: C++ 99 bis 100 % (Tiefe bis 9), Ägyptisch bestes Zeichenpaar 65 %, Tiefe 1. Gespiegelte Vierergruppen sind seltener als andere Umstellungen (0,20 gegen 0,54).
- **Kontrolle:** C++-Quelltext
- **Skript:** `nesting.py`

### Periodizität

- **Ergebnis:** Wiederholungsspitzen nur bei kurzen Abständen (2 bis 8). Bei Abstand 300: 3,35 % gegen 3,30 % nach Mischen.
- **Kontrolle:** gemischte Folge
- **Skript:** `periodicity.py`

### Burrows’ Delta (150 häufigste Lemmata oder Zeichen)

- **Ergebnis:** Nächster Text aus derselben Gruppe: 85,5 % mit Lemmata (387 Texte), 91,5 % blind mit Zeichen (201 Texte). Zwei Hälften desselben Textes finden sich in 40,9 % und 39,9 % der Fälle. Innerhalb eines Editionsprojekts 95,5 % (SAW) und 91,8 % (BBAW). Die Pyramidentexte liegen am nächsten beim Totenbuch (0,39).
- **Kontrolle:** Zufall 18,3 % und 28,0 %; lateinische Autoren: 79,8 % (Zufall 8,4 %)
- **Skript:** burrows_delta.py, burrows_delta2.py

### Datierung mit Burrows’ Delta (377 datierte Texte)

- **Ergebnis:** Richtige Epoche in 71,1 % mit Nachbarn aus allen Texten, in 43,5 % nur mit Nachbarn aus anderen Textgruppen. Von 27 undatierten Texten mit bekannter Sammlungsepoche trifft Delta 12; 9 von 11 spätzeitlichen Inschriften landen im Mittleren Reich (archaisierende Sprache). Delta misst Sprachform und Gattung, nicht das Alter der Handschrift.
- **Kontrolle:** Raten der größten Klasse: 49,6 %
- **Skript:** delta_dating.py

### Naturereignisse im Korpus

- **Ergebnis:** Sturm 14 und Beben 18 je 100.000 Wörter, vor allem in Ritual und Literatur. In den Pyramidentexten nennen 23 von 28 Sätzen mit bebender Erde im selben Satz den Himmel (feste Formel vor König oder Gott). Nur ein Satz verbindet ein Regierungsjahr mit einem Ereignis: eine niedrige Nilflut im Jahr 25.
- **Kontrolle:** Suche in den deutschen Glossen; Jahreszeitname ausgeschlossen
- **Skript:** events_check.py

### Ketten von Bedingungen (101.796 Sätze)

- **Ergebnis:** 2,7 % aller Sätze sind Bedingungssätze: Briefe 8,6 %, Medizin 4,5 %, Literatur 4,3 %, Pyramidentexte 1,3 %, Grabinschriften 0,1 %. Längste Folge aufeinanderfolgender Bedingungssätze: 8. In der Medizin stehen 80 Fälle nach dem Schema „Wenn du untersuchst“.
- **Kontrolle:** Erkennung über wenn, falls, sobald in der Übersetzung
- **Skript:** condition_chains.py

### Normierung des Wortlauts (je 25.000 Wörter pro Gruppe)

- **Ergebnis:** Anteil der Fünf-Wort-Folgen, die in einem anderen Text derselben Gruppe wiederkehren: Amarna 43,8 %, Grabinschriften 37,4 %, Ramessiden 29,2 %, Pyramidentexte 22,4 %, Totenbuch 9,5 %, Medizin 8,6 %, Literatur 6,7 %. Wörter für messen, wiegen, prüfen: in den Pyramidentexten 0 Treffer; „genau, richtig“ dort 11 je 100.000, der niedrigste Wert aller Gruppen.
- **Kontrolle:** gleiche Stichprobengröße, 5 Ziehungen
- **Skript:** standardization.py

### Ausschluss als Fragespiel (10 Hypothesen, 11 Tests)

- **Ergebnis:** Unsicherheit am Start 3,32 Bit. Der Koptisch-Test schließt vier Alternativen auf einmal aus (0,89 Bit). Sechs Tests genügen, um alle neun Alternativen zu widerlegen. Mit harter Regel bleibt „Sprache in bekannten Gattungen“ mit 0,99; kostet ein Widerspruch nur das halbe Gewicht und eine fehlende Vorhersage nichts, sinkt der Wert auf 0,25.
- **Kontrolle:** vier Annahmen zur Härte des Ausschlusses durchgerechnet
- **Skript:** elimination_game.py

### Themen ohne Bedeutungen (992 Texte, 10 Themen)

- **Ergebnis:** Eine Faktorzerlegung der Wortzählungen findet zehn Themen, die zu 78,1 % mit den Textgruppen der Bearbeiter übereinstimmen: Totenbuchsprüche, Himmelsaufstieg und Anrufungen der Pyramidentexte, Opferformel, Opferlisten, Rezepte, Lehren, Kriegsberichte, Königstitulatur, neuägyptische Briefe. Die Namen der Themen stammen erst aus den Glossen.
- **Kontrolle:** größte Gruppe allein: 28,0 %
- **Skript:** topics_nmf.py

### Feste Wortfolgen über die Zeit: Pyramidentexte und Totenbuch (1.929 Viererfolgen, die in den Pyramidentexten mindestens fünfmal stehen)

- **Ergebnis:** Wiederkehr in je 25.000 Wörtern: Totenbuch Neues Reich 2,4 %, Totenbuch spät 2,2 %, späte Totenliteratur 3,0 %; andere Gattungen 0,5 bis 1,5 %, Grabinschriften derselben Zeit 0,2 %. Im ganzen Totenbuch stehen 121 der 1.929 Folgen (6,3 %). Nur 14 von 510 Totenbuch-Texten teilen ganze Passagen mit einem Pyramidentext (bis 9 Wörter am Stück, etwa die Götterreihe von Atum bis Nephthys). Vom Neuen Reich zur Spätzeit wachsen die Sprüche: In 124 von 182 Textpaaren hat die spätere Fassung mehr Wörter zwischen den gemeinsamen Blöcken (9.325 gegen 8.510). Hinzu kommen vor allem der Titel „Osiris“ (261 gegen 58) und die Glosse „anders gesagt“ (79 gegen 8); die erste Person wird zur dritten (23 gegen 7), die Verneinung n zu nn (30 gegen 3).
- **Kontrolle:** Kriterien vorab in formula_chronology_prereg.txt. Zufallsniveau bei durchgewürfelter Wortstellung 0,12 %; zwei Hälften der Pyramidentexte untereinander 50,8 %. Vorzeichentest p = 0,000001; Paare innerhalb einer Epoche zeigen keine Richtung (182 zu 190, 45 zu 35, 46 zu 45). Bei Fünferfolgen liegt Amarna über dem Totenbuch, weil dort ein Opferritual Pyramidentexte zitiert. Wiederkehr mit einem ausgetauschten Wort liegt in allen Gattungen beim 1,3- bis 2,3-Fachen des Zufalls und trennt die Überlieferung nicht. Von den Pyramidentexten zum Totenbuch gibt es zu wenige Textpaare für eine Richtung.
- **Skript:** formula_chronology.py, formula_chronology_detail.py

### Wachsen die Sprüche von Pyramide zu Pyramide? (Pyramidentexte, sechs Pyramiden von Unas bis Neith, rund 150 Jahre)

- **Ergebnis:** Zuordnung über den Namen im Text: Unas 187 Texte, Teti 111, Pepi I. 493, Merenre 51, Pepi II. 239, Neith 254; 405 Texte ohne eindeutigen Namen bleiben außen vor. Fünf Nachbarschritte zusammen (208 Textpaare, 16.646 gemeinsame Wörter): 1.795 hinzugefügte gegen 1.867 weggelassene Wörter; die spätere Fassung hat in 62 Paaren mehr, in 63 weniger. Keine Richtung. Die Einzelschritte schwanken (Unas zu Teti 10 zu 3, Pepi I. zu Merenre 10 zu 22). Gerichtet sind nur kleine Änderungen: Der Name des Königs ersetzt das Pronomen „er, sein“ (51 gegen 16), das ältere pj wird zu pw (17 gegen 0), pw zu pn (15 gegen 2).
- **Kontrolle:** Kriterien vorab in pt_pyramids_prereg.txt. Vorzeichentest p = 1,0; Paarbildung von der älteren Pyramide aus: 69 zu 63 (p = 0,66); ohne die stark zerstörten Pyramiden von Pepi I. und Merenre: 38 zu 27 (p = 0,21). Königsnamen sind durch einen Platzhalter ersetzt, Doppelnamen zählen als ein Wort. Pepi I. und Pepi II. sind über den Doppelnamen getrennt (1.374 von 1.381 Fällen).
- **Skript:** pt_pyramids.py

### Sind die Königsnamen Namen von Personen oder von wiederkehrenden Zyklen? (9.339 Belege, 257 Namen)

- **Ergebnis:** Die Umgebung der Namen gleicht der von Privatpersonen, nicht der der Jahreszeiten. Eine Zahl im Umkreis von zwei Wörtern: Königsnamen 0,4 %, Personen 2,3 %, Jahreszeiten 84,4 %. Ein Verwandtschaftswort im Umkreis von drei Wörtern: 15,6 %, 17,0 %, 0,4 %. Lebensformel danach: 6,5 %, 7,2 %, 0,2 %. Ohne die Pyramidentexte: Titel davor 59,8 % (Personen 61,9 %). Korrektur: Die Verwandtschaftswerte enthalten den Königstitel „Sohn des Re“; ohne Titel sind es 6,1 % bei Königsnamen gegen 15,9 % bei Personen (ohne Pyramidentexte 2,9 % gegen 16,4 %). Wetter- und Flutwörter im Umkreis von fünf Wörtern: 39 von 9.339 Königsnamen (0,42 %), alle in den Pyramidentexten; bei Personen 4 von 15.713. Jahreszählungen unter einem Namen reichen von 1 bis 56 (59 Namen bei weiter Zuordnung über die Übersetzung „Regierungsjahr“, 28 bei strenger Zuordnung; nur ein Name erreicht 56). Die Texte allein trennen nicht zwischen Person und personifiziertem Namen; das leisten Belege außerhalb der Texte (Mumien, Erbgutanalyse von 2010). Jeder Name gehört in eine Epoche: 17 Namen mit mindestens 30 datierten Belegen, im Median 100 % in einer Epoche; die drei Jahreszeiten verteilen sich auf alle vier Epochen (höchstens 51 % in einer). Als Datierung nach einem Regierungsjahr stehen Königsnamen in 189 Belegen (2 %).
- **Kontrolle:** Kriterien vorab in kings_cycles_prereg.txt. Drei von vier Maßen näher an den Personen, ohne Pyramidentexte vier von vier. Niedrigster Epochenanteil bei Sesostris (73,5 %), dessen Name auch in späteren Abschriften steht. Der Test nutzt die Übersetzung der Nachbarwörter. Nachtest zum Einwand, auch Wettersysteme trügen Personennamen: Nach der dafür vorab gesetzten Regel ist diese Lesart aus den Texten nicht widerlegt; die Regel verglich Verhältnisse statt absoluter Anteile und war damit zu schwach.
- **Skript:** kings_cycles.py, kings_weather.py

### Königsnamen als Namen von Sternbildern

- **Ergebnis:** Kein Kriterium spricht dafür. Schreibung: 12 von 15 Sternnamen mit Hieroglyphen tragen das Sternzeichen N14, von 832 Königsnamen keiner. Außerhalb der Pyramidentexte steht ein Titel vor 59,8 % der Königsnamen und 1,2 % der Sternnamen, die Lebensformel folgt bei 21,1 % gegen 0 %; eine Jahresformel geht 84 Königsnamen voraus und keinem Sternnamen. Ein Sternname in fünf Wörtern Abstand steht nur in den Pyramidentexten (94 von 6.999 Königsnamen, sonst 0 von 2.340); dort naht der verstorbene König „als Stern“ (PT 610). Nach der festgelegten Regel widerlegt: Schreibung und Umgebung dagegen, Wiederkehr offen (3 von 3 Sternnamen in mehreren Epochen, 2 von 17 Königsnamen). Mit dem korrigierten Verwandtschaftsmaß steht das Umgebungskriterium 2:2; dann wäre das Urteil formal offen.
- **Kontrolle:** Vergleichsklasse sind die Sternnamen des Korpus selbst (Orion, Sothis, Großer Bär, Zirkumpolarsterne; 334 Belege, davon 80 außerhalb der Pyramidentexte). Personennamen tragen N14 in 0,1 %, Götternamen in 0,5 % der Fälle.
- **Skript:** stars_probe.py, kings_stars.py, kings_stars_prereg.txt

### Sternpassagen über ein Muster aus einer bekannten Sprache finden

- **Ergebnis:** Nach der Standardlesung gibt es 524 Sternsätze in 350 Texten (0,60 % der Sätze mit mindestens 3 Wörtern), 354 davon in den Pyramidentexten und 115 im Totenbuch. Die Begleiter von „Stern“ in der deutschen Bibel (Mond, Sonne, Himmel, Weise, Meer, Erde, Gott, Herr) stehen in 44,1 % der Sternsätze und in 13,7 % aller Sätze (3,2-fach). Als Suchmuster reichen sie nicht: Mindestens ein Begleiter markiert 11.968 Sätze, davon 231 Sternsätze (1,9 %); mindestens zwei markieren 1.357, davon 45 (3,3 %). Das Sternzeichen N14 trifft 45 von 53 Sternwörtern mit Hieroglyphen (84,9 %), aber nur 45 von 682 Wörtern mit N14 sind Sternwörter (6,6 %); die übrigen sind vor allem „preisen“, „Stunde“, „Unterwelt“, „Morgen“ und „Monat“.
- **Kontrolle:** Begleiter der Kontrollwörter: „Brot“ 0,2-fach, „Schwert“ 2,4-fach (rund 7 Sätze). Das vorab verlangte Doppelte der Kontrollen ist damit verfehlt. Der Weg über die Begleiter läuft durch die Standardübersetzung und ist nicht blind.
- **Skript:** stars_passages.py, stars_passages_prereg.txt

### Aufbau des Komplexes Königsname (Überblick, kein Test)

- **Ergebnis:** Außerhalb der Pyramidentexte 2.340 Belege, 256 Namen, 1.454 Sätze. Bis zu drei Wörter davor: „König von Ober- und Unterägypten“ 36 %, „Sohn des Re“ 19 %, „Horus“ 14 %, „Herr der Beiden Länder“ 13 %, „der von der Maat lebt“ 8 %. Danach: „geben“ 25 % und „leben“ 24 % (beschenkt mit Leben), „ewig“ 7 %. Im selben Satz: Titel 68 %, Verb 77 %, Göttername 27 % (Re 11 %, Amun-Re 4 %), Ortsname 12 %, Personenname 10 %, Zahl 9 %. In den Pyramidentexten 6.999 Belege, 8 Namen: davor „für“ 17 %, „Osiris“ 8 %; danach „dieser“ 22 %; im Satz „Gott“ 10 %, „Himmel“ 9 %, „Horusauge“ 5 %. Häufigste Dreiwortfolgen außerhalb der Pyramidentexte: Zahlenreihen 887, Opferformel 742, „er lebe ewig und immerdar“ 440.
- **Kontrolle:** Beschreibend; die Bedeutungen sind die Glossen der Herausgeber. Gezählt wurden 779.011 Wörter in 13.026 Texten und 16 Teilkorpora (Literatur 24,5 %, Pyramidentexte 14,4 %, Totenbuch 14,2 %, Grabinschriften 12,9 %).
- **Skript:** structure_overview.py

### Äußerer Anker: ägyptische Königsnamen in Keilschriftbriefen

- **Ergebnis:** Die Keilschriftdatei (CDLI, Stand 228da1b) enthält die Amarna-Briefe: 120 Zeilen auf 86 Tafeln nennen Ägypten (mi-is,-ri) oder einen der gesuchten Namen. EA 1, Zeile 2 bis 3: „ni-ib-mu-a-re-a, großer König, König von Ägypten, dein Bruder“; das entspricht dem Thronnamen Nb-mꜣꜥ.t-Rꜥw (Amenophis III.), der im ägyptischen Korpus bis Jahr 33 datiert. EA 9, Zeile 1: „an ni-ip-hu-ur-ri-ri-ia, König von Ägypten“. Andere Schrift und Sprache, unabhängig entziffert.
- **Kontrolle:** Nur gesichtet (Suche nach Schreibungen im Rohtext), kein vorab festgelegtes Kriterium. Die Namen sind nicht einzeln ausgezählt; der systematische Abgleich der Schreibungen gehört zum offenen Namen-Anker-Test.
- **Skript:** Suche mit awk in cdliatf_unblocked.atf; Befehl in 04_daten_holen.md des Projektpakets

## Zahlen

Zahlen zählen im Korpus Opfergaben, Tage und Dosierungen. Zahlsystem und Kalender lassen sich ohne Kenntnis der Bedeutungen aus den Daten ableiten.

### Zahlwörter im Korpus (789.633 Wörter)

- **Ergebnis:** 20.709 Zahlangaben, rund 98 % in Zahlzeichen, 435 ausgeschrieben. 81,5 % aller ganzen Zahlen sind 1 bis 4. Von 1.771 Brüchen sind 98,4 % die Halbierungsstufen 1/2 bis 1/64; 92 % stehen in medizinischen Rezepten. Alle 12 ausgeschriebenen Grundzahlwörter haben koptische Nachfolger.
- **Kontrolle:** Die Häufigkeit fällt mit n hoch −2,0 wie in heutigen Sprachen; eigene Spitze bei 4 (5,6-fach)
- **Skript:** `numvalues.py`, `numvalues2.py`, `mathvocab_eg.py`

### Platon als Vergleich (36 Werke, 561.555 Wörter)

- **Ergebnis:** Platon: 102-mal gerade/ungerade, 185 Verhältnis- und Vielfachenwörter, 139 Figurenwörter. Im ägyptischen Korpus dafür 0 Treffer; vorhanden sind zählen, summieren, verdoppeln, halbieren, messen. Brüche heißen in beiden Sprachen „Teile“.
- **Kontrolle:** Nomoi 819b nennt den ägyptischen Rechenunterricht als Vorbild
- **Skript:** `plato_numbers.py`, `plato_parts.py`

### Zahlsystem blind (733.431 Zeichen, 1.861 Zeichencodes)

- **Ergebnis:** Nur Z1 und V20 treten in neun verschiedenen Wiederholungslängen auf (1 bis 9), nie in 10. Rangfolge: V1 vor V20 (16 zu 0), V20 vor Z1 (122 zu 17). Die Regel 1 / 10 / 100 / 1000 trifft 97,1 % von 4.237 Zahlen; ein kleineres Zeichen vor einem größeren kommt 2-mal vor.
- **Kontrolle:** Römische Zahlen (1.259 Zahlen): Werte 1, 5, 10, 50, 100, 500 zu 100 % rekonstruiert; 12,6 % mit kleinerem Zeichen vor größerem
- **Skript:** `blind_numerals.py`, `blind_numerals_check.py`, `roman_control.py`

### Kalender blind (15.829 Zahlen mit gezähltem Wort)

- **Ergebnis:** Von 110 gezählten Wörtern sind genau zwei gleichmäßig begrenzt: Monat 1 bis 4 (406 Belege) und Tag 1 bis 29 (465 Belege). Die Kette Jahr, Monat, eine von drei Jahreszeiten, Tag steht 120-mal vollständig. 3 × 4 × 30 = 360.
- **Kontrolle:** Tag 30 und die 5 Zusatztage erscheinen fast nur als Wörter (34 und 12 Belege)
- **Skript:** `unit_radix.py`

### Mehrere Zahlenräume als Sichten (257 vollständige Daten)

- **Ergebnis:** Jahreszeit, Monat und Tag tragen 1,57 + 1,98 + 4,75 = 8,30 von 8,49 Bit; ihre Abhängigkeit liegt 0,12 Bit über Zufall. Bei Zählzahlen hängen Zehner und Einer zusammen: Der Anteil runder Zahlen steigt von 41 % (10 bis 19) auf 88 % (90 bis 99). Zeichen je Zahl: ägyptisch 2,49, römisch 2,81, Stellenwert 1,20, bei 3,08 Bit Inhalt.
- **Kontrolle:** Mischtest mit 2.000 Durchläufen
- **Skript:** views_information.py

### 2/n-Tabelle des Papyrus Rhind (50 Brüche, nicht im Korpus)

- **Ergebnis:** Alle 50 Zerlegungen stimmen exakt. Von 27.918 möglichen Zerlegungen (höchstens 4 Terme, Nenner unter 1000) trifft Greedy die Wahl der Schreiber in 5 Fällen, „wenigste Terme, dann kleinster größter Nenner“ in 25, die beste von 400 Regeln in 37; außerhalb der Stichprobe rund 65 %. Feste Muster: Vielfache von 3 in 17 von 17, Vielfache früherer Einträge in 7 von 9, gerader erster Nenner bei 19 von 19 großen Primzahlen. Für 2/101 existiert nur eine einzige Zerlegung.
- **Kontrolle:** Tabelle aus zwei Quellen abgeglichen und nachgerechnet
- **Skript:** rhind_2n.py, rhind_2n_b.py, rhind_2n_c.py

### Nullpunkte und Jahreszählung (254 Regierungsjahre)

- **Ergebnis:** Die Jahreszählung beginnt mit jedem König neu: Median 6, 67 % höchstens 10, Maximum 56. Ein Wort für Null oder Nullpunkt kommt in den Glossen nicht vor; Neujahr steht 426-mal, fast immer als Fest in Opferformeln.
- **Kontrolle:** Aus der Literatur: nfr als Grundlinie am Bau und als Nullsaldo in Abrechnungen
- **Skript:** Einzelabfragen

### Linear A: Bruchzeichen (1.722 Inschriften, 18 Zeichen)

- **Ergebnis:** Die Rangfolge aus Nachbarschaften ergibt dieselbe Kette wie die Literatur (J vor E vor F vor K vor L2). Von 30 Summenzeilen enthalten 5 Brüche, nur HT 104 geht glatt auf (J = 1/2). In meiner Nachkodierung der veröffentlichten harten Regeln bleiben von 3,14 Milliarden Wertbelegungen 349 Millionen: 3,2 von 31,6 Bit. Die veröffentlichte Lösung besteht alle Regeln. Zwei scheinbare Zusatzbedingungen (H vor K auf HT 34, A B B auf KH 86) halten der Prüfung am Kommentar nicht stand.
- **Kontrolle:** Corazza u. a. 2021: rund 3,8 Millionen Lösungen nach den harten Regeln, Entscheidung über Bewertungsfilter
- **Skript:** lineara_load.py, lineara_fractions.py, lineara_solve.py

### Blindprobe der Bruchwert-Methode an ägyptischen Brüchen (Werte verdeckt)

- **Ergebnis:** Rangfolge aus Nachbarschaften richtig und eindeutig (106 Paare größer vor kleiner, 2 umgekehrt). 2,72 Millionen Belegungen bestehen die harten Regeln, die wahre ist darunter. Mit den drei größten Werten als Prämisse setzt der kleinste gemeinsame Nenner die wahre Lösung auf Rang 1 von 3.537; das Kriterium „kleine Nenner“ wählt falsch (1/9, 1/10, 1/12). Häufigkeit folgt der Größe in Archiven (+1,00) und Briefen (+0,89), nicht in Rezepten (−0,90). Linear A: Unter 684.856 regelkonformen Zufallsbelegungen ist keine kohärenter als die veröffentlichte Lösung (die exakte Zählung findet 865, siehe Empfindlichkeitsprüfung); für H und A liegen 12 von rund 600 Paaren davor.
- **Kontrolle:** bekannte Werte als Prüfstein; Kriterien vorab festgelegt; zweites bekanntes System in der nächsten Zeile
- **Skript:** eg_fraction_seqs.py, blind_fraction_test.py

### Zweite Eichung an Keilschrift mit verdeckten Werten (Ur III, 70.980 Verwaltungstexte, 475.192 Zahlausdrücke; CDLI-Abzug vom 18.10.2021)

- **Ergebnis:** Ganze Zahlen: 11 von 12 Stufenfaktoren des Lehrbuchs richtig (6, 10, 5, 6, 10, 3 …). Als ein einziges Wertesystem gelesen stimmen nur 78,2 % von 433.593 Zahlen, weil Zehner und Einer im Zählsystem und im Hohlmaßsystem verschiedene Werte haben. Bruchzeichen 1/3, 1/2, 2/3, 5/6: Die harten Regeln der ägyptischen Probe schließen die wahre Lösung aus (14 Zeilen mit zwei benachbarten Bruchzeichen verschiedener Einheitenstufe unter 23.188 Belegen). Wahre Wertmenge unter 91.390 Mengen: kleinster gemeinsamer Nenner geteilter Rang 1 (5 Mengen), kleine Nenner 5 Mengen besser, ganzzahlige Verhältnisse 59.487 besser, Häufigkeit gegen Wert −0,80. Die Obergrenzenregel liefert die Wertmenge exakt nur für Mine und Schekel (20 + 10 + 10 + 10 + 10 = 60). Summenzeilen: Die Lehrbuchzuordnung ist der einzige Bestwert unter 2.193.360 Zuordnungen (259 von 277 Summen exakt, zweitbeste 239).
- **Kontrolle:** Kriterien vorab in cdli_prereg.txt. Summen ohne Bruchzeichen: 685 von 749 exakt; beide Hälften getrennt mit gleichem Ergebnis. Flächenbrüche 1/2 und 1/4 iku (Halbierungsreihe) bestehen alle Kriterien. Nicht vorab festgelegt: Auflösen eines Kreises in der Rangfolge; Ausweitung der Summenprüfung auf Hohlmaße (nur Gewichte: 19 Summen, 7 exakt). Die relative Schwelle 1/1000 fällt bei der Gegenprobe am ägyptischen Zeichenstrom durch.
- **Skript:** cdli_extract.py, cdli_blind.py, cdli_scores.py, cdli_sums.py, cdli_sums2.py, cdli_sums_R.py, cdli_checks.py, cap_r2_check.py, support_rule_check.py

### Linear A: Empfindlichkeit der veröffentlichten Bruchwerte gegen einzelne harte Regeln (18 Zeichenfolgen, 51 Einzelregeln)

- **Ergebnis:** Exakte Zählung. Kern (zehn Zeichen ohne H und A, 2.426.112 Belegungen): 466.176 bestehen alle Regeln, keine hat einen kleineren gemeinsamen Nenner als die veröffentlichte (120), 56 haben denselben. Allen 56 gemeinsam ist die L-Reihe 1/20, 1/30, 1/40, 1/60; offen bleiben K (1/10, 1/12, 1/15) sowie B und D. Streicht man eine einzelne Zeichenfolge, entstehen bessere Belegungen nur bei B B (Sparsamkeit) und K L2 (Rangfolge), je 4 Belege, je 2 bessere. Keine der 9 einfach belegten Folgen ist einzeln tragend; alle 9 zusammen gestrichen ergeben 5 bessere (K = 2/3 oder 5/6). Im Kern ändern 10 der 15 Folgen einzeln nichts; E B und JE B sichern dieselbe Schranke doppelt. Alle zwölf Zeichen: 865 von rund 358 Millionen regelkonformen Belegungen haben einen kleineren Nenner als 240 (849 mit 120), weil H = 1/16 den Nenner verdoppelt; 24.418 liegen gleichauf. Wörtlich gezählt schließt H K (HT 34) die veröffentlichte Lösung aus; E J (ZA 8) und J J (PH 9b) widersprechen schon den Prämissen.
- **Kontrolle:** Kriterien vorab in lineara_loo_prereg.txt; ganzzahlige Rechnung ohne Stichprobe (die Gesamtzahl ist inzwischen exakt nachgezählt: 358.786.594). Gegenprobe der Sparsamkeitsregel am Ägyptischen: 12 von 112 Zeichenfolgen (1/64 + 1/64) haben den Wert eines Einzelzeichens. Lesung von KH 86 als A A statt A B B: 473 statt 865 bessere. Nicht variiert: Prämissen J, E, F, die 36 Kandidatenwerte und die Teilungsreihe der L-Zeichen.
- **Skript:** lineara_compounds.py, lineara_loo.py, lineara_loo_detail.py, lineara_loo_joint.py, eg_economy_check.py

### Eichung der vier Bewertungsmaße aus Corazza u. a. 2021 (eigener Nachbau) an ägyptischen Brüchen und Keilschrift

- **Ergebnis:** Der Nachbau trifft drei im Aufsatz berichtete Zahlen auf fünf Stellen (G_Optimal 0,67094 und 0,71724; kleinster Wert des Häufigkeitsmaßes 0,00881 über alle 358.786.594 regelkonformen Belegungen). Lage der wahren Lösung unter den Kandidaten (bestanden = beste 1 %). Häufigkeit gegen Teiler: ägyptisch 0,004 % ohne Rezepte, 76,5 % mit allen Texten, 17,2 % nur Archive; Keilschrift 72,9 %. Gleiche Summen: trennt nicht (97 % gleichauf), in der Keilschrift nicht prüfbar. Typologie ohne die Werte des geprüften Systems: 12,6 % und 23,0 %. G_Optimal: ägyptisch 16,8 % (mit drei Vorgabewerten 37,1 %), Keilschrift 0,35 %. Gesamtverfahren: Die wahre ägyptische Lösung fällt mit allen Texten oder nur Archiven im Vorfilter heraus; ohne Rezepte übersteht sie ihn und steht danach auf Platz 760 von 4.550. Kein Maß besteht beide Systeme. Linear A, 56 gleich gute Kernbelegungen: Der veröffentlichte Kern steht bei G_Optimal und Typologie an der Spitze (je zusammen mit seinem Spiegelbild B 1/6, D 1/5), beim Häufigkeitsmaß liegen 36 davor.
- **Kontrolle:** Kriterien vorab in corazza_calib_prereg.txt. Die Typologieliste enthält die Werte beider Prüfsysteme (Zirkel); die bereinigte Fassung beruht auf meiner Annahme, dass 1/32 und 1/64 nur ägyptisch und 5/6 nur in der Keilschrift vorkommen. Zählweise bei gleichen Summen und der Umgang mit einem Faktor 0 im Produkt sind im Aufsatz nicht festgelegt; beide Lesarten gerechnet.
- **Skript:** corazza_measures_probe.py bis probe3.py, corazza_goptimal.py, corazza_freqdiv_scan.py, corazza_calib.py, corazza_lineara56.py

### Toleranz statt harter Schwellen: Linear A mit zulässigen Widersprüchen; Bestehensgrenze 98 % statt 99 %

- **Ergebnis:** Von 42 auswertbaren Belegen sicher gelesener Zeichenfolgen widersprechen zwei (E J, J J) jeder Belegung: Mehr als 95,2 % Übereinstimmung ist nicht erreichbar, die veröffentlichte Lösung kommt auf 92,9 %. Kern (38 Belege): Mit einem weiteren zugelassenen Widerspruch (92,1 %) hat weiterhin keine Belegung einen kleineren gemeinsamen Nenner; die Gleichstände steigen von 56 auf 142, davon 116 mit der L-Reihe 1/20, 1/30, 1/40, 1/60 und 26 mit 1/10, 1/15, 1/20, 1/30. Ab zwei weiteren (89,5 %) gewinnen Belegungen mit K = 5/6. Bestehensgrenze 98 %: Bei den vier Maßen der Veröffentlichung ändert sich nichts (wahre Lösung bei 12 bis 77 %). Das Kriterium kleine Nenner plus gemeinsamer Nenner bestünde erst ab 97 % (0,10 %, 2,5 %, 0,002 %); darunter steht der veröffentlichte Kern auf Rang 30 von 466.176, davor liegen Belegungen mit anderer L-Reihe und meist K = 1/9.
- **Kontrolle:** Exakte Zählung. Die Schwellen sind nachträglich gelockert und zählen deshalb schwächer als die vorab festgelegten Prüfungen.
- **Skript:** lineara_tolerance.py, lineara_simple_coherent.py

### Was ist zuerst belegt? Bruchzeichen und ihre Kombinationen nach Epoche (ägyptisch) und Fundzeit (Linear A)

- **Ergebnis:** Ägyptisch: Im Alten Reich stehen nur 1/2, 1/4 und 1/8 (65 Belege, dazu zweimal 1/12). 1/16, 1/32, 1/64 und die rʾ-Schreibungen erscheinen ab dem Mittleren Reich (1.206 Belege). Fünf spätere Kombinationen verlängern eine frühere um feinere Glieder, etwa 1/4 + 1/8 zu 1/4 + 1/8 + 1/32. Linear A: In den frühen Texten (44 datierte aus MM II–III, 38 undatierte aus Phaistos; 18 mit Brüchen) stehen L und Y, die später fehlen; A, L4, L6, W und X stehen nur in LM I. Frühe Zeichenfolgen wiederholen meist dasselbe Zeichen (9 von 11), in LM I sind es 10 von 41.
- **Kontrolle:** Exakter Test nach Fisher: p = 0,0009 mit allen Lesungen, 0,16 nur mit sicheren (4 von 6 gegen 10 von 36). Im ägyptischen Korpus fallen Epoche und Textsorte zusammen: Rezepte gibt es erst ab dem Mittleren Reich.
- **Skript:** chronology_first.py

### Jahreszahl 56 als Länge eines Zyklus

- **Ergebnis:** 218 Jahresformeln mit Zahl; 60 mit folgendem Königsnamen im selben Satz, 28 Namen. Die 56 kommt einmal vor, als höchste Zahl unter einem Namen (Horusname Ramses’ II.). Die übrigen Höchstwerte: 43, 34, 34, 34, 33, 14, 13, 12, 11; 18 von 28 Namen enden bei höchstens 10. Die Jahreszahlen 1 bis 12 stellen 153 der 218 Belege. In denselben Datierungen laufen die Monatszahlen von 1 bis 4 und die Tageszahlen bis 30, keine darüber. Gezählt werden Jahre, und jede Zählung hat ihre eigene Länge.
- **Kontrolle:** Deutbarkeit beliebiger Zahlen: Mit den Konstanten 7, 12, 27, 28, 29, 30 als Summe zweier oder als bis zu Achtfaches einer Konstante sind 33 von 100 Zahlen darstellbar, mit erlaubtem „+1 oder +2“ 64 von 100. Diese Auszählung veranschaulicht nur; ein Kriterium war dafür nicht vorab festgelegt.
- **Skript:** regnal_years.py

Die blinde Suche nach Zählzeichen liefert 8 Kandidaten; 5 sind Zahlzeichen, 3 nicht (Name der Nofretete, das Wort „Finger“, Körner als Deutzeichen). Für Maße wie Elle, Handbreit und Finger enthält das Korpus nur 4 bis 6 Ketten, zu wenig für eine Ableitung.

## Offene Schritte

Die 2/n-Tabelle ist geprüft (siehe Zahlen). Offen bleiben:

- [x] 2/n-Tabelle des Papyrus Rhind: Welche Regel erklärt die Zerlegungen der Schreiber (Greedy, kleinster größter Nenner, gerade Nenner)? Die Tabelle muss aus der Literatur geholt und geprüft werden.
- [ ] Euklid als drittes Korpus neben Platon: Wo entsteht das Vokabular für Verhältnis und Beweis?
- [ ] Häufigkeitsgesetz nach Epoche und Gattung: Bleiben der Exponent −2 und die Spitze bei 4 stabil?
- [ ] Namen-Anker-Test mit mindestens drei Ankern auf das Ägyptische anwenden.
- [ ] Linear A mit dem geeichten blinden Verfahren untersuchen.
- [x] Bewertungskriterien für Bruchwerte an Systemen mit bekannter Lösung eichen (ägyptische Brüche, römische Zahlen), dann auf Linear A anwenden.
- [x] Linear A: jede harte Regel einzeln weglassen und prüfen, ob die veröffentlichte Lösung unter dem kleinsten gemeinsamen Nenner vorn bleibt; zu jeder Regel die Zahl der Belege angeben.
- [x] Die vier Bewertungsmaße der Veröffentlichung zu Linear A (Corazza u. a. 2021) an ägyptischen Brüchen und Keilschrift eichen: Welches trennt die 56 gleich guten Kernbelegungen zuverlässig?
- [ ] Linear A: Hängen die Bruchzeichen an Warenarten? Prüfen, ob ein einziges Wertesystem für alle Waren gilt (in der Keilschrift haben dieselben Zeichen je nach Maßsystem verschiedene Werte).
- [x] Feste Wortfolgen in der Zeit: Welche Formeln der Pyramidentexte kehren im Totenbuch wieder, und sind sie dort verlängert? Kontrolle mit gleich großen Zufallsgruppen.
- [x] Zeitachse innerhalb der Pyramidentexte: Werden dieselben Sprüche von der ältesten zur jüngsten Pyramide länger? Voraussetzung: Zuordnung der Texte zu den Königen aus den Kontextdaten.
- [ ] Sprachuhr: Lassen sich Texte aus gerichteten Ersetzungen datieren (pj zu pw zu pn, n zu nn, =s zu =st)? Lernen an datierten Texten, Prüfen an zurückgehaltenen, Vergleich mit Burrows’ Delta.

Die Skripte liegen im Arbeitsbereich der Sitzung und lassen sich als Dateien ausgeben.
