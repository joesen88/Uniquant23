> Stand: Haupt-Tab des Projektdokuments, Revision 19 vom 12.11.2026. „Ich“ ist darin Claude. Die Zugriffsangaben („direkt geladen“, „gesperrt“, „manuell“) beschreiben Claudes Arbeitsumgebung, aus der nur GitHub erreichbar war; mit gewöhnlichem Netzzugang sind auch die dort gesperrten Quellen ladbar. Was tatsächlich verwendet wurde, steht in `04_daten_holen.md`.

# Hieroglyphen: Datenquellen für Klassifikations- und Entzifferungsexperimente

2026-11-12 · Joe

Direkt ladbar sind von hier aus rund 2,04 Mio. Zeichen-Token mit Standardlesung (AES und Ramses), die Zeichentabelle Unikemet mit Funktion und Lesung für über 4.200 Zeichen, 4.031 Glyphenfotos und 2.311 koptisch-ägyptische Etymologien. Hugging Face, Zenodo und die Projektportale sind gesperrt und brauchen einen manuellen Download. Für Klassifikationsversuche sind Zeichenfolge und Lesung am besten belegt; da ägyptische Hieroglyphen entziffert sind, taugt eine Alternativtheorie dort nur als Test gegen die Standardlesung.

Die Ergebnisse der Tests vom 12.11.2026 stehen im Tab Testergebnisse 12.11.2026.

## Entzifferungsstand: wo eine Alternativtheorie etwas entscheiden kann

Ägyptische Hieroglyphen sind seit 1822 entziffert; eine Alternativtheorie ist dort nur als Hypothesentest gegen die Standardlesung sinnvoll. Tatsächlich offen sind Kretische Hieroglyphen, Linear A, Proto-Elamisch, die Indus-Zeichen und Rongorongo. Beide Stränge laufen parallel: Ägyptisch als geeichter Testfall, Linear A als offener Fall mit direkt ladbarem Korpus.

### Ägyptisch (hieroglyphisch, hieratisch, demotisch)

- **Stand:** entziffert
- **Digitales Korpus:** [TLA](https://thesaurus-linguae-aegyptiae.de/info/text-corpus), [AES](https://github.com/simondschweitzer/aes)
- **Umfang:** TLA: rund 1,58 Mio. Lemma-Token; AES: 253.844 Wörter mit Hieroglyphen (gemessen)
- **Zugriff:** direkt (AES)

### Anatolische Hieroglyphen (Luwisch)

- **Stand:** entziffert
- **Digitales Korpus:** [eDiAna](https://www.ediana-remake.gwi.uni-muenchen.de/corpus), [ACLT](https://ancientworldonline.blogspot.com/2014/04/annotated-corpus-of-luwian-texts.html)
- **Umfang:** 942 Texte über alle anatolischen Teilkorpora; [583 Unicode-Zeichen](https://en.wikipedia.org/wiki/Anatolian_Hieroglyphs_(Unicode_block))
- **Zugriff:** Portal

### Maya-Hieroglyphen

- **Stand:** weitgehend entziffert
- **Digitales Korpus:** [TWKM Bonn](https://en.wikipedia.org/wiki/Text_Database_and_Dictionary_of_Classic_Mayan), [IDIAP Maya Codex](https://www.idiap.ch/dataset/maya-codex)
- **Umfang:** IDIAP: 174 Glyphen aus 72 Blöcken
- **Zugriff:** manuell

### Linear B (Kontrollfall)

- **Stand:** entziffert 1952
- **Digitales Korpus:** [NeuroDecipher](https://github.com/j-luo93/NeuroDecipher)
- **Umfang:** 919 Wortpaare Linear B–Griechisch (gemessen)
- **Zugriff:** direkt

### Kretische Hieroglyphen

- **Stand:** [unentziffert](https://en.wikipedia.org/wiki/Cretan_hieroglyphs)
- **Digitales Korpus:** CHIC, gedruckt 1996
- **Umfang:** [rund 200 Tondokumente, 136 Siegel, 16 sonstige](https://core-cms.cambridgecore.org/core/services/aop-cambridge-core/content/view/F6BAF70365CE3741F43487E1BAC43664/9781009490108int_1-12.pdf/introduction.pdf); 96 Syllabogramme
- **Zugriff:** kein offener Datensatz gefunden

### Linear A

- **Stand:** unentziffert
- **Digitales Korpus:** [lineara.xyz](https://github.com/mwenge/lineara.xyz), [SigLA](https://sigla.phis.me/paper.html)
- **Umfang:** 1.722 Einträge, 8.967 Zeichen-Token, 322 Zeichentypen (gemessen)
- **Zugriff:** direkt (lineara.xyz)

### Proto-Elamisch

- **Stand:** weitgehend unentziffert; [Lautwert-Vorschlag von 2022 unbestätigt](https://anoopsarkar.github.io/papers/pdf/IA57001.pdf)
- **Digitales Korpus:** [pe-decipher-toolkit](https://github.com/sfu-natlang/pe-decipher-toolkit), [pe-sign-value-data](https://github.com/sfu-natlang/pe-sign-value-data)
- **Umfang:** [rund 26.000 lesbare Token](https://aclweb.org/anthology/2022.emnlp-main.620.pdf) in 1.467 Texten
- **Zugriff:** direkt

### Indus-Zeichen

- **Stand:** unentziffert; Schriftcharakter umstritten
- **Digitales Korpus:** [ICIT](https://www.indus.epigraphica.de/)
- **Umfang:** [1.916 Inschriften ohne Dubletten, 11.110 Token, 584 Typen](https://arxiv.org/pdf/2604.17828)
- **Zugriff:** Portal mit Anmeldung

### Rongorongo

- **Stand:** unentziffert; Schriftcharakter umstritten
- **Digitales Korpus:** [rongopy](https://github.com/jgregoriods/rongopy)
- **Umfang:** Korpus als Pickle-Datei, nicht ausgewertet
- **Zugriff:** direkt

Innerhalb des Ägyptischen bleiben zwei echte Lücken: Die Schrift notiert keine Vokale, und 683 der 5.067 in Unicode kodierten Zeichen haben in Unikemet keine Funktionsangabe.

## Zugriff: was ich direkt laden kann

Aus meiner Arbeitsumgebung sind nur GitHub sowie die Paketregister PyPI und npm erreichbar. Alle anderen Datenhosts sind gesperrt: Ihre Seiten kann ich über die Websuche lesen, aber nicht als Datensatz herunterladen. Gemessen am 12.11.2026 mit je einem Abruf pro Host.

| Host | Ergebnis | Folge |
|---|---|---|
| GitHub (git) | erreichbar | Öffentliche Repositories direkt klonbar; Dateien in Git LFS nicht (403) |
| PyPI, npm | erreichbar | Pakete installierbar, z. B. aktuelle Unicode-Tabellen und Fonts |
| Hugging Face | gesperrt (403) | TLA-Datensätze nur über manuellen Download |
| Zenodo | gesperrt (403) | Ramses-Transliterationskorpus nur über manuellen Download |
| unicode.org | gesperrt (403) | Unikemet-Datei dort nicht ladbar; Ersatz siehe Zeicheninventare |
| Kaggle, Mendeley Data, GitLab | gesperrt (403) | Datensätze dort nur über manuellen Download |
| Projektportale: TLA, Thot Sign List, St Andrews | gesperrt (403) | nur Einzelseiten über die Websuche lesbar |

Für gesperrte Quellen gibt es zwei Wege: die Datei herunterladen und im Chat anhängen, oder einen Spiegel auf GitHub nutzen, wo einer existiert.

## Zeicheninventare und Kodierungen

Die Standardlesung liegt maschinenlesbar vor: Unikemet gibt für 4.384 der 5.067 kodierten Hieroglyphen eine Funktion und für 4.218 eine Lesung an. Diese Tabelle ist die Referenzabbildung, gegen die jede Alternativtheorie antritt.

### [Unikemet 18.0.0](https://github.com/unicode-org/unicodetools/blob/main/unicodetools/data/ucd/18.0.0/Unikemet.txt), beschrieben in [UAX #57](https://www.unicode.org/reports/tr57/)

- **Inhalt:** Je Codepunkt: Katalognummer, Bildbeschreibung, Funktion (Phonemogramm, Logogramm, Klassifikator), Lesung, Konkordanz zu JSesh, Hieroglyphica, IFAO
- **Umfang:** 5.067 Zeichen: 1.072 im Basisblock, 3.995 in Extended-A; 843 Einträge als Phonemogramm (gemessen)
- **Zugriff:** direkt
- **Lizenz:** Unicode-Lizenz

### [JSesh](https://github.com/rosmord/jsesh), Datei signs_description.xml

- **Inhalt:** Zeichenliste mit Lesungen, Formmerkmalen, Varianten und enthaltenen Teilzeichen; dazu Vektorglyphen
- **Umfang:** 6.800 Zeichen, 2.630 Lesungen, 14.702 Formmerkmale, 6.961 SVG-Glyphen (gemessen)
- **Zugriff:** direkt
- **Lizenz:** Zeichenliste CC BY, Code CeCILL-C

### [NewGardiner](https://github.com/nederhof/newgardiner)

- **Inhalt:** TrueType- und OpenType-Font für Basisliste und Kernzeichen der erweiterten Liste; Unikemet-Tabellen
- **Umfang:** 1.071 Basiszeichen plus die meisten der 3.995 erweiterten
- **Zugriff:** direkt
- **Lizenz:** SIL OFL 1.1

### [Thot Sign List](https://thotsignlist.org/About)

- **Inhalt:** Zeichen, Klassen (Varianten), Funktionen und belegte Token mit Quellenangabe
- **Umfang:** online 1.203 Zeichen, 4.842 Funktionen, 21.834 Token; Token-Bilder nur für registrierte Nutzer
- **Zugriff:** nur Einzelseiten
- **Lizenz:** auf der Seite nicht genannt

Für Python: Die Standardbibliothek hier kennt nur Unicode 15.1, also nicht Extended-A; `unicodedata2` 18.0.0 und `hieropy` 0.1.10 liegen auf PyPI, ein Noto-Font für den Basisblock auf npm. Die Korpora unten kodieren Zeichen als Gardiner-Nummern nach dem Manuel de Codage, AES zusätzlich in Unicode.

## Textkorpora

Direkt ladbar sind zwei Korpora mit zusammen rund 2,04 Mio. Zeichen-Token: AES für alle Sprachstufen und der Ramses-Trainingssatz für das Neuägyptische. Beide verbinden Zeichenfolgen mit der Transliteration der Standardlesung.

### [AES – Ancient Egyptian Sentences](https://github.com/simondschweitzer/aes)

- **Ebenen:** Hieroglyphen (Gardiner-Code und Unicode), Transliteration, Lemma, Wortart, deutsche Übersetzung, Datierung, Fundort
- **Umfang:** 101.796 Sätze, 13.026 Texte, 815.026 Wörter, davon 253.844 mit Hieroglyphen; 733.431 Zeichen-Token, rund 1.860 Zeichentypen (gemessen)
- **Zugriff:** direkt geladen
- **Lizenz:** CC BY-SA 4.0

### Ramses-Trainingssatz in [MaReTE TranslitModels](https://github.com/MaReTEgyptologists/TranslitModels)

- **Ebenen:** Neuägyptisch: Zeichenfolgen (Gardiner-Code) mit Wortgrenzen, Transliteration, Lücken markiert
- **Umfang:** 66.693 Zeilen, 518.486 Wörter, 1.310.992 Zeichen-Token, 1.109 Zeichentypen (gemessen)
- **Zugriff:** direkt geladen
- **Lizenz:** CC BY 4.0

### [ORAEC Rohdaten](https://github.com/oraec/corpus_raw_data)

- **Ebenen:** AES-Texte textweise als JSON mit Metadaten; Konkordanzen zu Trismegistos, Wikidata, Karnak
- **Umfang:** 13.026 Textdateien
- **Zugriff:** direkt
- **Lizenz:** CC BY-SA 4.0, Konkordanzen teils CC0

### [AED-TEI](https://github.com/simondschweitzer/aed-tei)

- **Ebenen:** TEI-Fassung desselben TLA-Auszugs von 2018; Wörterbuch mit über 30.000 Einträgen
- **Umfang:** über 11.000 Texte, 55.804 Dateien
- **Zugriff:** direkt
- **Lizenz:** CC BY-SA 4.0

### [UD Egyptian/Pre-Coptic](https://github.com/UniversalDependencies/UD_Egyptian-UJaen)

- **Ebenen:** Dependenzbaumbank in Transkription, ohne Hieroglyphen
- **Umfang:** 3.764 Sätze, 40.821 Token
- **Zugriff:** direkt
- **Lizenz:** CC BY-SA 4.0

### [TLA Earlier Egyptian v18 premium](https://huggingface.co/datasets/thesaurus-linguae-aegyptiae/tla-Earlier_Egyptian_original-v18-premium)

- **Ebenen:** Hieroglyphen in Unicode, Transliteration, Lemmatisierung, Wortart, Glossierung, Übersetzung, Datierung
- **Umfang:** 12.773 von 55.026 Sätzen: unzerstört, sicher gelesen, voll lemmatisiert
- **Zugriff:** manuell
- **Lizenz:** CC BY-SA 4.0

### [TLA Late Egyptian v19 premium](https://huggingface.co/datasets/thesaurus-linguae-aegyptiae/tla-late_egyptian-v19-premium)

- **Ebenen:** gleiche Felder
- **Umfang:** rund 3.600 Sätze
- **Zugriff:** manuell
- **Lizenz:** CC BY-SA 4.0

### [TLA Demotic v18 premium](https://huggingface.co/datasets/thesaurus-linguae-aegyptiae/tla-demotic-v18-premium/tree/main)

- **Ebenen:** Demotisch, Übersetzung und Token-Annotation
- **Umfang:** Größenklasse 10.000 bis 100.000 Sätze, 7,3 MB
- **Zugriff:** manuell
- **Lizenz:** CC BY-SA 4.0

### [Ramses, Originalablage](https://zenodo.org/records/4954597)

- **Ebenen:** Datenkorpus, Software und trainiertes Netz zur neuägyptischen Transliteration
- **Umfang:** Zip 9,4 MB, Netz 106,2 MB
- **Zugriff:** manuell
- **Lizenz:** CC BY 4.0

### [St Andrews corpus](https://lindat.mff.cuni.cz/repository/items/be36677f-ab98-49a3-ba54-3dc468e92fcc)

- **Ebenen:** Hieroglyphen, Transliteration, Übersetzung; [Papyrus Westcar](https://mjn.host.cs.st-andrews.ac.uk/egyptian/texts/corpus/pdf/Westcar.pdf) mit orthographischer Annotation
- **Umfang:** Umfang nicht geprüft
- **Zugriff:** manuell
- **Lizenz:** nicht geprüft

AES kodiert wortweise und nur vollständig erhaltene Schreibungen: Die Zeichenfolge innerhalb eines Wortes ist verlässlich, die Abfolge über Wortgrenzen nicht immer ([ORAEC](https://oraec.github.io/2022/10/14/four-challenges-when-converting-aes.html)). Der Hugging-Face-Datensatz [bbaw_egyptian](https://huggingface.co/datasets/phiwi/bbaw_egyptian/blob/main/README.md) und die Trainingsdaten des [Hieroglyphic Transformer](https://github.com/mattia-decao/hiero-transformer) stammen aus demselben TLA-Auszug von 2018 und bringen keine weiteren Texte. Das TLA selbst führt intern rund 1,58 Mio. Lemma-Token, veröffentlicht aber nur frei lizenzierte Texte.

## Bilddatensätze

Echte Glyphenfotos sind der Engpass: Der einzige etablierte offene Satz hat 4.210 Bilder in 171 Klassen, bei über 5.000 kodierten Zeichen. Größere Klassenzahlen sind nur über gerenderte Glyphen erreichbar.

| Quelle | Inhalt | Umfang | Zugriff |
|---|---|---|---|
| [GlyphDataset](https://github.com/morrisfranken/glyphreader) von Franken und van Gemert, 2013 | Fotos aus der Unas-Pyramide, je Zeichen ausgeschnitten und nach Gardiner etikettiert, mit Bildpositionen, Texten und Lexikon | 4.210 Bilder, 171 Klassen, 179 Bilder ohne Klasse | Original-Zip von hier nicht erreichbar; Spiegel auf [Hugging Face](https://huggingface.co/datasets/HamdiJr/Egyptian_hieroglyphs) manuell |
| Aufbereitete Fassung im Repository [ancient-egyptian-hieroglyphs-classification](https://github.com/KashiwaByte/ancient-egyptian-hieroglyphs-classification) | dieselben Bilder ohne die unklassifizierten, nach Klasse sortiert, mit Train-Test-Teilung | 4.031 PNG in 171 Klassen, 10,2 MB (gemessen) | direkt geladen |
| [GlyphNet-PyTorch](https://github.com/alexeyev/glyphnet-pytorch) | Nachbau des GlyphNet-Klassifikators auf diesem Datensatz | Code | direkt |
| JSesh-Glyphen und NewGardiner-Font, siehe Zeicheninventare | Vektorformen zum Rendern synthetischer Trainingsbilder | 6.961 SVG-Glyphen | direkt |
| [AKU-PAL](https://aku-pal.uni-mainz.de) | Hieratische Zeichenformen als Faksimile oder Fotoausschnitt mit Metadaten | [über 1.000 Grapheme](https://en.aku.uni-mainz.de/project/) | Portal |
| [Tabin 2023](https://aku.uni-mainz.de/hieratic-studies-online/) | Einzelne hieratische Zeichen mit OCR-Programm, quelloffen | 13.134 Zeichen | manuell |
| [Handgezeichneter Datensatz, IEEE 2024](https://ieeexplore.ieee.org/document/10486368) | Handgezeichnete Hieroglyphen nach Gardiner | 59.514 Bilder, 763 Zeichen | Download nicht geprüft |
| [HieroGlyphTranslator 2025](https://arxiv.org/pdf/2512.03817) | Erweiterung des GlyphDataset um weitere Klassen | 5.430 Bilder, 291 Klassen | Download nicht geprüft |

## Externe Anker

Unabhängige Prüfdaten entscheiden über jede Lesung: Koptisch ist alphabetisch mit Vokalen überliefert und über 2.311 Etymologie-Einträge direkt mit ägyptischen Lemmata verknüpft. Eine Lesetheorie muss zu diesen Formen regelmäßige Lautentsprechungen liefern.

| Anker | Quelle | Inhalt | Umfang | Zugriff |
|---|---|---|---|---|
| Koptisch zu Ägyptisch | [KELLIA dictionary](https://github.com/KELLIA/dictionary), Datei egyptian_etymologies.tab | Koptisches Lemma mit TLA-Nummer und Form des hieroglyphisch-ägyptischen und des demotischen Vorläufers, Bedeutung englisch und deutsch | 2.311 Einträge: 1.941 mit hieroglyphisch-ägyptischem, 1.844 mit demotischem Lemma (gemessen) | direkt geladen |
| Koptisches Lexikon | [Comprehensive Coptic Lexicon v1.2](https://blog.copticscriptorium.org/2020/10/01/comprehensive-coptic-lexicon-v1-2/) | TEI-XML mit ägyptisch-koptischen und griechisch-koptischen Einträgen | 11.263 Einträge, 31.847 Formen | manuell, [CC BY-SA 4.0](https://coptic-dictionary.org/about.py) |
| Koptische Texte | [Coptic SCRIPTORIUM corpora](https://github.com/CopticScriptorium/corpora) | Annotierte Texte in CoNLL-U, TEI XML und weiteren Formaten; Grundlage für ein Sprachmodell der Tochtersprache | 5.561 Dateien | direkt |
| Bilingue | [Digital Rosetta Stone](https://rosetta-stone.dh.uni-leipzig.de/rs/the-digital-rosetta-stone) | Alignment der hieroglyphischen, demotischen und griechischen Fassung, dazu Treebanks | ein Dekret | Portal; das [GitHub-Repository](https://github.com/digitalepigraphy/RosettaStone) enthält nur Foto, Tiefenkarte und 3D-Modell |
| Eigennamen | AES, Feld pos = entity_name | Götter-, Königs-, Personen- und Ortsnamen mit Schreibung und Lemma | 59.927 Wort-Token (gemessen) | direkt geladen |
| Textkonkordanz | [ORAEC Rohdaten](https://github.com/oraec/corpus_raw_data), Datei mapping_oraec_trismegistos.csv | Zuordnung der Texte zu Trismegistos-Nummern | nicht ausgewertet | direkt |

In der Namensliste des TLA-Auszugs von 2018 mit 11.396 Einträgen steht kein Text mit Rosette oder Kanopus im Titel. Der hieroglyphische Text der Bilingue muss also aus einem Portal kommen.

## Vergleichs- und Kontrolldaten

Ohne Kontrollkorpora ist kein Klassifikationsergebnis deutbar: Nach Sproat trennt keines der früher vorgeschlagenen Entropiemaße Schrift verlässlich von nichtsprachlichen Zeichensystemen. Jedes Experiment braucht deshalb einen Fall mit bekannter Lösung und einen ohne Sprache.

### Negativkontrolle

- **Quelle:** [Sproat 2014](https://research.google/pubs/a-statistical-comparison-of-written-language-and-nonlinguistic-symbol-systems/)
- **Inhalt:** Sieben nichtsprachliche und vierzehn sprachliche Korpora, darunter Kudurrus, Totempfähle und Wetter-Icons
- **Zugriff:** Ablageort der Korpora nicht gefunden

### Referenzwerte

- **Quelle:** [Indus-Scorecard 2026](https://arxiv.org/pdf/2604.17828)
- **Inhalt:** Kennzahlen für acht Zeichensysteme: Inventar, mittlere Länge, Hapax-Anteil, bedingte Entropie
- **Zugriff:** lesbar

### Positivkontrolle

- **Quelle:** [NeuroDecipher](https://github.com/j-luo93/NeuroDecipher)
- **Inhalt:** Kognatenlisten Linear B–Griechisch mit 919 Paaren und Ugaritisch–Hebräisch mit 43.951 Zeilen; das Verfahren trifft [67,3 % der Linear-B-Kognaten](https://arxiv.org/pdf/1906.06718)
- **Zugriff:** direkt geladen

### Unsegmentierte Schrift

- **Quelle:** [DecipherUnsegmented](https://github.com/j-luo93/DecipherUnsegmented)
- **Inhalt:** Daten und Code zu Iberisch und Gotisch
- **Zugriff:** direkt

### Frühe Zeichenbilder

- **Quelle:** [proto-cuneiform_signs](https://github.com/cdli-gh/proto-cuneiform_signs)
- **Inhalt:** 2.089 Zeichenbilder der Proto-Keilschrift, CC BY
- **Zugriff:** direkt

### Keilschrift gesamt

- **Quelle:** [CDLI-Datenabzug](https://github.com/cdli-gh/data)
- **Inhalt:** Katalog und Transliterationen, Stand August 2022
- **Zugriff:** nicht ladbar: Git LFS ist gesperrt

### Klassifikatoren

- **Quelle:** [iClassifier](https://www.arxiv.org/pdf/2407.00475)
- **Inhalt:** Wortformen mit markierten semantischen und phonetischen Klassifikatoren, darunter Sargtexte
- **Zugriff:** Portal

### Zeichenfunktions-Modell

- **Quelle:** [Nederhof und Rahman 2017](https://doi.org/10.15398/jlm.v5i1.150)
- **Inhalt:** Probabilistisches Modell: Zeichenfunktionen erzeugen zugleich Zeichenfolge und Phonemfolge
- **Zugriff:** lesbar

### Methodenüberblick

- **Quelle:** [Sommerschield u. a. 2023](https://doi.org/10.1162/coli_a_00481), [Ägäis-Überblick 2024](https://aclanthology.org/2024.cl-2.7.pdf)
- **Inhalt:** Aufgaben von Digitalisierung bis Entzifferung; Korpora und Verfahren für ägäische Schriften
- **Zugriff:** lesbar

## Zwei Schichten: Schriftsammlung und aktuelle Deutung

Beide lassen sich sauber trennen: Die Schriftsammlung enthält nur, welche Zeichen in welcher Reihenfolge auf welchem Objekt stehen. Alles, was aus der Standardlesung folgt, liegt in einer zweiten Schicht und hängt allein über Kennungen daran. Die geladenen Korpora sind bereits so geteilt.

| Schicht | Enthält | Felder und Quelle | Umfang (gemessen) |
|---|---|---|---|
| Schriftsammlung | Zeichen und ihre Reihenfolge je Objektzeile | AES: Zeichencodes, Unicode-Zeichen, Zeilenangabe; Ramses: Zeichenfolge je Zeile | AES: 28.520 Zeilen mit Zeichen, davon 18.386 lückenlos, 733.431 Zeichen-Token; Ramses: 66.693 Zeilen, 1.310.992 Zeichen-Token |
| Zeichenform | Wie ein Zeichen aussieht | JSesh: Glyphen und Formmerkmale; Unikemet: Bildbeschreibung; GlyphDataset: Fotos | 6.961 Glyphen, 14.702 Formmerkmale, 4.395 Beschreibungen, 4.031 Fotos |
| Kontext | Objekt und Herkunft | AES: Teilkorpus, Datierung, Fundort | 13.026 Texte |
| Aktuelle Deutung | Zeichenfunktion und Lesung, Transliteration, Lemma, Wortart, Übersetzung | Unikemet: Funktion und Lesung; AES: Transliteration, Lemma, Grammatik, Wort- und Satzübersetzung; Ramses: Transliteration | AES: 789.633 Wörter, 101.796 Sätze; Ramses: 66.693 Zeilen |

An drei Stellen steckt die Deutung trotzdem schon in der Schriftsammlung:

1. Wortgrenzen: AES und Ramses ordnen Zeichen Wörtern zu, und diese Einteilung folgt der Standardlesung. Die Schriftschicht führt sie als Gruppierung mit, die sich weglassen lässt; theoriefreie Einheit ist die Objektzeile.
2. Zeichenidentität: Der Gardiner-Code ist bereits eine Normalisierung, bei hieratischen Vorlagen eine [Umschrift in Hieroglyphen](https://thesaurus-linguae-aegyptiae.de/info/text-corpus). Wirklich roh sind nur Fotos und Faksimiles.
3. Lücken: AES kodiert nur vollständig erhaltene Schreibungen, deshalb sind nur 18.386 von 28.520 Zeilen lückenlos. Ergänzungen der Bearbeiter stehen bis auf 93 eckig geklammerte Wörter nur in der Deutungsschicht.

Für die Experimente heißt das: Gelernt wird auf der Schriftsammlung; die Deutung dient als Etikett oder zur Auswertung und lässt sich gegen eine andere austauschen.

## Klassifikationsexperimente

Jedes Experiment bildet eine Repräsentationsebene auf eine andere ab; überwacht trainierbar ist es nur dort, wo beide Ebenen im selben Datensatz belegt sind. Am besten belegt sind Zeichenfolge und Lesung, am schlechtesten das Bild.

[eingebettetes Element]

Hervorgehoben ist, was unabhängig von jeder Lesung vorliegt. An diesen Ebenen und am Koptischen muss sich eine Alternativtheorie messen, denn Funktion, Lesung, Lemma und Übersetzung der Korpora stammen bereits aus der Standardlesung.

| Experiment | Frage | Daten | Verfahren | Kontrolle |
|---|---|---|---|---|
| E1 Schrifttyp | Verrät die Verteilung der Zeichen den Schrifttyp? | Zeichenfolgen aus AES, Ramses, Linear A, Linear B, Proto-Elamisch | Kennzahlen bei gleicher Stichprobengröße: Inventar, Abdeckungskurve, Entropien, Wiederholungen; darauf ein Klassifikator | Linear B als bekannter Fall, nichtsprachliche Korpora als Gegenklasse |
| E2 Zeichenfunktion | Lassen sich Phonogramme, Logogramme und Klassifikatoren ohne Lesung trennen? | Wortschreibungen aus AES; Etiketten aus Unikemet nur zur Auswertung | Merkmale je Zeichen: Position im Wort, Anteil am Wortende, Kontextentropie; Clustering oder HMM | Zeichen innerhalb der Wörter zufällig umordnen |
| E3 Lesung | Sagt eine Zeichen-Wert-Tabelle die Transliteration ungesehener Wörter vorher? | 772.330 Wortpaare aus AES und Ramses; Unikemet als Standardtabelle, die Alternative als zweite Tabelle | Alignment- oder Transduktormodell; Kreuzentropie je Wort auf zurückgehaltenen Texten | dieselbe Tabelle mit vertauschten Zeichenwerten |
| E4 Koptischer Anker | Ergeben die Lesungen regelmäßige Lautentsprechungen zum Koptischen? | 1.941 Etymologie-Paare; Lemmaformen aus AES | Korrespondenzmodell, kreuzvalidiert: koptische Form aus der Lesung vorhersagen | Paarzuordnung permutieren |
| E5 Bild zu Zeichen | Wie weit trägt ein Bildklassifikator bei wenigen Fotos je Klasse? | 4.031 Fotos in 171 Klassen; gerenderte JSesh-Glyphen | Vortraining auf Renderings, Feinabstimmung auf Fotos | Teilung nach Fototafel statt zufällig |
| Übertrag | Was liefern E1 und E2 auf einer offenen Schrift? | Linear A, Proto-Elamisch | dieselben Verfahren unverändert | Eichung am verkleinerten ägyptischen Korpus und an der Linear-B-Wortliste mit 1.344 Wörtern |

Ausgangswerte aus den geladenen Daten: 90 % der Zeichen-Token decken in AES 140 Zeichentypen ab, im Ramses-Satz 109, in Linear A 72.

## Mathematischer Rahmen: Entzifferung als Modellselektion

Eine Lesetheorie wird prüfbar, sobald man sie als Wahrscheinlichkeitsmodell über Zeichenfolgen schreibt. Dann entscheidet die Kodelänge ungesehener Texte, nicht die Plausibilität einzelner Lesungen.

**Theorie als Modell.** Eine Theorie T besteht aus einem Sprachmodell der Zielsprache und einer Schreibabbildung φ von Sprachformen auf Zeichenfolgen. Die Wahrscheinlichkeit einer Zeichenfolge c ist die Summe über alle Sprachformen w, die sie erzeugen können:

```
p_T(c) = \sum_{w} p_L(w)\, p_\varphi(c \mid w)
```

**Vergleichsgröße.** Zwei Theorien vergleicht man über die Beschreibungslänge: Bits für die Theorie selbst plus Bits für das Korpus unter der Theorie. Jede Sonderregel und jede Ad-hoc-Lesung kostet Bits in L(T). Praktisch ersetzt man L(T) durch die Kreuzentropie auf Texten, die beim Aufstellen der Theorie nicht benutzt wurden.

```
\mathrm{DL}(T) = L(T) + \sum_{i=1}^{N} -\log_2 p_T(c_i), \qquad \Delta = \mathrm{DL}(T_1) - \mathrm{DL}(T_0)
```

**Nullmodell.** Untergrenze ist ein reines Zeichenmodell ohne Lesung. Gemessen, ohne Trennung von Trainings- und Testtext: in AES 6,63 bit je Zeichen als Unigramm und 5,16 bit bedingt auf das Vorgängerzeichen, im Ramses-Satz 6,41 und 4,78 bit. Eine Lesetheorie ist informativ, wenn sie diese Werte auf ungesehenem Text unterbietet, und zwar deutlich stärker als dieselbe Theorie mit zufällig vertauschten Zeichenwerten.

**Eindeutigkeit.** Shannons Unizitätsdistanz schätzt, ab welcher Textmenge nur noch ein Schlüssel passt: Schlüsselentropie geteilt durch die Redundanz der Zielsprache je Zeichen.

```
U = \frac{H(K)}{D}, \qquad D = \log_2 |A| - H_L
```

Für eine einfache Substitution über 26 Buchstaben ist H(K) = log2 26! ≈ 88,4 bit; mit D ≈ 3,2 bit je Buchstabe im Englischen folgt U ≈ 28 Buchstaben. Die Formel setzt ein bekanntes Sprachmodell voraus; bei unbekannter Sprache, Mehrdeutigkeit und Logogrammen liegt der Bedarf weit höher. Der Maßstab bleibt: 2,04 Mio. Zeichen-Token bei rund 1.860 Zeichentypen überbestimmen jede Lesung des Ägyptischen, während Linear A mit 8.967 Token bei 322 Typen wenig entscheiden kann.

**Vier Tests, die jede Theorie auf denselben Daten bestehen muss.**

1. Vorhersage: geringere Kreuzentropie als das Nullmodell auf zurückgehaltenen Texten. Geteilt wird nach Text, nicht nach Satz, damit Formeln nicht in beide Teile fallen.
2. Permutationstest: Der Abstand zur Theorie mit vertauschten Zeichenwerten ist die Teststatistik; der p-Wert ergibt sich aus der Verteilung über viele Permutationen.
3. Variantenkonsistenz: Verschiedene Schreibungen desselben Lemmas müssen dieselbe Lesung ergeben. AES liefert 11.031 Lemmata mit im Mittel 4,4 Schreibungen. Formal bilden die Varianten Äquivalenzklassen von Zeichenfolgen, und eine zulässige Lesung muss auf jeder Klasse konstant sein.
4. Externe Anker: Die Lesungen müssen zu den koptischen Formen der 1.941 Etymologie-Paare regelmäßige Lautentsprechungen ergeben, geprüft durch Kreuzvalidierung eines Korrespondenzmodells.

Zu erwarten ist, dass die Standardlesung alle vier Tests mit großem Abstand besteht. Der Ertrag einer Alternativtheorie im Ägyptischen ist deshalb vor allem die geeichte Testbatterie, die sich unverändert auf Linear A oder Proto-Elamisch anwenden lässt.

## Reihenfolge

Beide Stränge laufen parallel auf demselben Code: Ägyptisch liefert die Eichung, Linear A den offenen Fall. Jede Zeile ist ein Schritt, der in beiden Spalten gleichzeitig läuft.

### 1 Daten

- **Ägyptisch: geeichter Testfall:** AES und Ramses auf einen Gardiner-Zeichensatz bringen, über die JSesh-Nummer mit Unikemet verbinden, Teilung nach Text festlegen
- **Linear A: offener Fall:** Zeichenfolgen je Wort aus lineara.xyz ziehen; Silbenzeichen, Logogramme und Zahlzeichen trennen

### 2 E1 Kennzahlen

- **Ägyptisch: geeichter Testfall:** Kennzahlen auf vielen Stichproben von 8.967 Zeichen-Token rechnen, der Größe des Linear-A-Korpus; das ergibt die Streuung jeder Kennzahl bei bekanntem Schrifttyp
- **Linear A: offener Fall:** dieselben Kennzahlen auf dem ganzen Korpus, eingeordnet gegen diese Streuung

### 3 E2 Zeichenfunktion

- **Ägyptisch: geeichter Testfall:** Clustering gegen die Unikemet-Funktionen auswerten, zusätzlich auf 1.281 Wort-Token verkleinert, um die Trennschärfe bei dieser Datenmenge zu kennen
- **Linear A: offener Fall:** dasselbe Verfahren auf den 1.281 mehrzeichigen Wort-Token; Abgleich mit der üblichen Einteilung in Silbenzeichen und Logogramme

### 4 E3 und E4 Lesung

- **Ägyptisch: geeichter Testfall:** Standardtabelle gegen das Permutations-Nullmodell, danach die Alternativtheorie als zweite Tabelle; Koptisch als Anker
- **Linear A: offener Fall:** nur die Tests 1 bis 3; ein externer Anker fehlt

Die Grenze des Linear-A-Strangs ist die Datenmenge: 931 verschiedene mehrzeichige Wörter, davon 782 nur einmal belegt (gemessen).

## Quellen

Angaben mit dem Vermerk „gemessen“ stammen aus eigenen Auszählungen der geladenen Repositories am 12.11.2026; die Repositories sind in den Tabellen verlinkt. Weitere herangezogene Seiten:

- [TLA Text Corpus](https://thesaurus-linguae-aegyptiae.de/info/text-corpus): Umfang des TLA
- [TLA Earlier Egyptian v18 premium](https://huggingface.co/datasets/thesaurus-linguae-aegyptiae/tla-Earlier_Egyptian_original-v18-premium), [Late Egyptian v19](https://huggingface.co/datasets/thesaurus-linguae-aegyptiae/tla-late_egyptian-v19-premium), [Demotic v18](https://huggingface.co/datasets/thesaurus-linguae-aegyptiae/tla-demotic-v18-premium/tree/main): Datensatzkarten
- [Zenodo 4954597](https://zenodo.org/records/4954597): Ramses-Transliterationskorpus
- [UAX #57](https://www.unicode.org/reports/tr57/): Aufbau von Unikemet
- [Thot Sign List, About](https://thotsignlist.org/About): Umfang und Datenmodell
- [ORAEC, Four challenges when converting AES](https://oraec.github.io/2022/10/14/four-challenges-when-converting-aes.html): Eigenheiten der AES-Kodierung
- [Sproat 2014](https://research.google/pubs/a-statistical-comparison-of-written-language-and-nonlinguistic-symbol-systems/): Schrift gegen nichtsprachliche Zeichensysteme
- [Luo, Cao und Barzilay 2019](https://arxiv.org/pdf/1906.06718): Neural Decipherment
- [Nederhof und Rahman 2017](https://doi.org/10.15398/jlm.v5i1.150): Modell der Zeichenfunktionen
- [Sommerschield u. a. 2023](https://doi.org/10.1162/coli_a_00481): Machine Learning for Ancient Languages
- [Born u. a. 2022](https://aclweb.org/anthology/2022.emnlp-main.620.pdf): Proto-Elamisch, Korpusumfang
- [How Non-Linguistic Is the Indus Sign System?](https://arxiv.org/pdf/2604.17828): Indus-Korpus und Vergleichswerte
- [The Earliest Script on Crete, Einleitung](https://core-cms.cambridgecore.org/core/services/aop-cambridge-core/content/view/F6BAF70365CE3741F43487E1BAC43664/9781009490108int_1-12.pdf/introduction.pdf): Umfang von CHIC
- [AKU-Projekt](https://en.aku.uni-mainz.de/project/): hieratische Paläographie
