# Daten: wo sie liegen und wie man sie holt

Das Paket enthält keine Daten. Alle verwendeten Quellen sind öffentliche Repositories auf GitHub. `daten_holen.sh` lädt sie im festgehaltenen Stand und nur die Dateien, die die Skripte lesen.

```bash
bash daten_holen.sh klein        # rund 15 MB
bash daten_holen.sh aegyptisch   # dazu AES, Ramses, JSesh: rund 600 MB
bash daten_holen.sh alles        # dazu Vergleichskorpora und Keilschrift: rund 1,5 GB
```

Geprüft am 13.11.2026: Stufe `klein` lief in zehn Sekunden durch, und die vier wichtigsten Dateien waren bytegleich mit den in der Auswertung verwendeten. Die Stufen `aegyptisch` und `alles` nutzen denselben Mechanismus mit den unten genannten Ständen; sie wurden nicht erneut vollständig geladen.

## Ordner

```
projekt/
  skripte/      aus diesem Paket
  daten/        von daten_holen.sh angelegt, ein Unterordner je Quelle
  schichten/    Zwischendateien, von den Skripten erzeugt (siehe unten)
```

## Verwendete Quellen

| Stufe | Quelle | Stand | geladene Dateien | Inhalt | verwendet von |
|---|---|---|---|---|---|
| klein | [mwenge/lineara.xyz](https://github.com/mwenge/lineara.xyz) | 9c81beba66 vom 2026-09-28 | `LinearAInscriptions.js; commentary/HT34.html` | Linear A: alle Inschriften mit Umschrift, Fundort, Träger, Schreiber | alle lineara_*-Skripte, corazza_*, chronology_first.py |
| klein | [unicode-org/unicodetools](https://github.com/unicode-org/unicodetools) | 2f97de762e vom 2026-11-12 | `unicodetools/data/ucd/16.0.0/Unikemet.txt; unicodetools/data/ucd/17.0.0/Unikemet.txt; unicodetools/data/ucd/18.0.0/Unikemet.txt; unicodetools/data/ucd/dev/Unikemet.txt` | Unikemet: Funktion und Lesung der kodierten Hieroglyphen | unikemet_stats.py, Zeichen-Skripte (Argument uni_p) |
| klein | [KELLIA/dictionary](https://github.com/KELLIA/dictionary) | f365e2d239 vom 2026-08-26 | `data/egyptian_etymologies.tab` | Koptische Wörter mit ägyptischem Vorläufer (2.311 Einträge) | coptic_align.py, coptic_decode.py |
| klein | [simondschweitzer/aed-tei](https://github.com/simondschweitzer/aed-tei) | 462c722e03 vom 2025-05-18 | `concordance_name_text_id.csv` | Textnamen zu den Text-IDs von AES | alle Skripte mit Argument conc_p |
| klein | [j-luo93/NeuroDecipher](https://github.com/j-luo93/NeuroDecipher) | 480bad2487 vom 2021-09-20 | `data/` | Kognatenlisten Linear B–Griechisch, Ugaritisch–Hebräisch | nur gesichtet und gezählt |
| aegyptisch | [simondschweitzer/aes](https://github.com/simondschweitzer/aes) | 35276d2527 vom 2021-05-18 | `files/aes/` | AES: 101.796 Sätze mit Hieroglyphen, Umschrift, Lemma, Übersetzung, Datierung | fast alle Skripte zum Ägyptischen |
| aegyptisch | [MaReTEgyptologists/TranslitModels](https://github.com/MaReTEgyptologists/TranslitModels) | c612a91407 vom 2023-06-01 | `Output/ModifiedSources/; Output/WordLists/` | Ramses-Trainingssatz (Neuägyptisch): Zeichenfolge und Umschrift | ramses_stats.py, split_layers.py |
| aegyptisch | [rosmord/jsesh](https://github.com/rosmord/jsesh) | d16d8a9a48 vom 2026-11-04 | `jsesh/src/main/resources/jsesh/glyphs/resources/signs_description.xml; jseshGlyphs/src/main/resources/jseshGlyphs/` | JSesh: Zeichenbeschreibung und Glyphen als SVG | Ergebnisseite (glyph_boxes.py, build_page.py), Zahlzeichenbild |
| alles | [christos-c/bible-corpus](https://github.com/christos-c/bible-corpus) | 44e5fca1bf vom 2025-05-19 | `bibles/German.xml; bibles/Latin.xml; bibles/Hebrew.xml; bibles/Greek.xml; bibles/English.xml; bibles/Arabic.xml; bibles/Coptic-NT.xml; bibles/Chinese.xml; bibles/Chinese-tok.xml` | Parallele Bibel in neun Fassungen | Skripte mit Argument bdir, stars_passages.py |
| alles | [cltk/lat_text_latin_library](https://github.com/cltk/lat_text_latin_library) | 76229acaf0 vom 2018-08-10 | `*` | Lateinische Texte (Latin Library) | Skripte mit Argument latroot |
| alles | [UniversalDependencies/UD_Latin-ITTB](https://github.com/UniversalDependencies/UD_Latin-ITTB) | 16cc97fce6 vom 2026-11-10 | `*.conllu` | Lateinische Baumbank (Lemma, Wortart) | Skripte mit Argument ud_dirs |
| alles | [UniversalDependencies/UD_Latin-PROIEL](https://github.com/UniversalDependencies/UD_Latin-PROIEL) | 56e6e8c8f6 vom 2026-11-10 | `*.conllu` | Lateinische Baumbank | Skripte mit Argument ud_dirs |
| alles | [UniversalDependencies/UD_Latin-Perseus](https://github.com/UniversalDependencies/UD_Latin-Perseus) | 63aba6ffd1 vom 2026-11-10 | `*.conllu` | Lateinische Baumbank | Skripte mit Argument ud_dirs |
| alles | [PerseusDL/canonical-greekLit](https://github.com/PerseusDL/canonical-greekLit) | cae36e967c vom 2026-11-12 | `data/tlg0059/` | Platon, griechisch (TEI) | refcorpora.py und die Platon-Vergleiche |
| alles | [cplusplus/draft](https://github.com/cplusplus/draft) | ab4b978e6f vom 2026-11-10 | `source/basic.tex; source/lex.tex; source/statements.tex; source/std.tex` | C++-Standardentwurf: Grammatik als Nicht-Sprache | cpp_categories.py, nesting.py |
| alles | [cdli-gh/data](https://github.com/cdli-gh/data) | 228da1bd50 vom 2021-10-18 | `cdliatf_unblocked.atf; cdli_catalogue_*of4.csv` | Keilschrift: alle Umschriften und Katalog des CDLI, Stand vor der Auslagerung in Git LFS | cdli_extract.py, danach alle cdli_*-Skripte |
| alles | [KashiwaByte/ancient-egyptian-hieroglyphs-classification](https://github.com/KashiwaByte/ancient-egyptian-hieroglyphs-classification) | bd58028058 vom 2024-06-21 | `prepared_data.zip` | 4.031 Glyphenfotos in 171 Klassen | nur gesichtet und gezählt |

Lizenzen: AES steht unter CC BY-SA 4.0. Für alle anderen Quellen gilt die Lizenz im jeweiligen Repository; vor einer Weitergabe von Daten oder Auszügen dort nachsehen.

## Besonderheiten

- **Keilschrift (CDLI):** Seit der Auslagerung in Git LFS liefert das Repository nur Zeiger statt der Dateien. Verwendet ist deshalb der Stand 228da1b vom 18.10.2021, der Umschriften (84 MB) und Katalog (vier Teile zu je 38 MB) noch direkt enthält. Der Katalog ist in vier Teile zerschnitten; `cdli_extract.py` fügt sie selbst zusammen.
- **Amarna-Briefe in derselben Datei:** Die Suche nach Ägypten und ägyptischen Königsnamen in Keilschrift lief mit

  ```bash
  awk '/^&P/{h=$0} /mu-a-re-|mu-re-ia|mu-u2-re-ia|mu-a-ri-a|hu-ru-re-|hu-ur-ri-ri|hur-re-ia|hu-ri-ri-ia|ri-a-ma-sze-sza|mi-is,-ri|mi-is-ri-i/{n++; t[h]=1; if(n<=9) print h " | " $0} END{c=0; for(k in t)c++; print n, c}' daten/cdli-gh_data/cdliatf_unblocked.atf
  ```

  Ergebnis: 120 Zeilen auf 86 Tafeln.
- **Bibelkorpus, Perseus, C++-Entwurf:** Die Repositories sind groß; geladen werden nur die genannten Dateien.
- **Stand der Vergleichskorpora:** Mehrere Repositories wurden am 12.11.2026 im damals aktuellen Stand geladen. Die Commits in der Tabelle halten ihn fest.

## Quellen außerhalb von GitHub

Hugging Face (TLA-Datensätze v18 und v19), Zenodo (Ramses), unicode.org und die Projektportale waren aus der Arbeitsumgebung der Auswertung nicht erreichbar und sind deshalb nicht verwendet. Adressen und Umfang stehen in `03_grundlagen.md`. Mit gewöhnlichem Netzzugang sind sie ladbar; die neueren TLA-Fassungen wären die erste Erweiterung.

## Gesichtet, nicht ausgewertet

Diese Repositories wurden für die Übersicht in `03_grundlagen.md` angesehen. Kein Skript liest sie.

| Quelle | Stand |
|---|---|
| https://github.com/CopticScriptorium/corpora | 6fb51458e7 vom 2026-10-26 |
| https://github.com/UniversalDependencies/UD_Egyptian-UJaen | 1d3ac884bb vom 2026-11-10 |
| https://github.com/alexeyev/glyphnet-pytorch | 7fd229dc78 vom 2022-09-06 |
| https://github.com/cdli-gh/proto-cuneiform_signs | 04cb671c5b vom 2023-08-31 |
| https://github.com/digitalepigraphy/RosettaStone | f71fd09be0 vom 2026-09-20 |
| https://github.com/googleartsculture/workbench | 95388cd99a vom 2025-03-27 |
| https://github.com/j-luo93/DecipherUnsegmented | 3cdd0f4257 vom 2021-07-06 |
| https://github.com/jgregoriods/rongopy | f7f6e80de2 vom 2023-09-03 |
| https://github.com/mattia-decao/hiero-transformer | 0b95a9bec2 vom 2024-11-03 |
| https://github.com/metmuseum/openaccess | d31d26fa33 vom 2026-11-09 |
| https://github.com/microsoft/font-tools | d06068439f vom 2026-09-16 |
| https://github.com/morrisfranken/glyphreader | b27597eea2 vom 2017-12-24 |
| https://github.com/nederhof/hierojax | da318801e0 vom 2026-09-26 |
| https://github.com/nederhof/isut | 0bafc47e48 vom 2024-10-17 |
| https://github.com/nederhof/newgardiner | ef51d1aa11 vom 2026-11-05 |
| https://github.com/notofonts/egyptian-hieroglyphs | 209775d2fc vom 2026-11-02 |
| https://github.com/oraec/corpus | cf625e7167 vom 2023-09-22 |
| https://github.com/oraec/corpus_raw_data | b83a0ee5fa vom 2024-06-03 |
| https://github.com/rwsproat/symbols | 26d9fbce2f vom 2024-09-30 |
| https://github.com/sfu-natlang/pe-decipher-toolkit | 404f0505c1 vom 2023-06-12 |
| https://github.com/sfu-natlang/pe-sign-value-data | 538949cca9 vom 2022-08-12 |
| https://github.com/simondschweitzer/aed | ae906684e9 vom 2019-10-28 |

## Zwischendateien neu bauen

Die Auswertung arbeitete mit 85 MB Zwischendateien. Sie entstehen aus den Rohdaten:

```bash
AES=daten/simondschweitzer_aes/files/aes
RAM=daten/MaReTEgyptologists_TranslitModels/Output/ModifiedSources
CONC=daten/simondschweitzer_aed-tei/concordance_name_text_id.csv
UNI=daten/unicode-org_unicodetools/unicodetools/data/ucd/18.0.0/Unikemet.txt
LAT=daten/cltk_lat_text_latin_library
BIB=daten/christos-c_bible-corpus/bibles
S=schichten; mkdir -p $S

python3 -I skripte/split_layers.py $AES $RAM/src-sep-train_cleaned $RAM/tgt-train_cleaned $S
python3 -I skripte/corpus_structure.py $AES $S/text_complexity.json
python3 -I skripte/structure_check.py $AES $S/text_complexity.json $CONC $S/aes_texts_cache.json.gz
python3 -I skripte/structure_clean.py $AES $S/text_complexity.json $CONC $S/aes_tokens_cache.json.gz $S/text_complexity_v2.json
python3 -I skripte/letters.py $AES $UNI $S/aes_wordsigns_cache.json.gz $LAT
python3 -I skripte/blind_seg.py $S/aes_schrift.jsonl.gz $BIB $S/blind_segmentation.json.gz
python3 -I skripte/rare_signs.py $AES $CONC $UNI $S/rare_signs.json
python3 -I skripte/cdli_extract.py daten/cdli-gh_data $S/cdli_ur3.jsonl.gz
```

| Datei | Größe | Inhalt | erzeugt von |
|---|---|---|---|
| `aes_schrift.jsonl.gz` | 7,7 MB | Schrift-Schicht: Zeichenfolge je Wort | `split_layers.py` |
| `aes_deutung_token.jsonl.gz` | 33,5 MB | Deutung je Wort: Umschrift, Lemma, Wortart, Glosse | `split_layers.py` |
| `aes_deutung_satz.jsonl.gz` | 20,6 MB | Deutung je Satz: Übersetzung | `split_layers.py` |
| `aes_kontext.jsonl.gz` | 0,3 MB | Datierung, Fundort, Korpus je Text | `split_layers.py` |
| `ramses_schrift.jsonl.gz`, `ramses_deutung.jsonl.gz` | 1,9 und 1,2 MB | dasselbe für den Ramses-Satz | `split_layers.py` |
| `text_complexity.json` | 0,8 MB | Schwierigkeitsmaß je Text, erste Fassung | `corpus_structure.py` |
| `aes_texts_cache.json.gz` | 2,6 MB | je Text: Lemmata, Satzlängen, Zeichen | `structure_check.py` (legt die Datei an, wenn sie fehlt) |
| `aes_tokens_cache.json.gz` | 4,8 MB | je Text: Lemma-Nummer, Lemma, Wortart, Schreibung | `structure_clean.py` (ebenso) |
| `text_complexity_v2.json` | 1,8 MB | Schwierigkeitsmaß, bereinigte Fassung | `structure_clean.py` |
| `aes_wordsigns_cache.json.gz` | 0,8 MB | je Text: Zeichen je Wort | `letters.py` (ebenso) |
| `blind_segmentation.json.gz` | 5,8 MB | blind gesetzte Wortgrenzen mit Vergleichswerten | `blind_seg.py` |
| `rare_signs.json` | 0,1 MB | seltene Zeichen der Ritualpapyri | `rare_signs.py` |
| `cdli_ur3.jsonl.gz` | 6,3 MB | Ur-III-Verwaltungstexte, bereinigte Zeilen | `cdli_extract.py` |
| `glyph_boxes.json` | 0,7 MB | Maße der Glyphen für die Ergebnisseite | `glyph_boxes.py` (braucht Chrome über Playwright) |

Geprüft am 13.11.2026: `split_layers.py` lief mit genau diesem Aufruf in 22 Sekunden und lieferte alle sechs Schichtdateien inhaltsgleich zu den verwendeten. Die übrigen Aufrufe sind aus den Argumentlisten der Skripte übernommen und nicht erneut ausgeführt. Welche Unikemet-Fassung jeweils übergeben wurde, ist nicht protokolliert; die Angaben im Dokument beziehen sich auf 18.0.0.

Die meisten späteren Skripte brauchen nur `aes_tokens_cache.json.gz` oder den Rohdatenordner. `SKRIPTE.md` nennt die Argumente je Skript.
