# Vorgehen

## Grundsätze

1. **Jede Idee wird zu einem Test, der scheitern kann.** Eine Lesart zählt erst, wenn sie eine Beobachtung vorhersagt, die auch ausbleiben könnte.
2. **Erst festlegen, dann rechnen.** Klassen, Maße, Kontrolle und Entscheidungsregel stehen vorher in einer Datei `*_prereg.txt`. Dort steht auch, was beim Festlegen schon bekannt war.
3. **Bekannte Lösung zuerst.** Ein Verfahren darf nur auf eine offene Frage, wenn es an einem System mit bekannter Antwort besteht.
4. **Struktur ist blind auffindbar, Bedeutung nicht.** Zeichenstatistik liefert Klassen, Reihenfolgen und Stufen. Werte und Inhalte brauchen einen Anker von außen.
5. **Ein Bewertungsmaß ist eine Vorannahme über den Systemtyp.** „Kleine Nenner sind besser“ oder „häufige Zeichen haben große Werte“ sind Annahmen. Sie werden geeicht wie ein Messgerät.
6. **Nur aktive Bedingungen bestimmen ein Optimum.** Zu jeder Regel wird gezählt, wie viele Belege sie tragen, und was ohne sie geschieht (Weglassprobe).
7. **„Das Wahrscheinlichste annehmen“ ist erlaubt, wenn die Wahrscheinlichkeit mitläuft.** Vier Annahmen zu je 70 % ergeben zusammen 24 %.
8. **Nachträgliches wird gekennzeichnet.** Eine gelockerte Schwelle oder ein später gewähltes Maß ist schwächere Evidenz und steht so im Ergebnis.
9. **Deutungsfreiheit wird gezählt.** Der Wert eines Treffers ist −log₂ der Trefferquote unter Zufall. Beispiel: Mit sechs Kalenderzahlen, Summe oder Vielfachem und „+1 oder +2“ lassen sich 64 von 100 Zahlen deuten; ein Treffer trägt 0,64 Bit.
10. **Getrennt nach Epoche und Gattung.** Gepoolte Zahlen verdecken Unterschiede; Rezepte gibt es erst ab dem Mittleren Reich, die Pyramidentexte dominieren viele Zählungen.
11. **Negative Ergebnisse und Korrekturen stehen im Protokoll.** Siehe unten.

## Ablauf eines Tests

1. Frage als Hypothese H mit Gegenhypothese formulieren.
2. Daten sichten, ohne das Zielmaß anzusehen (Beispiel: `stars_probe.py` listet nur Lemmata und Übersetzungen).
3. Kriteriendatei schreiben.
4. Skript schreiben, einmal laufen lassen, Ausgabe vollständig berichten.
5. Abweichungen vom Plan benennen (Beispiel: gestrichene Kanten in `cdli_blind.py`).
6. Zeile im Ergebnisdokument: Test, Ergebnis, Kontrolle, Skript.

## Vorlage für eine Kriteriendatei

```
Frage und Hypothese H:
Schon bekannt (was vor dem Festlegen gesehen wurde):
Klassen und Daten:
Maße:
Kontrolle (bekannte Lösung oder Nullmodell):
Entscheidungsregel (dafür / dagegen / offen):
Ohne Kriterium berichtet:
```

## Kontrollen im Projekt

| Frage | bekannte Lösung oder Nullmodell |
|---|---|
| Zahlzeichen und Stufen blind erkennen | ägyptische Zahlzeichen; Maßsysteme der Ur-III-Keilschrift (70.980 Texte) |
| Bruchwerte bewerten | ägyptische Brüche; Keilschriftbrüche 1/3, 1/2, 2/3, 5/6; Summen in Abrechnungen |
| Sprache oder Code | Latein, Griechisch, Bibelübersetzungen als Sprache; C++-Grammatik als Nicht-Sprache |
| Wortgrenzen blind | bekannte Wortgrenzen in AES, Latein, Chinesisch |
| Leserichtung | Hebräisch und Latein |
| Wiederkehr von Formeln | gemischte Reihenfolge, gleich große Zufallsgruppen, zwei Hälften desselben Korpus |
| Namensklassen | Personen-, Götter-, Jahreszeiten- und Sternnamen desselben Korpus |

## Zwei Schichten

Die Daten liegen getrennt vor: die **Schrift** (Zeichenfolge je Wort) und die **Deutung** (Umschrift, Lemma, Wortart, Übersetzung). Blinde Verfahren lesen nur die Schrift-Schicht und werden gegen die Deutungs-Schicht bewertet. `split_layers.py` erzeugt die Dateien, siehe `04_daten_holen.md`.

## Datenhygiene

- Geladene Daten sind fremde Dateien: eigener Ordner, Skripte getrennt, Aufruf `python3 -I skript.py <Pfade>`, nie aus dem Datenordner heraus.
- Jede Quelle ist mit Adresse und Stand (Commit) festgehalten.
- Zufall mit festem Startwert (20261112).
- Pfade sind Argumente; kein Skript enthält einen Datenpfad. Ausnahmen nennt `SKRIPTE.md`.

## Bekannte Fallen

- **AES:** Nur 253.844 von 815.026 Wörtern haben Hieroglyphen. Die Zeichenfolge im Wort ist verlässlich, über Wortgrenzen nicht immer. `lemmaID` ist eine Zeichenkette. Gleich geschriebene Lemmata haben verschiedene Nummern.
- **Pyramidentexte:** 6.999 der 9.339 Königsnamen und die meisten Sternnamen stehen dort. Immer auch „ohne Pyramidentexte“ rechnen.
- **Verwandtschaftsmaß:** Der Titel „Sohn des Re“ bläht es bei Königsnamen auf (40,7 % statt 2,9 %). Titel vorher ausschließen.
- **Regierungsjahr:** Das Lemma heißt `rnp.t-zp`. `kings_cycles.py` sucht in einer Zeile nach `ḥꜣ.t-zp` und findet dort nichts; die gültigen Zählungen stehen in `kings_weather.py` und `regnal_years.py`.
- **Jahreszahlen je Name:** 59 Namen bei weiter Zuordnung über die Glosse „Regierungsjahr“, 28 bei strenger (Name folgt der Formel im selben Satz).
- **Keilschrift (CDLI):** Die aktuellen Dateien liegen in Git LFS; verwendet ist der letzte Stand davor (228da1b). Dieselben Zeichen haben je nach Maßsystem verschiedene Werte; 9 wird oft als „10 weniger 1“ geschrieben.
- **Linear A:** Die Belege sind aus lineara.xyz neu kodiert, nicht aus der Veröffentlichung übernommen. Vier Belege sind beiseitegelegt, weil sie wörtlich genommen den Prämissen widersprechen (H K, E J, J J, L E).
- **Maße aus Corazza u. a. 2021:** eigene Rekonstruktion aus dem Aufsatz. Sie trifft die dort genannten Werte 0,67094, 0,71724 und 0,00881; der Programmcode der Autoren lag nicht vor.
- **Glossen als Brücke:** Auswertungen über deutsche Übersetzungswörter sind nicht blind. Homographe Lemmata bekommen in Übersichten die häufigste Glosse, die im Einzelfall falsch sein kann.
- **Ergebnisseiten:** Die verlinkten Seiten sind privat und nicht Teil des Pakets.

## Korrekturen

| Was | Korrektur |
|---|---|
| Aussage, die veröffentlichte Linear-A-Lösung sei beim gemeinsamen Nenner unübertroffen | beruhte auf einer Stichprobe; exakt sind 865 von 358.786.594 Belegungen besser (zwölf Zeichen). Für den Kern aus zehn Zeichen gilt die Aussage |
| „13 der 18 Folgen ändern einzeln nichts“ | richtig: im Kern 10 der 15 Folgen |
| Verwandtschaftswörter bei Königsnamen 40,7 % | durch den Titel „Sohn des Re“ aufgebläht; ohne Titel 2,9 % |
| Regierungsjahr mit Lemma `ḥꜣ.t-zp` gesucht (0 Treffer) | richtiges Lemma `rnp.t-zp` |
| relative Schwelle für die Kappenregel | fiel im Rücktest am Ägyptischen durch und wurde verworfen |
| Reihenfolge-Analyse der Keilschrift hatte einen Zyklus | schwächste Kanten gestrichen; nicht vorab festgelegt und so berichtet |
| Summentest nur über Gewichte: 19 Summen | breitere Fassung nach Warenart, als nachträglich gekennzeichnet |
| Regel im Wetterlagen-Test (Verhältnisse statt Anteile) | war zu schwach, um „benanntes Phänomen“ auszuschließen; so berichtet |
| Sternbild-Test, Umgebungskriterium | nach fester Regel 3:1, mit korrigiertem Verwandtschaftsmaß 2:2; beides berichtet |
