# Offene Schritte

## Offene Tests

Die Liste entspricht den offenen Punkten am Ende von `02_ergebnisse.md`. Keiner ist gerechnet; für den Sprachvergleich stehen die Kriterien bereits fest.

| Schritt | Vorhersage oder Frage | Daten | Vorarbeit |
|---|---|---|---|
| Sprachvergleich des Königsnamen-Profils | Kehrt das Profil (Titel davor, Lebenswunsch danach, Gott im Satz, kaum Zahlen) in lesbaren Sprachen wieder, und bei welcher Namensklasse? Vorhersage: bei Herrschern | Vulgata; Königsinschriften der Ur-III-Zeit (CDLI) | Kriterien in `skripte/kings_profile_crosslang_prereg.txt`; guter Einstieg für eine neue Person |
| Interaktiver 3D-Viewer der Klassen | Darstellung, kein Test: Klassen als Punkte mit Häufigkeit, Verbindungen, Bedeutung laut Standardlesung und Prüfstatus | Ergebnisse dieses Pakets | Achsen noch nicht festgelegt. Das 27-Felder-Raster ist ausgezählt: effektiv 8,8 von 27 Feldern besetzt, die Achsen sind nicht unabhängig |
| Sprachuhr | Lassen sich Texte aus gerichteten Ersetzungen datieren (pj zu pw zu pn, n zu nn, =s zu =st)? Lernen an datierten Texten, Prüfen an zurückgehaltenen, Vergleich mit Burrows’ Delta | AES | `formula_chronology.py`, `pt_pyramids.py` zeigen die Richtungen |
| Linear A: Bruchzeichen und Warenarten | Gilt ein einziges Wertesystem für alle Waren? In der Keilschrift haben dieselben Zeichen je nach Maßsystem verschiedene Werte | lineara.xyz | `lineara_compounds.py`, `cdli_sums2.py` |
| Linear A mit dem geeichten blinden Verfahren | Liefert die Kette aus Kappenregel und Reihenfolge dieselben Stufen wie die Fachliteratur? | lineara.xyz | `cdli_blind.py` ist die geeichte Fassung |
| Namen-Anker-Test | Mindestens drei äußere Anker auf das Ägyptische anwenden. Erster Kandidat: Schreibungen ägyptischer Königsnamen in den Amarna-Briefen gegen die Zeichenwerte der Standardlesung | AES, CDLI | Befund in `02_ergebnisse.md`, Suchbefehl in `04_daten_holen.md` |
| Häufigkeitsgesetz nach Epoche und Gattung | Bleiben der Exponent −2 und die Spitze bei 4 stabil? | AES | Skripte zu den Zahlen |
| Euklid als drittes Korpus neben Platon | Wo entsteht das Vokabular für Verhältnis und Beweis? | Perseus | `refcorpora.py` |

## Ideenspeicher

Regel: Eine neue Idee kommt zuerst hierher, mit einer Vorhersage, die scheitern kann. Getestet wird eine nach der anderen. Ohne Vorhersage gibt es keinen Test.

| Idee | Vorhersage, die scheitern kann | Stand |
|---|---|---|
| Königsnamen sind Namen von Zyklen | Namen kehren über Epochen wieder; Umgebung wie bei Jahreszeiten | geprüft, nicht gestützt (`kings_cycles.py`) |
| Königsnamen wie Namen von Wetterlagen | Umgebung wie bei benannten Phänomenen | geprüft; Texte allein trennen Person und personifizierten Namen nicht, Belege außerhalb der Texte entscheiden (`kings_weather.py`) |
| Königsnamen sind Sternbilder | Schreibung mit dem Sternzeichen; Umgebung wie bei Sternnamen | geprüft; nach fester Regel widerlegt, mit korrigiertem Verwandtschaftsmaß formal offen, kein Kriterium dafür (`kings_stars.py`) |
| 56 ist die Länge eines Zyklus | viele Namen erreichen dieselbe Höchstzahl | geprüft, nicht gestützt: ein Name, ein Beleg (`regnal_years.py`) |
| Sternpassagen über ein Muster aus bekannten Sprachen finden | Begleiter von „Stern“ finden Sternsätze mit mindestens 50 % Treffgenauigkeit | geprüft, nicht gefunden: 1,9 % (`stars_passages.py`) |
| Könige als Sinnbild für eine Berechnung oder Energie | noch keine | offen; zuerst festlegen, welche Beobachtung für Personen spräche und welche dagegen |
| Folge der Dekane mit der Folge der Könige vergleichen | Dekane kehren in fester Reihenfolge wieder, Königsnamen nicht | offen; Dekanlisten und Sternuhren fehlen im Korpus und müssten beschafft werden |

## Sinnvolle erste Aufgaben für eine neue Person

1. **Schnellstart nachvollziehen** (`README.md`): beide erwarteten Ausgaben reproduzieren.
2. **Einen Test unabhängig nachrechnen.** Vorschlag: `kings_stars.py` mit eigener Abgrenzung der Sternnamen. `stars_probe.py` liefert die Kandidaten.
3. **Die Neukodierung der Linear-A-Belege gegenlesen.** Die 18 Zeichenfolgen in `lineara_loo.py` (`RUNS`, `EXTRA`, `ATT`) Beleg für Beleg mit lineara.xyz und der Veröffentlichung abgleichen. Hier hängt am meisten an einer einzelnen Kodierung.
4. **Die Rekonstruktion der vier Maße prüfen** (`corazza_goptimal.py`, `corazza_calib.py`), wenn der Code der Autoren zu bekommen ist.
5. **Fehlende Daten beschaffen:** TLA v18 und v19 von Hugging Face, Ramses von Zenodo, astronomische Texte.
6. **Kriterien für die Sprachuhr festlegen,** bevor jemand rechnet.

## Was ein zweiter Kopf am meisten bringt

Kriterien, die eine Person festlegt und eine andere auswertet, sind härter als alles bisher. Bislang lagen Festlegen und Rechnen in einer Hand.
