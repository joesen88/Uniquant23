import json, sys, re, glob, os, gzip, html, collections
aes_root, ramses_src, ramses_tgt, out = sys.argv[1:5]
os.makedirs(out, exist_ok=True)
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*')
INTERP = ('written_form','mdc','lemma_form','lemmaID','pos','cotext_translation','numerus','status','genus','pronoun','verbalClass','inflection','voice','name','epitheton','morphology','adjective','number','particle','adverb')
fs = gzip.open(os.path.join(out,'aes_schrift.jsonl.gz'),'wt',encoding='utf-8')
fd = gzip.open(os.path.join(out,'aes_deutung_token.jsonl.gz'),'wt',encoding='utf-8')
fz = gzip.open(os.path.join(out,'aes_deutung_satz.jsonl.gz'),'wt',encoding='utf-8')
fk = gzip.open(os.path.join(out,'aes_kontext.jsonl.gz'),'wt',encoding='utf-8')
st = collections.Counter(); seen_text = set()
for p in sorted(glob.glob(os.path.join(aes_root,'_aes_*.json'))):
    d = json.load(open(p,encoding='utf-8'))
    by_text = collections.OrderedDict()
    for sid, s in d.items(): by_text.setdefault(s['text'], []).append((sid, s))
    for tid, sents in by_text.items():
        if tid not in seen_text:
            seen_text.add(tid); s0 = sents[0][1]
            fk.write(json.dumps({'text':tid,'korpus':s0.get('corpus'),'datierung':s0.get('date'),'fundort':s0.get('findspot'),'bearbeiter':s0.get('owner')},ensure_ascii=False)+'\n'); st['texte']+=1
        line = None; lines = []
        for sid, s in sents:
            ids = []
            for t in s.get('token', []):
                tok = t.get('_id')
                if tok is None: continue
                ids.append(tok); st['token_deutung']+=1
                rec = {'tok':tok,'satz':sid,'text':tid}
                for k in INTERP:
                    if k in t: rec[k] = t[k]
                fd.write(json.dumps(rec,ensure_ascii=False)+'\n')
                lab = t.get('lineCount')
                if line is None or line['zeile'] != lab:
                    line = {'text':tid,'zeile':lab,'tok':[],'zeichen':[],'unicode':[]}; lines.append(line)
                h = t.get('hiero')
                line['tok'].append(tok)
                line['zeichen'].append(SIGN.findall(h) if h else None)
                line['unicode'].append(html.unescape(t['hiero_unicode']) if t.get('hiero_unicode') else None)
            fz.write(json.dumps({'satz':sid,'text':tid,'uebersetzung':s.get('sentence_translation'),'tok':ids},ensure_ascii=False)+'\n'); st['saetze']+=1
        for i, ln in enumerate(lines):
            n_h = sum(1 for z in ln['zeichen'] if z)
            st['zeilen']+=1
            if n_h == 0: continue
            ln['id'] = f'{tid}#{i}'; ln['lueckenlos'] = (n_h == len(ln['zeichen']))
            st['zeilen_mit_zeichen']+=1; st['zeilen_lueckenlos']+= ln['lueckenlos']
            st['wort_mit_zeichen']+= n_h; st['zeichen_token']+= sum(len(z) for z in ln['zeichen'] if z)
            fs.write(json.dumps(ln,ensure_ascii=False)+'\n')
for f in (fs,fd,fz,fk): f.close()
rs = gzip.open(os.path.join(out,'ramses_schrift.jsonl.gz'),'wt',encoding='utf-8')
rd = gzip.open(os.path.join(out,'ramses_deutung.jsonl.gz'),'wt',encoding='utf-8')
with open(ramses_src,encoding='utf-8') as a, open(ramses_tgt,encoding='utf-8') as b:
    for i,(x,y) in enumerate(zip(a,b)):
        words = [w.split() for w in x.strip().split(' _ ') if w.strip() and w.strip()!='_']
        words = [[t for t in w if t!='_'] for w in words]
        tr = [''.join(w.split()) for w in y.strip().split(' _ ') if w.strip() and w.strip()!='_']
        rs.write(json.dumps({'id':f'ramses:{i}','zeichen':words},ensure_ascii=False)+'\n')
        rd.write(json.dumps({'id':f'ramses:{i}','translit':tr},ensure_ascii=False)+'\n'); st['ramses_zeilen']+=1
rs.close(); rd.close()
print(dict(st))
