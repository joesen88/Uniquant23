import sys, re, collections
s = open(sys.argv[1], encoding='utf-8').read()
keys = collections.Counter(re.findall(r'^\s{4}"([A-Za-z]+)":', s, flags=re.M))
print('keys', keys.most_common(20))
blocks = re.findall(r'"transliteratedWords":\s*\[(.*?)\]', s, flags=re.S)
multi = collections.Counter(); single = 0; nums = 0
for b in blocks:
    for w in re.findall(r'"((?:[^"\\]|\\.)*)"', b):
        if w in ('\\n', '𐄁', ''): continue
        if re.fullmatch(r'[0-9/≈ .JEFKLBDAH]+', w): nums += 1; continue
        if '-' in w and re.search(r'[A-Z]', w): multi[w] += 1
        else: single += 1
print('multi-sign word tokens', sum(multi.values()), 'types', len(multi), 'hapax types', sum(1 for v in multi.values() if v == 1))
print('other single tokens', single, 'numeric-like', nums)
print('most common', multi.most_common(8))
