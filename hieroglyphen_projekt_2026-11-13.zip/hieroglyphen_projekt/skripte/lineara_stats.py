import sys, re, collections
s = open(sys.argv[1], encoding='utf-8').read()
names = re.findall(r'^\["([^"]+)",\{', s, flags=re.M)
print('inscriptions', len(names), 'distinct', len(set(names)))
pi = re.findall(r'"parsedInscription":\s*"((?:[^"\\]|\\.)*)"', s)
uni = collections.Counter(); ntok = 0
for t in pi:
    for ch in t:
        if 0x10600 <= ord(ch) <= 0x1077F: uni[ch] += 1; ntok += 1
print('parsedInscription fields', len(pi), 'Linear A sign tokens', ntok, 'types', len(uni), 'hapax', sum(1 for x in uni.values() if x == 1))
acc = 0
for i,(c,v) in enumerate(uni.most_common(),1):
    acc += v
    if acc/ntok >= 0.9: print('types for 90% coverage', i); break
print('sites', collections.Counter(re.findall(r'"site":\s*"([^"]*)"', s)).most_common(6))
print('supports', collections.Counter(re.findall(r'"support":\s*"([^"]*)"', s)).most_common(8))
