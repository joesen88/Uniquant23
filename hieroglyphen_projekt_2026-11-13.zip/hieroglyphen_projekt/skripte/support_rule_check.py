"""Retro-check of the pair-support rule (pair >= 3 and >= 1/1000 of the rarer sign) on the Egyptian fraction data,
and skip rates in the cuneiform chain. usage: python3 -I support_rule_check.py <aes_tokens_cache.json.gz> <cdli_ur3.jsonl.gz>"""
import sys, gzip, json, re, collections, itertools
C = collections.Counter
T = json.load(gzip.open(sys.argv[1], 'rt', encoding='utf-8'))
clean = lambda w: re.sub(r'[\[\]⸢⸣()\?{}〈〉<>\s⸮]', '', w or '')
SIX = ['1/2', '1/4', '1/8', '1/16', '1/32', '1/64']
n = C(); pair = C()
for t in T.values():
    toks = t['tok']; p0 = 0
    for L in t['sl']:
        s = toks[p0:p0 + L]; p0 += L; run = []
        for tk in s + [(None, None, None, None)]:
            w = clean(tk[3]) if tk[1] == '1...n' else None
            if w in SIX: run.append(w); n[w] += 1
            else:
                for a, b in zip(run, run[1:]): pair[(a, b)] += 1
                run = []
print('Egyptian fraction notations, tokens:', dict(n))
keep = []; drop = []
for a, b in itertools.combinations(SIX, 2):
    x, y = pair[(a, b)], pair[(b, a)]
    if x + y == 0: continue
    ok = (x + y) >= 3 and (x + y) >= min(n[a], n[b]) / 1000
    (keep if ok else drop).append((a, b, x, y))
print('  pairs kept by the support rule:', keep)
print('  pairs dropped by the support rule:', drop)
edges = collections.defaultdict(set); indeg = C()
for a, b, x, y in keep:
    hi, lo = (a, b) if x >= y else (b, a); edges[hi].add(lo); indeg[lo] += 1
order = []; uniq = True
while len(order) < 6:
    free = [s for s in SIX if s not in order and indeg[s] == 0]
    if not free: break
    if len(free) > 1: uniq = False
    s = free[0]; order.append(s)
    for t2 in edges[s]: indeg[t2] -= 1
print('  order with the support rule:', ' > '.join(order), '| unique:', uniq, '| correct:', order == SIX)

EL = re.compile(r'^(\d+)(?:/(\d+))?\(([^()]+)\)(.*)$'); GL = re.compile(r'^(?:\{[^{}]*\})+')
nxt = collections.defaultdict(C)
for line in gzip.open(sys.argv[2], 'rt', encoding='utf-8'):
    t = json.loads(line)
    for o in t['o']:
        for cl, body in o:
            if not cl: continue
            prev = None
            for tok in body.split():
                m = EL.match(tok)
                if not m: prev = None; continue
                cnt, den, name, suf = m.groups(); suf = GL.sub('', suf)
                s = None if den else name
                if prev and s: nxt[prev][s] += 1
                prev = s if not suf else None
print('\ncuneiform: which integer sign follows directly (share of all direct successors)')
for hi in ("gesz'u", 'gesz2', 'u', 'asz', 'barig', 'ban2'):
    tot = sum(nxt[hi].values())
    print(f'  after {hi:7s} ({tot:6d}): ' + ', '.join(f'{s} {c/tot:.1%}' for s, c in nxt[hi].most_common(5)))
