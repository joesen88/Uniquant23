import json, sys, collections
p = sys.argv[1]
d = json.load(open(p, encoding='utf-8'))
by_text = collections.OrderedDict()
for sid, s in d.items():
    by_text.setdefault(s['text'], []).append(s)
print('sentences', len(d), 'texts', len(by_text))
# show line labels sequence for the first 2 texts with hiero
shown = 0
for tid, sents in by_text.items():
    labels = [t.get('lineCount') for s in sents for t in s['token']]
    has = sum(1 for s in sents for t in s['token'] if t.get('hiero'))
    if has < 20: continue
    runs = []
    for l in labels:
        if not runs or runs[-1][0] != l: runs.append([l, 1])
        else: runs[-1][1] += 1
    print(tid, 'tokens', len(labels), 'with hiero', has, 'label runs', len(runs), 'distinct labels', len(set(labels)))
    print('  first runs', runs[:10])
    shown += 1
    if shown == 3: break
keys = collections.Counter(k for s in d.values() for t in s['token'] for k in t)
print('token keys', keys.most_common(30))
print('sentence keys', collections.Counter(k for s in d.values() for k in s).most_common())
