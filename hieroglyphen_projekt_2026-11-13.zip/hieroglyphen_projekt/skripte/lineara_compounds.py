"""Linear A: every run of two or more fraction signs, with tablet, context and reading certainty.
usage: python3 -I lineara_compounds.py <LinearAInscriptions.js>"""
import sys, json, re, unicodedata, collections
C = collections.Counter
s = open(sys.argv[1], encoding='utf-8').read()
i = s.index('new Map(') + len('new Map(')
body = re.sub(r'\\u\{([0-9A-Fa-f]+)\}', lambda m: chr(int(m.group(1), 16)), s[i:])
arr, _ = json.JSONDecoder().raw_decode(re.sub(r',\s*([\]}])', r'\1', body).lstrip())
NAME = {chr(cp): unicodedata.name(chr(cp)).split()[-1] for cp in range(0x10740, 0x10756)}
UNC = '\U0001076b'
occ = collections.defaultdict(list); single = C(); tok = 0; unc_comp = C()
for key, v in arr:
    W = v.get('words', []); T = v.get('transliteratedWords', [])
    for j, (w, t) in enumerate(zip(W, T)):
        if w and any(ch in NAME for ch in w) and all(ch in NAME or ch == UNC for ch in w):
            sig = [NAME[ch] for ch in w if ch in NAME]; tok += 1
            if len(sig) == 1: single[sig[0]] += 1
            else:
                ctx = ' '.join(x if x != '\n' else '/' for x in T[max(0, j - 4):j + 3])
                if UNC in w: unc_comp[' '.join(sig)] += 1
                else: occ[' '.join(sig)].append((key, v.get('site'), v.get('support'), ctx))
print('fraction tokens (one word of the sign layer):', tok, '| single-sign tokens:', sum(single.values()), '| runs of 2+ signs, certain:', sum(len(x) for x in occ.values()), '| uncertain:', sum(unc_comp.values()), dict(unc_comp))
print('single signs incl. ligature signs:', single.most_common())
for sig, L in sorted(occ.items(), key=lambda kv: -len(kv[1])):
    print(f'\n{sig}  x{len(L)}')
    for key, site, sup, ctx in L: print(f'    {key:12s} {str(site)[:14]:14s} {str(sup)[:10]:10s} … {ctx}')
