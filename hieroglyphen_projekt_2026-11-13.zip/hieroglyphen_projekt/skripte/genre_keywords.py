import sys, os, re, collections, math, unicodedata
bdir = sys.argv[1]
SEG = re.compile(r'''<seg id=['"]b\.([A-Z0-9]+)\.(\d+)\.(\d+)['"][^>]*>(.*?)</seg>''', re.S)
def norm(text, sm):
    t = text.lower()
    if sm: t = ''.join(c for c in unicodedata.normalize('NFD', t) if unicodedata.category(c) != 'Mn')
    t = t.replace('ـ', ''); return [w for w in re.split(r'[^\w]+', ''.join(c if unicodedata.category(c)[0] == 'L' else ' ' for c in t)) if w]
GEN = {'Bauanleitung': [('EXO', 25, 30), ('EXO', 36, 39), ('1KI', 6, 7), ('2CH', 3, 4), ('EZE', 40, 43)], 'Ritualvorschrift': [('LEV', 1, 16), ('NUM', 28, 29)], 'Hymnen': [('PSA', 1, 150)]}
for lang, (fn, sm) in {'Latein': ('Latin', False), 'Deutsch': ('German', False), 'Arabisch': ('Arabic', True), 'Chinesisch': ('Chinese-tok', False)}.items():
    V = collections.defaultdict(list); allc = collections.Counter()
    for b, ch, v, x in SEG.findall(open(os.path.join(bdir, fn + '.xml'), encoding='utf-8').read()):
        w = norm(x, sm) if lang != 'Chinesisch' else [t for t in x.split() if all(unicodedata.category(c) == 'Lo' for c in t)]
        V[(b, int(ch))] += w; allc.update(w)
    NT = sum(allc.values())
    for g, parts in GEN.items():
        c = collections.Counter(w for b, a, e in parts for ch in range(a, e + 1) for w in V.get((b, ch), [])); ni = sum(c.values()); nj = NT - ni; a0 = 500.0; sc = []
        for w, y in c.items():
            if y < 8: continue
            al = a0*allc[w]/NT; yj = allc[w] - y; d = math.log((y + al)/(ni + a0 - y - al)) - math.log((yj + al)/(nj + a0 - yj - al)); sc.append((d/math.sqrt(1/(y + al) + 1/(yj + al)), w, y))
        print(f'{lang:10s} {g:17s} ({ni} words): ' + ' '.join(f'{w}:{y}' for _, w, y in sorted(sc, reverse=True)[:16]))
