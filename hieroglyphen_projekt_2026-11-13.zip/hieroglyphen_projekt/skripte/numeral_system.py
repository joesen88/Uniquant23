import json, sys, glob, os, re, collections, hashlib, math
import numpy as np
root = sys.argv[1]
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*')
words = []   # (text, signs, pos, written_form)
for p in sorted(glob.glob(os.path.join(root,'_aes_*.json'))):
    d = json.load(open(p,encoding='utf-8'))
    for sid, s in d.items():
        for t in s.get('token', []):
            h = t.get('hiero')
            if not h: continue
            sg = SIGN.findall(h)
            if sg: words.append((s['text'], sg, t.get('pos'), t.get('written_form')))
tot_tokens = sum(len(w[1]) for w in words)
print('words with signs', len(words), 'sign tokens', tot_tokens)
# ---------- A: blind search on the script layer only (no pos, no reading)
runs = collections.defaultdict(collections.Counter)
for _, sg, _, _ in words:
    i = 0
    while i < len(sg):
        j = i
        while j < len(sg) and sg[j] == sg[i]: j += 1
        runs[sg[i]][j-i] += 1; i = j
cand = {}
for s, c in runs.items():
    long_runs = sum(v for k, v in c.items() if k >= 4)
    if long_runs >= 20: cand[s] = (long_runs, max(c), sum(c.values()))
print('A1 signs with >=20 runs of length>=4:', len(cand), 'of', len(runs), 'sign types')
for s,(lr,mx,n) in sorted(cand.items(), key=lambda x:-x[1][0]):
    c = runs[s]; print(f'   {s:6s} runs>=4: {lr:5d}  max run {mx:2d}  run-length hist 1..10:', [c.get(k,0) for k in range(1,11)])
C = set(cand)
pure = [w for w in words if all(x in C for x in w[1])]
pure_multi = [w for w in pure if len(set(w[1])) >= 2]
before = collections.Counter()
for _, sg, _, _ in pure_multi:
    order = []
    for x in sg:
        if not order or order[-1] != x: order.append(x)
    for i in range(len(order)):
        for j in range(i+1, len(order)): before[(order[i], order[j])] += 1
wins = collections.Counter(); cons = tot = 0
for (a,b), n in before.items():
    m = before.get((b,a), 0)
    if a < b or (b,a) not in before:
        cons += max(n,m); tot += n+m
    wins[a] += n
rank = sorted(C, key=lambda s: -sum(1 for t in C if before.get((s,t),0) > before.get((t,s),0)))
print('A2 words made only of these signs:', len(pure), ' with >=2 different signs:', len(pure_multi))
print('A2 order consistency (pairs in majority direction):', round(cons/max(tot,1),4), 'of', tot, 'pair observations')
print('A2 inferred order, first = always written first:', rank)
print('A3 max run length over candidates:', max(v[1] for v in cand.values()), '| share of runs longer than 9:', round(sum(v for s in C for k,v in runs[s].items() if k>9)/sum(sum(runs[s].values()) for s in C),5))
pure_tokens = sum(len(w[1]) for w in pure)
print('A4 share of all sign tokens inside such words:', round(pure_tokens/tot_tokens,4))
# how well does the blind class match the interpretation label "numeral"?
num_words = [w for w in words if w[2]=='numeral']
tp = sum(1 for w in pure if w[2]=='numeral')
print('A5 check against interpretation layer: pure words', len(pure), 'of which labelled numeral', tp, '| numerals with signs', len(num_words), 'recall', round(tp/max(len(num_words),1),3), 'precision', round(tp/max(len(pure),1),3))
# ---------- B: recover sign values by regression from stated integer values (uses interpretation layer)
ints = [(t, sg, int(wf)) for t, sg, pos, wf in num_words if wf and re.fullmatch(r'\d+', wf)]
cnt = collections.Counter(x for _, sg, _ in ints for x in sg)
feats = [s for s, n in cnt.items() if n >= 10]
fi = {s:i for i,s in enumerate(feats)}
usable = [(t,sg,v) for t,sg,v in ints if all(x in fi for x in sg)]
def split(t): return int(hashlib.sha256(t.encode()).hexdigest(),16) % 5 == 0
tr = [u for u in usable if not split(u[0])]; te = [u for u in usable if split(u[0])]
def mat(rows):
    X = np.zeros((len(rows), len(feats))); y = np.zeros(len(rows))
    for i,(t,sg,v) in enumerate(rows):
        for x in sg: X[i, fi[x]] += 1
        y[i] = v
    return X, y
Xtr, ytr = mat(tr); Xte, yte = mat(te)
# robust fit: iteratively drop gross outliers (mis-encodings), keep weights exact
keep = np.ones(len(ytr), bool)
for it in range(6):
    w, *_ = np.linalg.lstsq(Xtr[keep], ytr[keep], rcond=None)
    res = np.abs(Xtr @ w - ytr)
    keep = res <= 0.5
w_round = np.round(w)
pred = Xte @ w_round
print('B integer numerals with signs:', len(ints), 'usable', len(usable), 'train', len(tr), 'test', len(te), '| train rows kept after outlier removal', int(keep.sum()))
print('B recovered values (sign: fitted -> rounded, n):')
for s in sorted(feats, key=lambda s: (w_round[fi[s]], s)):
    print(f'   {s:6s} {w[fi[s]]:12.3f} -> {int(w_round[fi[s]]):8d}   n={cnt[s]}')
print('B held-out exact agreement, sum of sign values == stated number:', int((pred==yte).sum()), 'of', len(yte), '=', round(float((pred==yte).mean()),4))
big = sorted(set(int(v) for v in yte))[-8:]
print('B largest held-out values:', big)
