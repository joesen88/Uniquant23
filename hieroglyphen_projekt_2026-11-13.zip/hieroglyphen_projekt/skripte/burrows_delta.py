"""Burrows' Delta on the Egyptian corpus (lemma level and blind sign level), with a Latin control.
Delta(A,B) = mean_i |z_i(A) - z_i(B)|, z_i = (f_i - mu_i) / sigma_i over the n most frequent items.
usage: python3 -I burrows_delta.py <aes_tokens_cache.json.gz> <aes_texts_cache.json.gz> <latin library dir>
"""
import sys, gzip, json, re, os, collections
import numpy as np

C = collections.Counter
tok_p, txt_p, lat_dir = sys.argv[1], sys.argv[2], sys.argv[3]


def zscores(docs, n):
    tot = C()
    for d in docs: tot.update(d)
    vocab = [w for w, _ in tot.most_common(n)]
    idx = {w: i for i, w in enumerate(vocab)}
    F = np.zeros((len(docs), len(vocab)))
    for r, d in enumerate(docs):
        L = len(d)
        for w, k in C(d).items():
            j = idx.get(w)
            if j is not None: F[r, j] = k / L
    mu = F.mean(axis=0); sd = F.std(axis=0); sd[sd == 0] = 1.0
    return (F - mu) / sd, vocab


def burrows(Z):
    M = Z.shape[0]; D = np.zeros((M, M))
    for i in range(M): D[i] = np.abs(Z - Z[i]).mean(axis=1)
    return D


def cosine(Z):
    nrm = np.linalg.norm(Z, axis=1, keepdims=True); nrm[nrm == 0] = 1.0
    X = Z / nrm
    return 1.0 - X @ X.T


def nn(D, labels, ids=None, exclude_same_id=False):
    """share of items whose nearest neighbour has the same label; chance level for that"""
    labels = np.array(labels); M = len(labels); hit = 0; chance = 0.0
    idarr = np.array(ids) if ids is not None else None
    for i in range(M):
        d = D[i].copy(); mask = np.ones(M, dtype=bool); mask[i] = False
        if exclude_same_id: mask &= idarr != idarr[i]
        d[~mask] = np.inf
        j = int(np.argmin(d)); hit += labels[j] == labels[i]
        chance += (labels[mask] == labels[i]).sum() / mask.sum()
    return hit / M, chance / M


def report(name, docs, labels, ids, ns=(50, 150, 500), sibling=False):
    print(f'\n{name}: {len(docs)} items, {len(set(labels))} classes: ' + ', '.join(f'{k} {v}' for k, v in C(labels).most_common(8)))
    for n in ns:
        Z, vocab = zscores(docs, n)
        for dn, D in (('Burrows', burrows(Z)), ('Cosine ', cosine(Z))):
            out = f'  n={len(vocab):4d} {dn}: '
            if sibling:
                a, c = nn(D, ids)
                out += f'nearest item is the other half of the same text: {a:6.1%} (chance {c:.1%}) | '
                a2, c2 = nn(D, labels, ids, exclude_same_id=True)
                out += f'same class among other texts: {a2:6.1%} (chance {c2:.1%})'
            else:
                a2, c2 = nn(D, labels)
                out += f'nearest text has the same class: {a2:6.1%} (chance {c2:.1%})'
            print(out)
    return


# ---------- Egyptian, lemma level ----------
T = json.load(gzip.open(tok_p, 'rt', encoding='utf-8'))
texts = {}
for tid, t in T.items():
    lem = [tk[0] for tk in t['tok'] if tk[0] and tk[2] not in ('entity_name', 'numeral')]
    texts[tid] = (t['corpus'], lem)
docs = [(tid, c, l) for tid, (c, l) in texts.items() if len(l) >= 300]
report('Egyptian, whole texts (>= 300 lemmatised words), lemmas', [l for _, _, l in docs], [c for _, c, _ in docs], [t for t, _, _ in docs])
ch = []
for tid, (c, l) in texts.items():
    if len(l) >= 1000:
        ch.append((tid, c, l[:500])); ch.append((tid, c, l[500:1000]))
report('Egyptian, two 500-word halves per text (texts >= 1000 words), lemmas', [l for _, _, l in ch], [c for _, c, _ in ch], [t for t, _, _ in ch], sibling=True)

# centroids of the groups in z-space
Z, vocab = zscores([l for _, _, l in docs], 150)
labs = [c for _, c, _ in docs]
groups = [g for g, k in C(labs).items() if k >= 5]
cen = np.array([Z[[i for i, c in enumerate(labs) if c == g]].mean(axis=0) for g in groups])
Dg = burrows(cen)
print('\ngroup centroids (150 most frequent lemmas): nearest groups by Delta')
for i, g in enumerate(groups):
    order = np.argsort(Dg[i])[1:4]
    print(f'  {g:22s} n={C(labs)[g]:4d}  ' + ' ; '.join(f'{groups[j]} {Dg[i, j]:.2f}' for j in order))
R = np.corrcoef(Z.T); off = np.abs(R[np.triu_indices_from(R, k=1)])
print(f'feature dependence among the 150 lemma frequencies: mean |r| = {off.mean():.3f}; share of pairs with |r| > 0.3: {(off > 0.3).mean():.1%}')
gl = {}
for t in T.values():
    for tk in t['tok']:
        if tk[0] and tk[0] not in gl: gl[tk[0]] = tk[1]
print('first 25 features:', ' '.join(gl.get(v, '?') for v in vocab[:25]))

# ---------- Egyptian, blind sign level ----------
S = json.load(gzip.open(txt_p, 'rt', encoding='utf-8'))
chs = []; whole = []
for tid, t in S.items():
    sg = t.get('signs') or []
    if len(sg) >= 1000:
        chs.append((tid, t['corpus'], sg[:500])); chs.append((tid, t['corpus'], sg[500:1000]))
    if len(sg) >= 600: whole.append((tid, t['corpus'], sg))
report('Egyptian, whole texts (>= 600 signs), signs only', [l for _, _, l in whole], [c for _, c, _ in whole], [t for t, _, _ in whole], ns=(50, 150))
report('Egyptian, two 500-sign halves per text (texts >= 1000 signs), signs only', [l for _, _, l in chs], [c for _, c, _ in chs], [t for t, _, _ in chs], ns=(50, 150), sibling=True)

# ---------- Latin control: authors ----------
lat = []
for root, _, files in os.walk(lat_dir):
    for f in sorted(files):
        if not f.endswith('.txt'): continue
        rel = os.path.relpath(os.path.join(root, f), lat_dir)
        author = rel.split(os.sep)[0]
        author = re.sub(r'\d*\.txt$', '', author)
        with open(os.path.join(root, f), encoding='utf-8', errors='replace') as fh:
            words = re.findall(r"[^\W\d_]+", fh.read().lower())
        if len(words) >= 1000: lat.append((rel, author, words))
per = collections.defaultdict(list)
for rel, a, w in lat: per[a].append((rel, w))
chl = []
for a, fl in per.items():
    for rel, w in fl[:14]:
        chl.append((rel, a, w[:500])); chl.append((rel, a, w[500:1000]))
report('Latin control, two 500-word halves per file, word forms; class = author', [l for _, _, l in chl], [c for _, c, _ in chl], [t for t, _, _ in chl], ns=(50, 150, 500), sibling=True)
