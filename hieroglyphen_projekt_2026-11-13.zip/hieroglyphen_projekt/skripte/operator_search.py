import json, sys, glob, os, re, collections, random
from fractions import Fraction
root = sys.argv[1]
random.seed(20261112)
def parse_num(wf):
    if not wf: return None
    w = wf.strip()
    m = re.fullmatch(r'(\d+)', w)
    if m: return Fraction(int(m.group(1)))
    m = re.fullmatch(r'(\d+)/(\d+)', w)
    if m and int(m.group(2)): return Fraction(int(m.group(1)), int(m.group(2)))
    m = re.fullmatch(r'(\d+)-(\d+)/(\d+)', w)
    if m and int(m.group(3)): return Fraction(int(m.group(1))) + Fraction(int(m.group(2)), int(m.group(3)))
    return None
texts = collections.OrderedDict()   # text -> list of tokens (lemma, gloss, hiero, value or None)
corp = {}
for p in sorted(glob.glob(os.path.join(root,'_aes_*.json'))):
    d = json.load(open(p,encoding='utf-8'))
    for sid, s in d.items():
        L = texts.setdefault(s['text'], []); corp[s['text']] = s['corpus']
        for t in s.get('token', []):
            v = parse_num(t.get('written_form')) if t.get('pos') == 'numeral' else None
            L.append((t.get('lemma_form') or t.get('written_form'), (t.get('cotext_translation') or '')[:40], t.get('hiero'), v))
        L.append(('<S>', '', None, None))
nums_total = sum(1 for L in texts.values() for x in L if x[3] is not None)
print('texts', len(texts), 'numeral tokens with parsed value', nums_total)
# ---------- 1) cyclic counters: lemma directly before a number, hard maximum
ctx = collections.defaultdict(list); ctx_h = collections.defaultdict(collections.Counter); gloss = {}
for L in texts.values():
    for i in range(1, len(L)):
        if L[i][3] is not None and L[i-1][3] is None and L[i-1][0] != '<S>' and L[i][3].denominator == 1:
            ctx[L[i-1][0]].append(int(L[i][3])); gloss.setdefault(L[i-1][0], L[i-1][1])
            if L[i-1][2]: ctx_h[L[i-1][0]][L[i-1][2]] += 1
print('\n1) words directly before an integer: n, max, distinct, share of 1..max that occurs')
rows = []
for lem, vals in ctx.items():
    if len(vals) < 40: continue
    mx = max(vals); dist = len(set(vals)); cover = len(set(v for v in vals if 1 <= v <= mx)) / mx
    rows.append((lem, len(vals), mx, dist, cover))
for lem, n, mx, dist, cover in sorted(rows, key=lambda r: (-(r[4] >= 0.8 and r[2] >= 3), -r[1]))[:16]:
    sp = ctx_h[lem].most_common(1)[0][0] if ctx_h[lem] else '-'
    print(f'   {lem[:16]:16s} n={n:5d} max={mx:5d} distinct={dist:3d} cover={cover:.2f}  signs={sp[:22]:22s} | {gloss[lem]}')
# ---------- 2) arithmetic relations among neighbouring numbers, with shuffle null
def seqs():
    out = []
    for tid, L in texts.items():
        idx = [i for i, x in enumerate(L) if x[3] is not None]
        if len(idx) >= 3: out.append((tid, L, idx))
    return out
S = seqs()
def count_rel(values_by_text, collect=False):
    c = collections.Counter(); hits = []
    for (tid, L, idx), vals in zip(S, values_by_text):
        n = len(vals)
        for j in range(2, n):
            vj = vals[j]
            if vj >= 5:
                acc = Fraction(0)
                for k in range(1, 16):
                    if j-k < 0 or idx[j] - idx[j-k] > 80: break
                    acc += vals[j-k]
                    if k >= 2 and acc == vj and vj > max(vals[j-k:j]):
                        c['sum'] += 1
                        if collect: hits.append(('sum', tid, idx[j], k, vj))
                        break
                    if acc > vj: break
            a, b = vals[j-2], vals[j-1]
            if idx[j] - idx[j-2] <= 30:
                if a >= 2 and b >= 2 and a*b == vj and vj >= 6:
                    c['product'] += 1
                    if collect: hits.append(('product', tid, idx[j], 2, vj))
                if b >= 1 and a - b == vj and vj >= 1 and a >= 5:
                    c['difference'] += 1
                    if collect: hits.append(('difference', tid, idx[j], 2, vj))
        # arithmetic progressions: >=4 consecutive numbers with constant non-zero step
        run = 1
        for j in range(2, n):
            if vals[j]-vals[j-1] == vals[j-1]-vals[j-2] != 0: run += 1
            else:
                if run >= 3: c['progression>=4'] += 1
                run = 1
        if run >= 3: c['progression>=4'] += 1
    return (c, hits) if collect else c
real_vals = [[L[i][3] for i in idx] for tid, L, idx in S]
real, hits = count_rel(real_vals, collect=True)
null = collections.defaultdict(list)
for r in range(200):
    sh = []
    for v in real_vals:
        w = v[:]; random.shuffle(w); sh.append(w)
    c = count_rel(sh)
    for k in ('sum','product','difference','progression>=4'): null[k].append(c.get(k,0))
print('\n2) relations among neighbouring numbers: observed vs 200 shuffles within text (mean, max)')
for k in ('sum','product','difference','progression>=4'):
    m = sum(null[k])/len(null[k]); print(f'   {k:16s} observed {real.get(k,0):5d}   null mean {m:7.1f}  null max {max(null[k]):5d}')
# ---------- 3) which word stands right before the result number? enrichment vs all numbers
base = collections.Counter(); 
for tid, L, idx in S:
    for i in idx:
        j = i-1
        while j >= 0 and L[j][3] is not None: j -= 1
        if j >= 0: base[L[j][0]] += 1
nb = sum(base.values())
for rel in ('sum','product'):
    hc = collections.Counter(); hs = collections.defaultdict(collections.Counter); hg = {}
    hr = [h for h in hits if h[0] == rel]
    for _, tid, pos, k, v in hr:
        L = texts[tid]; j = pos-1
        while j >= 0 and L[j][3] is not None: j -= 1
        if j >= 0:
            hc[L[j][0]] += 1; hg.setdefault(L[j][0], L[j][1])
            if L[j][2]: hs[L[j][0]][L[j][2]] += 1
    print(f'\n3) word before the result of a {rel} (n={len(hr)}): count, share, lift vs all numbers')
    for lem, n in hc.most_common(6):
        lift = (n/len(hr)) / (base[lem]/nb) if base[lem] else float('inf')
        sp = hs[lem].most_common(1)[0][0] if hs[lem] else '-'
        print(f'   {lem[:16]:16s} {n:4d}  {n/len(hr):5.1%}  lift {lift:6.1f}  signs={sp[:20]:20s} | {hg[lem]}')
    bc = collections.Counter(corp[h[1]] for h in hr); print('   by corpus:', bc.most_common(5))
    ex = sorted(hr, key=lambda h: -h[4])[:3]
    for _, tid, pos, k, v in ex:
        L = texts[tid]; js = [i for i in range(max(0,pos-80), pos) if L[i][3] is not None][-k:]
        print('   example:', ' + '.join(str(L[i][3]) for i in js) if rel=='sum' else ' * '.join(str(L[i][3]) for i in js), '=', v)
