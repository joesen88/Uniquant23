"""Third probe: incompleteness and ambiguity built separately, many readings, looking for an exact 0.67094.
usage: python3 -I corazza_measures_probe3.py"""
import itertools, math, collections
from fractions import Fraction as Fr
C = collections.Counter
def reps(vals, kmax, maxmult):
    """value -> Counter(length -> number of multisets)"""
    r = collections.defaultdict(C); n = len(vals)
    for k in range(1, kmax + 1):
        for c in itertools.combinations_with_replacement(range(n), k):
            if max(C(c).values()) > maxmult: continue
            s = sum(vals[i] for i in c)
            if s < 1: r[s][k] += 1
    return r
core = [Fr(1, 2), Fr(1, 4), Fr(1, 8), Fr(1, 5), Fr(1, 6), Fr(1, 10), Fr(1, 20), Fr(1, 30), Fr(1, 40), Fr(1, 60)]
sols = {'best (1/32, 1/36)': core + [Fr(1, 32), Fr(1, 36)], 'final (1/16, 1/24)': core + [Fr(1, 16), Fr(1, 24)]}
def comps(vals):
    out = {}
    Dmax = max(v.denominator for v in vals)
    for kmax in (3, 4, 5):
        for maxmult in (1, 2, 4):
            if maxmult > kmax: continue
            r = reps(vals, kmax, maxmult)
            for dn, D in (('all', range(2, Dmax + 1)), ('signs', sorted({v.denominator for v in vals}))):
                for slots in ('unreduced', 'reduced/phi', 'reduced/(d-1)'):
                    inc = []; amb = collections.defaultdict(list)
                    for d in D:
                        ks = [k for k in range(1, d) if slots == 'unreduced' or math.gcd(k, d) == 1]
                        den = (d - 1) if slots != 'reduced/phi' else len(ks)
                        inc.append(sum(1 for k in ks if Fr(k, d) not in r) / den)
                        a_any = a_min = a_same = 0
                        for k in ks:
                            x = r.get(Fr(k, d))
                            if not x: continue
                            if sum(x.values()) > 1: a_any += 1
                            if x[min(x)] > 1: a_min += 1
                            if any(c > 1 for c in x.values()): a_same += 1
                        amb['any'].append(a_any / den); amb['minimal length'].append(a_min / den); amb['same length'].append(a_same / den)
                    m = lambda x: sum(x) / len(x)
                    out[('inc', kmax, maxmult, dn, slots)] = m(inc)
                    for an, a in amb.items(): out[('amb:' + an, kmax, maxmult, dn, slots)] = m(a)
    return out
R = {n: comps(v) for n, v in sols.items()}
b = R['best (1/32, 1/36)']; f = R['final (1/16, 1/24)']
incs = [k for k in b if k[0] == 'inc']; ambs = [k for k in b if k[0] != 'inc']
hits = []
for i in incs:
    hits.append((abs(b[i] - 0.67094), b[i], f[i], i, None))
    for a in ambs:
        if a[3] != i[3]: continue
        hits.append((abs(b[i] + b[a] - 0.67094), b[i] + b[a], f[i] + f[a], i, a))
hits.sort(key=lambda x: x[0])
print('closest readings to 0.67094 (best solution) | same reading for the final solution:')
for dist, g, gf, i, a in hits[:14]:
    print(f'   {g:.5f} (off {dist:.5f}) | final {gf:.5f} | incompleteness: kmax={i[1]} maxmult={i[2]} den={i[3]} slots={i[4]}' + (f' + ambiguity[{a[0][4:]}]: kmax={a[1]} maxmult={a[2]} slots={a[4]}' if a else ''))
print('readings tried:', len(hits))
