"""Which lemmas of the AES corpus name stars, constellations or decans? Lists candidates by their German translation only
(no context measures), so that the class of star names can be fixed before the comparison in kings_stars.py.
usage: python3 -I stars_probe.py <dir with _aes_*.json>"""
import sys, os, json, re, collections
d = sys.argv[1]
KEY = re.compile(r'Orion|Sothis|Sirius|Stern|Dekan|Gestirn|Stierschenkel|Großer Bär|Großer Wagen|Unvergänglich|Unermüdlich|Plejaden|Zirkumpolar|Himmelsgegend|Milchstraße|Planet|Venus|Jupiter|Mars\b|Saturn|Merkur')
L = collections.defaultdict(lambda: {'n': 0, 'tr': collections.Counter(), 'pos': collections.Counter(), 'name': collections.Counter(), 'corp': collections.Counter(), 'date': collections.Counter()})
ntok = 0
for fn in sorted(os.listdir(d)):
    if not fn.startswith('_aes_'): continue
    data = json.load(open(os.path.join(d, fn), encoding='utf-8'))
    for s in data.values():
        for tk in s['token']:
            ntok += 1
            tr = tk.get('cotext_translation') or ''
            if not KEY.search(tr): continue
            e = L[(str(tk.get('lemmaID') or ''), tk.get('lemma_form') or '')]
            e['n'] += 1; e['tr'][tr[:40]] += 1; e['pos'][tk.get('pos') or ''] += 1; e['name'][tk.get('name') or ''] += 1; e['corp'][s['corpus']] += 1; e['date'][s.get('date') or '?'] += 1
    del data
print('tokens read', ntok, '| lemmas with a star word in the translation:', len(L), '| their tokens:', sum(e['n'] for e in L.values()))
for (lid, lf), e in sorted(L.items(), key=lambda kv: -kv[1]['n']):
    if e['n'] < 3: continue
    print(f"{lid:>7s} {lf:22s} n={e['n']:4d} pos={dict(e['pos'].most_common(2))} name={dict(e['name'].most_common(2))} | {'; '.join(f'{t} {c}' for t, c in e['tr'].most_common(2))} | {dict(e['corp'].most_common(3))}")
