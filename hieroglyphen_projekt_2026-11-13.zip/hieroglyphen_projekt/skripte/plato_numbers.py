"""Number vocabulary in Plato (Perseus Greek texts) and number-word frequencies in Bible translations.
usage: python3 -I plato_numbers.py <tlg0059 dir> [<bibles dir>]
Form-based counts (no lemmatiser): Greek tokens are stripped of accents; breathings are used
where they distinguish number words (heis/eis, hen/en, hex/ex, hektos/ektos).
"""
import sys, os, re, glob, unicodedata, collections, math, html

C = collections.Counter
ROUGH = '̔'
TOK = re.compile(r"[Ͱ-Ͽἀ-῿̀-ͯʼ’']+")
END = r'(?:οσ|ου|ω|ον|ε|η|ησ|ην|οι|ων|οισ|ουσ|α|ασ|αν|αι|αισ)'


def norm(tok):
    t = re.sub(r"[ʼ’']", '', tok)
    d = unicodedata.normalize('NFD', t).lower()
    rough = ROUGH in d[:5]
    plain = ''.join(ch for ch in d if unicodedata.category(ch) == 'Ll').replace('ς', 'σ')
    return plain, rough


TENS = {'εικοσι': 20, 'εικοσιν': 20, 'τριακοντα': 30, 'τετταρακοντα': 40, 'τεσσαρακοντα': 40, 'πεντηκοντα': 50,
        'εξηκοντα': 60, 'εβδομηκοντα': 70, 'ογδοηκοντα': 80, 'ενενηκοντα': 90, 'εκατον': 100,
        'ενδεκα': 11, 'δωδεκα': 12}
TEENS = re.compile(r'^(τρεισκαιδεκα|τρισκαιδεκα|τριακαιδεκα|τετταρεσκαιδεκα|τετταρακαιδεκα|πεντεκαιδεκα|εκκαιδεκα|επτακαιδεκα|οκτωκαιδεκα|εννεακαιδεκα)')
HUND = re.compile(r'^(διακοσι|τριακοσι|τετρακοσι|πεντακοσι|εξακοσι|επτακοσι|οκτακοσι|ενακοσι)')
MYR = re.compile(r'^(δισ|τρισ|[α-ω]+κισ)?μυρι')


def cardinal(p, r):
    if r and p in ('εισ', 'εν', 'ενοσ', 'ενι', 'ενα'): return 1
    if p in ('μια', 'μιασ', 'μιαν'): return 1
    if p in ('δυο', 'δυοιν', 'δυειν', 'δυσι', 'δυσιν', 'δυ'): return 2
    if p in ('τρεισ', 'τρια', 'τριων', 'τρισι', 'τρισιν'): return 3
    if re.fullmatch(r'τε(ττ|σσ)αρ(εσ|α|ασ|ων)|τε(ττ|σσ)αρσιν?', p): return 4
    if p in ('πεντε', 'πενθ'): return 5
    if r and p == 'εξ': return 6
    if p in ('επτα', 'εφθ'): return 7
    if p == 'οκτω': return 8
    if p == 'εννεα': return 9
    if p == 'δεκα': return 10
    if p in TENS: return TENS[p]
    if TEENS.match(p): return 15       # class "13..19"
    if HUND.match(p): return 500       # class "200..900"
    if 'χιλι' in p: return 1000
    if MYR.match(p) and not p.startswith('μυριζ') and not p.startswith('μυρικ'): return 10000
    return None


ORD = {'πρωτ': 1, 'δευτερ': 2, 'τριτ': 3, 'τεταρτ': 4, 'πεμπτ': 5, 'εκτ': 6, 'εβδομ': 7, 'ογδο': 8, 'ενατ': 9, 'δεκατ': 10}
ORD_RE = {k: re.compile('^' + k + END + '$') for k in ORD}


def ordinal(p, r):
    for k, v in ORD.items():
        if ORD_RE[k].match(p):
            if k == 'εκτ' and not r: return None
            return v
    return None


VOC = [
    ('Verhältnis/Vielfaches', 'diplasios (doppelt)', r'^διπλασι'),
    ('Verhältnis/Vielfaches', 'triplasios … (n-fach)', r'^(τρι|τετρα|πεντα|εξα|επτα|οκτα|εννεα|δεκα|εικοσα|εκατοντα)πλασι'),
    ('Verhältnis/Vielfaches', 'pollaplasios (vielfach)', r'^πολλαπλασι'),
    ('Verhältnis/Vielfaches', 'hemiolios 3:2', r'^ημιολι'),
    ('Verhältnis/Vielfaches', 'epitritos 4:3', r'^επιτριτ'),
    ('Verhältnis/Vielfaches', 'epogdoos 9:8', r'^επογδο'),
    ('Verhältnis/Vielfaches', 'analogia (Proportion)', r'^αναλογι(α|ασ|αν|αι|ων|αισ)$|^αναλογον$'),
    ('Verhältnis/Vielfaches', 'symmetros (kommensurabel/ebenmäßig)', r'^(συμ|ξυμ)μετρ'),
    ('Verhältnis/Vielfaches', 'asymmetros (inkommensurabel)', r'^α(συμ|ξυμ)μετρ'),
    ('Teil', 'hemisys (Hälfte)', r'^ημισ(υ|ε)'),
    ('Teil', 'tritemorion u.ä. (n-ter Teil)', r'^(τριτη|τεταρτη|πεμπτη|εκτη|δεκατη|πολλοστη)μορι'),
    ('Teil', 'meros/morion (Teil)', r'^μερ(οσ|ουσ|ει|η|ων|εσι|εσιν)$|^μορι(ον|ου|ω|α|ων|οισ)$'),
    ('Eigenschaft', 'artios (gerade)', r'^αρτι(οσ|ου|ω|ον|οι|ων|οισ|ουσ|α|ασ|αν|αι|αισ)$'),
    ('Eigenschaft', 'perittos (ungerade/überzählig)', r'^περιττ' + END + '$'),
    ('Fach', 'arithmos, arithmein (Zahl, zählen)', r'^αριθμ(?!ητικ)'),
    ('Fach', 'arithmetike', r'^αριθμητικ'),
    ('Fach', 'logistike (Rechenkunst)', r'^λογιστικ'),
    ('Fach', 'logismos/logizesthai (rechnen, überlegen)', r'^λογισμ|^λογιζ|^ελογιζ|^λογισ(α|ω|η|ε)'),
    ('Fach', 'geometria', r'^γεωμετρ'),
    ('Fach', 'metretike/metrein (messen)', r'^μετρητ|^μετρ(ει|ου|ω|η)|^εμετρ'),
    ('Fach', 'astronomia', r'^αστρονομ'),
    ('Figur', 'trigonon (Dreieck)', r'^τριγων'),
    ('Figur', 'tetragonon (Quadrat)', r'^τετραγων'),
    ('Figur', 'gonia (Winkel)', r'^γωνι'),
    ('Figur', 'diametros (Diagonale)', r'^διαμετρ'),
    ('Figur', 'kybos (Würfel)', r'^κυβ(οσ|ου|ω|ον|οι|ων|οισ|ουσ)$'),
    ('Figur', 'pyramis', r'^πυραμι(σ|δ)'),
    ('Figur', 'oktaedron/eikosaedron', r'^(οκταεδρ|εικοσαεδρ|δωδεκαεδρ)'),
    ('Figur', 'epipedos (eben)', r'^επιπεδ'),
    ('Figur', 'stereos (Körper/fest)', r'^στερε' + END + '$'),
]
VOC_RE = [(g, n, re.compile(rx)) for g, n, rx in VOC]


def sections(path):
    s = open(path, encoding='utf-8').read()
    m = re.search(r'<body.*?</body>', s, flags=re.S)
    b = m.group(0) if m else s
    for tag in ('note', 'label', 'head', 'bibl', 'speaker'):
        b = re.sub(r'<%s\b[^>]*>.*?</%s>' % (tag, tag), ' ', b, flags=re.S)
    mark = lambda m: ' \x00' + m.group(1) + '\x00 '
    b = re.sub(r'<milestone[^>]*unit="section"[^>]*n="([^"]+)"[^>]*/>', mark, b)
    b = re.sub(r'<milestone[^>]*n="([^"]+)"[^>]*unit="section"[^>]*/>', mark, b)
    b = re.sub(r'<[^>]+>', ' ', b)
    b = html.unescape(b)
    parts = re.split(r'\x00([^\x00]+)\x00', b)
    out = [('0', parts[0])]
    for i in range(1, len(parts) - 1, 2):
        out.append((parts[i], parts[i + 1]))
    return out


d = sys.argv[1]
TITLES = {}
works = {}
for w in sorted(os.listdir(d)):
    wd = os.path.join(d, w)
    if not os.path.isdir(wd): continue
    cts = os.path.join(wd, '__cts__.xml')
    t = open(cts, encoding='utf-8').read() if os.path.exists(cts) else ''
    m = re.search(r'<ti:title[^>]*>([^<]+)<', t)
    TITLES[w] = m.group(1) if m else w
    g = sorted(glob.glob(os.path.join(wd, '*grc*.xml')))
    if g: works[w] = g[-1]

tot = C(); card = collections.defaultdict(C); ordn = collections.defaultdict(C); voc = collections.defaultdict(C)
secdens = []
ctx = {}
for w, p in works.items():
    for sec, txt in sections(p):
        toks = TOK.findall(txt)
        nn = 0; n_tok = 0
        for tk in toks:
            pl, r = norm(tk)
            if not pl: continue
            n_tok += 1
            v = cardinal(pl, r)
            if v is not None:
                card[w][v] += 1
                if v >= 2: nn += 1
                continue
            o = ordinal(pl, r)
            if o is not None:
                ordn[w][o] += 1
                if o >= 2: nn += 1
                continue
            for g, n, rx in VOC_RE:
                if rx.search(pl):
                    voc[w][(g, n)] += 1
                    if g in ('Verhältnis/Vielfaches',) or n.startswith('hemisys') or n.startswith('tritemorion'): nn += 1
                    break
        tot[w] += n_tok
        secdens.append((nn, n_tok, TITLES[w], sec))
        if w == 'tlg034' and 'πεντήκοντα' in unicodedata.normalize('NFC', txt) and sec.startswith('73'):
            ctx['Laws ' + sec] = ' '.join(txt.split())[:420]
        if w == 'tlg006' and 'ἑπτακαιδεκάποδος' in unicodedata.normalize('NFC', txt):
            ctx['Theaetetus ' + sec] = ' '.join(txt.split())[:420]
        if w == 'tlg031' and sec in ('36a', '36b'):
            ctx['Timaeus ' + sec] = ' '.join(txt.split())[:520]

N = sum(tot.values())
print(f'Plato: {len(works)} works, {N} Greek tokens')
allc = C(); allo = C(); allv = C()
for w in works:
    allc.update(card[w]); allo.update(ordn[w]); allv.update(voc[w])
per = lambda x: 1e5 * x / N
print('cardinals (all works):', sorted(allc.items()))
print('ordinals  (all works):', sorted(allo.items()))
c2 = sum(v for k, v in allc.items() if k >= 2); o2 = sum(v for k, v in allo.items() if k >= 2)
print(f'cardinals >=2: {c2} = {per(c2):.0f} per 100k | "one": {allc[1]} = {per(allc[1]):.0f} | ordinals >=2: {o2} = {per(o2):.0f} | "first": {allo[1]} = {per(allo[1]):.0f}')
print('\nvocabulary (all works), per 100k tokens:')
bygroup = C()
for (g, n), c in sorted(allv.items(), key=lambda kv: (kv[0][0], -kv[1])):
    bygroup[g] += c
    top = sorted(((voc[w][(g, n)], TITLES[w]) for w in works if voc[w][(g, n)]), reverse=True)[:4]
    print(f'  {g:22s} {n:42s} {c:5d}  {per(c):6.1f}   top: ' + ', '.join(f'{t} {k}' for k, t in top))
print('  groups:', {g: (c, round(per(c), 1)) for g, c in bygroup.items()})

print('\nper work: tokens | cardinals>=2 per 100k | ratio/multiple words | even/odd | figure words')
for w in works:
    n = tot[w]
    c = sum(v for k, v in card[w].items() if k >= 2)
    ra = sum(v for (g, nm), v in voc[w].items() if g == 'Verhältnis/Vielfaches')
    eo = sum(v for (g, nm), v in voc[w].items() if g == 'Eigenschaft')
    fi = sum(v for (g, nm), v in voc[w].items() if g == 'Figur')
    print(f'  {TITLES[w]:16s} {n:7d} | {1e5*c/n:6.0f} | {ra:4d} = {1e5*ra/n:5.0f} | {eo:4d} | {fi:4d}')

print('\nsections with the most number words (cardinals>=2, ordinals>=2, ratio/part words):')
for nn, n_tok, t, sec in sorted(secdens, reverse=True)[:22]:
    print(f'  {t:14s} {sec:6s} {nn:3d} of {n_tok:4d} tokens = {nn/max(n_tok,1):.0%}')

def slope(pairs):
    xs = [math.log(a) for a, b in pairs if b > 0]; ys = [math.log(b) for a, b in pairs if b > 0]
    n = len(xs); mx = sum(xs) / n; my = sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs); sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    syy = sum((y - my) ** 2 for y in ys)
    return sxy / sxx, (sxy ** 2) / (sxx * syy)

b, r2 = slope([(v, allc[v]) for v in range(2, 10)])
print(f'\nPlato cardinals 2..9: slope {b:.2f} (R2 {r2:.2f}); counts 2..10:', [allc[v] for v in range(2, 11)], '| 12:', allc[12], '| 100:', allc[100], '| 1000:', allc[1000], '| myriad:', allc[10000])
for k, v in ctx.items():
    print('\n[' + k + ']', v)

if len(sys.argv) > 2:
    bd = sys.argv[2]
    SETS = {
        'Latin': {2: 'duo duae duos duas duorum duarum duobus duabus', 3: 'tres tria trium tribus', 4: 'quattuor quatuor', 5: 'quinque', 6: 'sex', 7: 'septem', 8: 'octo', 9: 'novem', 10: 'decem', 12: 'duodecim', 40: 'quadraginta', 100: 'centum', 1000: 'mille milia millia milibus millibus milium millium'},
        'English': {2: 'two', 3: 'three', 4: 'four', 5: 'five', 6: 'six', 7: 'seven', 8: 'eight', 9: 'nine', 10: 'ten', 12: 'twelve', 40: 'forty', 100: 'hundred', 1000: 'thousand thousands'},
        'German': {2: 'zwei zween zwo zweien zweier', 3: 'drei dreien dreier', 4: 'vier', 5: 'fünf', 6: 'sechs', 7: 'sieben', 8: 'acht', 9: 'neun', 10: 'zehn', 12: 'zwölf', 40: 'vierzig', 100: 'hundert', 1000: 'tausend'},
    }
    for lang, sets in SETS.items():
        p = os.path.join(bd, lang + '.xml')
        if not os.path.exists(p): print('missing', p); continue
        s = open(p, encoding='utf-8').read()
        verses = re.findall(r'<seg[^>]*>(.*?)</seg>', s, flags=re.S)
        words = re.findall(r"[^\W\d_]+", ' '.join(verses).lower())
        wc = C(words)
        cnt = {v: sum(wc[x] for x in forms.split()) for v, forms in sets.items()}
        b, r2 = slope([(v, cnt[v]) for v in range(2, 10)])
        print(f'\n{lang} Bible: {len(words)} words; counts 2..10: {[cnt[v] for v in range(2, 11)]} | 12: {cnt[12]} | 40: {cnt[40]} | 100: {cnt[100]} | 1000: {cnt[1000]} | slope 2..9: {b:.2f} (R2 {r2:.2f})')
