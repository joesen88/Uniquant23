import json, sys, glob, os, re, collections, math, random, statistics, gzip
import numpy as np
from scipy.stats import spearmanr
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
aes, scores_p, conc_p, cache_p = sys.argv[1:5]
random.seed(20261112); rng = np.random.default_rng(20261112)
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*')
if os.path.exists(cache_p):
    T = json.load(gzip.open(cache_p, 'rt', encoding='utf-8'))
else:
    T = {}
    for p in sorted(glob.glob(os.path.join(aes, '_aes_*.json'))):
        d = json.load(open(p, encoding='utf-8'))
        for sid, s in d.items():
            t = T.setdefault(s['text'], {'corpus': s['corpus'], 'date': s.get('date'), 'lem': [], 'sl': [], 'signs': []})
            n = 0
            for k in s.get('token', []):
                if not k.get('_id'): continue
                l = k.get('lemma_form') or k.get('written_form') or '?'
                if l == '[...]': continue
                t['lem'].append(l); n += 1
                if k.get('hiero'): t['signs'] += SIGN.findall(k['hiero'])
            if n: t['sl'].append(n)
    json.dump(T, gzip.open(cache_p, 'wt', encoding='utf-8'), ensure_ascii=False)
rows = json.load(open(scores_p, encoding='utf-8')); R = {r['text']: r for r in rows}
id2name = {}
for line in open(conc_p, encoding='utf-8'):
    p = line.rstrip('\n').split('\t')
    if len(p) == 2: id2name[p[1]] = p[0]
print('texts', len(T), 'scored', len(rows), 'names found for scored:', sum(1 for r in rows if r['text'] in id2name))
def nm(tid): return (id2name.get(tid, tid))[:70]
def mattr(seq, w):
    if len(seq) < w: return None
    c = collections.Counter(seq[:w]); tot = len(c); n = 1
    for i in range(w, len(seq)):
        a = seq[i-w]; c[a] -= 1
        if c[a] == 0: del c[a]
        c[seq[i]] += 1; tot += len(c); n += 1
    return tot/n/w
# 1 length confound
print('\n[1] Spearman D vs text length:', round(spearmanr([r['D'] for r in rows], [r['n'] for r in rows])[0], 2))
# 2 script-only difficulty
SG = collections.Counter(s for t in T.values() for s in t['signs']); NS = sum(SG.values())
ss = {s: -math.log2(c/NS) for s, c in SG.items()}
S = [(tid, sum(ss[x] for x in t['signs'])/len(t['signs']), mattr(t['signs'], 50), len(t['signs'])) for tid, t in T.items() if len(t['signs']) >= 100]
a = np.array([x[1] for x in S]); b = np.array([x[2] for x in S]); Ds = ((a-a.mean())/a.std() + (b-b.mean())/b.std())/2
DS = {x[0]: float(d) for x, d in zip(S, Ds)}
both = [t for t in DS if t in R]
print(f'\n[2] sign tokens {NS}, sign types {len(SG)}; texts with >=100 signs: {len(S)}; of these also word-scored: {len(both)}')
print('    Spearman word-based D vs sign-only D:', round(spearmanr([R[t]['D'] for t in both], [DS[t] for t in both])[0], 2),
      '| word rarity vs sign rarity:', round(spearmanr([R[t]['surp'] for t in both], [x[1] for x in S if x[0] in R])[0], 2),
      '| word variety vs sign variety:', round(spearmanr([R[t]['mattr'] for t in both], [x[2] for x in S if x[0] in R])[0], 2))
gm = []
for c in sorted(set(R[t]['corpus'] for t in both)):
    tt = [t for t in both if R[t]['corpus'] == c]
    if len(tt) >= 10: gm.append((c, len(tt), statistics.median(R[t]['D'] for t in tt), statistics.median(DS[t] for t in tt)))
for g in sorted(gm, key=lambda g: g[3]): print(f'    {g[0]:22s} n={g[1]:4d} median D words {g[2]:+.2f} | median D signs {g[3]:+.2f}')
print('    group-level Spearman (n groups =', len(gm), '):', round(spearmanr([g[2] for g in gm], [g[3] for g in gm])[0], 2))
# 3 bootstrap intervals
print('\n[3] median D with 5-95% bootstrap interval')
MAIN = {'bbawarchive': 'Verwaltung/Briefe', 'bbawbriefe': 'Verwaltung/Briefe', 'bbawpyramidentexte': 'Jenseits/Ritual', 'tb': 'Jenseits/Ritual', 'bbawtotenlit': 'Jenseits/Ritual',
        'sawmedizin': 'Wissen', 'bbawtempelbib': 'Wissen', 'sawlit': 'Literatur', 'bbawgrabinschriften': 'Grab/Privat', 'bbawgraeberspzt': 'Grab/Privat', 'tuebingerstelen': 'Grab/Privat',
        'bbawamarna': 'Koenig/Geschichte', 'bbawramessiden': 'Koenig/Geschichte', 'bbawhistbiospzt': 'Koenig/Geschichte', 'bbawfelsinschriften': 'Koenig/Geschichte', 'smaek': 'Sonstige'}
def boot(v):
    v = np.array(v); m = np.median(rng.choice(v, (2000, len(v))), axis=1); return np.median(v), np.percentile(m, 5), np.percentile(m, 95)
res = []
for c in sorted(set(r['corpus'] for r in rows)):
    v = [r['D'] for r in rows if r['corpus'] == c]
    if len(v) >= 10: res.append((boot(v), c, len(v)))
for (m, lo, hi), c, n in sorted(res): print(f'    {c:22s} n={n:4d} {m:+.2f} [{lo:+.2f}, {hi:+.2f}]')
print('    main themes:')
res = []
for mt in sorted(set(MAIN.values())):
    rr = [r for r in rows if MAIN[r['corpus']] == mt]
    if len(rr) >= 10:
        lv = collections.Counter(r['level'] for r in rr)
        res.append((boot([r['D'] for r in rr]), mt, len(rr), [lv.get(i, 0) for i in (1, 2, 3, 4)], sum(1 for t in T.values() if MAIN[t['corpus']] == mt), sum(len(t['lem']) for t in T.values() if MAIN[t['corpus']] == mt)))
for (m, lo, hi), mt, n, lv, nt, nw in sorted(res): print(f'    {mt:20s} texts {nt:5d} words {nw:6d} scored {n:4d} {m:+.2f} [{lo:+.2f}, {hi:+.2f}] levels {lv} = ' + '/'.join(f'{x/n:.0%}' for x in lv))
# 4 examples
print('\n[4] examples per level (three longest):')
for L in (1, 2, 3, 4):
    for r in sorted([r for r in rows if r['level'] == L], key=lambda r: -r['n'])[:3]: print(f"    L{L} {r['corpus']:20s} n={r['n']:5d} D={r['D']:+.2f} sl={r['sl']} | {nm(r['text'])}")
big = sorted([r for r in rows if r['n'] >= 300], key=lambda r: r['D'])
print('    texts with >=300 words:', len(big)); 
for r in big[:6]: print(f"    lowest  {r['corpus']:20s} n={r['n']:5d} D={r['D']:+.2f} sl={r['sl']} surp={r['surp']:.2f} mattr={r['mattr']:.2f} | {nm(r['text'])}")
for r in big[-6:]: print(f"    highest {r['corpus']:20s} n={r['n']:5d} D={r['D']:+.2f} sl={r['sl']} surp={r['surp']:.2f} mattr={r['mattr']:.2f} | {nm(r['text'])}")
print('\n[5] sample text names per corpus:')
for c in sorted(set(t['corpus'] for t in T.values())):
    ids = [tid for tid, t in T.items() if t['corpus'] == c and tid in id2name]; random.shuffle(ids)
    print(f'    {c}:', ' || '.join(nm(i)[len(c)+1:][:48] if nm(i).startswith(c) else nm(i)[:48] for i in ids[:5]))
# 6 clusters
docs = [(tid, t['lem'], t['corpus']) for tid, t in T.items() if len(t['lem']) >= 80]
vec = TfidfVectorizer(analyzer=lambda d: d, min_df=5, sublinear_tf=True); X = vec.fit_transform([d for _, d, _ in docs])
km = KMeans(n_clusters=12, n_init=5, random_state=0).fit(X); voc = np.array(vec.get_feature_names_out())
print('\n[6] clusters on words: size | median D | top corpora | top terms')
out = []
for j in range(12):
    mem = [i for i, l in enumerate(km.labels_) if l == j]
    cc = collections.Counter(docs[i][2] for i in mem).most_common(3)
    dd = [R[docs[i][0]]['D'] for i in mem if docs[i][0] in R]
    out.append((statistics.median(dd), len(mem), ', '.join(f'{c} {n}' for c, n in cc), ' '.join(voc[np.argsort(-km.cluster_centers_[j])[:9]])))
for md, n, cc, terms in sorted(out): print(f'    {n:4d} | {md:+.2f} | {cc} | {terms}')
print('    share of each corpus in its largest cluster:')
for c in sorted(set(d[2] for d in docs)):
    lab = collections.Counter(km.labels_[i] for i, d in enumerate(docs) if d[2] == c); n = sum(lab.values())
    print(f'    {c:22s} n={n:4d} {lab.most_common(1)[0][1]/n:.0%} (clusters used: {len(lab)})')
