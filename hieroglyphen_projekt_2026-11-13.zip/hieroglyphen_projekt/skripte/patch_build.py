s = open('build_page.py', encoding='utf-8').read()
a = s.index('G = {}; refs = 0'); b = s.index('def one(code, k')
new = r'''BOX = json.load(open(gdir, encoding='utf-8')); G = {}; refs = 0
def glyph(code):
    if code in G: return G[code]
    for c in [code] + ([base(code)] if base(code) != code else []):
        if c in BOX:
            v = BOX[c]
            G[code] = {'id': 's-' + re.sub(r'\W', '', c), 'vb': '%.5g %.5g %.5g %.5g' % (v['x'], v['y'], v['w'], v['h']), 'w': v['w']*v['scale'], 'h': v['h']*v['scale'], 'body': v['body'], 'exact': c == code}
            return G[code]
    G[code] = None; return None
'''
s = s[:a] + new + s[b:]
a = s.index("symbols = ''.join("); b = s.index('\n', a)
s = s[:a] + '''SY = {}
for g in G.values():
    if g: SY[g['id']] = '<symbol id="%s" viewBox="%s">%s</symbol>' % (g['id'], g['vb'], g['body'])
symbols = ''.join(SY.values())''' + s[b:]
open('build_page.py', 'w', encoding='utf-8').write(s)
