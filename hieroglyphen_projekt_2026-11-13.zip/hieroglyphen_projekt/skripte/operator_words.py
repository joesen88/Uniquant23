import json, sys, glob, os, re, collections, random
from fractions import Fraction
root = sys.argv[1]; random.seed(20261112)
def parse_num(wf):
    if not wf: return None
    w = wf.strip()
    m = re.fullmatch(r'(\d+)', w)
    if m: return Fraction(int(m.group(1)))
    m = re.fullmatch(r'(\d+)/(\d+)', w)
    if m and int(m.group(2)): return Fraction(int(m.group(1)), int(m.group(2)))
    m = re.fullmatch(r'(\d+)-(\d+)/(\d+)', w)
    if m and int(m.group(3)): return Fraction(int(m.group(1))) + Fraction(int(m.group(2)), int(m.group(3)))
    return None
texts = collections.OrderedDict(); lem_n = collections.Counter(); big = collections.Counter(); gl = {}; sp = collections.defaultdict(collections.Counter)
for p in sorted(glob.glob(os.path.join(root,'_aes_*.json'))):
    d = json.load(open(p,encoding='utf-8'))
    for sid, s in d.items():
        L = texts.setdefault(s['text'], []); prev = None
        for t in s.get('token', []):
            lem = t.get('lemma_form') or t.get('written_form')
            v = parse_num(t.get('written_form')) if t.get('pos') == 'numeral' else None
            L.append((lem, v)); lem_n[lem] += 1; gl.setdefault(lem, (t.get('cotext_translation') or '')[:38])
            if t.get('hiero'): sp[lem][t['hiero']] += 1
            if prev is not None: big[(prev, lem)] += 1
            prev = lem
        L.append(('<S>', None))
S = []
for tid, L in texts.items():
    idx = [i for i, x in enumerate(L) if x[1] is not None]
    if len(idx) >= 3:
        ctx = []
        for i in idx:
            j = i-1
            while j >= 0 and L[j][1] is not None: j -= 1
            ctx.append(L[j][0] if j >= 0 else '<S>')
        S.append((idx, [L[i][1] for i in idx], ctx))
def hits(vals, idx):
    out = []
    n = len(vals)
    for j in range(2, n):
        vj = vals[j]
        if vj >= 5:
            acc = Fraction(0)
            for k in range(1, 16):
                if j-k < 0 or idx[j]-idx[j-k] > 80: break
                acc += vals[j-k]
                if k >= 2 and acc == vj and vj > max(vals[j-k:j]): out.append(('sum', j)); break
                if acc > vj: break
        a, b = vals[j-2], vals[j-1]
        if idx[j]-idx[j-2] <= 30:
            if a >= 2 and b >= 2 and a*b == vj and vj >= 6: out.append(('product', j))
            if b >= 1 and a-b == vj and vj >= 1 and a >= 5: out.append(('difference', j))
            if b >= 2 and a >= 4 and a/b == vj and vj >= 2: out.append(('quotient', j))
    return out
def tally(shuffle):
    c = collections.Counter()
    for idx, vals, ctx in S:
        v = vals[:]
        if shuffle: random.shuffle(v)
        for rel, j in hits(v, idx): c[(rel, ctx[j])] += 1; c[(rel, '*')] += 1
    return c
real = tally(False); N = 300; nulls = [tally(True) for _ in range(N)]
ctx_n = collections.Counter(c for idx, vals, ctx in S for c in ctx)
print('numbers in texts with >=3 numbers:', sum(len(s[1]) for s in S))
for rel in ('sum','difference','product','quotient'):
    obs = real[(rel,'*')]; nm = [n[(rel,'*')] for n in nulls]
    print(f'\n{rel}: observed {obs}, shuffled mean {sum(nm)/N:.1f}, shuffled max {max(nm)}, p={sum(1 for x in nm if x >= obs)/N:.3f}')
    rows = []
    for (r, w), o in real.items():
        if r != rel or w == '*' or o < 3: continue
        nw = [n[(rel, w)] for n in nulls]; pv = sum(1 for x in nw if x >= o)/N
        rows.append((pv, -o, w, o, sum(nw)/N))
    for pv, _, w, o, m in sorted(rows)[:5]:
        s1 = sp[w].most_common(1)[0][0] if sp[w] else '-'
        print(f'   word before result: {w[:14]:14s} hits {o:3d} of {ctx_n[w]:4d} numbers after it | shuffled mean {m:5.2f} | p={pv:.3f} | signs {s1[:18]:18s} | {gl.get(w,"")}')
print('\ncalendar and cyclic counters (word directly before an integer):')
by = collections.defaultdict(list)
for tid, L in texts.items():
    for i in range(1, len(L)):
        if L[i][1] is not None and L[i][1].denominator == 1 and L[i-1][1] is None: by[L[i-1][0]].append(int(L[i][1]))
for w, vals in by.items():
    g = gl.get(w, '')
    if len(vals) >= 15 and re.search(r'Monatstag|Monat|Regierungsjahr|Stunde|^Jahr|Tag\b|Mal\b', g):
        c = collections.Counter(vals); mx = max(vals)
        s1 = sp[w].most_common(1)[0][0] if sp[w] else '-'
        print(f'   {w[:12]:12s} n={len(vals):4d} max={mx:4d} distinct={len(c):3d} values<=30: {sum(1 for v in vals if v<=30)/len(vals):.0%} | signs {s1[:16]:16s} | {g}')
print('\nrecurring formula words:')
for w in ('ḏ.t','nḥḥ','ḥḥ','ḥꜣ.t-zp','ḥtp-ḏi̯-nswt','dmḏ'):
    print(f'   {w:14s} tokens {lem_n.get(w,0):6d} | {gl.get(w,"")}')
print('   bigram ꜥnḫ + ḏ.t:', big.get(('ꜥnḫ','ḏ.t'),0), '| ḏ.t + nḥḥ:', big.get(('ḏ.t','nḥḥ'),0), '| nḥḥ + ḏ.t:', big.get(('nḥḥ','ḏ.t'),0))
print('   most frequent lemmas overall:', [(w, n) for w, n in lem_n.most_common(12)])
