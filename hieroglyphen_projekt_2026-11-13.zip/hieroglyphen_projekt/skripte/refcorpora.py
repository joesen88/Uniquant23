import json, sys, glob, os, re, collections, math, lzma, random, tokenize, io, array, ast
root = sys.argv[1]; random.seed(20261112); N = 40000
def stats(tok):
    tok = tok[:N]; n = len(tok); cnt = collections.Counter(tok)
    H1 = -sum(v/n*math.log2(v/n) for v in cnt.values())
    top20 = sum(v for _, v in cnt.most_common(20))/n
    ids = {t:i for i,t in enumerate(cnt)}; arr = array.array('I', (ids[t] for t in tok))
    bits = 8*len(lzma.compress(arr.tobytes(), preset=6))/n
    six = collections.Counter(tuple(tok[i:i+6]) for i in range(n-5)); rep = sum(v for v in six.values() if v >= 2)/(n-5)
    return n, len(cnt), top20, rep, bits, H1
stdlib = os.path.dirname(os.__file__)
files = sorted(glob.glob(os.path.join(stdlib, '*.py'))); random.shuffle(files)
code, prose = [], []
for f in files:
    try:
        src = open(f, 'rb').read()
        for t in tokenize.tokenize(io.BytesIO(src).readline):
            if t.type in (tokenize.NAME, tokenize.NUMBER): code.append(t.string)
        tree = ast.parse(src)
        for node in ast.walk(tree):
            if isinstance(node, (ast.Module, ast.FunctionDef, ast.ClassDef, ast.AsyncFunctionDef)):
                ds = ast.get_docstring(node)
                if ds: prose += re.findall(r"[A-Za-z']+", ds.lower())
    except Exception: continue
    if len(code) > 3*N and len(prose) > 3*N: break
import pydoc_data.topics as T
book = re.findall(r"[A-Za-z_]\w*|\d+", '\n'.join(T.topics[k] for k in sorted(T.topics)).lower())
random.seed(1); 
cpp = []
hdrs = sorted(glob.glob('/usr/include/c++/*/bits/*.h')) + sorted(glob.glob('/usr/include/c++/*/*'))
random.shuffle(hdrs)
for h in hdrs:
    if not os.path.isfile(h): continue
    try: s = open(h, encoding='utf-8', errors='ignore').read()
    except Exception: continue
    s = re.sub(r'/\*.*?\*/', ' ', s, flags=re.S); s = re.sub(r'//[^\n]*', ' ', s); s = re.sub(r'"(?:[^"\\]|\\.)*"', ' STR ', s)
    cpp += re.findall(r"[A-Za-z_]\w*|\d+", s)
    if len(cpp) > 3*N: break
texts = collections.OrderedDict(); corp = {}
for p in sorted(glob.glob(os.path.join(root,'_aes_*.json'))):
    d = json.load(open(p,encoding='utf-8'))
    for sid, s in d.items(): texts.setdefault(s['text'], []).append(s); corp[s['text']] = s['corpus']
order = list(texts); random.seed(20261112); random.shuffle(order)
def egy(corpus=None, kind='lemma'):
    out = []
    for tid in order:
        if corpus and corp[tid] != corpus: continue
        for s in texts[tid]:
            if kind == 'de': out += re.findall(r'\w+', (s.get('sentence_translation') or '').lower())
            else: out += [(t.get('lemma_form') or t.get('written_form') or '?') for t in s.get('token', []) if t.get('_id')]
    return out
rows = [('Python code (names, numbers)', code), ('C++ code (libstdc++ headers)', cpp), ('Python reference text: prose + code', book), ('English prose (docstrings)', prose),
        ('German prose (corpus translations)', egy(kind='de')), ('Egyptian: medical', egy('sawmedizin')), ('Egyptian: Pyramid Texts', egy('bbawpyramidentexte')),
        ('Egyptian: tomb inscriptions', egy('bbawgrabinschriften')), ('Egyptian: literary', egy('sawlit')), ('Egyptian: all', egy())]
print(f'words-only streams at N={N}: types | top-20 share | in repeated 6-grams | LZMA bits/word | H1')
for name, st in rows:
    if len(st) < N: print(f'   {name:38s} too short ({len(st)})'); continue
    n, V, t20, rep, bits, H1 = stats(st)
    print(f'   {name:38s} {V:6d} | {t20:5.1%} | {rep:5.1%} | {bits:5.2f} | {H1:5.2f}')
