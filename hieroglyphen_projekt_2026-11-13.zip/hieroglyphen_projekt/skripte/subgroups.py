import sys, os, re, json, gzip, glob, collections, math
import numpy as np, simplemma
latroot, toks_p, ud_dirs = sys.argv[1], sys.argv[2], sys.argv[3:]
norm = lambda s: s.lower().replace('v', 'u').replace('j', 'i')
GROUP = {**{k: 'Geruest' for k in ('ADP', 'PRON', 'DET', 'CCONJ', 'SCONJ', 'PART', 'AUX', 'ADV', 'NUM', 'INTJ')}, **{k: 'Inhalt' for k in ('NOUN', 'VERB', 'ADJ')}, 'PROPN': 'Namen'}
FORM = collections.defaultdict(collections.Counter); LEM = collections.defaultdict(collections.Counter); tags = collections.Counter()
for d in ud_dirs:
    for p in glob.glob(os.path.join(d, '*.conllu')):
        for line in open(p, encoding='utf-8'):
            if line[:1].isdigit():
                c = line.split('\t')
                if '-' in c[0] or '.' in c[0]: continue
                tags[c[3]] += 1
                if c[3] in GROUP: FORM[norm(c[1])][GROUP[c[3]]] += 1; LEM[norm(c[2])][GROUP[c[3]]] += 1
print('UD tokens', sum(tags.values()), 'forms', len(FORM), 'lemmas', len(LEM), '| tags', tags.most_common(8))
TOKRE = re.compile(r"[A-Za-z]+")
def read(paths, cap_total):
    out = []
    for p in paths:
        try: txt = open(os.path.join(latroot, p), encoding='utf-8', errors='ignore').read()
        except FileNotFoundError: continue
        for line in txt.split('\n'):
            if 'Latin Library' in line or 'Classics Page' in line: continue
            first = True
            for m in TOKRE.finditer(line):
                w = m.group(0); pre = line[:m.start()].rstrip(' "\'([0123456789'); out.append((w, first or (pre[-1:] in '.?!:;' if pre else True))); first = False
        if len(out) >= cap_total: break
    return out[:cap_total]
REL = read(['bible/psalms.txt', 'bible/matthew.txt', 'bible/mark.txt', 'bible/luke.txt', 'bible/john.txt', 'bible/genesis.txt'], 112391)
LIT = read([f'caesar/gall{i}.txt' for i in range(1, 8)], 47783) + read([f'vergil/aen{i}.txt' for i in range(1, 13)], 47783) + read([f'ovid/ovid.met{i}.txt' for i in range(1, 16)], 47783) + read(['cicero/cat1.txt', 'cicero/cat2.txt', 'cicero/cat3.txt', 'cicero/cat4.txt', 'cicero/amic.txt', 'cicero/arch.txt', 'cicero/cael.txt', 'cicero/att1.txt', 'cicero/att2.txt', 'cicero/fam1.txt', 'cicero/brut.txt'], 47783)
TEC = read([f'vitruvius{i}.txt' for i in (10, 9, 1)], 18696) + read([f'apicius/apicius{i}.txt' for i in range(1, 6)], 18696) + read(['cato/cato.agri.txt', 'isidore/4.txt', 'isidore/3.txt', 'frontinus/aqua1.txt'], 18696)
capm = collections.Counter(); tot = collections.Counter(); cap = collections.Counter()
for seq in (REL, LIT, TEC):
    for w, ini in seq:
        l = w.lower(); tot[l] += 1
        if w[0].isupper(): cap[l] += 1; capm[l] += (not ini)
name = {l for l in tot if capm[l] >= 1 and cap[l]/tot[l] >= 0.8}; cache = {}; unk = collections.Counter()
def lat(w):
    l = w.lower()
    if l in name: return 'N:' + l, 'Namen'
    if l not in cache: cache[l] = simplemma.lemmatize(l, lang='la').lower()
    lm = cache[l]; c = FORM.get(norm(l)) or LEM.get(norm(lm))
    if not c: unk['unknown'] += 1; return lm, 'Inhalt'
    unk['known'] += 1; return lm, c.most_common(1)[0][0]
def seqs(S): return [lat(w) for w, _ in S]
R, L, T = seqs(REL), seqs(LIT), seqs(TEC); print('Latin tokens without lexicon entry (default Inhalt):', f"{unk['unknown']/(unk['unknown']+unk['known']):.1%}")
def grid(P, A, B, title, gl=None):
    N = len(P); Aset = set(l for l, _ in A); Bset = set(l for l, _ in B); cell = collections.Counter(); lem = collections.defaultdict(collections.Counter)
    for l, g in P:
        k = 1 if l in Aset else 2 if l in Bset else 3; cell[(k, g)] += 1; lem[(k, g)][l] += 1
    print(f'\n{title} ({N} words): share of all words per cell | lemmas | top words')
    for k in (1, 2, 3):
        rowt = sum(cell[(k, g)] for g in ('Geruest', 'Inhalt', 'Namen', 'offen'))
        for g in ('Geruest', 'Inhalt', 'Namen', 'offen'):
            if cell[(k, g)]: print(f"  Klasse {k} x {g:8s} {cell[(k, g)]/N:6.2%} (of class {cell[(k, g)]/rowt:4.0%}) | {len(lem[(k, g)]):5d} | " + ', '.join(f"{(gl[x] if gl else x)} {n}" for x, n in lem[(k, g)].most_common(7)))
    return cell
grid(R, L, T, 'LATEIN Vulgata gegen Literatur / Fachtexte')
grid(T, L, R, 'LATEIN Fachtexte gegen Literatur / Vulgata')
TK = json.load(gzip.open(toks_p, 'rt', encoding='utf-8'))
EG = {'pronoun': 'Geruest', 'preposition': 'Geruest', 'particle': 'Geruest', 'adverb': 'Geruest', 'numeral': 'Geruest', 'interjection': 'Geruest', 'substantive': 'Inhalt', 'verb': 'Inhalt', 'adjective': 'Inhalt', 'entity_name': 'Namen', 'epitheton_title': 'Namen'}
form = {}
def eg(corpus):
    out = []
    for t in TK.values():
        if t['corpus'] == corpus:
            for k in t['tok']:
                if k[0]: out.append((k[0], EG.get(k[2], 'offen'))); form.setdefault(k[0], k[1])
    return out
P, EL, EM = eg('bbawpyramidentexte'), eg('sawlit'), eg('sawmedizin')
grid(P, EL, EM, 'AEGYPTISCH Pyramidentexte gegen Literatur / Medizin', form)
grid(EM, EL, P, 'AEGYPTISCH Medizin gegen Literatur / Pyramidentexte', form)
# rank-frequency regimes
def regimes(counter, label):
    f = np.array(sorted(counter.values(), reverse=True), float); r = np.arange(1, len(f) + 1)
    idx = np.unique(np.round(np.logspace(0, np.log10(len(f)), 60)).astype(int)) - 1; x = np.log10(r[idx]); y = np.log10(f[idx])
    one = np.polyfit(x, y, 1); sse1 = ((np.polyval(one, x) - y)**2).sum(); best = None
    for b in range(6, len(x) - 6):
        a1 = np.polyfit(x[:b], y[:b], 1); a2 = np.polyfit(x[b:], y[b:], 1); sse = ((np.polyval(a1, x[:b]) - y[:b])**2).sum() + ((np.polyval(a2, x[b:]) - y[b:])**2).sum()
        if best is None or sse < best[0]: best = (sse, int(r[idx][b]), a1[0], a2[0])
    fm = f[f >= 1]; alpha = 1 + len(fm)/np.log(fm/0.5).sum()
    print(f"  {label:34s} types {len(f):5d} | one slope {one[0]:+.2f} | two regimes: break at rank {best[1]:5d}, slopes {best[2]:+.2f} / {best[3]:+.2f}, error reduced by {1 - best[0]/sse1:.0%} | hapax {np.mean(f == 1):.0%}, twice {np.mean(f == 2):.0%} | spectrum exponent (MLE) {alpha:.2f}")
print('\nrank-frequency: one line or two regimes?')
regimes(collections.Counter(l for l, _ in P), 'Aegyptisch Pyramidentexte (Woerter)'); regimes(collections.Counter(l for l, _ in EL), 'Aegyptisch Literatur (Woerter)'); regimes(collections.Counter(l for l, _ in EM), 'Aegyptisch Medizin (Woerter)')
regimes(collections.Counter(l for l, _ in R), 'Latein Vulgata (Woerter)'); regimes(collections.Counter(l for l, _ in L), 'Latein Literatur (Woerter)'); regimes(collections.Counter(l for l, _ in T), 'Latein Fachtexte (Woerter)')
