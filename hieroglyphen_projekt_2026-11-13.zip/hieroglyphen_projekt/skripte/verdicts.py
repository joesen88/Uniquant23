import json, sys, re, collections
p = sys.argv[1]; conc = sys.argv[2]
names = {}
for line in open(conc, encoding='utf-8'):
    q = line.rstrip('\n').split('\t')
    if len(q) >= 2: names[q[-1]] = q[0]
d = json.load(open(p, encoding='utf-8'))
c = collections.Counter(); ex = {}
for sid, s in d.items():
    nm = names.get(s['text'], '')
    tr = s.get('sentence_translation') or ''
    L = ' '.join((t.get('lemma_form') or '') for t in s.get('token', []))
    smith = 'Smith' in nm
    if re.search(r'\bmr\b', L) and 'jri̯' in L and '=j' in L and 'ꜥḥꜣ' not in L and not re.search(r'\bn\b jri̯|nn jri̯', L) and 'ḏd' not in L[:0]:
        k = 'A treat'
    elif re.search(r'\bmr\b', L) and 'ꜥḥꜣ' in L and '=j' in L: k = 'B contend'
    elif re.search(r'\bmr\b', L) and re.search(r'(^| )(n|nn) jri̯', L): k = 'C not treatable'
    else: continue
    c[(k, 'Smith' if smith else 'other')] += 1; ex.setdefault(k, (L[:70], tr[:90]))
for k, v in sorted(c.items()): print(k, v)
for k, v in ex.items(): print(k, '|', v)
