"""Pyramid Texts: do the same spells grow from the oldest to the youngest pyramid? (criteria: pt_pyramids_prereg.txt)
usage: python3 -I pt_pyramids.py <aes_tokens_cache.json.gz>"""
import sys, gzip, json, collections, difflib, math, itertools
C = collections.Counter
T = json.load(gzip.open(sys.argv[1], 'rt', encoding='utf-8'))
OWN = {'800001': 'Unas', '450656': 'Teti', '400309': 'Pepi I', '401145': 'Pepi I', '401175': 'Merenre', '854416': 'Merenre', '400330': 'Pepi II', '702960': 'Neith', '400313': 'Ppy'}
ORDER = ['Unas', 'Teti', 'Pepi I', 'Merenre', 'Pepi II', 'Neith']
uid = itertools.count(1); FORM = {'KING': '<owner>'}; POS = {}; unk = lambda x: x.startswith('?')
texts = {}; pyr = {}; stat = C()
for tid, t in T.items():
    if t['corpus'] != 'bbawpyramidentexte': continue
    sents = []; p0 = 0; toks = t['tok']; owners = C()
    for L in t['sl'] + ([len(toks) - sum(t['sl'])] if sum(t['sl']) < len(toks) else []):
        s = []
        for tk in toks[p0:p0 + L]:
            k = str(tk[0]) if tk[0] else None
            if k in OWN:
                owners[OWN[k]] += 1
                if not (s and s[-1] == 'KING'): s.append('KING')
            elif k:
                s.append(k); FORM.setdefault(k, tk[1]); POS.setdefault(k, tk[2])
            else: s.append('?%d' % next(uid))
        p0 += L
        if s: sents.append(s)
    texts[tid] = sents
    kings = set(owners) - {'Ppy', 'Neith'}
    if 'Ppy' in owners and 'Pepi II' not in owners: kings.add('Pepi I')
    if not kings and 'Neith' in owners: kings = {'Neith'}
    elif 'Neith' in owners and kings: kings.add('Neith')
    if len(kings) == 1: pyr[tid] = next(iter(kings))
    stat['no owner name' if not kings else ('two owners' if len(kings) > 1 else next(iter(kings)))] += 1
words = C();
for tid, p in pyr.items(): words[p] += sum(len(s) for s in texts[tid])
print('texts per pyramid (texts, words):', [(p, stat[p], words[p]) for p in ORDER], '| left out:', stat['no owner name'], 'without owner name,', stat['two owners'], 'with two owners')
ngr = lambda s, n: [tuple(s[i:i + n]) for i in range(len(s) - n + 1)]
flat = lambda tid: [x for s in texts[tid] for x in s]
grams = {tid: set(g for s in texts[tid] for g in ngr(s, 4) if not any(unk(x) for x in g)) for tid in pyr}
f = lambda x: str(FORM.get(x, x))
def best_pairs(src, dst):
    """for each text in src the text in dst sharing most sequences (>= 5)"""
    inv = collections.defaultdict(set)
    for tid in dst:
        for g in grams[tid]: inv[g].add(tid)
    out = []
    for tid in src:
        share = C()
        for g in grams[tid]:
            for e in inv.get(g, ()): share[e] += 1
        if share and share.most_common(1)[0][1] >= 5: out.append((tid, share.most_common(1)[0][0]))
    return out
def gaps(e, l):
    a, b = flat(e), flat(l)
    blocks = [m for m in difflib.SequenceMatcher(None, a, b, autojunk=False).get_matching_blocks() if m.size >= 3]
    sh = sum(m.size for m in blocks)
    out = []
    for m1, m2 in zip(blocks, blocks[1:]):
        ga = a[m1.a + m1.size:m2.a]; gb = b[m1.b + m1.size:m2.b]
        if len(ga) > 15 or len(gb) > 15 or (not ga and not gb): continue
        if any(unk(x) for x in ga) or any(unk(x) for x in gb): continue
        out.append((ga, gb, a[max(0, m1.a + m1.size - 3):m1.a + m1.size], a[m2.a:m2.a + 3]))
    return sh, out
def measure(pairs):
    """pairs: (earlier text, later text)"""
    add = drop = more = fewer = shared = 0; A = C(); D = C(); S = C(); ex = []
    for e, l in pairs:
        sh, gs = gaps(e, l); shared += sh; pa = pd = 0
        for ga, gb, left, right in gs:
            pa += len(gb); pd += len(ga); A.update(gb); D.update(ga)
            if len(ga) == 1 and len(gb) == 1: S[(ga[0], gb[0])] += 1
            if not ga and len(ex) < 400: ex.append(' '.join(f(x) for x in left) + '  [+ ' + ' '.join(f(x) for x in gb) + ']  ' + ' '.join(f(x) for x in right))
        add += pa; drop += pd; more += pa > pd; fewer += pa < pd
    n = more + fewer
    p = min(1.0, 2 * sum(math.comb(n, i) for i in range(0, min(more, fewer) + 1)) / 2 ** n) if n else 1.0
    return dict(pairs=len(pairs), shared=shared, add=add, drop=drop, more=more, fewer=fewer, p=p, A=A, D=D, S=S, ex=ex)
def show(label, r):
    ratio = r['add'] / r['drop'] if r['drop'] else float('nan')
    print(f'  {label:44s} {r["pairs"]:4d} pairs, {r["shared"]:6,d} shared words | added {r["add"]:5,d}, dropped {r["drop"]:5,d} (ratio {ratio:4.2f}) | later text has more {r["more"]:3d}, fewer {r["fewer"]:3d}, p = {r["p"]:.4f}')
by = {p: [tid for tid, q in pyr.items() if q == p] for p in ORDER}
print('\n[1] neighbouring steps, pairing started from the later pyramid')
allp = []
for a, b in zip(ORDER, ORDER[1:]):
    pr = [(e, l) for l, e in best_pairs(by[b], by[a])]; allp += pr; show(f'{a} -> {b}', measure(pr))
R = measure(allp); show('all five steps pooled', R)
print('\n[2] robustness')
allq = []
for a, b in zip(ORDER, ORDER[1:]): allq += best_pairs(by[a], by[b])
show('five steps pooled, pairing from the earlier', measure(allq))
show('Unas -> Pepi II (long step)', measure([(e, l) for l, e in best_pairs(by['Pepi II'], by['Unas'])]))
show('Unas -> Neith', measure([(e, l) for l, e in best_pairs(by['Neith'], by['Unas'])]))
good = ['Unas', 'Teti', 'Pepi II', 'Neith']; gp = []
for a, b in zip(good, good[1:]): gp += [(e, l) for l, e in best_pairs(by[b], by[a])]
show('without Pepi I and Merenre (3 steps pooled)', measure(gp))
print('\n[3] what is added, dropped, replaced (five steps pooled)')
net = C({k: R['A'][k] - R['D'][k] for k in set(R['A']) | set(R['D'])})
print('  largest net additions (word: added, dropped):', [(f(k), R['A'][k], R['D'][k]) for k, v in net.most_common(12)])
print('  largest net omissions:', [(f(k), R['A'][k], R['D'][k]) for k, v in sorted(net.items(), key=lambda kv: kv[1])[:10]])
pa = C(POS.get(k, 'owner' if k == 'KING' else '?') for k in R['A'].elements()); pd = C(POS.get(k, 'owner' if k == 'KING' else '?') for k in R['D'].elements())
print('  by word class (added / dropped):', [(p, pa[p], pd[p]) for p, _ in (pa + pd).most_common(9)])
print('  single-word replacements (earlier -> later: count, reverse count):')
seen = set()
for (a, b), n in R['S'].most_common(60):
    if (b, a) in seen: continue
    seen.add((a, b)); print(f'      {f(a):14s} -> {f(b):14s} {n:4d}   reverse {R["S"][(b, a)]:4d}')
    if len(seen) >= 12: break
print('  examples of pure additions (context [+ added] context):')
for x in R['ex'][:400:40]: print('     ', x[:140])
