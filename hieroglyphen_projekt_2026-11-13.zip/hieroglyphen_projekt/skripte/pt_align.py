import json, sys, re, gzip, collections, difflib
aes_dir, toks_p = sys.argv[1:3]
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*')
def base(s): return re.sub(r'(?<=\d)[A-Za-z]+$', '', s)
d = json.load(open(aes_dir + '/_aes_bbawpyramidentexte.json', encoding='utf-8'))
T = collections.defaultdict(list)
for sid, s in d.items():
    for k in s.get('token', []):
        if k.get('hiero'):
            sg = SIGN.findall(k['hiero'])
            if sg: T[s['text']].append((k['hiero'], [base(x) for x in sg], k.get('lemma_form') or '', (k.get('cotext_translation') or '')[:28]))
big = sorted(T, key=lambda t: -sum(len(x[1]) for x in T[t]))[:2]; A, B = T[big[0]], T[big[1]]
def flat(X): return [(b, i) for i, x in enumerate(X) for b in x[1]]
fa, fb = flat(A), flat(B); sm = difflib.SequenceMatcher(None, [x[0] for x in fa], [x[0] for x in fb], autojunk=False)
print('signs A', len(fa), 'B', len(fb), 'similarity ratio', round(sm.ratio(), 3), '| identical sign positions', sum(b - a for tag, a, b, c, e in sm.get_opcodes() if tag == 'equal'))
RARE = {'O194', 'L7', 'F139', 'D207', 'L6', 'I28', 'G33', 'O30', 'R6'}
def show(X, Y, fx, fy, ops, lab):
    seen = set()
    for tag, a1, a2, b1, b2 in ops:
        for p in range(a1, a2):
            if fx[p][0] in RARE and fx[p][1] not in seen:
                seen.add(fx[p][1]); w = X[fx[p][1]]
                other = sorted(set(fy[q][1] for q in range(b1, b2))) if b2 > b1 else []
                if tag == 'equal': other = [fy[b1 + (p - a1)][1]]
                print(f"  {lab} {fx[p][0]:5s} in {w[2]} ({w[3]}) [{w[0]}]  <->  {tag}: " + ' | '.join(f'{Y[j][2]} [{Y[j][0]}]' for j in other[:4]))
ops = sm.get_opcodes(); show(A, B, fa, fb, ops, 'A')
ops2 = [(t, b1, b2, a1, a2) for t, a1, a2, b1, b2 in ops]; show(B, A, fb, fa, ops2, 'B')
# word level: Egyptian medical vs literary and Pyramid Texts
TK = json.load(gzip.open(toks_p, 'rt', encoding='utf-8'))
def lem(corpus):
    c = collections.Counter(); pos = {}; form = {}
    for t in TK.values():
        if t['corpus'] == corpus:
            for k in t['tok']:
                if k[0]: c[k[0]] += 1; pos.setdefault(k[0], k[2]); form.setdefault(k[0], k[1])
    return c, pos, form
M, posM, formM = lem('sawmedizin'); L, _, _ = lem('sawlit'); P, _, _ = lem('bbawpyramidentexte'); N = sum(M.values())
print(f'\nEgyptian medical vs literary and Pyramid Texts: {N} words, {len(M)} lemmas')
for lab, c in (('class1 also in literary', {k: v for k, v in M.items() if k in L}), ('class2 not literary but PT', {k: v for k, v in M.items() if k not in L and k in P}), ('class3 rest', {k: v for k, v in M.items() if k not in L and k not in P})):
    t = sum(c.values()); nm = sum(v for k, v in c.items() if posM.get(k) == 'entity_name')
    print(f'  {lab:28s} {len(c):5d} lemmas = {len(c)/len(M):6.1%} | {t:6d} words = {t/N:6.2%} | names {nm/t:.0%} | top: ' + ', '.join(f'{formM[k]} {v}' for k, v in sorted(c.items(), key=lambda x: -x[1])[:14]))
