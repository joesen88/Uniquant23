"""Blind inference of the numeral system from the sign stream; validation against the editors' values.
usage: python3 -I blind_numerals.py <aes_schrift.jsonl.gz> <aes_deutung_token.jsonl.gz>
Blind part: only the stream of sign codes is used (no word boundaries, no lemmas, no values).
"""
import sys, gzip, json, re, collections, random, itertools

C = collections.Counter
schrift_p, deut_p = sys.argv[1], sys.argv[2]

segs = []; tokrec = []
with gzip.open(schrift_p, 'rt', encoding='utf-8') as f:
    for line in f:
        r = json.loads(line)
        cur = []
        for tk, z in zip(r['tok'], r['zeichen']):
            if z:
                cur.extend(z); tokrec.append((tk, z))
            else:
                if cur: segs.append(cur); cur = []
        if cur: segs.append(cur)
nsig = sum(len(s) for s in segs)
print(f'sign stream: {len(segs)} segments, {nsig} signs, {len(set(x for s in segs for x in s))} sign codes')


def runs(seq):
    return [(s, len(list(g))) for s, g in itertools.groupby(seq)]


def histo(R):
    h = collections.defaultdict(C); occ = C()
    for rs in R:
        for s, L in rs:
            h[s][L] += 1; occ[s] += L
    return h, occ


R = [runs(s) for s in segs]
hist, occ = histo(R)
K = lambda h, sup=3: sum(1 for L, c in h.items() if c >= sup)
rng = random.Random(0)
shuf = []
for s in segs:
    t = s[:]; rng.shuffle(t); shuf.append(t)
hist_s, _ = histo([runs(s) for s in shuf])

print('\n[1] signs by number of distinct run lengths (each length seen >= 3 times); shuffled control in brackets')
rank = sorted(hist, key=lambda s: (-K(hist[s]), -occ[s]))
for s in rank[:16]:
    h = hist[s]; inrun = sum(L * c for L, c in h.items() if L >= 2) / occ[s]
    print(f'  {s:6s} occ {occ[s]:6d}  distinct lengths {K(h)} [{K(hist_s[s])}]  in runs>=2: {inrun:5.1%}  runs by length: ' + ' '.join(f'{L}:{h[L]}' for L in sorted(h)) + '   | shuffled: ' + ' '.join(f'{L}:{hist_s[s][L]}' for L in sorted(hist_s[s])))
dist = C(K(hist[s]) for s in hist)
print('  how many signs have k distinct run lengths:', sorted(dist.items()))
cand = [s for s in rank if K(hist[s]) >= 4]
print('  candidates (>= 4 distinct run lengths):', cand)

print('\n[2] what stands directly before a run of a candidate sign (top by specificity = share of that sign\'s runs)')
nruns = C(); follow = collections.defaultdict(C)
for rs in R:
    for (a, la), (b, lb) in zip(rs, rs[1:]):
        follow[b][a] += 1
    for s, L in rs: nruns[s] += 1
for b in cand[:4]:
    tot = sum(follow[b].values())
    top = sorted(((n / nruns[a], n, a) for a, n in follow[b].items() if n >= 5), reverse=True)[:8]
    print(f'  before {b} ({tot} cases): ' + ' ; '.join(f'{a} {n} ({sp:.0%} of its runs)' for sp, n, a in top))
    topn = follow[b].most_common(6)
    print(f'      by count: ' + ' ; '.join(f'{a} {n}' for a, n in topn))

print('\n[3] order and caps between two candidate signs (runs directly adjacent)')
pairs = collections.defaultdict(C)
after = collections.defaultdict(lambda: collections.defaultdict(C))
for rs in R:
    for (a, la), (b, lb) in zip(rs, rs[1:]):
        pairs[(a, b)][(la, lb)] += 1
        after[a][b][lb] += 1
for a, b in itertools.permutations(cand[:4] + [s for s in ('V1', 'M12', 'D50') if s not in cand[:4]], 2):
    n = sum(pairs[(a, b)].values())
    if n >= 3:
        h = after[a][b]
        print(f'  {a} -> {b}: {n:5d}   lengths of the {b} run: ' + ' '.join(f'{L}:{h[L]}' for L in sorted(h)))

# ---------- validation against the editors' values ----------
num = {}
with gzip.open(deut_p, 'rt', encoding='utf-8') as f:
    for line in f:
        r = json.loads(line)
        if r.get('lemma_form') == '1...n':
            w = re.sub(r'[\[\]⸢⸣()\?{}〈〉<>\s⸮]', '', r.get('written_form') or '')
            if re.fullmatch(r'\d+', w): num[r['tok']] = int(w)
data = [(z, num[tk]) for tk, z in tokrec if tk in num]
print(f'\n[4] validation: {len(data)} numeral tokens with signs and an integer value from the editors')
core = {'Z1': 1, 'V20': 10, 'V1': 100, 'M12': 1000}
pure = [(z, v) for z, v in data if all(s in core for s in z)]
ok = sum(1 for z, v in pure if sum(core[s] for s in z) == v)
print(f'  tokens written only with Z1/V20/V1/M12: {len(pure)} = {len(pure)/len(data):.1%}; value 1/10/100/1000 rule reproduces the editors\' value in {ok} = {ok/len(pure):.2%}')
# order inside tokens: is the sequence always non-increasing in rank?
order = ['M12', 'V1', 'V20', 'Z1']
viol = sum(1 for z, v in pure if any(order.index(a) > order.index(b) for a, b in zip(z, z[1:])))
print(f'  tokens with a lower sign before a higher one: {viol}')
mx = C()
for z, v in pure:
    for s, L in runs(z): mx[(s, L)] += 1
for s in order:
    print(f'  run lengths of {s} inside numeral tokens: ' + ' '.join(f'{L}:{mx[(s, L)]}' for L in range(1, 12) if mx[(s, L)]))
# anchored learning of all sign values (train half / test half)
rng = random.Random(1); idx = list(range(len(data))); rng.shuffle(idx)
tr = [data[i] for i in idx[:len(idx) // 2]]; te = [data[i] for i in idx[len(idx) // 2:]]
ratio = collections.defaultdict(C)
for z, v in tr:
    if len(set(z)) == 1 and v % len(z) == 0: ratio[z[0]][v // len(z)] += 1
w = {s: c.most_common(1)[0][0] for s, c in ratio.items() if c.most_common(1)[0][1] >= 3}
print('  values learned from the training half (sign: value, support):', {s: (w[s], ratio[s][w[s]]) for s in sorted(w, key=lambda s: w[s])})
cov = [(z, v) for z, v in te if all(s in w for s in z)]
hit = sum(1 for z, v in cov if sum(w[s] for s in z) == v)
print(f'  test half: {len(te)} tokens; all signs known in {len(cov)} = {len(cov)/len(te):.1%}; exact value in {hit} = {hit/len(cov):.2%} of those, {hit/len(te):.1%} of all')
err = C((' '.join(z), v) for z, v in cov if sum(w[s] for s in z) != v)
print('  most frequent misses (signs, editors\' value):', err.most_common(8))
unk = C(s for z, v in te for s in z if s not in w)
print('  signs without learned value (test half):', unk.most_common(12))
