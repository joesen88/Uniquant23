import json, sys, glob, os, re, collections, hashlib, statistics
root = sys.argv[1]
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*')
num = []; f35 = collections.Counter(); tot_tokens = 0; num_tokens = 0
for p in sorted(glob.glob(os.path.join(root,'_aes_*.json'))):
    d = json.load(open(p,encoding='utf-8'))
    for sid, s in d.items():
        for t in s.get('token', []):
            h = t.get('hiero')
            if not h: continue
            sg = SIGN.findall(h)
            if not sg: continue
            tot_tokens += len(sg)
            if re.search(r'(?:^|-)F35-F35-F35-F35', h): f35[(t.get('written_form'), t.get('pos'))] += 1
            if t.get('pos') == 'numeral':
                num_tokens += len(sg)
                wf = t.get('written_form')
                if wf and re.fullmatch(r'\d+', wf): num.append((s['text'], sg, int(wf)))
print('F35 runs>=4 come from:', f35.most_common(5))
print('sign tokens in words labelled numeral:', num_tokens, 'of', tot_tokens, '=', round(num_tokens/tot_tokens,4))
def held(t): return int(hashlib.sha256(t.encode()).hexdigest(),16) % 5 == 0
tr = [x for x in num if not held(x[0])]; te = [x for x in num if held(x[0])]
known = {}
for rnd in range(8):
    est = collections.defaultdict(list)
    for _, sg, v in tr:
        c = collections.Counter(sg)
        unk = [s for s in c if s not in known]
        if len(unk) != 1: continue
        s = unk[0]; rest = v - sum(known[x]*n for x, n in c.items() if x != s)
        est[s].append(rest / c[s])
    new = 0
    for s, vals in est.items():
        if len(vals) < 5: continue
        med = statistics.median(vals); share = sum(1 for x in vals if x == med) / len(vals)
        if share >= 0.7 and med == int(med) and med > 0:
            known[s] = int(med); new += 1
            print(f'  round {rnd}: {s:6s} = {int(med):8d}   from {len(vals):5d} words, {share:.0%} agree')
    if not new: break
ok = n_all = cov = 0
for _, sg, v in te:
    n_all += 1
    if all(x in known for x in sg):
        cov += 1; ok += (sum(known[x] for x in sg) == v)
print('recovered sign values:', dict(sorted(known.items(), key=lambda kv:(kv[1],kv[0]))))
print('integer numerals with signs:', len(num), 'train', len(tr), 'held-out', len(te))
print('held-out: words fully covered by recovered signs', cov, 'of', n_all, '| exact sum == stated number', ok, 'of', cov, '=', round(ok/max(cov,1),4))
print('largest held-out numbers matched:', sorted({v for _, sg, v in te if all(x in known for x in sg) and sum(known[x] for x in sg)==v})[-8:])
