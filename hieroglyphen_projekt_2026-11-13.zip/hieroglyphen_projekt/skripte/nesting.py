import sys, os, re, json, glob, gzip, collections, math, random, itertools
import numpy as np
wcache, aes_dir, inc = sys.argv[1:4]; random.seed(20261112)
W = json.load(gzip.open(wcache, 'rt', encoding='utf-8')); texts = [[x for w in t['w'] for x in w] for t in W.values()]
def pair_test(seqs, minocc=60, top=6, cand=None):
    fr = collections.Counter(x for s in seqs for x in s); syms = [s for s, n in fr.items() if n >= minocc] if cand is None else cand
    pos = collections.defaultdict(list)
    for i, s in enumerate(seqs):
        for j, x in enumerate(s): pos[x].append((i, j))
    by = collections.defaultdict(lambda: collections.defaultdict(list))
    for x in syms:
        for i, j in pos[x]: by[x][i].append(j)
    res = []
    for a in syms:
        for b in syms:
            if a == b or not (0.8 <= fr[a]/fr[b] <= 1.25): continue
            ok = n = 0; depth = 0
            for i in set(by[a]) | set(by[b]):
                ev = sorted([(j, 1) for j in by[a].get(i, [])] + [(j, -1) for j in by[b].get(i, [])]); d = 0; good = True; mx = 0
                for _, v in ev:
                    d += v; mx = max(mx, d)
                    if d < 0: good = False; break
                good = good and d == 0; w = len(ev); n += w
                if good: ok += w; depth = max(depth, mx)
            res.append((ok/max(n, 1), a, b, fr[a], fr[b], depth))
    return sorted(res, reverse=True)[:top], len(syms)
r, n = pair_test(texts); print(f'[1] blind search for bracket pairs among {n} frequent signs (share of occurrences in texts where the pair is balanced and properly nested | maximum depth):')
print('    Egyptian: ' + ' | '.join(f'{a}/{b} {v:.0%} (n={x}/{y}, depth {d})' for v, a, b, x, y, d in r))
# explicit enclosure markers in the raw encoding
op = cl = 0; nest = 0; mx = 0; texts_with = 0; bad = 0
for f in sorted(glob.glob(os.path.join(aes_dir, '_aes_*.json'))):
    d = json.load(open(f, encoding='utf-8')); cur = None; depth = 0
    for s in d.values():
        for k in s.get('token', []):
            h = k.get('hiero') or ''
            for ch in h:
                if ch == '<': op += 1; depth += 1; mx = max(mx, depth)
                elif ch == '>': cl += 1; depth -= 1
                if depth < 0: bad += 1; depth = 0
        depth = 0
print(f'    explicit enclosure marks in the sign encoding (name rings): opening {op}, closing {cl}, maximum depth {mx}')
# C++ tokens
KW = set(); OPS = sorted(['{', '}', '[', ']', '(', ')', ';', ':', '...', '?', '::', '.', '.*', '->', '->*', '~', '!', '+', '-', '*', '/', '%', '^', '&', '|', '=', '+=', '-=', '*=', '/=', '%=', '^=', '&=', '|=', '==', '!=', '<', '>', '<=', '>=', '<=>', '&&', '||', '<<', '>>', '<<=', '>>=', '++', '--', ',', '#'], key=len, reverse=True)
T = re.compile(r'(?P<lit>"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|\.?\d[\w.\']*)|(?P<id>[A-Za-z_]\w*)|(?P<op>' + '|'.join(re.escape(o) for o in OPS) + r')'); cpp = []
for f in sorted(glob.glob(os.path.join(inc, 'bits', '*.h')))[:80]:
    s = open(f, encoding='utf-8', errors='ignore').read(); s = re.sub(r'/\*.*?\*/', ' ', s, flags=re.S); s = re.sub(r'//[^\n]*', ' ', s); s = re.sub(r'^\s*#.*$', ' ', s, flags=re.M)
    cpp.append([m.group(0) if m.lastgroup == 'op' else ('ID' if m.lastgroup == 'id' and m.group(0) not in ('if', 'else', 'for', 'while', 'return', 'template', 'typename', 'const', 'class', 'struct', 'namespace') else m.group(0) if m.lastgroup == 'id' else 'LIT') for m in T.finditer(s)])
r, n = pair_test(cpp, minocc=200, top=5); print('    C++ (same blind search): ' + ' | '.join(f'{a} {b} {v:.0%} (depth {d})' for v, a, b, x, y, d in r))
# 2 mirror test: is the exact reverse of a sign group more common than other reorderings?
g4 = collections.Counter(tuple(s[i:i + 4]) for s in texts for i in range(len(s) - 3)); rev = []; oth = []
for g, c in g4.items():
    if c >= 5 and len(set(g)) == 4:
        rev.append(g4.get(g[::-1], 0)); perms = [p for p in itertools.permutations(g) if p != g and p != g[::-1]]; oth.append(np.mean([g4.get(p, 0) for p in perms]))
print(f'\n[2] mirror test on {len(rev)} frequent groups of four different signs: mean count of the exact reverse {np.mean(rev):.3f} | mean count of any other reordering {np.mean(oth):.3f} | groups whose reverse occurs at all: {np.mean(np.array(rev) > 0):.1%}')
g2 = collections.Counter((a, b) for s in texts for a, b in zip(s, s[1:])); r2 = [(c, g2.get((b, a), 0)) for (a, b), c in g2.items() if a != b and c >= 20]; print(f'    pairs of adjacent signs (>=20 occurrences): {len(r2)}; reverse order occurs at least a tenth as often in {np.mean([y >= 0.1*x for x, y in r2]):.0%}')
# 3 dependence over distance: chain or tree-like?
def mi_profile(seqs, K=60, D=(1, 2, 4, 8, 16, 32, 64, 128)):
    fr = collections.Counter(x for s in seqs for x in s); ids = {s: i for i, (s, _) in enumerate(fr.most_common(K))}; enc = [np.array([ids.get(x, K) for x in s]) for s in seqs if len(s) > 140]; out = []
    for d in D:
        def mi(E):
            J = np.zeros((K + 1, K + 1))
            for x in E: np.add.at(J, (x[:-d], x[d:]), 1)
            P = J/J.sum(); px = P.sum(1, keepdims=True); py = P.sum(0, keepdims=True); nz = P > 0; return float((P[nz]*np.log2(P[nz]/(px @ py)[nz])).sum())
        out.append(mi(enc) - mi([np.random.default_rng(1).permutation(x) for x in enc]))
    return D, out
for name, seqs in (('Egyptian signs', texts), ('C++ tokens', cpp)):
    D, m = mi_profile(seqs); m = np.maximum(m, 1e-6); pl = np.corrcoef(np.log(D), np.log(m))[0, 1]**2; ex = np.corrcoef(D, np.log(m))[0, 1]**2
    print(f'[3] {name}: shared information between positions at distance 1..128 (bits): ' + ' '.join(f'{x:.3f}' for x in m) + f' | fit as power law R2 {pl:.2f}, as exponential R2 {ex:.2f}')
