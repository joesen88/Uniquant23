"""Hypothesis elimination as a game of questions: which test excludes what, how many bits does each test yield,
what is the smallest set of tests that excludes every alternative, and how much uncertainty is left.
usage: python3 -I elimination_game.py
Entries: 1 = the hypothesis predicts the observed outcome, 0 = it predicts the opposite, None = it predicts nothing.
"""
import math, itertools
H = ['H0 Sprache in bekannten Gattungen', 'H1 verborgene Mathematik', 'H2 Programmcode', 'H3 Frequenzkarte', 'H4 Vier-Ringe-Code',
     'H5 doppelte Leserichtung', 'H6 Ereignisprotokoll', 'H7 Logikketten als Grundmuster', 'H8 Nullpunkt-Referenz', 'H9 Kalibriernorm']
T = ['A Lautwerte sagen Koptisch voraus', 'B Zahlen selten, zaehlen Dinge', 'C keine Periodizitaet', 'D keine Schachtelung', 'E eine Leserichtung',
     'F kein Kombinationsraster', 'G Gattung wie in Vergleichssprachen', 'H keine datierten Ereignisberichte', 'I Bedingungssaetze selten',
     'J Jahreszaehlung ohne festen Nullpunkt', 'K Rituale ohne Messvokabular']
N = None
M = [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],      # H0
     [0, 0, N, N, N, N, N, N, N, N, N],      # H1
     [0, N, N, 0, N, N, N, N, 0, N, N],      # H2
     [0, 0, 0, N, N, N, N, N, N, N, N],      # H3
     [0, N, N, N, N, 0, N, N, N, N, N],      # H4
     [N, N, N, 0, 0, N, N, N, N, N, N],      # H5
     [1, N, 1, 1, 1, 1, N, 0, N, N, N],      # H6
     [1, N, 1, N, 1, 1, N, N, 0, N, N],      # H7
     [1, N, 1, 1, 1, 1, N, N, N, 0, N],      # H8
     [1, N, 1, 1, 1, 1, N, N, N, N, 0]]      # H9
nh, nt = len(H), len(T)
ent = lambda p: -sum(x * math.log2(x) for x in p if x > 0)

def like(h, t, eps, vague):
    v = M[h][t]
    return 1.0 if v == 1 else (eps if v == 0 else vague)

def eig(prior, t, eps=0.0, vague=0.5):
    py = sum(prior[h] * like(h, t, eps, vague) for h in range(nh)); pn = 1 - py
    post_y = [prior[h] * like(h, t, eps, vague) / py for h in range(nh)] if py > 0 else prior
    post_n = [prior[h] * (1 - like(h, t, eps, vague)) / pn for h in range(nh)] if pn > 0 else prior
    return ent(prior) - (py * ent(post_y) + pn * ent(post_n)), post_y

uni = [1 / nh] * nh
print(f'{nh} hypotheses, {nt} tests; uncertainty at the start: {ent(uni):.2f} bits (log2 of {nh})')
print('\ncontradicted predictions per hypothesis:')
for h in range(nh):
    bad = [T[t][0] for t in range(nt) if M[h][t] == 0]; none = sum(1 for t in range(nt) if M[h][t] is None)
    print(f'  {H[h]:36s} contradicted by {len(bad)}: {" ".join(bad) or "-":8s} | no prediction for {none} tests')
print('\neach test at the start (all hypotheses equally likely): which alternatives it excludes, expected information')
for t in sorted(range(nt), key=lambda t: -eig(uni, t)[0]):
    ex = [H[h][:2] for h in range(nh) if M[h][t] == 0]
    print(f'  {T[t]:40s} excludes {len(ex)}: {" ".join(ex):12s} expected gain {eig(uni, t)[0]:.2f} bits')
# greedy order of questions, updating on the observed outcome (always "yes")
print('\ngreedy order (always the test with the largest expected gain, then update on the observed result):')
prior = uni[:]; left = list(range(nt))
while left:
    t = max(left, key=lambda t: eig(prior, t)[0]); g, post = eig(prior, t)
    prior = post; left.remove(t)
    alive = [H[h][:2] for h in range(nh) if prior[h] > 1e-12]
    print(f'  {T[t]:40s} gain {g:.2f} bits -> P(H0) = {prior[0]:.3f}, left {ent(prior):.2f} bits, not yet excluded: {" ".join(alive)}')
    if len(alive) == 1: break
# smallest set of tests that contradicts every alternative
for k in range(1, nt + 1):
    sols = [c for c in itertools.combinations(range(nt), k) if all(any(M[h][t] == 0 for t in c) for h in range(1, nh))]
    if sols:
        print(f'\nsmallest set of tests that contradicts every alternative: {k} tests; {len(sols)} such sets, e.g. ' + ', '.join(T[t][0] for t in sols[0]))
        break
print('\nwhat is left after all tests, under different assumptions (eps = weight kept after a contradicted prediction, vague = probability a hypothesis without prediction gives to the observed result):')
for eps, vague in ((0.1, 0.5), (0.5, 0.5), (0.1, 1.0), (0.5, 1.0)):
    w = [math.prod(like(h, t, eps, vague) for t in range(nt)) for h in range(nh)]; s = sum(w); p = [x / s for x in w]
    second = max(range(1, nh), key=lambda h: p[h])
    print(f'  eps={eps}, vague={vague}: P(H0) = {p[0]:.4f}; remaining uncertainty {ent(p):.3f} bits; strongest alternative {H[second][:2]} with {p[second]:.4f}')
    if (eps, vague) == (0.5, 1.0):
        best_next = max(range(nt), key=lambda t: eig(p, t, eps, vague)[0])
        print(f'     even here, repeating the most informative test would yield only {eig(p, best_next, eps, vague)[0]:.3f} bits')
