"""Does the 'economy' rule (the sum of a written run is never the value of a single sign) hold in the known Egyptian system?
usage: python3 -I eg_economy_check.py <aes_tokens_cache.json.gz>"""
import sys, gzip, json, re, collections
from fractions import Fraction as Fr
C = collections.Counter
T = json.load(gzip.open(sys.argv[1], 'rt', encoding='utf-8'))
clean = lambda w: re.sub(r'[\[\]⸢⸣()\?{}〈〉<>\s⸮]', '', w or '')
SIX = ['1/2', '1/4', '1/8', '1/16', '1/32', '1/64']; VAL = {Fr(x) for x in SIX}
runs = C(); where = collections.defaultdict(C); ex = collections.defaultdict(list)
for tid, t in T.items():
    toks = t['tok']; p0 = 0
    for L in t['sl']:
        s = toks[p0:p0 + L]; p0 += L; run = []
        for i, tk in enumerate(s + [(None, None, None, None)]):
            w = clean(tk[3]) if tk[1] == '1...n' else None
            if w in SIX: run.append(w)
            else:
                if len(run) >= 2:
                    runs[tuple(run)] += 1; where[tuple(run)][t['corpus']] += 1
                    if len(ex[tuple(run)]) < 2: ex[tuple(run)].append(' '.join((x[1] or '?') + (('=' + clean(x[3])) if x[1] == '1...n' else '') for x in s[max(0, i - len(run) - 3):i + 1]))
                run = []
tot = sum(runs.values())
viol = {r: n for r, n in runs.items() if sum(Fr(x) for x in r) in VAL}
ge1 = {r: n for r, n in runs.items() if sum(Fr(x) for x in r) >= 1}
dbl = {r: n for r, n in runs.items() if len(set(r)) < len(r)}
print(f'runs of two or more fraction notations: {tot} tokens, {len(runs)} types')
print(f'runs whose sum equals the value of a single sign (economy violated): {sum(viol.values())} tokens = {sum(viol.values())/tot:.1%}')
for r, n in sorted(viol.items(), key=lambda kv: -kv[1]): print(f'    {" + ".join(r):22s} = {sum(Fr(x) for x in r)}   x{n}   {dict(where[r])}   e.g. {ex[r][0][:110]}')
print(f'runs with a repeated sign: {sum(dbl.values())} tokens; of these with a sum equal to a single sign: {sum(n for r, n in dbl.items() if r in viol)}')
for r, n in sorted(dbl.items(), key=lambda kv: -kv[1]): print(f'    {" + ".join(r):22s} = {sum(Fr(x) for x in r)}   x{n}   {dict(where[r])}')
print(f'runs with a sum of 1 or more: {sum(ge1.values())}', dict(ge1))
