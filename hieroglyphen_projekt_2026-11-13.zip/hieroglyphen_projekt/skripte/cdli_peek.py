"""Peek at the CDLI dump: catalogue fields and raw token shapes (for writing the parser only, no analysis).
usage: python3 -I cdli_peek.py <dir with cdliatf_unblocked.atf and cdli_catalogue_[1-4]of4.csv>"""
import sys, os, csv, io, re, collections
C = collections.Counter
d = sys.argv[1]
raw = b''.join(open(os.path.join(d, f'cdli_catalogue_{i}of4.csv'), 'rb').read() for i in (1, 2, 3, 4))
txt = raw.decode('utf-8', errors='replace')
csv.field_size_limit(10**9)
rd = csv.DictReader(io.StringIO(txt))
per = C(); gen = C(); cat = {}
for r in rd:
    try: pid = int(r['id_text'])
    except Exception: continue
    cat[pid] = (r['period'], r['genre'], r['language'], r['provenience'])
    per[r['period']] += 1; gen[r['genre']] += 1
print('catalogue rows:', len(cat)); print('periods:', per.most_common(12)); print('genres:', gen.most_common(8))
ur3 = {p for p, v in cat.items() if 'Ur III' in v[0]}
print('Ur III entries:', len(ur3), '| genres:', C(cat[p][1] for p in ur3).most_common(6))
shapes = C(); ntok = C(); cur = None; lang = None; n_txt = 0; shown = 0
num = re.compile(r'\d\(|\d/\d')
with open(os.path.join(d, 'cdliatf_unblocked.atf'), encoding='utf-8', errors='replace') as f:
    for line in f:
        if line.startswith('&P'):
            m = re.match(r'&P(\d+)', line); cur = int(m.group(1)) if m else None
            if cur in ur3: n_txt += 1
            continue
        if cur not in ur3: continue
        if shown < 40 and n_txt == 5000: print('   ', line.rstrip()); shown += 1
        if not re.match(r"\d+'?\.", line): continue
        for t in line.split()[1:]:
            if num.search(t):
                ntok[t] += 1
                shapes[re.sub(r'\d+', 'N', t)] += 1
print('Ur III texts with transliteration:', n_txt)
print('number-token shapes (digits -> N):', len(shapes))
for s, n in shapes.most_common(90): print(f'  {n:8d}  {s}')
