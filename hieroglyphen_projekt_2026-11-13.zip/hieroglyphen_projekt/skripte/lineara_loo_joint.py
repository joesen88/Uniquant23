import sys, runpy, math
from fractions import Fraction as Fr
import numpy as np
M = runpy.run_path(sys.argv[1], run_name='loo')
P36, setup, violations, variants, ATT = (M[k] for k in ('P36', 'setup', 'violations', 'variants', 'ATT'))
def count(core, drop):
    runs, keys, V = variants(core)
    signs = ['J', 'E', 'F', 'K', 'L2', 'L3', 'L4', 'L6', 'B', 'D']
    tot = 0; better = 0; tie = 0
    for n in range(2, 54):
        for K in P36:
            SC, val, den, shape, names = setup(n, K, {s: P36 for s in ('B', 'D')}, core)
            vio = violations(val, SC, signs, runs)
            nv = np.zeros(shape, dtype=np.int16)
            for k in keys:
                if k[0] in drop: continue
                nv += vio[k]
            L = np.full(shape, math.lcm(2, 4, 8, 2 * n, 3 * n, 4 * n, 6 * n), dtype=np.int64)
            for s in ['K'] + names: L = np.lcm(L, den[s])
            p = nv == 0; tot += int(p.sum()); better += int((p & (L < 120)).sum()); tie += int((p & (L == 120)).sum())
    return tot, better, tie
five = {'D D', 'B B', 'K L2', 'D D D D', 'F K'}
allruns = {r[0] for r in M['RUNS']}
print('core, full rule set:', count(True, set()))
print('core, only the five runs D D, B B, K L2, D D D D, F K kept (13 others removed together):', count(True, allruns - five))
print('core, E B and JE B removed together:', count(True, {'E B', 'JE B'}))
print('core, J K and F K removed together:', count(True, {'J K', 'F K'}))
print('core, all single-attestation runs removed:', count(True, {r for r in allruns if ATT[r] < 2}))
