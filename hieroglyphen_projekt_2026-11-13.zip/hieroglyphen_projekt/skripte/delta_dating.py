"""Dating with Burrows' Delta: validate on dated texts (also across text groups), then place the undated ones.
usage: python3 -I delta_dating.py <aes_tokens_cache.json.gz>
"""
import sys, gzip, json, collections
import numpy as np

C = collections.Counter
T = json.load(gzip.open(sys.argv[1], 'rt', encoding='utf-8'))
PER = ['OK & FIP', 'MK & SIP', 'NK', 'TIP - Roman times']
SHORT = {'OK & FIP': 'AR/1.Zw', 'MK & SIP': 'MR/2.Zw', 'NK': 'NR', 'TIP - Roman times': '3.Zw-röm'}
IMPLIED = {'bbawramessiden': 'NK', 'bbawamarna': 'NK', 'bbawhistbiospzt': 'TIP - Roman times', 'bbawtempelbib': 'TIP - Roman times', 'bbawgrabinschriften': 'OK & FIP'}
docs = []
for tid, t in T.items():
    lem = [tk[0] for tk in t['tok'] if tk[0] and tk[2] not in ('entity_name', 'numeral')]
    if len(lem) >= 100: docs.append((tid, t['corpus'], t.get('date') or 'unknown', lem))
ref = [i for i, d in enumerate(docs) if d[2] in PER and len(d[3]) >= 300]
print(f'texts >= 100 words: {len(docs)}; reference set (dated, >= 300 words): {len(ref)}:', C(docs[i][2] for i in ref).most_common())


def build(n):
    tot = C()
    for i in ref: tot.update(docs[i][3])
    vocab = [w for w, _ in tot.most_common(n)]; idx = {w: j for j, w in enumerate(vocab)}
    F = np.zeros((len(docs), n))
    for r, d in enumerate(docs):
        L = len(d[3])
        for w, k in C(d[3]).items():
            j = idx.get(w)
            if j is not None: F[r, j] = k / L
    mu = F[ref].mean(axis=0); sd = F[ref].std(axis=0); sd[sd == 0] = 1.0
    return (F - mu) / sd


def predict(Z, i, pool, k=5):
    d = np.abs(Z[pool] - Z[i]).mean(axis=1)
    order = np.argsort(d)[:k]
    labs = [docs[pool[j]][2] for j in order]
    c = C(labs); top = c.most_common()
    best = [l for l, v in top if v == top[0][1]]
    lab = best[0] if len(best) == 1 else next(l for l in labs if l in best)
    return lab, c[lab] / k, float(d[order[0]])


for n in (150, 500):
    Z = build(n)
    refarr = np.array(ref)
    res = {'all': [], 'other groups only': [], 'same group only': []}
    for i in ref:
        pool_all = refarr[refarr != i]
        res['all'].append((docs[i][2], predict(Z, i, pool_all)[0]))
        other = np.array([j for j in ref if docs[j][1] != docs[i][1]])
        res['other groups only'].append((docs[i][2], predict(Z, i, other)[0]))
        same = np.array([j for j in ref if docs[j][1] == docs[i][1] and j != i])
        if len(same) >= 5 and len({docs[j][2] for j in same}) >= 2:
            res['same group only'].append((docs[i][2], predict(Z, i, same)[0]))
    print(f'\n== n = {n} features, 5 nearest neighbours, leave-one-out on the reference set')
    for name, pairs in res.items():
        acc = np.mean([a == b for a, b in pairs]); maj = C(a for a, _ in pairs).most_common(1)[0][1] / len(pairs)
        adj = np.mean([abs(PER.index(a) - PER.index(b)) <= 1 for a, b in pairs])
        rec = {SHORT[p]: f"{np.mean([b == p for a, b in pairs if a == p]):.0%} of {sum(1 for a, _ in pairs if a == p)}" for p in PER if any(a == p for a, _ in pairs)}
        print(f'  neighbours from {name:18s}: n={len(pairs):3d}  correct period {acc:.1%} (always guessing the largest class: {maj:.1%}); within one period {adj:.1%}; recall {rec}')
    if n == 150:
        conf = C(res['other groups only'])
        print('  confusion (true -> predicted), other groups only:', {f'{SHORT[a]}->{SHORT[b]}': v for (a, b), v in conf.most_common(12)})

Z = build(150); refarr = np.array(ref)
und = [i for i, d in enumerate(docs) if d[2] not in PER]
print(f'\n== undated texts with >= 100 words: {len(und)}')
rows = []
for i in und:
    tid, corp, _, lem = docs[i]
    lab, share, dist = predict(Z, i, refarr)
    other = np.array([j for j in ref if docs[j][1] != corp])
    lab2, share2, dist2 = predict(Z, i, other)
    rows.append((corp, len(lem), lab, share, lab2, share2, IMPLIED.get(corp), tid))
for r in sorted(rows):
    print(f'  {r[0]:20s} {r[1]:5d} words | all neighbours: {SHORT[r[2]]:9s} ({r[3]:.0%}) | other groups only: {SHORT[r[4]]:9s} ({r[5]:.0%}) | period implied by the collection: {SHORT.get(r[6], "-")}   {r[7]}')
imp = [r for r in rows if r[6]]
print(f'\nundated texts whose collection implies a period: {len(imp)}')
print(f'  all neighbours agree with it: {sum(1 for r in imp if r[2] == r[6])} | other groups only: {sum(1 for r in imp if r[4] == r[6])} | both agree with each other: {sum(1 for r in rows if r[2] == r[4])} of {len(rows)}')
for corp in sorted({r[0] for r in rows}):
    sub = [r for r in rows if r[0] == corp]
    print(f'  {corp:20s} n={len(sub):2d}  all: {dict(C(SHORT[r[2]] for r in sub))} | other groups: {dict(C(SHORT[r[4]] for r in sub))}')
