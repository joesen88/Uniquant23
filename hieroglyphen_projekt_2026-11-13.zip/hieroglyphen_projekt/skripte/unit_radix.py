"""Blind to meaning: for every word that stands directly before a number, the distribution of those numbers.
Bounded, evenly used ranges = cyclic units or numbered series; open, heavy-tailed ranges = plain counts.
usage: python3 -I unit_radix.py <aes_tokens_cache.json.gz> <aes_deutung_token.jsonl.gz>
"""
import sys, gzip, json, re, collections, math

C = collections.Counter
tok_p, deut_p = sys.argv[1], sys.argv[2]
with gzip.open(tok_p, 'rt', encoding='utf-8') as f:
    T = json.load(f)
gl = collections.defaultdict(C); epag = C()
with gzip.open(deut_p, 'rt', encoding='utf-8') as f:
    for line in f:
        r = json.loads(line)
        lid = r.get('lemmaID'); t = (r.get('cotext_translation') or '').strip()
        if lid: gl[lid][t] += 1
        if 'Epagomen' in t: epag[(r.get('lemma_form'), t[:40])] += 1
g = lambda lid: (gl[lid].most_common(1)[0][0][:26] if gl.get(lid) else '')
clean = lambda w: re.sub(r'[\[\]⸢⸣()\?{}〈〉<>\s⸮]', '', w or '')

vals = collections.defaultdict(list); name = {}
pooled = []
chains = collections.defaultdict(list); between = collections.defaultdict(C); triples = C()
after_month = C()
for tid, t in T.items():
    toks = t['tok']; p0 = 0; sents = []
    for L in t['sl']:
        sents.append(toks[p0:p0 + L]); p0 += L
    if p0 < len(toks): sents.append(toks[p0:])
    for s in sents:
        items = []
        for i, tk in enumerate(s):
            if tk[1] != '1...n' or i == 0: continue
            cw = clean(tk[3])
            if not re.fullmatch(r'\d+', cw): continue
            u = s[i - 1]
            if u[2] == 'numeral' or not u[0]: continue
            v = int(cw)
            vals[u[0]].append(v); name[u[0]] = u[1]; pooled.append(v)
            items.append((i, u[0], v))
        for a, b in zip(items, items[1:]):
            if b[0] - a[0] <= 5:
                chains[(a[1], b[1])].append((a[2], b[2]))
                between[(a[1], b[1])][' '.join(x[1] or '?' for x in s[a[0] + 1:b[0] - 1])] += 1
        for a, b, c in zip(items, items[1:], items[2:]):
            if b[0] - a[0] <= 5 and c[0] - b[0] <= 5: triples[(a[1], b[1], c[1])] += 1

P = C(pooled); NP = len(pooled)
cdf = lambda cap: sum(c for v, c in P.items() if v <= cap) / NP
print(f'numbers with a counted word before them: {NP}; different counted words: {len(vals)}; with >= 30 numbers: {sum(1 for v in vals.values() if len(v) >= 30)}')
rows = []
for lid, vs in vals.items():
    n = len(vs)
    if n < 30: continue
    c = C(vs)
    cap = max(v for v, k in c.items() if k >= 2)
    inside = [v for v in vs if 1 <= v <= cap]
    cov = len(set(inside)) / cap
    H = -sum((k / len(inside)) * math.log2(k / len(inside)) for k in C(inside).values())
    Hn = H / math.log2(cap) if cap > 1 else 0.0
    # KS distance to the uniform distribution on 1..cap
    ks = 0.0; cum = 0
    ci = C(inside)
    for v in range(1, cap + 1):
        cum += ci[v]
        ks = max(ks, abs(cum / len(inside) - v / cap))
    lp = n * math.log10(cdf(cap)) if cdf(cap) < 1 else 0.0
    rows.append((lid, n, cap, max(vs), cov, Hn, ks, lp, c))
print('\nwords before numbers, sorted by evenness of use of the range 1..cap (cap = largest value seen at least twice)')
print('  word         gloss (shown only after the fact)      n   cap  max  coverage  evenness   KS   log10 p(all<=cap)   most frequent values')
bounded = []
for lid, n, cap, mx, cov, Hn, ks, lp, c in sorted(rows, key=lambda r: (-(r[5] if r[2] >= 3 else 0), -r[1])):
    flag = cap >= 3 and cov >= 0.9 and Hn >= 0.85 and lp <= -3
    if flag: bounded.append((name[lid], g(lid), n, cap, mx))
    print(f'  {"*" if flag else " "} {name[lid]:11s} {g(lid):26s} {n:5d} {cap:5d} {mx:5d}   {cov:5.0%}    {Hn:5.2f}   {ks:4.2f}   {lp:8.1f}     ' + ' '.join(f'{v}:{k}' for v, k in c.most_common(8)))
print('\nbounded and evenly used (cap >= 3, coverage >= 90 %, evenness >= 0.85, p <= 1e-3):')
for b in bounded: print('  ', b)

print('\nchains: counted word + number directly followed (within 5 tokens) by another counted word + number')
for (a, b), vs in sorted(chains.items(), key=lambda kv: -len(kv[1]))[:22]:
    ca = C(x for x, _ in vs); cb = C(y for _, y in vs)
    capa = max(ca); capb = max(cb)
    print(f'  {name[a]:10s} ({g(a)[:14]:14s}) -> {name[b]:10s} ({g(b)[:14]:14s}) {len(vs):4d}   first: max {capa:4d}, distinct {len(ca):3d}   second: max {capb:4d}, distinct {len(cb):3d}   between: ' + ' ; '.join(f'[{k}] {n}' for k, n in between[(a, b)].most_common(4)))
print('\ntriples:', [(tuple(name[x] for x in k), n) for k, n in triples.most_common(8)])
print('\nepagomenal days in the glosses:', epag.most_common(6))
