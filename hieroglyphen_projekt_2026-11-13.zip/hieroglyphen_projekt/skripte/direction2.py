import sys, os, re, json, gzip, collections, math, lzma, bz2, array, unicodedata, random, statistics
import numpy as np
wcache, bdir = sys.argv[1:3]; random.seed(20261112)
W = json.load(gzip.open(wcache, 'rt', encoding='utf-8'))
def H(c):
    n = sum(c.values()); return -sum(v/n*math.log2(v/n) for v in c.values())
def cond(seqs):
    big = collections.Counter()
    for s in seqs:
        for a, b in zip(s, s[1:]): big[(a, b)] += 1
    first = collections.Counter()
    for (a, b), n in big.items(): first[a] += n
    return H(big) - H(first)
def comp(seqs):
    ids = {}; a = array.array('H', (ids.setdefault(x, len(ids) + 1) for s in seqs for x in list(s) + ['\n'])).tobytes()
    return 8*min(len(lzma.compress(a, preset=9 | lzma.PRESET_EXTREME)), len(bz2.compress(a, 9)))
texts = [[x for w in t['w'] for x in w] for t in W.values()]; N = sum(len(s) for s in texts)
print(f'as recorded: given neighbour {cond(texts):.3f} bits per sign | compressed {comp(texts)/N:.3f}')
for L in (10, 30, 100):
    mix = []
    for s in texts:
        o = []
        for j in range(0, len(s), L): c = s[j:j+L]; o += c[::-1] if (j//L) % 2 else c
        mix.append(o)
    print(f'  every second stretch of {L} signs reversed (alternating direction): given neighbour {cond(mix):.3f} | compressed {comp(mix)/N:.3f}')
# per-text direction test against the rest of the corpus
big = collections.Counter(); uni = collections.Counter()
for s in texts:
    for a, b in zip(s, s[1:]): big[(a, b)] += 1; uni[a] += 1
V = len(set(x for s in texts for x in s)); k = 0.1; res = []
for s in texts:
    if len(s) < 100: continue
    own = collections.Counter(zip(s, s[1:])); ownu = collections.Counter(s[:-1])
    def score(seq):
        return -sum(math.log2((big.get((a, b), 0) - own.get((a, b), 0) + k)/(uni.get(a, 0) - ownu.get(a, 0) + k*V)) for a, b in zip(seq, seq[1:]))/(len(seq) - 1)
    res.append((score(s), score(s[::-1]), len(s)))
fw = sum(1 for a, b, n in res if a < b); print(f'\nper-text direction test (texts with >=100 signs: {len(res)}): {fw} = {fw/len(res):.1%} are better predicted in the recorded direction; median advantage {statistics.median(b - a for a, b, n in res):.2f} bits per sign; texts preferring the reverse: {len(res) - fw}')
# triangulation: how many independent names until a letter value is fixed?
SEG = re.compile(r'''<seg id=['"]([^'"]+)['"][^>]*>(.*?)</seg>''', re.S)
def norm(text, strip_marks):
    t = text.lower()
    if strip_marks: t = ''.join(c for c in unicodedata.normalize('NFD', t) if unicodedata.category(c) != 'Mn')
    return [w for w in re.split(r'[^\w]+', ''.join(c if unicodedata.category(c)[0] == 'L' else ' ' for c in t)) if w]
rawL = open(os.path.join(bdir, 'Latin.xml'), encoding='utf-8').read(); VL = {i: norm(x, False) for i, x in SEG.findall(rawL)}; VH = {i: norm(x, True) for i, x in SEG.findall(open(os.path.join(bdir, 'Hebrew.xml'), encoding='utf-8').read())}
capc = collections.Counter(); totc = collections.Counter()
for i, x in SEG.findall(rawL):
    for m in re.finditer(r"[A-Za-z]+", x): totc[m.group(0).lower()] += 1; capc[m.group(0).lower()] += m.group(0)[0].isupper()
ids = sorted(set(i for i, w in VL.items() if w) & set(i for i, w in VH.items() if w)); inv = collections.defaultdict(set); invB = collections.defaultdict(set)
for i in ids:
    for w in set(VL[i]): inv[w].add(i)
    for w in set(VH[i]): invB[w].add(i)
pairs = []
for w, vs in inv.items():
    if not 3 <= len(vs) <= 120 or capc[w]/max(totc[w], 1) < 0.8: continue
    c = collections.Counter(u for i in vs for u in set(VH[i])); best = max(((n/len(vs | invB[u]), u) for u, n in c.most_common(8)), default=(0, ''))
    if best[0] >= 0.8: pairs.append((list(best[1]) + ['#'], list(w)))
GOLD = {'ב': 'bv', 'ג': 'g', 'ד': 'd', 'ה': 'hae', 'ו': 'uvo', 'ז': 'z', 'ח': 'ha', 'ט': 't', 'י': 'ije', 'כ': 'ck', 'ך': 'ck', 'ל': 'l', 'מ': 'm', 'ם': 'm', 'נ': 'n', 'ן': 'n', 'ס': 's', 'פ': 'pf', 'ף': 'pf', 'צ': 's', 'ץ': 's', 'ק': 'ck', 'ר': 'r', 'ש': 's', 'ת': 't', 'א': 'aeiou', 'ע': 'aeiou'}
STRICT = set('בגדזטכךלמםנןספףצץקרשת')
def model1(P):
    hs = sorted(set(h for p in P for h in p[0])); ls = sorted(set(l for p in P for l in p[1])); t = {h: {l: 1/len(ls) for l in ls} for h in hs}
    for it in range(25):
        cnt = {h: collections.Counter() for h in hs}
        for hw, lw in P:
            for l in lw:
                z = sum(t[h][l] for h in hw)
                for h in hw: cnt[h][l] += t[h][l]/z
        for h in hs:
            s = sum(cnt[h].values()) or 1; t[h] = {l: cnt[h][l]/s for l in ls}
    return {h: max(t[h], key=t[h].get) for h in hs if h != '#'}
print(f'\ntriangulation with {len(pairs)} name pairs (Hebrew letters treated as unknown, Latin as known); consonant letters only:')
byn = collections.defaultdict(list)
for kk in (3, 5, 10, 20, 40, 80, len(pairs)):
    acc = []
    for rep in range(1 if kk == len(pairs) else 120):
        P = pairs if kk == len(pairs) else random.sample(pairs, kk); val = model1(P); occ = collections.Counter(h for hw, _ in P for h in set(hw)); ok = []
        for h, l in val.items():
            if h in STRICT: good = l in GOLD[h]; ok.append(good); byn[min(occ[h], 12)].append(good)
        acc.append(np.mean(ok) if ok else 0)
    print(f'  {kk:3d} names: {np.mean(acc):.0%} of the consonant letters that occur get the right value')
print('  by number of different names a letter occurs in: ' + ' | '.join(f"{n if n < 12 else '12+'}: {np.mean(v):.0%} (n={len(v)})" for n, v in sorted(byn.items()) if n in (1, 2, 3, 4, 5, 6, 8, 10, 12)))
