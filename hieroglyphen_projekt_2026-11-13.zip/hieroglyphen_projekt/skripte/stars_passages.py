"""Star passages: can a pattern taken from a known language find them? (criteria: stars_passages_prereg.txt)
Part A: the star sign N14 as a marker that needs no reading. Part B: what accompanies "Stern" in the German Bible,
carried over through the standard translation of the Egyptian words.
usage: python3 -I stars_passages.py <dir with _aes_*.json> <German.xml of the Bible corpus> <concordance.csv>"""
import sys, os, json, re, collections
C = collections.Counter
d, bible, conc = sys.argv[1:4]
KEY = set('30890 500410 127020 851672 133310 247 75770 116440 131180 113850 141220 87500 131280 108470 164880 851596 132210 60840 851749 853991 853304'.split())
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*'); base = lambda s: re.sub(r'(?<=\d)[A-Za-z]+$', '', s)
names = {}
for line in open(conc, encoding='utf-8'):
    p = line.rstrip('\n').split('\t')
    if len(p) >= 2: names[p[-1]] = p[0][:62]
verses = [re.findall(r'[A-Za-zÄÖÜäöüß]+', v) for v in re.findall(r'<seg[^>]*type="verse"[^>]*>(.*?)</seg>', open(bible, encoding='utf-8').read(), flags=re.S)]
def stem(w):
    for suf in ('ern', 'en', 'es', 'e', 'n', 's'):
        if w.endswith(suf) and len(w) - len(suf) >= 4: return w[:-len(suf)]
    return w
def companions(pref, k=10, mina=5):
    a = C(); b = C(); S = 0
    for v in verses:
        st = [stem(w) for w in v]
        nouns = {x for w, x in zip(v[1:], st[1:]) if w[0].isupper() and len(w) >= 4 and not x.startswith(pref)}
        for x in nouns: b[x] += 1
        if any(x.startswith(pref) for x in st):
            S += 1
            for x in nouns: a[x] += 1
    N = len(verses)
    return S, sorted(((a[x] / S) / (b[x] / N), x, a[x], b[x]) for x in a if a[x] >= mina)[::-1][:k]
print('German Bible: verses', len(verses))
sets = {}
for label, pref in (('Stern', ('Stern', 'Gestirn', 'Morgenstern')), ('Brot', ('Brot',)), ('Schwert', ('Schwert',))):
    S, r = companions(pref); sets[label] = [x for _, x, _, _ in r]
    print(f'   companions of {label} ({S} verses): ' + ', '.join(f'{x} {ra:.0f}x ({a}/{b})' for ra, x, a, b in r))
rx = {k: re.compile(r'\b(' + '|'.join(sorted(map(re.escape, v), key=len, reverse=True)) + ')') for k, v in sets.items()}
tok = C(); fp = C(); sent = C(); anyc = collections.defaultdict(C); kdist = C(); kstar = C(); texts = C(); tcorp = {}; ex = []
for fn in sorted(os.listdir(d)):
    if not fn.startswith('_aes_'): continue
    data = json.load(open(os.path.join(d, fn), encoding='utf-8'))
    for sid, s in data.items():
        toks = s['token']; key = [str(tk.get('lemmaID') or '') in KEY for tk in toks]
        s14 = skey = shier = False
        for tk, k in zip(toks, key):
            h = tk.get('hiero')
            if not h: continue
            has = 'N14' in {base(x) for x in SIGN.findall(h)}; shier = True; s14 |= has; skey |= k
            tok[(has, k)] += 1
            if has and not k: fp[(tk.get('lemma_form') or '', (tk.get('cotext_translation') or '')[:28])] += 1
        if shier: sent[('A', s14, skey)] += 1
        if len(toks) < 3: continue
        star = any(key); sent['n'] += 1; sent['star'] += star
        if star: texts[s['text']] += 1; tcorp[s['text']] = s['corpus']
        gl = ' | '.join(tk.get('cotext_translation') or '' for tk, k in zip(toks, key) if not k)
        for label, r in rx.items():
            found = {m.group(1) for m in r.finditer(gl)}
            if found: anyc[label]['all'] += 1; anyc[label]['star'] += star
            if label == 'Stern':
                for k in range(1, len(found) + 1): kdist[k] += 1; kstar[k] += star
                if star and len(found) >= 3 and len(ex) < 3: ex.append((names.get(s['text'], s['text']), (s.get('sentence_translation') or '')[:150]))
    del data
tp, fpn, fn_ = tok[(True, True)], tok[(True, False)], tok[(False, True)]
print(f'\n[A] star sign N14 as marker, words with hieroglyphs: {sum(tok.values())}; star words among them {tp + fn_}; words with N14 {tp + fpn}')
print(f'   precision {tp / max(1, tp + fpn):.1%} ({tp} of {tp + fpn}) | recall {tp / max(1, tp + fn_):.1%} ({tp} of {tp + fn_})')
print('   other words with the star sign:', '; '.join(f'{l} "{g}" {n}' for (l, g), n in fp.most_common(9)))
a11, a10, a01 = sent[('A', True, True)], sent[('A', True, False)], sent[('A', False, True)]
print(f'   sentence level: precision {a11 / max(1, a11 + a10):.1%} ({a11} of {a11 + a10}) | recall {a11 / max(1, a11 + a01):.1%} ({a11} of {a11 + a01})')
n, ns = sent['n'], sent['star']; base_rate = ns / n
print(f'\n[B] sentences with at least 3 words: {n}; star sentences {ns} = {base_rate:.2%}')
enr = {}
for label in sets:
    sa, ss = anyc[label]['all'] / n, anyc[label]['star'] / ns; enr[label] = ss / sa
    print(f'   at least one companion of {label:8s}: star sentences {ss:6.1%} | all sentences {sa:6.1%} | enrichment {enr[label]:.2f}x')
b1 = enr['Stern'] >= 3 and all(enr['Stern'] >= 2 * enr[c] for c in ('Brot', 'Schwert'))
print('   B1 pattern present by the fixed rule:', b1)
best = 'not found'
for k in sorted(kdist):
    if k > 4: break
    pr, rc = kstar[k] / kdist[k], kstar[k] / ns
    print(f'   at least {k} star companions: {kdist[k]:6d} sentences, star sentences among them {kstar[k]:4d} | precision {pr:6.2%} | recall {rc:6.1%} | lift {pr / base_rate:5.1f}x')
    if pr >= 0.5 and rc >= 0.2: best = 'found'
    elif pr / base_rate >= 10 and rc >= 0.2 and best != 'found': best = 'partly'
print('   B2 passages found by the fixed rule:', best)
print('\nwhere the star sentences are (by the standard reading): texts', len(texts))
for t, c in texts.most_common(10): print(f'   {c:3d}  {names.get(t, t)}  [{tcorp[t]}]')
print('   by corpus:', dict(C(tcorp[t] for t in texts.elements()).most_common(6)))
for nm, tr in ex: print('   example:', nm, '|', tr)
