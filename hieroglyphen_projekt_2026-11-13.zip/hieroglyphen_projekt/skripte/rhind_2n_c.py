"""Final checks for the 2/n analysis. usage: python3 -I rhind_2n_c.py"""
import collections, runpy, io, contextlib
from fractions import Fraction as Fr
C = collections.Counter
with contextlib.redirect_stdout(io.StringIO()):
    G = runpy.run_path('/home/claude/scripts/rhind_2n.py')
TABLE, CAND, cls, decomps, tau = (G[k] for k in ('TABLE', 'CAND', 'cls', 'decomps', 'tau'))
primes = [n for n in TABLE if cls[n] == 'prime']
large = [p for p in primes if p >= 13 and p not in (23, 101)]
triv = [p for p in primes if 6 * p < TABLE[p][-1]]
print('primes where 1/p + 1/2p + 1/3p + 1/6p has a smaller largest denominator than the scribes\' choice:', len(triv), triv)
print('primes where the scribes used it:', [p for p in primes if TABLE[p] == (p, 2 * p, 3 * p, 6 * p)])
ok = []
for p in large:
    fam = [t for t in CAND[p] if t[0] < p and all(d % p == 0 and (p * t[0]) % d == 0 for d in t[1:])]
    if TABLE[p][-1] == min(t[-1] for t in fam): ok.append(p)
print(f'large primes, family with p/2 < a < p: scribes have the smallest largest denominator in {len(ok)}/19; not: {sorted(set(large) - set(ok))}')
ok2 = []
for p in large:
    fam = [t for t in CAND[p] if t[0] < p and t[0] % 2 == 0 and all(d % p == 0 and (p * t[0]) % d == 0 for d in t[1:])]
    if TABLE[p][-1] == min(t[-1] for t in fam): ok2.append(p)
print(f'  ... with even a only: {len(ok2)}/19; not: {sorted(set(large) - set(ok2))}')
print('large primes: a even', sum(TABLE[p][0] % 2 == 0 for p in large), '| a < p', sum(TABLE[p][0] < p for p in large), '| values of a:', sorted(C(TABLE[p][0] for p in large).items()))
minterms = [n for n in TABLE if len(TABLE[n]) == min(len(t) for t in CAND[n])]
print(f'scribes use the smallest possible number of terms: {len(minterms)}/50; primes among them: {[n for n in minterms if cls[n] == "prime"]}')
forced4 = [n for n in TABLE if min(len(t) for t in CAND[n]) == 4]
print('fractions where 4 terms are unavoidable under the limits:', forced4, '| scribes use 4 terms for:', [n for n in TABLE if len(TABLE[n]) == 4])
m3 = [n for n in TABLE if n % 3 == 0]
best2 = [n for n in m3 if TABLE[n][-1] == min(t[-1] for t in CAND[n] if len(t) == 2)]
print(f'multiples of 3: pattern equals the two-term form with the smallest largest denominator in {len(best2)}/17: {best2}')
q = decomps(75, 1012)
print('75/1012, three terms:', [t for t in q if len(t) == 3])
four = sorted((t for t in q if len(t) == 4), key=lambda t: t[-1])[:4]
print('75/1012, four terms with the smallest largest denominator:', four, [sum(Fr(1, d) for d in t) == Fr(75, 1012) for t in four])
print('is (22, 44, 253, 506) among them:', (22, 44, 253, 506) in q)
tot = sum(len(c) for c in CAND.values()); print('total candidates', tot, '| by terms', dict(C(len(t) for c in CAND.values() for t in c)))
