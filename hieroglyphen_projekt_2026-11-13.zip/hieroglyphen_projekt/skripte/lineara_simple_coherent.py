"""Linear A core (ten signs): rank of the published values under 'small denominators + small common denominator',
the one further criterion that passes all three calibration settings when the pass mark is relaxed from the best 1 % to the best 3 %.
usage: python3 -I lineara_simple_coherent.py <lineara_loo.py>"""
import sys, runpy, math
from fractions import Fraction as Fr
import numpy as np
M = runpy.run_path(sys.argv[1], run_name='loo')
P36, setup, violations, variants, PUB = (M[k] for k in ('P36', 'setup', 'violations', 'variants', 'PUB'))
runs, keys, V = variants(True); signs = ['J', 'E', 'F', 'K', 'L2', 'L3', 'L4', 'L6', 'B', 'D']
rows = []
for n in range(2, 54):
    for K in P36:
        SC, val, den, shape, names = setup(n, K, {s: P36 for s in ('B', 'D', 'H', 'A')}, True)
        vio = violations(val, SC, signs, runs); nv = np.zeros(shape, dtype=np.int16)
        for k in keys: nv += vio[k]
        L = np.full(shape, math.lcm(2, 4, 8, 2 * n, 3 * n, 4 * n, 6 * n), dtype=np.int64)
        for s in ['K'] + names: L = np.lcm(L, den[s])
        simple = math.log2(2 * 4 * 8) + math.log2(K.denominator) + sum(math.log2(k * n) for k in (2, 3, 4, 6)) + np.log2(den['B']) + np.log2(den['D'])
        sc = simple + np.log2(L)
        for i in np.argwhere(nv == 0):
            rows.append((float(sc[tuple(i)]), float(np.broadcast_to(simple, shape)[tuple(i)]), int(L[tuple(i)]), n, K, P36[i[0]], P36[i[1]]))
rows.sort(key=lambda r: r[0])
pub = [k for k, r in enumerate(rows) if r[3:] == (10, Fr(1, 10), Fr(1, 5), Fr(1, 6))][0]
better = sum(1 for r in rows if r[0] < rows[pub][0] - 1e-9); tie = sum(1 for r in rows if abs(r[0] - rows[pub][0]) <= 1e-9)
print(f'{len(rows):,} core assignments pass the hard rules; published core: score {rows[pub][0]:.2f}, {better:,} better, {tie} tied -> within the best {100 * (better + tie) / len(rows):.3f} %')
print('best under this criterion:')
for r in rows[:8]: print(f'   {r[0]:6.2f}  (denominators {r[1]:.2f} + common denominator {r[2]})   K {r[4]}, B {r[5]}, D {r[6]}, L series 1/{2*r[3]}, 1/{3*r[3]}, 1/{4*r[3]}, 1/{6*r[3]}')
import collections
top = rows[:better]
print('among the assignments ranked before the published core: L base', sorted(collections.Counter(f'1/{r[3]}' for r in top).items(), key=lambda kv: -kv[1])[:6], '| K', sorted(collections.Counter(str(r[4]) for r in top).items(), key=lambda kv: -kv[1])[:6])
