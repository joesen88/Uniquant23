"""Robustness of the Delta results: editing project as a confound, merged sign variants, dating.
usage: python3 -I burrows_delta2.py <aes_tokens_cache.json.gz> <aes_texts_cache.json.gz>
"""
import sys, gzip, json, re, collections
import numpy as np

C = collections.Counter
tok_p, txt_p = sys.argv[1], sys.argv[2]


def zscores(docs, n):
    tot = C()
    for d in docs: tot.update(d)
    vocab = [w for w, _ in tot.most_common(n)]
    idx = {w: i for i, w in enumerate(vocab)}
    F = np.zeros((len(docs), len(vocab)))
    for r, d in enumerate(docs):
        L = len(d)
        for w, k in C(d).items():
            j = idx.get(w)
            if j is not None: F[r, j] = k / L
    mu = F.mean(axis=0); sd = F.std(axis=0); sd[sd == 0] = 1.0
    return (F - mu) / sd


def burrows(Z):
    M = Z.shape[0]; D = np.zeros((M, M))
    for i in range(M): D[i] = np.abs(Z - Z[i]).mean(axis=1)
    return D


def nn_pred(D, labels):
    labels = np.array(labels); M = len(labels); pred = []; chance = 0.0
    for i in range(M):
        d = D[i].copy(); d[i] = np.inf
        pred.append(labels[int(np.argmin(d))])
        chance += ((labels == labels[i]).sum() - 1) / (M - 1)
    pred = np.array(pred)
    return pred, (pred == labels).mean(), chance / M


def run(name, docs, labels, n=150):
    Z = zscores(docs, n); D = burrows(Z)
    pred, acc, ch = nn_pred(D, labels)
    print(f'{name}: {len(docs)} texts, {len(set(labels))} classes | nearest text same class {acc:.1%} (chance {ch:.1%})')
    return pred


PROJ = lambda c: 'SAW' if c.startswith('saw') else ('BBAW' if c.startswith('bbaw') else c)
T = json.load(gzip.open(tok_p, 'rt', encoding='utf-8'))
docs = []
for tid, t in T.items():
    lem = [tk[0] for tk in t['tok'] if tk[0] and tk[2] not in ('entity_name', 'numeral')]
    if len(lem) >= 300: docs.append((tid, t['corpus'], t.get('date') or 'unknown', lem))
labs = [c for _, c, _, _ in docs]
print('== lemma level, 150 most frequent lemmas')
pred = run('all groups', [l for *_, l in docs], labs)
conf = C((a, b) for a, b in zip(labs, pred) if a != b)
print('  most frequent confusions (true -> nearest):', conf.most_common(8))
same_proj = sum(1 for a, b in zip(labs, pred) if a != b and PROJ(a) == PROJ(b)); wrong = sum(1 for a, b in zip(labs, pred) if a != b)
print(f'  of {wrong} wrong neighbours, {same_proj} stay inside the same editing project')
print('  nearest text from the same editing project:', f'{np.mean([PROJ(a) == PROJ(b) for a, b in zip(labs, pred)]):.1%}')
for proj in ('SAW', 'BBAW'):
    sub = [(c, l) for _, c, _, l in docs if PROJ(c) == proj]
    run(f'  only {proj} texts', [l for _, l in sub], [c for c, _ in sub])
lit = [(d, l) for _, c, d, l in docs if c == 'sawlit']
print('  dating labels of the literary texts:', C(d for d, _ in lit).most_common(8))
known = [(d, l) for d, l in lit if d != 'unknown']
if len(known) >= 20: run('  literary texts only, class = dating', [l for _, l in known], [d for d, _ in known])

print('\n== sign level (blind), 150 most frequent signs')
S = json.load(gzip.open(txt_p, 'rt', encoding='utf-8'))
base = lambda s: re.sub(r'(?<=\d)[A-Za-z]+$', '', s)
whole = [(t['corpus'], t.get('date') or 'unknown', t['signs']) for t in S.values() if len(t.get('signs') or []) >= 600]
run('raw sign codes, all groups', [s for *_, s in whole], [c for c, _, _ in whole])
run('variant codes merged, all groups', [[base(x) for x in s] for *_, s in whole], [c for c, _, _ in whole])
for proj in ('SAW', 'BBAW'):
    sub = [(c, [base(x) for x in s]) for c, _, s in whole if PROJ(c) == proj]
    run(f'  only {proj} texts, merged', [s for _, s in sub], [c for c, _ in sub])
# without the 30 most frequent signs: does the signal sit in a few very frequent signs?
tot = C(x for *_, s in whole for x in s); top30 = {w for w, _ in tot.most_common(30)}
run('raw sign codes without the 30 most frequent signs', [[x for x in s if x not in top30] for *_, s in whole], [c for c, _, _ in whole])
