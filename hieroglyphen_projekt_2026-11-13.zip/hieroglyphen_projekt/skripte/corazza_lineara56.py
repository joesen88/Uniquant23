"""The four measures of the paper (my reconstruction) on the 56 Linear A core assignments that tie on the common denominator.
usage: python3 -I corazza_lineara56.py <lineara_loo.py> <corazza_calib.py>"""
import sys, runpy, math, itertools, collections
from fractions import Fraction as Fr
import numpy as np
L = runpy.run_path(sys.argv[1], run_name='loo'); K = runpy.run_path(sys.argv[2], run_name='calib')
P36, setup, violations, variants = (L[k] for k in ('P36', 'setup', 'violations', 'variants'))
m1_freqdiv, m2_ambcombs, m4_goptimal, TYP, SC = (K[k] for k in ('m1_freqdiv', 'm2_ambcombs', 'm4_goptimal', 'TYP', 'SC'))
def tied_cores(thr=120):
    runs, keys, V = variants(True); signs = ['J', 'E', 'F', 'K', 'L2', 'L3', 'L4', 'L6', 'B', 'D']; out = []
    for n in range(2, 54):
        base = math.lcm(8, 12 * n)
        if base > thr: continue
        lst = [v for v in P36 if math.lcm(base, v.denominator) <= thr]
        for Kv in lst:
            SCn, val, den, shape, names = setup(n, Kv, {s: lst for s in ('B', 'D', 'H', 'A')}, True)
            vio = violations(val, SCn, signs, runs); nv = np.zeros(shape, dtype=np.int16)
            for k in keys: nv += vio[k]
            Lc = np.full(shape, math.lcm(2, 4, 8, 2 * n, 3 * n, 4 * n, 6 * n), dtype=np.int64)
            for s in ['K'] + names: Lc = np.lcm(Lc, den[s])
            for i in np.argwhere((nv == 0) & (Lc <= thr)): out.append((n, Kv, lst[i[0]], lst[i[1]]))
    return out
SIGNS = ['J', 'E', 'F', 'K', 'L2', 'L3', 'L4', 'L6', 'B', 'D']
FREQ = {'J': 137, 'E': 105, 'D': 68, 'B': 36, 'K': 32, 'L2': 26, 'F': 23, 'L3': 3, 'L4': 2, 'L6': 2}          # Table 2 of the paper
COMBOS = ['J E', 'D D', 'B B', 'E F', 'K L2', 'E L2', 'J B', 'J E L2', 'J L2', 'D D D D', 'E B', 'E L4', 'E L6', 'F K', 'J E B', 'J F', 'J K', 'L2 L4']   # Table 1, without H, A, L, Y
cores = tied_cores(); assert len(cores) == 56
rows = [[Fr(1, 2), Fr(1, 4), Fr(1, 8), Kv, Fr(1, 2 * n), Fr(1, 3 * n), Fr(1, 4 * n), Fr(1, 6 * n), B, D] for n, Kv, B, D in cores]
vals = np.array([[int(v * SC) for v in r] for r in rows], dtype=np.int64); dens = np.array([[v.denominator for v in r] for r in rows], dtype=np.int64)
pub = cores.index((10, Fr(1, 10), Fr(1, 5), Fr(1, 6)))
m1 = m1_freqdiv(vals, [FREQ[s] for s in SIGNS])
m2 = m2_ambcombs(vals, [tuple(SIGNS.index(x) for x in c.split()) for c in COMBOS])
m3 = np.array([sum(1 for v in r if v not in TYP) for r in rows])
m4 = m4_goptimal(vals, dens)
def pos(g, name):
    better = int((g < g[pub] - 1e-9).sum()); tie = int((np.abs(g - g[pub]) <= 1e-9).sum())
    b = int(np.argmin(g)); n, Kv, B, D = cores[b]
    print(f'  {name:34s} published core {g[pub]:.4f}: {better} better, {tie} tied of 56 | best: K {Kv}, B {B}, D {D} ({g[b]:.4f}); spread {g.min():.4f} to {g.max():.4f}')
print('56 core assignments with common denominator 120 (all share L2..L6 = 1/20, 1/30, 1/40, 1/60)')
pos(m1, 'M1 frequency vs divisors'); pos(m2.astype(float), 'M2 runs with equal sums'); pos(m3.astype(float), 'M3 typology (list as published)'); pos(m4, 'M4 G_Optimal (ten signs)')
print('  by K (mean of each measure):')
for Kv in (Fr(1, 10), Fr(1, 12), Fr(1, 15)):
    sel = np.array([c[1] == Kv for c in cores])
    print(f'     K = {Kv}: n = {int(sel.sum()):2d}   M1 {m1[sel].mean():.3f}   M2 {m2[sel].mean():.2f}   M3 {m3[sel].mean():.2f}   M4 {m4[sel].mean():.4f} (best {m4[sel].min():.4f})')
print('  the ten best by G_Optimal:')
for i in np.argsort(m4, kind='stable')[:10]:
    n, Kv, B, D = cores[i]; print(f'     {m4[i]:.4f}  K {Kv}, B {B}, D {D}   (M1 {m1[i]:.3f}, M2 {m2[i]}, M3 {m3[i]})' + ('   <- published' if i == pub else ''))
print('  the five best by M1:')
for i in np.argsort(m1, kind='stable')[:5]:
    n, Kv, B, D = cores[i]; print(f'     {m1[i]:.4f}  K {Kv}, B {B}, D {D}' + ('   <- published' if i == pub else ''))
