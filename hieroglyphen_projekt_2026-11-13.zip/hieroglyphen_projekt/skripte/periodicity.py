import sys, json, gzip, collections, statistics
import numpy as np
wcache, toks_p, conc_p = sys.argv[1:4]; rng = np.random.default_rng(20261112)
id2name = {}
for line in open(conc_p, encoding='utf-8'):
    p = line.rstrip('\n').split('\t')
    if len(p) == 2: id2name[p[1]] = p[0]
def lagprofile(seqs, D):
    m = np.zeros(D + 1); n = np.zeros(D + 1)
    for x in seqs:
        for d in range(1, min(D, len(x) - 1) + 1): m[d] += (x[:-d] == x[d:]).sum(); n[d] += len(x) - d
    return m[1:]/np.maximum(n[1:], 1), n[1:]
def analyse(name, items, D=300):
    ids = {}; seqs = [np.array([ids.setdefault(v, len(ids)) for v in s]) for _, s in items if len(s) >= 40]; keys = [k for k, s in items if len(s) >= 40]
    M, n = lagprofile(seqs, D); null = np.mean([lagprofile([rng.permutation(x) for x in seqs], D)[0] for _ in range(5)], 0)
    trend = np.array([np.median(M[max(0, i - 8):i + 9]) for i in range(D)]); res = M - trend; sd = np.std(res[20:]) + 1e-12; z = res/sd
    print(f'\n{name}: {len(seqs)} sequences, {sum(map(len, seqs))} symbols | chance of the same symbol at distance d: d=1 {M[0]:.4f}, d=2 {M[1]:.4f}, d=5 {M[4]:.4f}, d=20 {M[19]:.4f}, d=100 {M[99]:.4f}, d=300 {M[299]:.4f} | order destroyed: {null.mean():.4f}')
    top = np.argsort(-z)[:8]; print('  sharpest peaks above the smooth trend (distance: excess in units of noise):', [(int(i + 1), round(float(z[i]), 1)) for i in sorted(top)], '| distances with more than 5 units:', int((z > 5).sum()), 'of', D)
    d = int(np.argmax(z[10:]) + 11); contrib = []
    for k, x in zip(keys, seqs):
        if len(x) > d + 20: contrib.append((float((x[:-d] == x[d:]).mean() - trend[d - 1]), int(len(x)), k))
    contrib.sort(reverse=True); print(f'  strongest distance beyond 10: {d}; sequences that carry it:', [(id2name.get(k, k)[:46], n_, round(e, 2)) for e, n_, k in contrib[:4]])
    share = sum(1 for e, n_, k in contrib if e > 3*sd)/max(len(contrib), 1); print(f'  share of sequences that show this distance at all: {share:.0%}')
W = json.load(gzip.open(wcache, 'rt', encoding='utf-8')); analyse('all sign texts (signs)', [(t, [x for w in v['w'] for x in w]) for t, v in W.items()])
TK = json.load(gzip.open(toks_p, 'rt', encoding='utf-8'))
analyse('Pyramid Texts (words)', [(t, [k[0] or k[3] for k in v['tok']]) for t, v in TK.items() if v['corpus'] == 'bbawpyramidentexte'])
analyse('medical texts (words)', [(t, [k[0] or k[3] for k in v['tok']]) for t, v in TK.items() if v['corpus'] == 'sawmedizin'])
analyse('literary texts (words)', [(t, [k[0] or k[3] for k in v['tok']]) for t, v in TK.items() if v['corpus'] == 'sawlit'])
