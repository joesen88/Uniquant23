import sys, os, re, json, gzip, collections, math, random, statistics
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import svds
from sklearn.cluster import KMeans
from sklearn.metrics import normalized_mutual_info_score
seg_p, deut_p, wcache_p, uni_p = sys.argv[1:5]; random.seed(20261112); rng = np.random.default_rng(20261112)
D = json.load(gzip.open(seg_p, 'rt', encoding='utf-8')); pred, seqs, gold, meta = D['pred'], D['seqs'], D['gold'], D['meta']
# 1 where do the extra cuts fall inside editorial words?
pos = collections.Counter(); chance = collections.Counter()
for g, p in zip(gold, pred):
    P = set(p); st = 0
    for e in g:
        L = e - st
        if L >= 3:
            for c in range(st + 1, e):
                where = 'vor dem letzten Zeichen' if c == e - 1 else 'nach dem ersten Zeichen' if c == st + 1 else 'in der Mitte'
                chance[where] += 1
                if c in P: pos[where] += 1
        st = e
print('[1] cuts inside editorial words of >=3 signs: share of possible positions that were cut:', {k: f'{pos[k]/chance[k]:.0%}' for k in chance})
# blind tokens
toks = []; exact = []
for s, p, g, (text, tids) in zip(seqs, pred, gold, meta):
    gs = dict(zip([0] + g[:-1], zip(g, tids))); st = 0; row = []
    for e in p:
        w = tuple(s[st:e]); row.append(w); exact.append((w, gs[st][1] if st in gs and gs[st][0] == e else None, text)); st = e
    toks.append(row)
cnt = collections.Counter(w for r in toks for w in r); print(f'\n[2] blind units: {sum(cnt.values())} tokens, {len(cnt)} types; hapax share {sum(1 for v in cnt.values() if v == 1)/len(cnt):.0%}; top 10 types cover {sum(v for _, v in cnt.most_common(10))/sum(cnt.values()):.0%}')
f = np.array(sorted(cnt.values(), reverse=True), float); r = np.arange(1, len(f) + 1); m = (r >= 5) & (r <= 500); print('    rank-frequency slope of blind units (ranks 5-500):', round(float(np.polyfit(np.log10(r[m]), np.log10(f[m]), 1)[0]), 2))
vocab = [w for w, v in cnt.items() if v >= 10]; ix = {w: i for i, w in enumerate(vocab)}; rows = []; cols = []
for rw in toks:
    ids = [ix.get(w, -1) for w in rw]
    for i, a in enumerate(ids):
        if a < 0: continue
        for j in range(max(0, i - 2), min(len(ids), i + 3)):
            if j != i and ids[j] >= 0: rows.append(a); cols.append(ids[j])
M = coo_matrix((np.ones(len(rows)), (rows, cols)), shape=(len(vocab), len(vocab))).tocsr(); tot = M.sum(); rs = np.asarray(M.sum(1)).ravel(); cs = np.asarray(M.sum(0)).ravel()**0.75; cs = cs/cs.sum()
C = M.tocoo(); pmi = np.log2((C.data/tot)/((rs[C.row]/tot)*cs[C.col])); keep = pmi > 0; PP = coo_matrix((pmi[keep], (C.row[keep], C.col[keep])), shape=M.shape).tocsr()
U, S, _ = svds(PP, k=50); X = U*np.sqrt(S); X = X/(np.linalg.norm(X, axis=1, keepdims=True) + 1e-9)
# gold info only for scoring
POS = {}; GL = {}
with gzip.open(deut_p, 'rt', encoding='utf-8') as fh:
    for line in fh:
        r_ = json.loads(line); POS[r_['tok']] = r_.get('pos') or ''; GL[r_['tok']] = (r_.get('lemma_form') or '') + ' "' + (r_.get('cotext_translation') or '')[:18] + '"'
GRP = {'pronoun': 'Geruest', 'preposition': 'Geruest', 'particle': 'Geruest', 'adverb': 'Geruest', 'numeral': 'Geruest', 'interjection': 'Geruest', 'substantive': 'Inhalt', 'verb': 'Inhalt', 'adjective': 'Inhalt', 'entity_name': 'Namen', 'epitheton_title': 'Namen'}
lab = collections.defaultdict(collections.Counter); gl = collections.defaultdict(collections.Counter); ex = collections.Counter()
for w, t, text in exact:
    if t: lab[w][GRP.get(POS.get(t, ''), 'offen')] += 1; gl[w][GL.get(t, '')] += 1; ex[w] += 1
sel = [w for w in vocab if cnt[w] >= 20 and ex[w]/cnt[w] >= 0.6]; y = [lab[w].most_common(1)[0][0] for w in sel]; Xs = X[[ix[w] for w in sel]]
km = KMeans(n_clusters=12, n_init=5, random_state=0).fit(Xs); pur = sum(max(collections.Counter(l for l, c in zip(y, km.labels_) if c == j).values()) for j in set(km.labels_))/len(y)
print(f"\n[3] blind units clustered by neighbourhood (12 clusters, {len(sel)} units that coincide with editorial words): purity against word class {pur:.2f} (largest class {max(collections.Counter(y).values())/len(y):.2f}), NMI {normalized_mutual_info_score(y, km.labels_):.2f}")
for j in range(12):
    mem = [w for w, c in zip(sel, km.labels_) if c == j]; cc = collections.Counter(lab[w].most_common(1)[0][0] for w in mem); top = sorted(mem, key=lambda w: -cnt[w])[:6]
    print(f"    cluster {j:2d} n={len(mem):4d} {dict(cc.most_common(3))} | " + '; '.join(gl[w].most_common(1)[0][0] for w in top))
print('    nearest neighbours by context:')
for w in sorted(sel, key=lambda w: -cnt[w])[20:400:38]:
    sims = Xs @ X[ix[w]]; nb = [sel[i] for i in np.argsort(-sims)[1:4]]; print(f"      {gl[w].most_common(1)[0][0]:32s} -> " + ' | '.join(gl[n].most_common(1)[0][0] for n in nb))
# 4 text vectors as weighted sums
W = json.load(gzip.open(wcache_p, 'rt', encoding='utf-8')); df = collections.Counter(); tt = collections.defaultdict(list)
for rw, (text, _) in zip(toks, meta): tt[text] += [w for w in rw if w in ix]
for text, ws in tt.items(): df.update(set(ws))
texts = [t for t, ws in tt.items() if len(ws) >= 100]; idf = {w: math.log(len(tt)/df[w]) for w in df}
TV = np.array([sum(idf[w]*X[ix[w]] for w in tt[t]) for t in texts]); TV = TV/(np.linalg.norm(TV, axis=1, keepdims=True) + 1e-9); yl = [W[t]['corpus'] for t in texts]
k2 = KMeans(n_clusters=11, n_init=5, random_state=0).fit(TV); pur = sum(max(collections.Counter(l for l, c in zip(yl, k2.labels_) if c == j).values()) for j in set(k2.labels_))/len(yl)
print(f'\n[4] texts as weighted sums of unit vectors ({len(texts)} texts): 11 clusters, purity against the editorial text groups {pur:.2f} (largest group {max(collections.Counter(yl).values())/len(yl):.2f}), NMI {normalized_mutual_info_score(yl, k2.labels_):.2f}')
# 5 twins: signs with (nearly) identical neighbourhoods
fr = collections.Counter(x for s in seqs for x in s); top = [s for s, _ in fr.most_common(300)]; ctx = [s for s, _ in fr.most_common(400)]; ci = {s: i for i, s in enumerate(ctx)}; ti = {s: i for i, s in enumerate(top)}
V = np.zeros((300, 800)); VA = np.zeros((300, 800)); VB = np.zeros((300, 800))
for s in seqs:
    for i, x in enumerate(s):
        if x not in ti: continue
        half = VA if random.random() < 0.5 else VB
        if i > 0 and s[i-1] in ci: V[ti[x], ci[s[i-1]]] += 1; half[ti[x], ci[s[i-1]]] += 1
        if i + 1 < len(s) and s[i+1] in ci: V[ti[x], 400 + ci[s[i+1]]] += 1; half[ti[x], 400 + ci[s[i+1]]] += 1
def nz(A): A = np.sqrt(A); return A/(np.linalg.norm(A, axis=1, keepdims=True) + 1e-9)
Vn, An, Bn = nz(V), nz(VA), nz(VB); selfsim = (An*Bn).sum(1); Sm = Vn @ Vn.T; np.fill_diagonal(Sm, 0); T = Sm/np.sqrt(np.outer(selfsim, selfsim)); np.fill_diagonal(T, 0)
cp = collections.defaultdict(dict)
for line in open(uni_p, encoding='utf-8'):
    if line.startswith('U+'):
        p_ = line.rstrip('\n').split('\t')
        if len(p_) == 3: cp[p_[0]][p_[1]] = p_[2]
VAL = {}
for u, d in cp.items():
    if 'kEH_JSesh' in d: VAL.setdefault(d['kEH_JSesh'], (d.get('kEH_FVal', '') or d.get('kEH_Func', '')[:12]))
best = T.max(1); print(f'\n[5] twin test on the 300 most frequent signs: median self-similarity (two halves of the same sign) {np.median(selfsim):.2f}; signs whose most similar other sign reaches >=90% of that: {int((best >= 0.9).sum())}, >=80%: {int((best >= 0.8).sum())}, >=70%: {int((best >= 0.7).sum())}; median best partner {np.median(best):.2f}')
pr = sorted(((T[i, j], top[i], top[j]) for i in range(300) for j in range(i + 1, 300)), reverse=True)[:14]
print('    closest pairs: ' + ' | '.join(f"{a}({VAL.get(a, '')})~{b}({VAL.get(b, '')}) {v:.2f}" for v, a, b in pr))
# 6 does every text use the same core?
g30 = set(s for s, _ in fr.most_common(30)); g100 = set(s for s, _ in fr.most_common(100)); ov = []; cov = []
for t in W.values():
    c = collections.Counter(x for w in t['w'] for x in w); n = sum(c.values())
    if n >= 300: ov.append(len(g30 & set(s for s, _ in c.most_common(30)))); cov.append(sum(v for s, v in c.items() if s in g100)/n)
print(f'\n[6] texts with >=300 signs: {len(ov)}; of each text\'s 30 most frequent signs, shared with the corpus-wide 30: median {statistics.median(ov)}, minimum {min(ov)}; share of a text written with the corpus-wide 100 most frequent signs: median {statistics.median(cov):.0%}, minimum {min(cov):.0%}')
