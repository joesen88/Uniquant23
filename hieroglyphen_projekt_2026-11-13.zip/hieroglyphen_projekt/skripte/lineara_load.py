"""Load the lineara.xyz inscriptions (JS Map literal -> JSON) and inspect how numbers and fractions are written.
usage: python3 -I lineara_load.py <LinearAInscriptions.js>
"""
import sys, json, re, collections, unicodedata
C = collections.Counter
s = open(sys.argv[1], encoding='utf-8').read()
i = s.index('new Map(') + len('new Map('); j = len(s)
body = re.sub(r'\\u\{([0-9A-Fa-f]+)\}', lambda m: chr(int(m.group(1), 16)), s[i:j])
arr, _end = json.JSONDecoder().raw_decode(re.sub(r',\s*([\]}])', r'\1', body).lstrip())
print('inscriptions:', len(arr))
sites = C(v.get('site') for k, v in arr); sup = C(v.get('support') for k, v in arr)
print('sites:', sites.most_common(8)); print('supports:', sup.most_common(8))
tok = C(); ntok = 0
for k, v in arr:
    for w in v.get('transliteratedWords', []):
        tok[w] += 1; ntok += 1
print('transliterated tokens:', ntok, 'types:', len(tok))
num = C(w for w in tok.elements() if re.fullmatch(r'\d+', w))
print('pure integers:', sum(num.values()), 'distinct', len(num), 'top', num.most_common(12))
other = C({w: c for w, c in tok.items() if not re.fullmatch(r'[A-Z0-9₂₃₄\-\*\+\?\[\]<>]+', w) and w not in ('\n', '𐄁')})
print('tokens that are not plain sign groups (top 60):')
for w, c in other.most_common(60):
    print(f'   {c:4d}  {w!r}  ' + ' '.join(unicodedata.name(ch, hex(ord(ch)))[:28] for ch in w[:3] if ord(ch) > 0x2000))
frac_chars = C(ch for k, v in arr for w in v.get('words', []) for ch in w if 0x10740 <= ord(ch) <= 0x1077F)
print('Linear A fraction signs in the sign layer:', [(unicodedata.name(ch, hex(ord(ch))), c) for ch, c in frac_chars.most_common(30)])
ku = [k for k, v in arr if any(w in ('KU-RO', 'PO-TO-KU-RO') for w in v.get('transliteratedWords', []))]
print('inscriptions with KU-RO (total):', len(ku), ku[:30])
for name in ('HT104', 'HT9a', 'HT13', 'HT123+124a'):
    for k, v in arr:
        if k == name:
            print('\n', k, v.get('site'), '|', ' '.join(w if w != '\n' else '/' for w in v.get('transliteratedWords', []))[:700])
            print('   signs:', ' '.join(w if w != '\n' else '/' for w in v.get('words', []))[:400])
