import sys
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox']); pg = b.new_page(viewport={'width': 1040, 'height': 1300})
    pg.goto('file://' + sys.argv[1]); pg.wait_for_timeout(1200); pg.evaluate("window.scrollTo(0, 560)"); pg.wait_for_timeout(200); pg.screenshot(path=sys.argv[2]); b.close()
