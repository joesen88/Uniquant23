import json, sys, glob, os, collections, re
root = sys.argv[1]
n = nh = 0; samples = []; corp = collections.Counter(); sub = collections.Counter()
for p in sorted(glob.glob(os.path.join(root,'_aes_*.json'))):
    d = json.load(open(p,encoding='utf-8'))
    for sid, s in d.items():
        for t in s.get('token', []):
            if t.get('pos') == 'numeral':
                n += 1; sub[t.get('numeral') or t.get('number') or '-'] += 1
                if t.get('hiero'):
                    nh += 1; corp[s['corpus']] += 1
                    if len(samples) < 400 and (nh % 37 == 0): samples.append((t.get('written_form'), t.get('mdc'), t.get('hiero'), t.get('cotext_translation'), t.get('lemma_form')))
print('numeral tokens', n, 'with hiero', nh)
print('by corpus', corp.most_common(8))
print('numeral subtype field', sub.most_common(8))
for x in samples[:28]: print('  ', x)
