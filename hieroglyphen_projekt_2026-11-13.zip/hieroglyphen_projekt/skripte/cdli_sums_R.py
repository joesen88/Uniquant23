"""Is the ratio 'small unit per large unit' (gin2 per sila3 / per ma-na) itself fixed by the sums?
Equations are linear in the ratio R; they are rebuilt from two parser runs (R = 60 and R = 61).
usage: python3 -I cdli_sums_R.py <eq60.pkl> <eq61.pkl>"""
import sys, pickle, collections
from fractions import Fraction as Fr
C = collections.Counter
a = pickle.load(open(sys.argv[1], 'rb')); b = pickle.load(open(sys.argv[2], 'rb'))
assert len(a) == len(b) and all(x[2] == y[2] and x[4] == y[4] for x, y in zip(a, b))
E = []
for x, y in zip(a, b):
    cA = [v - u for u, v in zip(x[0], y[0])]; cB = [u - 60 * d for u, d in zip(x[0], cA)]
    dA = y[1] - x[1]; dB = x[1] - 60 * dA
    E.append((cA, cB, dA, dB, x[3]))
print(f'{len(E)} sums; of these {sum(1 for e in E if e[2])} mix whole large units and small units on the integer side')
rows = []
for R in range(2, 241):
    nof = sum(1 for cA, cB, dA, dB, ns in E if not ns and dA * R + dB == 0)
    agree = 0; modes = []
    for k in range(4):
        imp = C()
        for cA, cB, dA, dB, ns in E:
            c = [x * R + y for x, y in zip(cA, cB)]
            if c[k] and not any(v for j, v in enumerate(c) if j != k): imp[Fr(dA * R + dB, c[k])] += 1
        if imp:
            v, n = imp.most_common(1)[0]; agree += n; modes.append(str(v))
        else: modes.append('-')
    rows.append((nof, agree, R, modes))
print('ratio R: sums without fraction signs that are exact | single-sign sums agreeing on one value per sign | those values')
for nof, agree, R, modes in sorted(rows, reverse=True)[:6]: print(f'   R={R:3d}   {nof:4d}   {agree:4d}   {modes}')
print('by agreement of the fraction sums:')
for nof, agree, R, modes in sorted(rows, key=lambda r: -r[1])[:6]: print(f'   R={R:3d}   {nof:4d}   {agree:4d}   {modes}')
