import sys, os, re, json, gzip, collections, math, lzma, bz2, array, unicodedata
import numpy as np
wcache, toks_p, bdir = sys.argv[1:4]
W = json.load(gzip.open(wcache, 'rt', encoding='utf-8'))
def H(c):
    n = sum(c.values()); return -sum(v/n*math.log2(v/n) for v in c.values())
def cond(seqs):
    uni = collections.Counter(); big = collections.Counter()
    for s in seqs:
        for a, b in zip(s, s[1:]): big[(a, b)] += 1; uni[a] += 1
    first = collections.Counter(a for (a, b), n in big.items() for _ in range(n)); return H(big) - H(first)
def comp(seqs):
    ids = {}; a = array.array('H', (ids.setdefault(x, len(ids) + 1) for s in seqs for x in list(s) + ['\n'])).tobytes()
    return 8*min(len(lzma.compress(a, preset=9 | lzma.PRESET_EXTREME)), len(bz2.compress(a, 9)))
texts = [[x for w in t['w'] for x in w] for t in W.values()]; rev = [s[::-1] for s in texts]; N = sum(len(s) for s in texts)
print(f'Egyptian sign sequences: {len(texts)} texts, {N} signs')
print(f'  bits per sign given the neighbouring sign: as recorded {cond(texts):.3f} | read backwards {cond(rev):.3f}')
print(f'  compressed size: as recorded {comp(texts)/N:.3f} bits per sign | read backwards {comp(rev)/N:.3f}')
wr = [[w[::-1] for w in t['w']] for t in W.values()]; inner = [[x for w in t for x in w] for t in wr]
print(f'  only the order inside each word reversed: given neighbour {cond(inner):.3f} | compressed {comp(inner)/N:.3f}')
import random; random.seed(1); sh = []
for t in W.values():
    ws = [w[:] for w in t['w']]
    for w in ws: random.shuffle(w)
    sh.append([x for w in ws for x in w])
print(f'  order inside each word shuffled at random (control): given neighbour {cond(sh):.3f} | compressed {comp(sh)/N:.3f}')
allsh = [random.sample(s, len(s)) for s in texts]; print(f'  all signs of a text shuffled (control): given neighbour {cond(allsh):.3f} | compressed {comp(allsh)/N:.3f}')
words = [w for t in W.values() for w in t['w'] if len(w) >= 2]
f, l = collections.Counter(w[0] for w in words), collections.Counter(w[-1] for w in words)
print(f'\nword edges (words with >=2 signs: {len(words)}): entropy of first sign {H(f):.2f} bits (effective {2**H(f):.0f} signs) | of last sign {H(l):.2f} bits (effective {2**H(l):.0f} signs)')
SEG = re.compile(r'''<seg id=['"]([^'"]+)['"][^>]*>(.*?)</seg>''', re.S)
def norm(text, strip_marks):
    t = text.lower()
    if strip_marks: t = ''.join(c for c in unicodedata.normalize('NFD', t) if unicodedata.category(c) != 'Mn')
    t = t.replace('ـ', ''); return [w for w in re.split(r'[^\w]+', ''.join(c if unicodedata.category(c)[0] == 'L' else ' ' for c in t)) if w]
V = {}
for nm_, (fn, sm) in {'Latein': ('Latin', False), 'Deutsch': ('German', False), 'Hebraeisch': ('Hebrew', True), 'Arabisch': ('Arabic', True), 'Koptisch': ('Coptic-NT', True), 'Chinesisch': ('Chinese', False)}.items():
    V[nm_] = {i: x for i, x in SEG.findall(open(os.path.join(bdir, fn + '.xml'), encoding='utf-8').read())}
    if nm_ != 'Chinesisch':
        ws = [w for i, x in V[nm_].items() if i.startswith('b.MAT') or i.startswith('b.JOH') or i.startswith('b.LUK') or i.startswith('b.MAR') for w in norm(x, sm) if len(w) >= 2]
        f, l = collections.Counter(w[0] for w in ws), collections.Counter(w[-1] for w in ws); print(f'  {nm_:11s} first letter {H(f):.2f} bits (effective {2**H(f):.0f}) | last letter {H(l):.2f} bits (effective {2**H(l):.0f})')
# text-level markers in the Pyramid Texts
TK = json.load(gzip.open(toks_p, 'rt', encoding='utf-8')); n = st = en = 0
for t in TK.values():
    if t['corpus'] == 'bbawpyramidentexte' and len(t['tok']) >= 5:
        n += 1; st += t['tok'][0][1] == 'ḏd-mdw'; en += t['tok'][-1][1] == 'ḏd-mdw'
print(f'\nPyramid Text spells with >=5 words: {n}; beginning with the recitation mark: {st} = {st/n:.0%}; ending with it: {en} = {en/n:.1%}')
# script type: Chinese on the same NT verses as German
common = sorted(i for i in V['Deutsch'] if i in V['Chinesisch'] and i in V['Arabisch'] and i in V['Hebraeisch'] and i in V['Koptisch'] and V['Chinesisch'][i].strip())
def letters(nm_, sm): return [''.join(' '.join(norm(V[nm_][i], sm))) for i in common]
def cb8(seqs):
    ids = {}; raw = bytes(ids.setdefault(c, len(ids) + 1) for s in seqs for c in s + '\n'); return 8*min(len(lzma.compress(raw, preset=9 | lzma.PRESET_EXTREME)), len(bz2.compress(raw, 9)))
de = letters('Deutsch', False); nde = sum(len(s.replace(' ', '')) for s in de); bde = cb8(de)
zh = [[c for c in V['Chinesisch'][i] if unicodedata.category(c) == 'Lo'] for i in common]; nzh = sum(len(s) for s in zh); czh = collections.Counter(c for s in zh for c in s); bzh = comp(zh)
print(f'\nscript type on {len(common)} shared verses, relative to German ({nde/len(common):.1f} letters and {bde/len(common):.0f} bits per verse):')
for nm_, sm in (('Arabisch', True), ('Hebraeisch', True), ('Koptisch', True)):
    s = letters(nm_, sm); n_ = sum(len(x.replace(' ', '')) for x in s); c = collections.Counter(ch for x in s for ch in x if ch != ' '); b = cb8(s)
    print(f'  {nm_:11s} signs in use {sum(1 for v in c.values() if v/n_ >= 1e-4):5d} | signs per verse {n_/len(common):6.1f} = {n_/nde:.2f} of German | single-sign entropy {H(c):.2f} | compressed bits per sign {b/n_:.2f} | bits per verse {b/len(common):.0f} = {b/bde:.2f} of German')
print(f"  Chinesisch  signs in use {sum(1 for v in czh.values() if v/nzh >= 1e-4):5d} (of {len(czh)}) | signs per verse {nzh/len(common):6.1f} = {nzh/nde:.2f} of German | single-sign entropy {H(czh):.2f} | compressed bits per sign {bzh/nzh:.2f} | bits per verse {bzh/len(common):.0f} = {bzh/bde:.2f} of German")
