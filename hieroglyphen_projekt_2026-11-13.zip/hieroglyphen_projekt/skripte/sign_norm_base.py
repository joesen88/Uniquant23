import json, sys, gzip, re, collections, random
import numpy as np
TX = json.load(gzip.open(sys.argv[1], 'rt', encoding='utf-8')); random.seed(20261112)
def base(s): return re.sub(r'(?<=\d)[A-Za-z]+$', '', s)
SEQ = collections.defaultdict(list); allc = collections.Counter()
for t in TX.values():
    if t['signs']: s = [base(x) for x in t['signs']]; SEQ[t['corpus']].append(s); allc.update(s)
tot = sum(allc.values()); cum = np.cumsum(sorted(allc.values(), reverse=True))/tot
print('merged: types', len(allc), 'tokens', tot, '| signs needed for 50/80/90/95/99%:', [int(np.searchsorted(cum, q) + 1) for q in (0.5, 0.8, 0.9, 0.95, 0.99)], '| types with count<=2:', sum(1 for v in allc.values() if v <= 2))
def take(tl, n):
    o = []
    for s in tl:
        o += s
        if len(o) >= n: break
    return o[:n]
out = collections.defaultdict(list); SL, SM, SR = SEQ['sawlit'], SEQ['sawmedizin'], SEQ['bbawtotenlit']
for it in range(300):
    random.shuffle(SL); half = sum(map(len, SL))//2; a = []; b = []; acc = 0
    for s in SL: (a if acc < half else b).append(s); acc += len(s)
    ref = set(x for s in b for x in s)
    for nm, tl in (('literary vs literary half', a), ('ritual vs literary half', random.sample(SR, len(SR))), ('medical vs literary half', random.sample(SM, len(SM)))):
        pr = collections.Counter(take(tl, 100000)); ex = {s: n for s, n in pr.items() if s not in ref}
        out[nm].append((len(pr), len(ex), len(ex)/len(pr), sum(ex.values())/sum(pr.values())))
print('probe 100k tokens vs random literary half (300 splits, variants merged): types | not in reference | share of types | share of tokens')
for nm, v in out.items(): v = np.array(v); print(f'  {nm:26s} {v[:,0].mean():6.0f} | {v[:,1].mean():5.1f} ± {v[:,1].std():4.1f} | {v[:,2].mean():6.1%} | {v[:,3].mean():6.2%} ± {v[:,3].std():.2%}')
full = set(x for s in SL for x in s)
for nm, tl in (('ritual vs full literary', SR), ('medical vs full literary', SM)):
    v = []
    for it in range(50):
        pr = collections.Counter(take(random.sample(tl, len(tl)), 100000)); ex = {s: n for s, n in pr.items() if s not in full}; v.append((len(pr), len(ex), len(ex)/len(pr), sum(ex.values())/sum(pr.values())))
    v = np.array(v); print(f'  {nm:26s} {v[:,0].mean():6.0f} | {v[:,1].mean():5.1f} ± {v[:,1].std():4.1f} | {v[:,2].mean():6.1%} | {v[:,3].mean():6.2%} ± {v[:,3].std():.2%}')
