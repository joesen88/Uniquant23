import sys, json, gzip, re, collections, math
from fractions import Fraction
deut_p = sys.argv[1]
lem = collections.Counter(); tr = collections.defaultdict(collections.Counter); ex = {}; arith = collections.Counter(); arith_tr = {}
ARI = ('dmḏ', 'ḥsb', 'psš', 'ꜥḥꜥ.w', 'ḏꜣ.t', 'wḏꜣ.t', 'ḫbi̯', 'sqd', 'tp-ḥsb', 'ḥsb.w', 'zp', 'rʾ', 'gs', 'r.wj', 'ḥqꜣ.t', 'hnw', 'dbn', 'qd.t', 'mḥ', 'šzp', 'ḏbꜥ', 'ḫꜣ', 'ḥḥ', 'ḥfn', 'tp.j', 'sn.nw', 'wꜥ', 'jp', 'jp.t', 'kꜣ.t', 'ḫꜣi̯', 'wr', 'ꜥḥꜥ')
n = 0
with gzip.open(deut_p, 'rt', encoding='utf-8') as f:
    for line in f:
        r = json.loads(line); lf = r.get('lemma_form') or ''; t = (r.get('cotext_translation') or '').strip()
        if r.get('pos') == 'numeral': lem[lf] += 1; tr[lf][t] += 1; n += 1
        if lf in ARI: arith[lf] += 1; arith_tr.setdefault(lf, collections.Counter())[t[:26]] += 1
print('numeral tokens', n, '| numeral lemmas', len(lem))
for lf, c in lem.most_common(40): print(f'  {lf:14s} {c:6d}  ' + ' ; '.join(f'{k[:22]} {v}' for k, v in tr[lf].most_common(5)))
vals = collections.Counter(); fr = collections.Counter(); other = collections.Counter()
for lf in lem:
    for t, c in tr[lf].items():
        s = t.strip('[]() ').replace('.', '').replace(' ', '')
        m = re.fullmatch(r'(\d+)', s)
        if m: vals[int(m.group(1))] += c; continue
        m = re.fullmatch(r'(\d+)/(\d+)(?:[A-Za-zḥqꜣHAtT. ]*)', t.strip('[]() '))
        if m: fr[Fraction(int(m.group(1)), int(m.group(2)))] += c; continue
        other[t[:28]] += c
N = sum(vals.values()); print(f'\nintegers read from the editors\' renderings: {N} tokens, {len(vals)} different values; most frequent: {vals.most_common(14)}')
fd = collections.Counter(int(str(v)[0]) for v, c in vals.items() for _ in range(c) if v > 0); tot = sum(fd.values()); print('first-digit shares 1..9: ' + ' '.join(f'{fd[d]/tot:.1%}' for d in range(1, 10)) + ' | Benford: ' + ' '.join(f'{math.log10(1 + 1/d):.1%}' for d in range(1, 10)))
big = sorted(vals.items(), reverse=True)[:8]; print('largest integers:', big, '| share of values >= 1000:', f'{sum(c for v, c in vals.items() if v >= 1000)/N:.1%}')
F = sum(fr.values()); print(f'\nfractions: {F} tokens; by value: {[(str(k), v) for k, v in fr.most_common(16)]}')
unit = sum(c for k, c in fr.items() if k.numerator == 1); dy = sum(c for k, c in fr.items() if k.numerator == 1 and k.denominator in (2, 4, 8, 16, 32, 64)); print(f'  unit fractions {unit/F:.1%}; of all fractions powers of two (1/2..1/64) {dy/F:.1%}; 2/3: {fr.get(Fraction(2, 3), 0)}; other non-unit: {[(str(k), v) for k, v in fr.items() if k.numerator != 1 and k != Fraction(2, 3)]}')
print('  not parsed (top):', other.most_common(14))
print('\narithmetical and measure words:'); 
for lf in ARI:
    if arith[lf]: print(f'  {lf:8s} {arith[lf]:6d}  ' + ' ; '.join(f'{k} {v}' for k, v in arith_tr[lf].most_common(3)))
