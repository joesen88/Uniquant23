"""Details behind the leave-one-out table: who ties with the published core, what wins when a load-bearing rule goes,
and how the twelve-sign assignments with a smaller common denominator look.
usage: python3 -I lineara_loo_detail.py <path to lineara_loo.py>"""
import sys, runpy, math, itertools, collections
from fractions import Fraction as Fr
import numpy as np
M = runpy.run_path(sys.argv[1], run_name='loo')
P36, RUNS, EXTRA, setup, violations, variants, PUB = (M[k] for k in ('P36', 'RUNS', 'EXTRA', 'setup', 'violations', 'variants', 'PUB'))
C = collections.Counter

def collect(core, drop_names=(), thr=None, only_pub_core=False):
    """all passing assignments with common denominator <= thr under the rule set minus the named runs/rules"""
    runs, keys, V = variants(core)
    signs = ['J', 'E', 'F', 'K', 'L2', 'L3', 'L4', 'L6', 'B', 'D'] + ([] if core else ['H', 'A'])
    out = []
    for n in range(2, 54):
        base = math.lcm(8, 12 * n)
        if base > thr: continue
        lst = [v for v in P36 if math.lcm(base, v.denominator) <= thr]
        for K in lst:
            if only_pub_core and not (n == 10 and K == PUB['K']): continue
            free = {s: lst for s in ('B', 'D', 'H', 'A')}
            SC, val, den, shape, names = setup(n, K, free, core)
            vio = violations(val, SC, signs, runs)
            nv = np.zeros(shape, dtype=np.int16)
            for k in keys:
                if k[0] in drop_names or k in drop_names or (k[0] != 'all' and M['ATT'][k[0]] < 2 and 'SINGLES' in drop_names): continue
                nv += vio[k]
            L = np.full(shape, math.lcm(2, 4, 8, 2 * n, 3 * n, 4 * n, 6 * n), dtype=np.int64)
            for s in ['K'] + names: L = np.lcm(L, den[s])
            for idx in np.argwhere((nv == 0) & (L <= thr)):
                out.append((int(L[tuple(idx)]), n, K, tuple(lst[i] for i in idx)))
    return out
fmt = lambda t: f'K {t[2]}, ' + ', '.join(f'{s} {v}' for s, v in zip(('B', 'D', 'H', 'A'), t[3])) + f', L 1/{t[1]}'

print('[1] core, full rule set: the 56 assignments with common denominator 120')
tied = collect(True, thr=120)
assert len(tied) == 56 and all(t[0] == 120 for t in tied)
print('   by L base:', sorted(C(f'1/{t[1]}' for t in tied).items()), '| by K:', sorted(C(str(t[2]) for t in tied).items()))
print('   by B:', sorted(C(str(t[3][0]) for t in tied).items(), key=lambda kv: -kv[1]))
print('   by D:', sorted(C(str(t[3][1]) for t in tied).items(), key=lambda kv: -kv[1]))
same = [t for t in tied if t[1] == 10 and t[2] == Fr(1, 10)]
print(f'   with the published K = 1/10 and L = 1/10: {len(same)} ->', '; '.join(f'B {t[3][0]}, D {t[3][1]}' for t in same))
print('   simplest by sum of log2 denominators (B, D, K, L series):')
sc = lambda t: sum(math.log2(x.denominator) for x in (t[2],) + t[3]) + sum(math.log2(k * t[1]) for k in (2, 3, 4, 6))
for t in sorted(tied, key=sc)[:6]: print(f'      {sc(t):6.2f}  {fmt(t)}' + ('   <- published' if (t[1], t[2], t[3]) == (10, Fr(1, 10), (Fr(1, 5), Fr(1, 6))) else ''))
print(f'   published core: rank {1 + sum(1 for t in tied if sc(t) < sc((120, 10, Fr(1, 10), (Fr(1, 5), Fr(1, 6)))) - 1e-9)} of 56 by that measure')

print('\n[2] core: what beats the published core when a load-bearing rule is removed')
for label, drop in (('without B B / economy', {('B B', 'economy')}), ('without K L2 / order', {('K L2', 'order K>L2')}), ('without all single-attestation runs', {'SINGLES'}), ('without distinctness', {('all', 'distinct')})):
    b = [t for t in collect(True, drop, thr=119)]
    print(f'   {label}: {len(b)} ->', ' | '.join(f'[{t[0]}] {fmt(t)}' for t in sorted(b)[:9]))

print('\n[3] twelve signs, full rule set: assignments with a common denominator below 240')
bet = collect(False, thr=239)
print(f'   {len(bet)} assignments; by common denominator:', sorted(C(t[0] for t in bet).items()))
cores = C((t[1], t[2], t[3][0], t[3][1]) for t in bet)
print(f'   distinct cores among them: {len(cores)}; with the published core (K 1/10, B 1/5, D 1/6, L 1/10): {cores[(10, Fr(1, 10), Fr(1, 5), Fr(1, 6))]}')
pc = [t for t in bet if (t[1], t[2], t[3][0], t[3][1]) == (10, Fr(1, 10), Fr(1, 5), Fr(1, 6))]
print('   (H, A) pairs that give the published core a common denominator of 120:', ', '.join(f'({t[3][2]}, {t[3][3]})' for t in sorted(pc, key=lambda t: (-t[3][2], -t[3][3]))))
allp = collect(False, thr=240, only_pub_core=True)
allp = [t for t in allp if t[3][0] == Fr(1, 5) and t[3][1] == Fr(1, 6)]
print(f'   published core with any admissible (H, A) and common denominator <= 240: {len(allp)} pairs; H values with 240:', sorted({str(t[3][2]) for t in allp if t[0] == 240}), '| A values:', sorted({str(t[3][3]) for t in allp if t[0] == 240}))
h16 = [t for t in allp if t[3][2] == Fr(1, 16)]
print(f'   with H = 1/16 fixed: {len(h16)} admissible A values with common denominator 240:', sorted((str(t[3][3]) for t in h16)))
