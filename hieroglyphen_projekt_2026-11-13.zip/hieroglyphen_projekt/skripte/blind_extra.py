import sys, os, re, json, gzip, collections, math, random, unicodedata
import numpy as np
bdir, seg_p = sys.argv[1:3]; random.seed(20261112); rng = np.random.default_rng(20261112)
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*'); base = lambda s: re.sub(r'(?<=\d)[A-Za-z]+$', '', s)
def nvbe_segment(seqs, L):
    ids = {}; enc = [[ids.setdefault(x, len(ids) + 1) for x in s] for s in seqs]; B = len(ids) + 1
    assert B**(L + 1) < 9.2e18, (B, L)
    flat = np.array([y for s in enc for y in s + [0]], dtype=np.int64); N = len(flat); zc = np.concatenate([[0], np.cumsum(flat == 0)])
    code = {}; valid = {}; uq = {}; ct = {}
    for n in range(1, L + 2):
        c = np.zeros(N - n + 1, dtype=np.int64)
        for j in range(n): c = c*B + flat[j:N - n + 1 + j]
        v = (zc[n:N + 1] - zc[0:N - n + 1]) == 0; code[n] = c; valid[n] = v; uq[n], ct[n] = np.unique(c[v], return_counts=True)
    def ent(keys, cnt):
        order = np.argsort(keys, kind='stable'); k = keys[order]; c = cnt[order].astype(float); st = np.flatnonzero(np.concatenate([[True], k[1:] != k[:-1]]))
        tot = np.add.reduceat(c, st); return k[st], np.log2(tot) - np.add.reduceat(c*np.log2(c), st)/tot
    p1 = ct[1]/ct[1].sum(); H0 = float(-(p1*np.log2(p1)).sum()); hr = {0: None}; hl = {0: None}
    for n in range(1, L + 1):
        for store, keys in ((hr, uq[n + 1]//B), (hl, uq[n + 1] % (B**n))):
            k, h = ent(keys, ct[n + 1]); arr = np.zeros(len(uq[n])); arr[np.searchsorted(uq[n], k)] = h; store[n] = arr
    a = {}
    for n in range(1, L + 1):
        if n == 1: pr = np.full(len(uq[1]), H0); pl = pr
        else: pr = hr[n - 1][np.searchsorted(uq[n - 1], uq[n]//B)]; pl = hl[n - 1][np.searchsorted(uq[n - 1], uq[n] % (B**(n - 1)))]
        vr = hr[n] - pr; vl = hl[n] - pl; a[n] = (vr - vr.mean())/(vr.std() + 1e-9) + (vl - vl.mean())/(vl.std() + 1e-9)
    A = {}
    for n in range(1, L + 1):
        x = np.full(len(code[n]), -1e9); x[valid[n]] = a[n][np.searchsorted(uq[n], code[n][valid[n]])]; A[n] = x
    out = []; pos = 0
    for s in enc:
        m = len(s); best = [0.0] + [-1e18]*m; back = [0]*(m + 1)
        for j in range(1, m + 1):
            for l in range(1, min(L, j) + 1):
                v = best[j - l] + A[l][pos + j - l]*l
                if v > best[j]: best[j] = v; back[j] = l
        cuts = []; j = m
        while j > 0: cuts.append(j); j -= back[j]
        out.append(sorted(cuts)); pos += m + 1
    return out
def evaluate(gold, pred, name):
    tp = npred = ngold = wt = wg = wp = 0; rnd = 0
    for g, p in zip(gold, pred):
        m = g[-1]; G = set(g[:-1]); P = set(p[:-1]); tp += len(G & P); npred += len(P); ngold += len(G)
        gw = set(zip([0] + g[:-1], g)); pw = set(zip([0] + p[:-1], p)); wt += len(gw & pw); wg += len(gw); wp += len(pw)
        if m > 1 and P: R = set(rng.choice(np.arange(1, m), size=min(len(P), m - 1), replace=False).tolist()); rnd += len(G & R)
    pr, rc = tp/max(npred, 1), tp/max(ngold, 1); f = 2*pr*rc/(pr + rc); wpz, wr = wt/wp, wt/wg; rp, rr = rnd/max(npred, 1), rnd/max(ngold, 1)
    print(f'  {name:30s} boundaries: precision {pr:.2f} recall {rc:.2f} F1 {f:.2f} (random boundaries F1 {2*rp*rr/max(rp + rr, 1e-9):.2f}) | whole words: precision {wpz:.2f} recall {wr:.2f} | units per gold word {wp/wg:.2f}')
    return f

SEG = re.compile(r"""<seg id=['"]([^'"]+)['"][^>]*>(.*?)</seg>""", re.S)
S = []; G = []; n = 0
for i, x in SEG.findall(open(os.path.join(bdir, 'Chinese-tok.xml'), encoding='utf-8').read()):
    w = [t for t in x.split() if all(unicodedata.category(c) == 'Lo' for c in t)]
    if not w: continue
    S.append([c for t in w for c in t]); G.append(list(np.cumsum([len(t) for t in w]))); n += len(S[-1])
    if n >= 733000: break
print('Chinese signs', n, 'types', len(set(c for q in S for c in q)), 'mean word length', round(n/sum(len(g) for g in G), 2)); evaluate(G, nvbe_segment(S, 4), 'Chinesisch (Zeichen)')
D = json.load(gzip.open(seg_p, 'rt', encoding='utf-8')); cnt = collections.Counter()
for s_, p in zip(D['seqs'], D['pred']):
    st = 0
    for e in p: cnt[tuple(s_[st:e])] += 1; st = e
N = sum(cnt.values()); H = -sum(v/N*math.log2(v/N) for v in cnt.values()); ns = sum(len(k)*v for k, v in cnt.items())
print(f'blind units: {N} tokens, mean length {ns/N:.2f} signs, entropy {H:.2f} bits per unit = {H*N/ns:.2f} bits per sign; units of length 1/2/3/4/5: ' + '/'.join(f"{sum(v for k, v in cnt.items() if len(k) == L)/N:.0%}" for L in (1, 2, 3, 4, 5)))
gold_len = collections.Counter(b_ - a_ for g in D['gold'] for a_, b_ in zip([0] + g[:-1], g)); T = sum(gold_len.values()); print('editorial words by length 1/2/3/4/5/6+: ' + '/'.join(f"{gold_len[L]/T:.0%}" for L in (1, 2, 3, 4, 5)) + f"/{sum(v for k, v in gold_len.items() if k >= 6)/T:.0%}")
coh = tot = 0
for g, p in zip(D['gold'], D['pred']):
    Gs = set(g[:-1]); Ps = set(p[:-1]); m = g[-1]
    for c in range(1, m):
        if c not in Ps: tot += 1; coh += c not in Gs
print(f'positions the statistics keep together: {tot}; of these inside an editorial word: {coh/tot:.1%}')
