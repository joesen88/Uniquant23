"""After-the-fact labelling of the blind candidates: which words contain the long runs?
usage: python3 -I blind_numerals_check.py <aes_schrift.jsonl.gz> <aes_deutung_token.jsonl.gz>
"""
import sys, gzip, json, re, collections, itertools

C = collections.Counter
schrift_p, deut_p = sys.argv[1], sys.argv[2]
info = {}
with gzip.open(deut_p, 'rt', encoding='utf-8') as f:
    for line in f:
        r = json.loads(line)
        info[r['tok']] = (r.get('lemma_form') or '?', (r.get('cotext_translation') or '')[:26], r.get('written_form') or '', r.get('pos') or '')
WATCH = {'D50': 2, 'N33': 4, 'Z1A': 2, 'F35': 3, 'M12': 2, 'V1': 2, 'Z1': 5}
lab = collections.defaultdict(C); pos_share = collections.defaultdict(C)
long_v20 = []
z1_ctx = C(); z1_runs_tok = C(); z1_runs_stream = C()
with gzip.open(schrift_p, 'rt', encoding='utf-8') as f:
    for line in f:
        r = json.loads(line)
        toks = [(tk, z) for tk, z in zip(r['tok'], r['zeichen'])]
        # runs inside single tokens
        for tk, z in toks:
            if not z: continue
            for s, g in itertools.groupby(z):
                L = len(list(g))
                if s in WATCH and L >= WATCH[s]:
                    lf, tr, w, p = info.get(tk, ('?', '', '', ''))
                    lab[s][(lf, tr)] += 1; pos_share[s][p] += 1
        # stream runs with token attribution
        stream = []
        for tk, z in toks:
            if z: stream.extend((s, tk) for s in z)
            else: stream.append((None, None))
        i = 0
        while i < len(stream):
            j = i
            while j < len(stream) and stream[j][0] == stream[i][0]: j += 1
            s, L = stream[i][0], j - i
            if s == 'V20' and L >= 10:
                tks = list(dict.fromkeys(t for _, t in stream[i:j]))
                long_v20.append((r['text'], r['zeile'], L, [(info.get(t, ('?',))[0], info.get(t, ('', '', ''))[2]) for t in tks]))
            if s == 'Z1' and L >= 2:
                tks = list(dict.fromkeys(t for _, t in stream[i:j]))
                kinds = tuple('NUM' if info.get(t, ('', '', '', ''))[3] == 'numeral' else 'word' for t in tks)
                z1_ctx[(min(L, 10), kinds if len(kinds) <= 3 else ('many',))] += 1
            i = j
for s in WATCH:
    tot = sum(lab[s].values())
    print(f'\n{s}: {tot} runs of length >= {WATCH[s]} inside one word; part of speech: {dict(pos_share[s].most_common(4))}')
    print('   ' + ' ; '.join(f'{lf} "{tr}" {n}' for (lf, tr), n in lab[s].most_common(8)))
print('\nV20 runs of length >= 10 in the stream:')
for x in long_v20: print('  ', x)
print('\nZ1 runs (length>=2) in the stream by composition (length, tokens involved):')
by_len = collections.defaultdict(C)
for (L, kinds), n in z1_ctx.items(): by_len[L][kinds] += n
for L in sorted(by_len):
    tot = sum(by_len[L].values())
    print(f'  length {L}: {tot}  ' + ' ; '.join(f'{"+".join(k)} {n}' for k, n in by_len[L].most_common(5)))
