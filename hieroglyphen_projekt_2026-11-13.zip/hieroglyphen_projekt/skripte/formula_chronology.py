"""Fixed word sequences across time: Pyramid Texts -> Book of the Dead (criteria: formula_chronology_prereg.txt).
usage: python3 -I formula_chronology.py <aes_tokens_cache.json.gz>"""
import sys, gzip, json, random, collections, difflib, math, itertools
C = collections.Counter
T = json.load(gzip.open(sys.argv[1], 'rt', encoding='utf-8'))
uid = itertools.count(1); FORM = {}; POS = {}
unk = lambda x: x.startswith('?')
texts = {}
for tid, t in T.items():
    sents = []; p0 = 0; toks = t['tok']
    for L in t['sl'] + ([len(toks) - sum(t['sl'])] if sum(t['sl']) < len(toks) else []):
        s = []
        for tk in toks[p0:p0 + L]:
            if tk[0]:
                k = str(tk[0]); s.append(k); FORM.setdefault(k, tk[1]); POS.setdefault(k, tk[2])
            else: s.append('?%d' % next(uid))
        p0 += L
        if s: sents.append(s)
    texts[tid] = (t['corpus'], t['date'], sents)
GROUPS = collections.OrderedDict([
    ('Pyramid Texts (source)', lambda c, d: c == 'bbawpyramidentexte'),
    ('Book of the Dead, New Kingdom', lambda c, d: c == 'tb' and d == 'NK'),
    ('Book of the Dead, late', lambda c, d: c == 'tb' and d == 'TIP - Roman times'),
    ('late funerary literature', lambda c, d: c == 'bbawtotenlit'),
    ('literature, New Kingdom', lambda c, d: c == 'sawlit' and d == 'NK'),
    ('literature, Middle Kingdom', lambda c, d: c == 'sawlit' and d == 'MK & SIP'),
    ('Ramesside inscriptions', lambda c, d: c == 'bbawramessiden'),
    ('letters, New Kingdom', lambda c, d: c == 'bbawbriefe' and d == 'NK'),
    ('medical texts', lambda c, d: c == 'sawmedizin'),
    ('Amarna', lambda c, d: c == 'bbawamarna'),
    ('tomb inscriptions, Old Kingdom', lambda c, d: c == 'bbawgrabinschriften'),
])
G = {g: [tid for tid, (c, d, s) in texts.items() if f(c, d)] for g, f in GROUPS.items()}
sents_of = lambda g: [s for tid in G[g] for s in texts[tid][2]]
ngr = lambda s, n: [tuple(s[i:i + n]) for i in range(len(s) - n + 1)]
PT = sents_of('Pyramid Texts (source)')
print('groups (texts, sentences, words):')
for g in GROUPS:
    ss = sents_of(g); print(f'   {g:32s} {len(G[g]):5d} {len(ss):6d} {sum(len(s) for s in ss):8,d}')

def sample(ss, n_words, rng):
    idx = list(range(len(ss))); rng.shuffle(idx); out = []; n = 0
    for i in idx:
        out.append(ss[i]); n += len(ss[i])
        if n >= n_words: break
    return out
def returns(F, ss, n):
    Gt = set(g for s in ss for g in ngr(s, n))
    exact = sum(1 for g in F if g in Gt)
    wild = collections.defaultdict(set)
    for g in Gt:
        for i in range(n): wild[(i, g[:i] + g[i + 1:])].add(g[i])
    var = 0; subs = []
    for g in F:
        if g in Gt: continue
        hit = None
        for i in range(n):
            alt = wild.get((i, g[:i] + g[i + 1:]))
            if alt: hit = (g[i], next(iter(alt))); break
        if hit: var += 1; subs.append(hit)
    return exact, var, subs
SIZE = 25000; DRAWS = 20
for n, minf in ((4, 5), (3, 5), (5, 5)):
    cnt = C(g for s in PT for g in ngr(s, n) if not any(unk(x) for x in g))
    F = [g for g, c in cnt.items() if c >= minf]
    print(f'\n[1] formulas of {n} lemmas occurring at least {minf} times in the Pyramid Texts: {len(F):,}')
    print(f'    target group (samples of {SIZE:,} words, {DRAWS} draws)   exact return   chance   ratio | varied return   chance   ratio')
    rows = {}
    for g in list(GROUPS)[1:]:
        ss = sents_of(g); nw = sum(len(s) for s in ss); rng = random.Random(1)
        ex = va = exs = vas = 0.0
        for d in range(DRAWS):
            smp = sample(ss, SIZE, rng)
            e, v, _ = returns(F, smp, n); ex += e; va += v
            sh = [rng.sample(s, len(s)) for s in smp]
            e, v, _ = returns(F, sh, n); exs += e; vas += v
        ex, va, exs, vas = (100 * x / DRAWS / len(F) for x in (ex, va, exs, vas)); rows[g] = (ex, exs, va, vas)
        note = '' if nw >= SIZE else f'  (group has only {nw:,} words)'
        print(f'    {g:32s} {ex:6.2f} %  {exs:6.2f} %  {ex / exs if exs else float("inf"):6.1f} | {va:6.2f} %  {vas:6.2f} %  {va / vas if vas else float("inf"):6.1f}{note}')
    if n == 4:
        # upper bound: one half of the Pyramid Texts as source, the other half as target
        rng = random.Random(2); ids = G['Pyramid Texts (source)'][:]; rng.shuffle(ids); A = ids[:len(ids) // 2]; B = ids[len(ids) // 2:]
        cntA = C(g for tid in A for s in texts[tid][2] for g in ngr(s, 4) if not any(unk(x) for x in g)); FA = [g for g, c in cntA.items() if c >= 3]
        e = sum(returns(FA, sample([s for tid in B for s in texts[tid][2]], SIZE, rng), 4)[0] for _ in range(DRAWS)) / DRAWS
        print(f'    (for scale: formulas from one half of the Pyramid Texts found in {SIZE:,} words of the other half: {100 * e / len(FA):.1f} % of {len(FA):,})')
        # what is replaced in the varied returns (full Book of the Dead, no sampling)
        _, _, subs = returns(F, sents_of('Book of the Dead, New Kingdom') + sents_of('Book of the Dead, late'), 4)
        kinds = C(); pairs = C()
        for old, new in subs:
            po, pn = POS.get(old, '?'), POS.get(new, '?')
            k = 'name -> name' if 'name' in po and 'name' in pn else ('pronoun -> pronoun' if 'pronoun' in po and 'pronoun' in pn else ('same word class' if po == pn else 'different word class'))
            kinds[k] += 1; pairs[(FORM.get(old), FORM.get(new))] += 1
        print(f'    varied returns in the whole Book of the Dead: {len(subs)}; what is replaced:', dict(kinds.most_common()))
        print('    most frequent replacements (old -> new):', [(a, b, c) for (a, b), c in pairs.most_common(12)])
        ex_ex = [g for g in sorted(F, key=lambda g: -cnt[g]) if g in set(x for s in sents_of('Book of the Dead, New Kingdom') for x in ngr(s, 4))][:8]
        print('    examples of formulas that return exactly (lemma forms, frequency in the Pyramid Texts):', [(' '.join(str(FORM.get(x)) for x in g), cnt[g]) for g in ex_ex])

# ---------------- [2] supplementation: alignment of text pairs ----------------
def flat(tid): return [x for s in texts[tid][2] for x in s]
def grams_text(tid): return set(g for s in texts[tid][2] for g in ngr(s, 4) if not any(unk(x) for x in g))
def step(early, late, label, rng=None, arbitrary=False):
    inv = collections.defaultdict(set)
    for tid in early:
        for g in grams_text(tid): inv[g].add(tid)
    pairs = []; seen = set()
    for tid in late:
        share = C()
        for g in grams_text(tid):
            for e in inv.get(g, ()):
                if e != tid: share[e] += 1
        if not share: continue
        e, k = share.most_common(1)[0]
        if k < 5: continue
        if arbitrary:
            key = tuple(sorted((e, tid)))
            if key in seen: continue
            seen.add(key)
            if rng.random() < 0.5: e, tid2 = tid, e
            else: tid2 = tid
            pairs.append((e, tid2, k))
        else: pairs.append((e, tid, k))
    add = drop = npure_add = npure_drop = nrep = 0; more = fewer = 0; shared = 0
    for e, l, k in pairs:
        a, b = flat(e), flat(l)
        blocks = [m for m in difflib.SequenceMatcher(None, a, b, autojunk=False).get_matching_blocks() if m.size >= 3]
        pa = pd = 0; shared += sum(m.size for m in blocks)
        for m1, m2 in zip(blocks, blocks[1:]):
            ga = a[m1.a + m1.size:m2.a]; gb = b[m1.b + m1.size:m2.b]
            if len(ga) > 15 or len(gb) > 15 or (not ga and not gb): continue
            if any(unk(x) for x in ga) or any(unk(x) for x in gb): continue
            pd += len(ga); pa += len(gb)
            if ga and gb: nrep += 1
            elif gb: npure_add += 1
            else: npure_drop += 1
        add += pa; drop += pd; more += pa > pd; fewer += pa < pd
    n = more + fewer
    p = sum(math.comb(n, i) for i in range(0, min(more, fewer) + 1)) / 2 ** n * 2 if n else 1.0
    print(f'  {label}: {len(pairs)} text pairs, {shared:,} words in shared blocks | words only in the later text {add:,}, only in the earlier {drop:,} (ratio {add / drop if drop else float("nan"):.2f}) | gaps: pure additions {npure_add}, pure omissions {npure_drop}, replacements {nrep} | pairs with more added {more}, more dropped {fewer}, sign test p = {min(1.0, p):.3f}')
    return pairs
print('\n[2] supplementation between two consecutive shared blocks (gaps of at most 15 words, no damaged words)')
PTt = G['Pyramid Texts (source)']; NK = G['Book of the Dead, New Kingdom']; LATE = G['Book of the Dead, late']
p1 = step(PTt, NK, 'Pyramid Texts -> Book of the Dead (New Kingdom)')
p1b = step(PTt, LATE, 'Pyramid Texts -> Book of the Dead (late)')
p2 = step(NK, LATE, 'Book of the Dead New Kingdom -> late')
rng = random.Random(3)
step(PTt, PTt, 'symmetry check inside the Pyramid Texts', rng, True)
step(NK, NK, 'symmetry check inside the New Kingdom Book of the Dead', rng, True)
step(LATE, LATE, 'symmetry check inside the late Book of the Dead', rng, True)
print('\n  how many later texts have a Pyramid Text partner (at least 5 shared sequences): New Kingdom', len(p1), 'of', len(NK), '| late', len(p1b), 'of', len(LATE))
json.dump({'p1': p1[:400], 'p1b': p1b[:400]}, open('/tmp/formula_pairs.json', 'w'))
