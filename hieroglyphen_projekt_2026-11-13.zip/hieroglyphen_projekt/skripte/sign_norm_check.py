import json, sys, gzip, re, collections, math, random
import numpy as np
TX = json.load(gzip.open(sys.argv[1], 'rt', encoding='utf-8')); id2name = {}
for line in open(sys.argv[2], encoding='utf-8'):
    p = line.rstrip('\n').split('\t')
    if len(p) == 2: id2name[p[1]] = p[0]
random.seed(20261112)
def base(s): return re.sub(r'(?<=\d)[A-Za-z]+$', '', s)
print('variant pairs (literary | medical | ritual):')
C0 = collections.defaultdict(collections.Counter)
for t in TX.values(): C0[t['corpus']].update(t['signs'])
for a in ('V31', 'V31A', 'Z5', 'Z5A', 'Z3', 'Z3A', 'Z4', 'Z4A', 'N35', 'N35A', 'G7', 'G7A', 'Y1', 'Y1A', 'D21', 'W24', 'W24A'):
    print(f"  {a:5s} {C0['sawlit'][a]:6d} | {C0['sawmedizin'][a]:6d} | {C0['bbawtotenlit'][a]:6d}")
C = collections.defaultdict(collections.Counter); DF = collections.defaultdict(collections.Counter); SEQ = collections.defaultdict(list); Pn = collections.Counter()
for tid, t in TX.items():
    if not t['signs']: continue
    s = [base(x) for x in t['signs']]; C[t['corpus']].update(s); DF[t['corpus']].update(set(s)); SEQ[t['corpus']].append(s)
    if t['corpus'] == 'bbawpyramidentexte' or (t['corpus'] == 'bbawgraeberspzt' and re.search(r'\bPT\b', id2name.get(tid, ''))): Pn.update(s)
L, M, R = C['sawlit'], C['sawmedizin'], C['bbawtotenlit']
allc = sum(C.values(), collections.Counter()); print('\nnormalized inventory:', len(allc), 'types (raw 1861)')
def part(name, Pc):
    N = sum(Pc.values()); c1 = {s: n for s, n in Pc.items() if s in L}; c2 = {s: n for s, n in Pc.items() if s not in L and s in M}; c3 = {s: n for s, n in Pc.items() if s not in L and s not in M}
    print(f'  {name:34s} tokens {N:7d} types {len(Pc):4d} | class1 {len(c1):4d} = {sum(c1.values())/N:7.2%} | class2 {len(c2):3d} = {sum(c2.values())/N:6.2%} ({sum(c2.values())} tokens) | class3 {len(c3):3d} = {sum(c3.values())/N:6.2%} ({sum(c3.values())} tokens)')
    return c2, c3
print('partition with variants merged:'); p2, p3 = part('PT sample', Pn); r2, r3 = part('ritual papyri', R); part('Old Kingdom tomb inscriptions', C['bbawgrabinschriften'])
print('   PT sample class2:', sorted(p2.items(), key=lambda x: -x[1])[:10], '| class3:', sorted(p3.items(), key=lambda x: -x[1])[:12])
print('   ritual class2:', sorted(r2.items(), key=lambda x: -x[1])[:12]); print('   ritual class3 top:', sorted(r3.items(), key=lambda x: -x[1])[:14], '| count<=2:', sum(1 for v in r3.values() if v <= 2), 'of', len(r3))
for s in ['Z1', 'Z2', 'V20', 'V1', 'M12', 'D50', 'C11', 'D14', 'D15', 'D16', 'D22']: print(f"   {s:4s} PT {Pn.get(s,0):4d} ritual {R.get(s,0):5d} lit {L.get(s,0):5d} med {M.get(s,0):5d}")
big = ['sawlit', 'sawmedizin', 'bbawtotenlit', 'bbawamarna', 'bbawgrabinschriften', 'bbawtempelbib']
core = set.intersection(*[set(C[c]) for c in big]); tot = sum(allc.values())
print(f'core: {len(core)} of {len(allc)} types in all six groups cover {sum(allc[s] for s in core)/tot:.1%}')
def take(tl, n):
    o = []
    for s in tl:
        o += s
        if len(o) >= n: break
    return collections.Counter(o[:n])
def js(a, b):
    na, nb = sum(a.values()), sum(b.values()); d = 0.0
    for s in set(a) | set(b):
        p, q = a.get(s, 0)/na, b.get(s, 0)/nb; m = (p + q)/2
        if p: d += 0.5*p*math.log2(p/m)
        if q: d += 0.5*q*math.log2(q/m)
    return d
def halves(tl):
    tl = tl[:]; random.shuffle(tl); h = sum(map(len, tl))//2; a = []; b = []; acc = 0
    for s in tl: (a if acc < h else b).append(s); acc += len(s)
    return a, b
res = collections.defaultdict(list); n = 50000
for it in range(100):
    la, lb = halves(SEQ['sawlit']); ma, mb = halves(SEQ['sawmedizin']); ra, rb = halves(SEQ['bbawtotenlit'])
    a, b, m1, m2, r1, r2_ = take(la, n), take(lb, n), take(ma, n), take(mb, n), take(ra, n), take(rb, n)
    res['literary half vs half'].append(js(a, b)); res['medical half vs half'].append(js(m1, m2)); res['ritual half vs half'].append(js(r1, r2_))
    res['literary vs medical'].append(js(a, m1)); res['literary vs ritual'].append(js(a, r1)); res['medical vs ritual'].append(js(m1, r1))
print('JS divergence with variants merged (50k tokens, 100 resamples):')
for k, v in res.items(): print(f'  {k:26s} {np.mean(v):.3f} ± {np.std(v):.3f}')
def key(target, ref, mindf=8, a0=5000.0):
    T, Rf = C[target], C[ref]; nT, nR = sum(T.values()), sum(Rf.values()); both = T + Rf; nB = nT + nR; out = {}
    for s, y in T.items():
        if DF[target][s] < mindf: continue
        a = a0*both[s]/nB; yr = Rf.get(s, 0)
        d = math.log((y + a)/(nT + a0 - y - a)) - math.log((yr + a)/(nR + a0 - yr - a)); out[s] = (d/math.sqrt(1/(y + a) + 1/(yr + a)), (y/nT)/((yr + 0.5)/nR))
    return out
km, kr = key('sawmedizin', 'sawlit'), key('bbawtotenlit', 'sawlit')
sh = sorted([(min(km[s][0], kr[s][0]), s) for s in km if s in kr and km[s][0] > 3 and kr[s][0] > 3 and km[s][1] >= 1.5 and kr[s][1] >= 1.5], reverse=True)
print(f'enriched in both medical and ritual vs literary (variants merged): {len(sh)} signs; token share medical {sum(M[s] for _, s in sh)/sum(M.values()):.1%}, ritual {sum(R[s] for _, s in sh)/sum(R.values()):.1%}, literary {sum(L[s] for _, s in sh)/sum(L.values()):.1%}')
print('  ', [(s, round(km[s][1], 1), round(kr[s][1], 1)) for _, s in sh])
