"""Linear A fraction signs: counts, order inside compound fractions, repetitions, and sum lines (KU-RO) as equations.
usage: python3 -I lineara_fractions.py <LinearAInscriptions.js>
"""
import sys, json, re, collections, unicodedata
from fractions import Fraction as Fr
C = collections.Counter
s = open(sys.argv[1], encoding='utf-8').read()
i = s.index('new Map(') + len('new Map(')
body = re.sub(r'\\u\{([0-9A-Fa-f]+)\}', lambda m: chr(int(m.group(1), 16)), s[i:])
arr, _ = json.JSONDecoder().raw_decode(re.sub(r',\s*([\]}])', r'\1', body).lstrip())
NAME = {}
for cp in range(0x10740, 0x10756):
    n = unicodedata.name(chr(cp), '')
    NAME[chr(cp)] = n.split()[-1] if n else hex(cp)
UNC = '\U0001076b'
AEG = {}
for cp in range(0x10107, 0x10134):
    n = unicodedata.name(chr(cp), '')
    m = re.search(r'NUMBER (\w+)(?: (\w+))?', n)
    words = {'ONE': 1, 'TWO': 2, 'THREE': 3, 'FOUR': 4, 'FIVE': 5, 'SIX': 6, 'SEVEN': 7, 'EIGHT': 8, 'NINE': 9, 'TEN': 10, 'TWENTY': 20, 'THIRTY': 30, 'FORTY': 40,
             'FIFTY': 50, 'SIXTY': 60, 'SEVENTY': 70, 'EIGHTY': 80, 'NINETY': 90}
    if m:
        a, b = m.group(1), m.group(2)
        v = words.get(a)
        if b == 'HUNDRED': v = words[a] * 100
        elif b == 'THOUSAND': v = words[a] * 1000
        elif b == 'TEN': v = None
        AEG[chr(cp)] = v
# robust: parse names like 'AEGEAN NUMBER TWO HUNDRED', 'AEGEAN NUMBER TEN THOUSAND'
for cp in range(0x10107, 0x10134):
    n = unicodedata.name(chr(cp), '').replace('AEGEAN NUMBER ', '')
    parts = n.split()
    base = {'ONE': 1, 'TWO': 2, 'THREE': 3, 'FOUR': 4, 'FIVE': 5, 'SIX': 6, 'SEVEN': 7, 'EIGHT': 8, 'NINE': 9, 'TEN': 10, 'TWENTY': 20, 'THIRTY': 30, 'FORTY': 40, 'FIFTY': 50, 'SIXTY': 60, 'SEVENTY': 70, 'EIGHTY': 80, 'NINETY': 90}
    if not parts or parts[0] not in base: continue
    v = base[parts[0]]
    for p in parts[1:]:
        v *= {'HUNDRED': 100, 'THOUSAND': 1000}.get(p, 1)
    AEG[chr(cp)] = v
is_int = lambda w: bool(w) and all(ch in AEG or ch == UNC for ch in w) and any(ch in AEG for ch in w)
is_frac = lambda w: bool(w) and all(ch in NAME or ch == UNC for ch in w) and any(ch in NAME for ch in w)
cnt = C(); pairs = C(); reps = C(); comp = C(); after_int = C(); alone = C()
eqs = []
for key, v in arr:
    words = v.get('words', []); tl = v.get('transliteratedWords', [])
    # counts and order
    for j, w in enumerate(words):
        if is_frac(w):
            sig = [NAME[ch] for ch in w if ch in NAME]
            unc = UNC in w
            cnt.update(sig)
            if len(sig) >= 2 and not unc:
                comp[' '.join(sig)] += 1
                for a, b in zip(sig, sig[1:]):
                    if a != b: pairs[(a, b)] += 1
                    else: reps[a] += 1
            prev = words[j - 1] if j else ''
            (after_int if is_int(prev) else alone)[' '.join(sig)] += 1
    # sum lines
    if 'KU-RO' in tl:
        lines = []; cur = []
        for w, t in zip(words, tl):
            if t == '\n':
                lines.append(cur); cur = []
            else: cur.append((w, t))
        if cur: lines.append(cur)
        items = []; uncertain = False; seg = []
        for ln in lines:
            ts = [t for _, t in ln]
            ints = [sum(AEG[ch] for ch in w if ch in AEG) for w, t in ln if is_int(w)]
            fr = C(NAME[ch] for w, t in ln if is_frac(w) for ch in w if ch in NAME)
            if any(UNC in w for w, t in ln if is_int(w) or is_frac(w)): uncertain = True
            if 'KU-RO' in ts:
                if seg and ints:
                    tot_i = sum(x for x, _ in seg); tot_f = C()
                    for _, f in seg: tot_f.update(f)
                    eqs.append((key, tot_i, tot_f, sum(ints), fr, uncertain, len(seg)))
                seg = []; uncertain = False
            elif ints or fr:
                seg.append((sum(ints), fr))
print('inscriptions', len(arr), '| fraction sign counts:', cnt.most_common())
print('after an integer:', sum(after_int.values()), '| without integer before:', sum(alone.values()))
print('compound fractions (certain readings):', comp.most_common(30))
print('ordered pairs A before B:', sorted(pairs.items(), key=lambda kv: -kv[1]))
print('same sign repeated (adjacent):', reps.most_common())
print(f'\nKU-RO sum lines: {len(eqs)}')
print('  tablet       entries  sum of integers  total integer  difference  fractions in entries -> fractions in total   uncertain')
for key, ti, tf, ki, kf, unc, n in eqs:
    f1 = ' '.join(f'{c}{s}' for s, c in sorted(tf.items())) or '-'; f2 = ' '.join(f'{c}{s}' for s, c in sorted(kf.items())) or '-'
    print(f'  {key:12s} {n:3d}   {ti:6d}   {ki:6d}   {ki - ti:+5d}   {f1:28s} -> {f2:12s} {"?" if unc else ""}')
