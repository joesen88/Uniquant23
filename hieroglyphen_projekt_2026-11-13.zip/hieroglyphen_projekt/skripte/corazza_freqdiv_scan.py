"""G_FreqVSDiv as reconstructed from the paper: 1 - Spearman(frequency, number of other sign values that divide the sign's value).
Scan of all assignments that pass the hard rules (my re-encoding) for the smallest value; the paper reports 'approaching 0.00881'.
usage: python3 -I corazza_freqdiv_scan.py <path to lineara_loo.py> [first n] [last n]"""
import sys, runpy, math, time, itertools
from fractions import Fraction as Fr
import numpy as np
M = runpy.run_path(sys.argv[1], run_name='loo')
P36, setup, violations, variants, PUB = (M[k] for k in ('P36', 'setup', 'violations', 'variants', 'PUB'))
n0 = int(sys.argv[2]) if len(sys.argv) > 2 else 2; n1 = int(sys.argv[3]) if len(sys.argv) > 3 else 53
SIGNS = ['J', 'E', 'D', 'B', 'K', 'L2', 'F', 'H', 'A', 'L3', 'L4', 'L6']
FREQ = [137, 105, 68, 36, 32, 26, 23, 19, 15, 3, 2, 2]                     # Table 2 totals of the paper
def ranks_rows(X):
    """average ranks along axis 1 for an (N, k) array"""
    less = (X[:, None, :] < X[:, :, None]).sum(axis=2); eq = (X[:, None, :] == X[:, :, None]).sum(axis=2)
    return less + (eq + 1) / 2.0
rf = ranks_rows(np.array([FREQ], dtype=np.float64))[0]; rfc = rf - rf.mean(); sf = math.sqrt((rfc ** 2).sum())
def freqdiv(Vals):
    """Vals: (N, 12) integer-scaled values in the order of SIGNS -> 1 - Spearman"""
    N, k = Vals.shape; ncd = np.zeros((N, k), dtype=np.int16)
    for i in range(k):
        for j in range(k):
            if i != j: ncd[:, i] += (Vals[:, i] % Vals[:, j] == 0)
    rn = ranks_rows(ncd.astype(np.float64)); rnc = rn - rn.mean(axis=1, keepdims=True)
    sn = np.sqrt((rnc ** 2).sum(axis=1)); cov = (rnc * rfc).sum(axis=1)
    with np.errstate(invalid='ignore', divide='ignore'): r = np.where(sn > 0, cov / (sn * sf), 0.0)
    return 1 - r, ncd
if __name__ == '__main__':
    runs, keys, V = variants(False)
    signs12 = ['J', 'E', 'F', 'K', 'L2', 'L3', 'L4', 'L6', 'B', 'D', 'H', 'A']
    best = (9.0, None); hist = np.zeros(2001, dtype=np.int64); total = 0; t0 = time.time(); pub = None; top = []
    for n in range(n0, n1 + 1):
        for K in P36:
            SC, val, den, shape, names = setup(n, K, {s: P36 for s in ('B', 'D', 'H', 'A')}, False)
            vio = violations(val, SC, signs12, runs)
            nv = np.zeros(shape, dtype=np.int16)
            for k in keys: nv += vio[k]
            idx = np.argwhere(nv == 0)
            if not len(idx): continue
            PV = np.array([int(v * SC) for v in P36], dtype=np.int64)
            cols = {'B': PV[idx[:, 0]], 'D': PV[idx[:, 1]], 'H': PV[idx[:, 2]], 'A': PV[idx[:, 3]]}
            Vals = np.empty((len(idx), 12), dtype=np.int64)
            for c, s in enumerate(SIGNS): Vals[:, c] = cols[s] if s in cols else val[s]
            for a in range(0, len(Vals), 200000):
                g, ncd = freqdiv(Vals[a:a + 200000]); total += len(g)
                hist += np.bincount(np.minimum((g * 1000).astype(int), 2000), minlength=2001)
                m = int(np.argmin(g))
                if g[m] < best[0] - 1e-12: best = (float(g[m]), (n, K, tuple(P36[i] for i in idx[a + m]), ncd[m].tolist()))
                for q in np.where(g < 0.0125)[0][:50]:
                    if len(top) < 400: top.append((float(g[q]), n, str(K), tuple(str(P36[i]) for i in idx[a + q])))
                if n == 10 and K == PUB['K']:
                    want = np.array([P36.index(PUB[s]) for s in ('B', 'D', 'H', 'A')])
                    hit = np.where((idx[a:a + 200000] == want).all(axis=1))[0]
                    if len(hit): pub = (float(g[hit[0]]), ncd[hit[0]].tolist())
        print(f'n={n}: {total:,} passing assignments so far, best {best[0]:.5f}, {time.time() - t0:.0f}s', flush=True)
    print('smallest value:', f'{best[0]:.5f}', '| L = 1/%d, K = %s, (B, D, H, A) = %s' % (best[1][0], best[1][1], tuple(str(x) for x in best[1][2])), '| divisor counts', dict(zip(SIGNS, best[1][3])))
    print('published solution:', pub and f'{pub[0]:.5f}', '| divisor counts', pub and dict(zip(SIGNS, pub[1])))
    if pub: print(f'assignments with a smaller value than the published one: {int(hist[:int(pub[0] * 1000)].sum()):,} of {total:,} (binned to 0.001)')
    print('distinct small values seen:', sorted({round(t[0], 5) for t in top})[:12])
