"""Anchored test: weights with a total line; which assignment of values to the four fraction signs makes the sums exact?
usage: python3 -I cdli_sums.py <cdli_ur3.jsonl.gz>     (criteria: cdli_prereg.txt, B5 anchored + addendum)"""
import sys, gzip, json, re, collections, itertools
from fractions import Fraction as Fr
import numpy as np
C = collections.Counter
EL = re.compile(r'^(\d+)(?:/(\d+))?\(([^()]+)\)(.*)$'); GL = re.compile(r'^(?:\{[^{}]*\})+')
def parse_line(body):
    items = []; cur = None
    for t in body.split():
        m = EL.match(t)
        if m:
            cnt, den, name, suf = m.groups(); suf = GL.sub('', suf)
            el = (1, f'{cnt}/{den}({name})', True) if den else (int(cnt), name, False)
            if cur is None:
                cur = []; items.append(('P', cur))
            cur.append(el)
            if suf: items.append(('W', suf)); cur = None
        else:
            items.append(('W', t)); cur = None
    return items
SIGNS = ['1/3(disz)', '1/2(disz)', '2/3(disz)', '5/6(disz)']      # opaque labels a, b, c, d for the search
TRUE = [Fr(1, 3), Fr(1, 2), Fr(2, 3), Fr(5, 6)]
S = {'disz': 1, 'asz': 1, 'u': 10, 'gesz2': 60, "gesz'u": 600, 'szar2': 3600}
UNITS = {'gu2': 3600, 'ma-na': 60, 'gin2': 1}
def weights(it):
    out = []; i = 0
    while i < len(it) - 1:
        if it[i][0] == 'P' and it[i + 1][0] == 'W' and it[i + 1][1] in UNITS:
            qi = 0; qf = C(); bad = False; last = None; j = i
            if i > 0 and it[i - 1] == ('W', 'la2'): bad = True
            while j < len(it) - 1 and it[j][0] == 'P' and it[j + 1][0] == 'W' and it[j + 1][1] in UNITS:
                sc = UNITS[it[j + 1][1]]
                if last is not None and sc >= last: break
                for cnt, s, fr in it[j][1]:
                    if fr:
                        if s in SIGNS: qf[s] += sc
                        else: bad = True
                    elif s in S: qi += cnt * S[s] * sc
                    else: bad = True
                last = sc; j += 2
            if j < len(it):
                if it[j][0] == 'W' and (it[j][1].startswith('igi-') or it[j][1] == 'la2'): bad = True
                if it[j][0] == 'P' and j + 1 < len(it) and it[j + 1][1].split('-')[0] in ('sze', 'gin2', 'ma-na'): bad = True
            out.append((qi, qf, bad)); i = j
        else: i += 1
    return out
first = C(); eqs = []; stat = C()
with gzip.open(sys.argv[1], 'rt', encoding='utf-8') as f:
    for line in f:
        t = json.loads(line)
        for o in t['o']:
            for cl, body in o:
                w0 = body.split()[0]
                if 'nigin' in w0: first[w0] += 1
            if not all(cl for cl, _ in o): stat['objects with a damaged line'] += 1; continue
            items = []; totals = []; ok = True; seen_total = False
            for cl, body in o:
                it = parse_line(body); ws = weights(it)
                is_tot = it and it[0][0] == 'W' and re.match(r'^szu[-+]?nigin2?$|^szunigin2?$', it[0][1])
                if is_tot:
                    if ws: totals.append(ws); seen_total = True
                elif not seen_total: items.extend(ws)
            if len(totals) != 1 or len(totals[0]) != 1: continue
            stat['objects, all lines clean, exactly one total line with one weight'] += 1
            if len(items) < 2: stat['  fewer than two weights before the total'] += 1; continue
            T = totals[0][0]
            if T[2] or any(b for _, _, b in items): stat['  a weight uses sze / igi-n-gal2 / la2 / other signs'] += 1; continue
            c = C()
            for _, qf, _ in items: c.update(qf)
            c.subtract(T[1])
            D = T[0] - sum(q for q, _, _ in items)
            nsig = sum(1 for _, qf, _ in items for s in qf) + len(T[1])
            eqs.append(([c[s] for s in SIGNS], D, t['p'], nsig, t['prov']))
print('first words of lines containing "nigin":', first.most_common(8))
for k, v in stat.items(): print(f'  {k}: {v:,}')
print(f'usable sums: {len(eqs)}; with at least one of the four fraction signs: {sum(1 for e in eqs if e[3])}; with a non-zero net coefficient: {sum(1 for e in eqs if any(e[0]))}')
tv = np.array([float(x) for x in TRUE])
holds = lambda e, vals: abs(sum(ci * float(v) for ci, v in zip(e[0], vals)) - e[1]) < 1e-9
nofr = [e for e in eqs if not e[3]]
print(f'sums without any fraction sign (a check of the parser, independent of the values): exact {sum(1 for e in nofr if e[1] == 0)} of {len(nofr)}')
inf = [e for e in eqs if any(e[0])]
print(f'informative sums (net coefficient non-zero): {len(inf)}; exact under the textbook values: {sum(1 for e in inf if holds(e, TRUE))}')
# all assignments of four distinct candidate values
VALS = sorted(set([Fr(5, 6), Fr(3, 4), Fr(2, 3), Fr(1, 2), Fr(1, 3), Fr(1, 4), Fr(1, 5), Fr(1, 6), Fr(3, 20), Fr(1, 8)] + [Fr(1, d) for d in (7, 9, 10, 12, 15, 16, 20, 24, 30, 32, 36, 40, 48, 50, 60, 64, 70, 72, 80, 84, 90, 96, 108, 100, 120, 160, 200, 240, 300, 320)]), reverse=True)
SC = 302400
assert all((v * SC).denominator == 1 for v in VALS)
VI = np.array([int(v * SC) for v in VALS], dtype=np.int64)
perm = np.array(list(itertools.permutations(range(len(VALS)), 4)), dtype=np.int16)
PV = VI[perm]
cnt = np.zeros(len(perm), dtype=np.int32)
for cvec, D, *_ in inf:
    cnt += (PV @ np.array(cvec, dtype=np.int64) == D * SC)
order = np.argsort(-cnt)
tidx = [VALS.index(v) for v in TRUE]
trow = int(np.where((perm == np.array(tidx)).all(axis=1))[0][0])
print(f'\nall {len(perm):,} assignments of four distinct candidate values to the four signs:')
print('  signs in the order', SIGNS)
for r in order[:8]:
    print(f'   {int(cnt[r]):4d} exact sums   values {[str(VALS[i]) for i in perm[r]]}' + ('   <- textbook' if r == trow else ''))
print(f'  textbook assignment: {int(cnt[trow])} exact sums; assignments with more: {int((cnt > cnt[trow]).sum())}; with as many: {int((cnt == cnt[trow]).sum()) - 1}')
print('  the 24 orderings of the value set {1/3, 1/2, 2/3, 5/6}:')
res = []
for p in itertools.permutations(range(4)):
    vals = [TRUE[i] for i in p]; res.append((sum(1 for e in inf if holds(e, vals)), [str(v) for v in vals]))
for n, v in sorted(res, reverse=True)[:6]: print(f'   {n:4d}  {v}')
# how well is each sign pinned individually?
print('  per sign: sums in which this sign is the only one with a non-zero coefficient, and the value they imply:')
for k, s in enumerate(SIGNS):
    imp = C()
    for cvec, D, *_ in inf:
        if cvec[k] and not any(c for j, c in enumerate(cvec) if j != k): imp[Fr(D, cvec[k])] += 1
    print(f'    {s}: {sum(imp.values())} sums; implied values: {[(str(v), n) for v, n in imp.most_common(5)]}')
print('  by provenience (informative sums / exact under textbook):', C(e[4] for e in inf).most_common(5), C(e[4] for e in inf if holds(e, TRUE)).most_common(5))
