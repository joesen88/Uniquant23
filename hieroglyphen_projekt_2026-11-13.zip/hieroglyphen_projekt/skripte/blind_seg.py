import sys, os, re, json, gzip, collections, math, random, unicodedata
import numpy as np
schrift_p, bdir, out_p = sys.argv[1:4]; random.seed(20261112); rng = np.random.default_rng(20261112)
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*'); base = lambda s: re.sub(r'(?<=\d)[A-Za-z]+$', '', s)
def nvbe_segment(seqs, L):
    ids = {}; enc = [[ids.setdefault(x, len(ids) + 1) for x in s] for s in seqs]; B = len(ids) + 1
    assert B**(L + 1) < 9.2e18, (B, L)
    flat = np.array([y for s in enc for y in s + [0]], dtype=np.int64); N = len(flat); zc = np.concatenate([[0], np.cumsum(flat == 0)])
    code = {}; valid = {}; uq = {}; ct = {}
    for n in range(1, L + 2):
        c = np.zeros(N - n + 1, dtype=np.int64)
        for j in range(n): c = c*B + flat[j:N - n + 1 + j]
        v = (zc[n:N + 1] - zc[0:N - n + 1]) == 0; code[n] = c; valid[n] = v; uq[n], ct[n] = np.unique(c[v], return_counts=True)
    def ent(keys, cnt):
        order = np.argsort(keys, kind='stable'); k = keys[order]; c = cnt[order].astype(float); st = np.flatnonzero(np.concatenate([[True], k[1:] != k[:-1]]))
        tot = np.add.reduceat(c, st); return k[st], np.log2(tot) - np.add.reduceat(c*np.log2(c), st)/tot
    p1 = ct[1]/ct[1].sum(); H0 = float(-(p1*np.log2(p1)).sum()); hr = {0: None}; hl = {0: None}
    for n in range(1, L + 1):
        for store, keys in ((hr, uq[n + 1]//B), (hl, uq[n + 1] % (B**n))):
            k, h = ent(keys, ct[n + 1]); arr = np.zeros(len(uq[n])); arr[np.searchsorted(uq[n], k)] = h; store[n] = arr
    a = {}
    for n in range(1, L + 1):
        if n == 1: pr = np.full(len(uq[1]), H0); pl = pr
        else: pr = hr[n - 1][np.searchsorted(uq[n - 1], uq[n]//B)]; pl = hl[n - 1][np.searchsorted(uq[n - 1], uq[n] % (B**(n - 1)))]
        vr = hr[n] - pr; vl = hl[n] - pl; a[n] = (vr - vr.mean())/(vr.std() + 1e-9) + (vl - vl.mean())/(vl.std() + 1e-9)
    A = {}
    for n in range(1, L + 1):
        x = np.full(len(code[n]), -1e9); x[valid[n]] = a[n][np.searchsorted(uq[n], code[n][valid[n]])]; A[n] = x
    out = []; pos = 0
    for s in enc:
        m = len(s); best = [0.0] + [-1e18]*m; back = [0]*(m + 1)
        for j in range(1, m + 1):
            for l in range(1, min(L, j) + 1):
                v = best[j - l] + A[l][pos + j - l]*l
                if v > best[j]: best[j] = v; back[j] = l
        cuts = []; j = m
        while j > 0: cuts.append(j); j -= back[j]
        out.append(sorted(cuts)); pos += m + 1
    return out
def evaluate(gold, pred, name):
    tp = npred = ngold = wt = wg = wp = 0; rnd = 0
    for g, p in zip(gold, pred):
        m = g[-1]; G = set(g[:-1]); P = set(p[:-1]); tp += len(G & P); npred += len(P); ngold += len(G)
        gw = set(zip([0] + g[:-1], g)); pw = set(zip([0] + p[:-1], p)); wt += len(gw & pw); wg += len(gw); wp += len(pw)
        if m > 1 and P: R = set(rng.choice(np.arange(1, m), size=min(len(P), m - 1), replace=False).tolist()); rnd += len(G & R)
    pr, rc = tp/max(npred, 1), tp/max(ngold, 1); f = 2*pr*rc/(pr + rc); wpz, wr = wt/wp, wt/wg; rp, rr = rnd/max(npred, 1), rnd/max(ngold, 1)
    print(f'  {name:30s} boundaries: precision {pr:.2f} recall {rc:.2f} F1 {f:.2f} (random boundaries F1 {2*rp*rr/max(rp + rr, 1e-9):.2f}) | whole words: precision {wpz:.2f} recall {wr:.2f} | units per gold word {wp/wg:.2f}')
    return f
# Egyptian: runs of consecutive tokens with signs inside a physical line
E = []; meta = []
with gzip.open(schrift_p, 'rt', encoding='utf-8') as f:
    for line in f:
        r = json.loads(line); run = []; toks = []
        for z, t in list(zip(r['zeichen'], r['tok'])) + [(None, None)]:
            if z: run.append([base(x) for x in z]); toks.append(t)
            else:
                if run: E.append(run); meta.append((r['text'], toks))
                run = []; toks = []
seqs = [[x for w in run for x in w] for run in E]; gold = [list(np.cumsum([len(w) for w in run])) for run in E]
print(f'Egyptian: {len(seqs)} uninterrupted stretches, {sum(map(len, seqs))} signs, {sum(len(r) for r in E)} editorial words (used only to score)')
pred = nvbe_segment(seqs, 5); evaluate(gold, pred, 'Aegyptisch (Zeichen)')
json.dump({'pred': [[int(x) for x in p] for p in pred], 'seqs': seqs, 'gold': [[int(x) for x in g] for g in gold], 'meta': meta}, gzip.open(out_p, 'wt', encoding='utf-8'))
sh = [random.sample(s, len(s)) for s in seqs]; ps = nvbe_segment(sh, 5); evaluate(gold, ps, 'Kontrolle: Zeichen gemischt')
SEG = re.compile(r'''<seg id=['"]([^'"]+)['"][^>]*>(.*?)</seg>''', re.S)
def words(text, strip_marks):
    t = text.lower()
    if strip_marks: t = ''.join(c for c in unicodedata.normalize('NFD', t) if unicodedata.category(c) != 'Mn')
    return [w for w in re.split(r'[^\w]+', ''.join(c if unicodedata.category(c)[0] == 'L' else ' ' for c in t)) if w]
for name, fn, sm, L in (('Latein (Buchstaben)', 'Latin', False, 10), ('Deutsch (Buchstaben)', 'German', False, 10), ('Hebraeisch (Buchstaben)', 'Hebrew', True, 8), ('Arabisch (Buchstaben)', 'Arabic', True, 8), ('Chinesisch (Zeichen)', 'Chinese-tok', False, 4)):
    S = []; G = []; n = 0
    for i, x in SEG.findall(open(os.path.join(bdir, fn + '.xml'), encoding='utf-8').read()):
        w = words(x, sm) if 'Chinese' not in fn else [t for t in x.split() if all(unicodedata.category(c) == 'Lo' for c in t)]
        if not w: continue
        S.append([c for t in w for c in t]); G.append(list(np.cumsum([len(t) for t in w]))); n += len(S[-1])
        if n >= 733000: break
    evaluate(G, nvbe_segment(S, L), name)
