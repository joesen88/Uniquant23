"""Linear A fraction values: leave-one-out sensitivity of the published solution (criteria: lineara_loo_prereg.txt).
usage: python3 -I lineara_loo.py [sample size per n for the totals, default 400000]
Exact integer arithmetic throughout (values scaled by a common multiple of all denominators)."""
import sys, math, itertools, collections
from fractions import Fraction as Fr
import numpy as np

P36 = [Fr(5, 6), Fr(2, 3), Fr(1, 3), Fr(1, 5), Fr(1, 6), Fr(3, 20)] + [Fr(1, d) for d in (7, 9, 10, 12, 15, 16, 20, 24, 30, 32, 36, 40, 48, 50, 60, 64, 70, 72, 80, 84, 90, 96, 108, 100, 120, 160, 200, 240, 300, 320)]
assert len(P36) == 36
BASE_SC = 302400
assert all((v * BASE_SC).denominator == 1 for v in P36)
PUB = {'B': Fr(1, 5), 'D': Fr(1, 6), 'K': Fr(1, 10), 'H': Fr(1, 16), 'A': Fr(1, 24), 'n': 10}
# attested runs: name, attestations, tablets, terms, order pairs used
RUNS = [
    ('D D', 8, 6, ['D', 'D'], []),
    ('J B', 4, 4, ['J', 'B'], [('J', 'B')]),
    ('B B', 4, 3, ['B', 'B'], []),
    ('K L2', 4, 2, ['K', 'L2'], [('K', 'L2')]),
    ('J L2', 2, 2, ['J', 'L2'], [('J', 'L2')]),
    ('JE B', 1, 1, ['J', 'E', 'B'], [('E', 'B')]),
    ('J K', 1, 1, ['J', 'K'], [('J', 'K')]),
    ('E L2', 1, 1, ['E', 'L2'], [('E', 'L2')]),
    ('J H', 1, 1, ['J', 'H'], [('J', 'H')]),
    ('D D D D', 1, 1, ['D', 'D', 'D', 'D'], []),
    ('J A', 1, 1, ['J', 'A'], [('J', 'A')]),
    ('E B', 1, 1, ['E', 'B'], [('E', 'B')]),
    ('E L4', 1, 1, ['E', 'L4'], [('E', 'L4')]),
    ('E L6', 1, 1, ['E', 'L6'], [('E', 'L6')]),
    ('A B B', 1, 1, ['A', 'B', 'B'], []),
    ('F K', 1, 1, ['F', 'K'], [('F', 'K')]),
    ('E F', 5, 5, ['E', 'F'], [('E', 'F')]),
    ('J F', 1, 1, ['J', 'F'], [('J', 'F')]),
]
EXTRA = [
    ('A A', 1, 1, ['A', 'A'], []),                     # KH 86 as read in the publication
    ('H K', 1, 1, ['H', 'K'], [('H', 'K')]),           # set aside: HT 34
    ('E J', 1, 1, ['E', 'J'], [('E', 'J')]),           # set aside: ZA 8
    ('J J', 1, 1, ['J', 'J'], []),                     # set aside: PH 9b
]
ATT = {r[0]: r[1] for r in RUNS + EXTRA}

def setup(n, K, free, core):
    """K: Fraction or 1-D array of indices into P36; free: dict sign -> list of Fractions (grid) or index array (sample)."""
    SC = math.lcm(BASE_SC, 12 * n)
    val = {'J': SC // 2, 'E': SC // 4, 'F': SC // 8, 'L2': SC // (2 * n), 'L3': SC // (3 * n), 'L4': SC // (4 * n), 'L6': SC // (6 * n)}
    den = {'J': 2, 'E': 4, 'F': 8, 'L2': 2 * n, 'L3': 3 * n, 'L4': 4 * n, 'L6': 6 * n}
    PV = np.array([int(v * SC) for v in P36], dtype=np.int64); PD = np.array([v.denominator for v in P36], dtype=np.int64)
    names = ['B', 'D'] if core else ['B', 'D', 'H', 'A']
    if isinstance(K, Fr):
        val['K'] = int(K * SC); den['K'] = K.denominator
        for i, s in enumerate(names):
            shape = [1] * len(names); shape[i] = len(free[s])
            idx = np.array([P36.index(x) for x in free[s]])
            val[s] = PV[idx].reshape(shape); den[s] = PD[idx].reshape(shape)
        shape = tuple(len(free[s]) for s in names)
    else:
        val['K'] = PV[K]; den['K'] = PD[K]
        for s in names: val[s] = PV[free[s]]; den[s] = PD[free[s]]
        shape = K.shape
    return SC, val, den, shape, names

def violations(val, SC, signs, runs):
    out = collections.OrderedDict()
    for name, att, tab, terms, orders in runs:
        if any(t not in val for t in terms): continue
        s = 0
        for t in terms: s = s + val[t]
        for x, y in orders:
            out[(name, f'order {x}>{y}')] = np.asarray(~(np.asarray(val[y]) < np.asarray(val[x])))
        out[(name, 'below 1')] = np.asarray(np.asarray(s) >= SC)
        eco = np.zeros((), dtype=bool)
        for z in signs: eco = eco | (np.asarray(s) == np.asarray(val[z]))
        out[(name, 'economy')] = np.asarray(eco)
    d = np.zeros((), dtype=bool)
    for a, b in itertools.combinations(signs, 2): d = d | (np.asarray(val[a]) == np.asarray(val[b]))
    out[('all', 'distinct')] = np.asarray(d)
    return out

def variants(core):
    runs = [r for r in RUNS if not (core and any(t in ('H', 'A') for t in r[3]))]
    keys = []
    for name, att, tab, terms, orders in runs:
        keys += [(name, f'order {x}>{y}') for x, y in orders] + [(name, 'below 1'), (name, 'economy')]
    keys.append(('all', 'distinct'))
    V = collections.OrderedDict()
    V['full rule set'] = (set(), [])
    for r in runs: V[f'without run {r[0]} ({r[1]}x)'] = ({k for k in keys if k[0] == r[0]}, [])
    for k in keys: V[f'without rule {k[0]} / {k[1]}'] = ({k}, [])
    V['only runs with >= 2 attestations'] = ({k for k in keys if k[0] != 'all' and ATT[k[0]] < 2}, [])
    V['only runs with >= 4 attestations'] = ({k for k in keys if k[0] != 'all' and ATT[k[0]] < 4}, [])
    V['without all order rules'] = ({k for k in keys if k[1].startswith('order')}, [])
    V['without all below-1 rules'] = ({k for k in keys if k[1] == 'below 1'}, [])
    V['without all economy rules'] = ({k for k in keys if k[1] == 'economy'}, [])
    if not core:
        V['KH 86 read as A A instead of A B B'] = ({k for k in keys if k[0] == 'A B B'}, ['A A'])
        V['literal: plus H K (HT 34)'] = (set(), ['H K'])
    V['literal: plus E J (ZA 8)'] = (set(), ['E J'])
    V['literal: plus J J (PH 9b)'] = (set(), ['J J'])
    return runs, keys, V

def run(core, mode, per_n=400000, seed=0):
    thr = 120 if core else 240
    runs, keys, V = variants(core)
    extra = [r for r in EXTRA if not (core and any(t in ('H', 'A') for t in r[3]))]
    res = {v: {'pass': 0, 'better': 0, 'tie': 0, 'min': None, 'nmin': 0, 'ex': []} for v in V}
    only = collections.Counter(); space = 0
    rng = np.random.default_rng(seed)
    signs = ['J', 'E', 'F', 'K', 'L2', 'L3', 'L4', 'L6', 'B', 'D'] + ([] if core else ['H', 'A'])
    pub_seen = False
    for n in range(2, 54):
        base = math.lcm(8, 12 * n)
        if mode == 'pruned' and base > thr: continue
        if mode == 'sample':
            names = ['B', 'D'] if core else ['B', 'D', 'H', 'A']
            Kidx = rng.integers(0, 36, per_n); free = {s: rng.integers(0, 36, per_n) for s in names}
            jobs = [(Kidx, free)]
        else:
            ok = (lambda v: math.lcm(base, v.denominator) <= thr) if mode == 'pruned' else (lambda v: True)
            lst = [v for v in P36 if ok(v)]
            jobs = [(K, {s: lst for s in ('B', 'D', 'H', 'A')}) for K in lst]
        for K, free in jobs:
            SC, val, den, shape, names = setup(n, K, free, core)
            vio = violations(val, SC, signs, runs + extra)
            nv = np.zeros(shape, dtype=np.int16)
            for k in keys: nv += vio[k]
            L = np.full(shape, math.lcm(2, 4, 8, 2 * n, 3 * n, 4 * n, 6 * n), dtype=np.int64)
            for s in ['K'] + names: L = np.lcm(L, den[s])
            space += L.size
            if mode != 'sample':
                # which single rule is the only one violated (exact redundancy check)
                one = nv == 1
                if one.any():
                    for k in keys:
                        c = int((one & vio[k]).sum())
                        if c: only[k] += c
            for v, (drop, add) in V.items():
                m = nv.copy()
                for k in drop: m -= vio[k]
                for name in add:
                    for k2, a in vio.items():
                        if k2[0] == name: m += a
                p = m == 0
                r = res[v]; r['pass'] += int(p.sum())
                if not p.any(): continue
                r['better'] += int((p & (L < thr)).sum()); r['tie'] += int((p & (L == thr)).sum())
                if mode != 'sample':
                    lm = int(L[p].min())
                    if r['min'] is None or lm < r['min']: r['min'] = lm; r['nmin'] = 0; r['ex'] = []
                    if lm == r['min']:
                        hit = np.argwhere(p & (L == lm)); r['nmin'] += len(hit)
                        for h in hit[:6]:
                            if len(r['ex']) < 6:
                                r['ex'].append(', '.join([f'K {K}'] + [f'{s} {free[s][i]}' for s, i in zip(names, h)] + [f'L 1/{n}']))
            if mode != 'sample' and n == PUB['n'] and K == PUB['K']:
                i = tuple(free[s].index(PUB[s]) for s in names)
                pub_seen = True
                assert nv[i] == 0 and int(L[i]) == thr, (int(nv[i]), int(L[i]))
    return res, only, space, keys, V, pub_seen

if __name__ == '__main__':
    per_n = int(sys.argv[1]) if len(sys.argv) > 1 else 400000
    for core, label in ((True, 'CORE (ten signs, without H and A), threshold 120'), (False, 'ALL TWELVE SIGNS, threshold 240')):
        mode = 'all' if core else 'pruned'
        res, only, space, keys, V, pub_seen = run(core, mode)
        print(f'\n===== {label} =====')
        print(f'enumerated exactly: {space:,} assignments' + (' (the whole core space)' if core else f' (all with a common denominator <= 240)') + f'; published solution passes the full rule set: {pub_seen}')
        tot = None
        if not core:
            sres, _, sspace, _, _, _ = run(core, 'sample', per_n)
            tot = {v: sres[v]['pass'] / sspace * 36 ** 5 * 52 for v in V}
            print(f'totals for the twelve signs are estimates from a random sample of {sspace:,} assignments')
        base = res['full rule set']
        print(f'{"variant":52s} {"passing":>14s} {"better":>8s} {"tied":>7s}  smallest common denominator (how many) and examples')
        for v in V:
            r = res[v]
            pas = f'{r["pass"]:,}' if core else f'~{tot[v]:,.0f}'
            flag = ''
            if r['better'] != base['better'] or r['tie'] != base['tie']: flag = ' *'
            ex = '; '.join(r['ex'][:2]) if r['min'] is not None and r['min'] < (120 if core else 240) else ''
            print(f'{v:52s} {pas:>14s} {r["better"]:8d} {r["tie"]:7d}{flag:2s} {str(r["min"]):>5s} ({r["nmin"]}) {ex}')
        if core:
            print('rules that are the only violated rule for at least one assignment (i.e. not redundant), with that number:')
            for k in keys: print(f'   {k[0]:8s} {k[1]:14s} {only[k]:10,d}')
