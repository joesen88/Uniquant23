"""Egyptian corpus: is there vocabulary for ratio, even/odd, figures, operations? Search the editors' German glosses.
usage: python3 -I mathvocab_eg.py <aes_deutung_token.jsonl.gz>
"""
import sys, gzip, json, re, collections

C = collections.Counter
KEYS = {
    'gerade/ungerade (Zahl)': r'\bungerade|gerade Zahl|geradzahlig',
    'Verhältnis/Proportion': r'\bVerhältnis|\bProportion|\bim Verhältnis',
    'doppelt/Doppeltes/verdoppeln': r'\bdoppelt|\bDoppelte|\bverdoppel|\bzweifach|\bdreifach|\bvierfach|\bvielfach',
    'halbieren/Hälfte': r'\bhalbier|\bHälfte',
    'Drittel/Viertel/Teil (Bruch)': r'\bDrittel|\bViertel|\bZweidrittel|\bBruchteil',
    'addieren/Summe': r'\baddier|\bSumme|\bGesamtsumme|\bGesamtbetrag|\bzusammenzähl',
    'abziehen/Rest/Differenz': r'\babzieh|\bsubtrah|\bDifferenz|\bRestbetrag|\bRest\b|\bFehlbetrag',
    'multiplizieren/teilen (rechn.)': r'\bmultipliz|\bdividier|\bmalnehm',
    'rechnen/berechnen/zählen': r'\brechnen|\bberechn|\bAbrechnung|\bRechnung|\bzählen|\bZählung|\bAnzahl',
    'messen/wiegen/Maß': r'\bmessen|\bvermess|\bMessung|\bwiegen|\babwiegen|\bMaß\b',
    'Dreieck/Quadrat/Rechteck/Kreis': r'\bDreieck|\bQuadrat|\bRechteck|\bKreis\b|\bUmfang|\bDurchmesser|\bDiagonal',
    'Pyramide/Böschung/Höhe/Basis': r'\bPyramide\b|\bBöschung|\bNeigung',
    'Fläche/Flächenmaß': r'\bFlächenmaß|\bArure',
    'gleich/genau/richtig (Rechenprobe)': r'\bgenau\b|\bRichtigkeit|\bgleich viel',
}
RX = {k: re.compile(v) for k, v in KEYS.items()}
cnt = C(); lem = collections.defaultdict(C); corp_lemma = {}
n = 0
with gzip.open(sys.argv[1], 'rt', encoding='utf-8') as f:
    for line in f:
        r = json.loads(line); n += 1
        t = r.get('cotext_translation') or ''
        if not t: continue
        for k, rx in RX.items():
            if rx.search(t):
                cnt[k] += 1; lem[k][(r.get('lemma_form') or '?', t[:34])] += 1
print('tokens', n)
for k in KEYS:
    print(f'\n{k}: {cnt[k]}')
    print('   ' + ' ; '.join(f'{lf} "{t}" {c}' for (lf, t), c in lem[k].most_common(12)))
