"""Year numbers under kings' names: one fixed "cycle length"? Lists the highest year number per name, shows how dates nest
(year > month > day), and counts how many numbers can be written with a few calendar constants (illustration, no test).
usage: python3 -I regnal_years.py <dir with _aes_*.json>"""
import sys, os, json, re, collections
C = collections.Counter
d = sys.argv[1]
def num(t):
    wf = (t.get('written_form') or '').strip()
    return int(wf) if t.get('pos') == 'numeral' and re.fullmatch(r'\d+', wf) else None
years = collections.defaultdict(list); yall = C(); months = C(); days = C(); nform = nking = 0
for fn in sorted(os.listdir(d)):
    if not fn.startswith('_aes_'): continue
    data = json.load(open(os.path.join(d, fn), encoding='utf-8'))
    for s in data.values():
        T = s['token']; vals = [num(t) for t in T]
        for i, t in enumerate(T):
            if (t.get('lemma_form') or '') != 'rnp.t-zp' or i + 1 >= len(T) or vals[i + 1] is None: continue
            y = vals[i + 1]; nform += 1; yall[y] += 1
            for j in range(i + 2, min(i + 10, len(T))):
                if T[j].get('lemma_form') == 'ꜣbd' and j + 1 < len(T) and vals[j + 1] is not None: months[vals[j + 1]] += 1
                if 'Monatstag' in (T[j].get('cotext_translation') or '') and j + 1 < len(T) and vals[j + 1] is not None: days[vals[j + 1]] += 1
            k = next((x.get('lemma_form') for x in T[i + 2:] if x.get('name') == 'kings_name'), None)
            if k: years[k].append(y); nking += 1
    del data
mx = {k: max(v) for k, v in years.items()}
print(f'year formulas with a number: {nform}; followed by a king\'s name in the same sentence: {nking}; names: {len(years)}')
print('highest year number per name, top 12:', ', '.join(f'{k} {m} (n={len(years[k])})' for k, m in sorted(mx.items(), key=lambda kv: -kv[1])[:12]))
bins = [(1, 5), (6, 10), (11, 20), (21, 30), (31, 40), (41, 50), (51, 60), (61, 99)]
print('names by highest year number:', ', '.join(f'{a}-{b}: {sum(1 for m in mx.values() if a <= m <= b)}' for a, b in bins))
print('names whose highest number is 56:', sum(1 for m in mx.values() if m == 56), '| names reaching 50 or more:', sum(1 for m in mx.values() if m >= 50), '| year numbers above 56 anywhere:', sorted(y for y in yall if y > 56))
print('all year numbers, how often:', ', '.join(f'{y}: {c}' for y, c in sorted(yall.items())))
print('within these dates: month numbers', dict(sorted(months.items())), '| day numbers: highest', max(days) if days else None, ', different values', len(days), ', above 30:', sum(c for v, c in days.items() if v > 30))
B = {'week': 7, 'months per year': 12, 'sidereal month': 27, 'four weeks': 28, 'synodic month': 29, 'calendar month': 30}
E0 = {a + b for a in B.values() for b in B.values()} | {a * k for a in B.values() for k in range(1, 9)}
E1 = E0 | {x + 1 for x in E0} | {x + 2 for x in E0}
for lo, hi in ((1, 100), (30, 100)):
    R = range(lo, hi + 1); print(f'numbers {lo}..{hi} that can be written as a sum of two constants or as up to 8 times one constant: {sum(1 for x in R if x in E0)} of {len(R)}; with "+1 or +2 for start and end state" allowed: {sum(1 for x in R if x in E1)} of {len(R)}')
print('constants used:', B)
