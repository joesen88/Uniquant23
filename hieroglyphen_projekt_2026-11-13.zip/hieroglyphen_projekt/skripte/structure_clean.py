import json, sys, glob, os, collections, math, statistics, gzip
import numpy as np
from scipy.stats import spearmanr
aes, scores_p, conc_p, cache_p, out_p = sys.argv[1:6]
rng = np.random.default_rng(20261112)
if os.path.exists(cache_p):
    T = json.load(gzip.open(cache_p, 'rt', encoding='utf-8'))
else:
    T = {}
    for p in sorted(glob.glob(os.path.join(aes, '_aes_*.json'))):
        d = json.load(open(p, encoding='utf-8'))
        for sid, s in d.items():
            t = T.setdefault(s['text'], {'corpus': s['corpus'], 'date': s.get('date'), 'tok': [], 'sl': []})
            n = 0
            for k in s.get('token', []):
                if not k.get('_id'): continue
                if (k.get('lemma_form') or '') == '[...]': continue
                t['tok'].append([str(k.get('lemmaID') or ''), k.get('lemma_form') or '', k.get('pos') or '', k.get('written_form') or '']); n += 1
            if n: t['sl'].append(n)
    json.dump(T, gzip.open(cache_p, 'wt', encoding='utf-8'), ensure_ascii=False)
old = {r['text']: r for r in json.load(open(scores_p, encoding='utf-8'))}
id2name = {}
for line in open(conc_p, encoding='utf-8'):
    p = line.rstrip('\n').split('\t')
    if len(p) == 2: id2name[p[1]] = p[0]
NTOK = sum(len(t['tok']) for t in T.values())
noid = sum(1 for t in T.values() for k in t['tok'] if not k[0]); noform = sum(1 for t in T.values() for k in t['tok'] if not k[1])
print(f'tokens {NTOK}; without lemmaID {noid} ({noid/NTOK:.1%}); without lemma_form {noform} ({noform/NTOK:.1%})')
print('pos classes:', collections.Counter(k[2] for t in T.values() for k in t['tok']).most_common(14))
# inspect one suspicious text
for tid, t in T.items():
    if 'Hordjedef' in id2name.get(tid, '') and len(t['tok']) > 250:
        print('sample', id2name[tid][:60], [(k[3][:12], k[1][:12], k[0][:8], k[2][:6]) for k in t['tok'][:14]]); break
print('\nper corpus: share of tokens without lemmaID | share entity_name | share numeral | texts with median sentence length > 30')
for c in sorted(set(t['corpus'] for t in T.values())):
    tk = [k for t in T.values() if t['corpus'] == c for k in t['tok']]
    ts = [t for t in T.values() if t['corpus'] == c and len(t['tok']) >= 30]
    print(f"  {c:22s} {sum(1 for k in tk if not k[0])/len(tk):6.1%} | {sum(1 for k in tk if k[2]=='entity_name')/len(tk):6.1%} | {sum(1 for k in tk if k[2]=='numeral')/len(tk):6.1%} | {sum(1 for t in ts if statistics.median(t['sl'])>30)}/{len(ts)}")
def mattr(seq, w):
    if len(seq) < w: return None
    c = collections.Counter(seq[:w]); tot = len(c); n = 1
    for i in range(w, len(seq)):
        a = seq[i-w]; c[a] -= 1
        if c[a] == 0: del c[a]
        c[seq[i]] += 1; tot += len(c); n += 1
    return tot/n/w
def score(keep):
    G = collections.Counter(k[0] for t in T.values() for k in t['tok'] if k[0] and keep(k)); N = sum(G.values())
    rows = []
    for tid, t in T.items():
        L = [k[0] for k in t['tok'] if k[0] and keep(k)]
        if len(L) < 30 or len(t['tok']) < 30: continue
        rows.append({'text': tid, 'corpus': t['corpus'], 'date': t['date'], 'n': len(t['tok']), 'nlem': len(L), 'unlem': 1 - sum(1 for k in t['tok'] if k[0])/len(t['tok']),
                     'sl': statistics.median(t['sl']), 'surp': sum(-math.log2(G[l]/N) for l in L)/len(L), 'mattr': mattr(L, 30)})
    cap = np.quantile([r['sl'] for r in rows], 0.99)
    def z(v): v = np.array(v, float); return (v - v.mean())/v.std()
    D = (z([r['surp'] for r in rows]) + z([math.log2(min(r['sl'], cap)) for r in rows]) + z([r['mattr'] for r in rows]))/3
    qs = np.quantile(D, [0.25, 0.5, 0.75])
    for r, dv in zip(rows, D): r['D'] = float(dv); r['level'] = int(1 + sum(dv > q for q in qs))
    return rows, cap, qs
def report(rows, title):
    print('\n' + title)
    res = []
    for c in sorted(set(r['corpus'] for r in rows)):
        rr = [r for r in rows if r['corpus'] == c]
        if len(rr) < 10: continue
        v = np.array([r['D'] for r in rr]); m = np.median(rng.choice(v, (2000, len(v))), axis=1); lv = collections.Counter(r['level'] for r in rr)
        res.append((float(np.median(v)), c, len(rr), np.percentile(m, 5), np.percentile(m, 95), [lv.get(i, 0) for i in (1, 2, 3, 4)],
                    statistics.median(r['sl'] for r in rr), statistics.mean(r['surp'] for r in rr), statistics.mean(r['mattr'] for r in rr)))
    for md, c, n, lo, hi, lv, sl, su, ma in sorted(res):
        print(f"  {c:22s} n={n:4d} D {md:+.2f} [{lo:+.2f}, {hi:+.2f}] levels {'/'.join(f'{x/n:.0%}' for x in lv)} counts {lv} | median sl {sl:4.1f} | surp {su:5.2f} | mattr30 {ma:.3f}")
    return {c: md for md, c, *_ in res}
A, cap, qsA = score(lambda k: True)
print(f'\ncleaned score (lemmaID, unlemmatized tokens dropped): texts {len(A)}, sentence-length cap {cap}, cut points {[round(float(q),2) for q in qsA]}')
ra = report(A, '[A] cleaned D per corpus')
B, capB, qsB = score(lambda k: k[2] != 'entity_name')
rb = report(B, f'[B] cleaned D without proper names per corpus (texts {len(B)})')
C, capC, qsC = score(lambda k: k[2] not in ('entity_name', 'numeral'))
rc = report(C, f'[C] without proper names and numerals (texts {len(C)})')
a = {r['text']: r for r in A}; b = {r['text']: r for r in B}
com = [t for t in a if t in old]; print('\nSpearman old D vs cleaned D (texts):', round(spearmanr([old[t]['D'] for t in com], [a[t]['D'] for t in com])[0], 3), 'n', len(com))
com = [t for t in a if t in b]; print('Spearman cleaned D vs without names (texts):', round(spearmanr([a[t]['D'] for t in com], [b[t]['D'] for t in com])[0], 3), 'n', len(com))
cs = [c for c in ra if c in rb]; print('group-level Spearman A vs B:', round(spearmanr([ra[c] for c in cs], [rb[c] for c in cs])[0], 2), '| A vs C:', round(spearmanr([ra[c] for c in cs if c in rc], [rc[c] for c in cs if c in rc])[0], 2))
print('level agreement A vs B (same level):', round(sum(1 for t in com if a[t]['level'] == b[t]['level'])/len(com), 2), '| within one level:', round(sum(1 for t in com if abs(a[t]['level'] - b[t]['level']) <= 1)/len(com), 3))
print('component correlations (B):', np.round(np.corrcoef([[r['surp'] for r in B], [math.log2(min(r['sl'], capB)) for r in B], [r['mattr'] for r in B]]), 2).tolist())
ep = collections.defaultdict(collections.Counter)
for r in B: ep[r['date']][r['level']] += 1
print('levels by epoch (B):', {k: [v.get(i, 0) for i in (1, 2, 3, 4)] for k, v in ep.items()})
for r in B: r['name'] = id2name.get(r['text'], '')
json.dump({'A': A, 'B': B}, open(out_p, 'w', encoding='utf-8'), ensure_ascii=False)
big = sorted([r for r in B if r['n'] >= 300], key=lambda r: r['D'])
print('\nextremes among texts >=300 words (B):', len(big))
for r in big[:6] + big[-6:]: print(f"  {r['corpus']:20s} n={r['n']:5d} D={r['D']:+.2f} sl={r['sl']} surp={r['surp']:.2f} mattr={r['mattr']:.2f} unlem={r['unlem']:.0%} | {r['name'][:64]}")
