"""Data for the map of kings' names: how often, when and where each name occurs, and in which order names are mentioned
within a text (order of the sentences in the files). Descriptive, no test.
usage: python3 -I kings_map_data.py <dir with _aes_*.json> <out.json>"""
import sys, os, json, re, collections
C = collections.Counter
d, out = sys.argv[1:3]
PER = ('OK & FIP', 'MK & SIP', 'NK', 'TIP - Roman times')
cnt = C(); per = collections.defaultdict(C); corp = collections.defaultdict(C); gl = collections.defaultdict(C); texts = collections.defaultdict(set); seq = collections.defaultdict(list); ymax = {}
def num(t):
    wf = (t.get('written_form') or '').strip()
    return int(wf) if t.get('pos') == 'numeral' and re.fullmatch(r'\d+', wf) else None
for fn in sorted(os.listdir(d)):
    if not fn.startswith('_aes_'): continue
    data = json.load(open(os.path.join(d, fn), encoding='utf-8'))
    for s in data.values():
        T = s['token']
        for i, t in enumerate(T):
            if t.get('name') == 'kings_name':
                k = t.get('lemma_form'); cnt[k] += 1; per[k][s.get('date') if s.get('date') in PER else 'undatiert'] += 1; corp[k][s['corpus']] += 1; texts[k].add(s['text'])
                if t.get('cotext_translation'): gl[k][t['cotext_translation'][:60]] += 1
                q = seq[s['text']]
                if not q or q[-1] != k: q.append(k)
            elif t.get('lemma_form') == 'rnp.t-zp' and i + 1 < len(T) and num(T[i + 1]) is not None:
                k = next((x.get('lemma_form') for x in T[i + 2:] if x.get('name') == 'kings_name'), None)
                if k: ymax[k] = max(ymax.get(k, 0), num(T[i + 1]))
    del data
edges = C()
for q in seq.values():
    for a, b in zip(q, q[1:]): edges[(a, b)] += 1
keep = {k for k, n in cnt.items() if n >= 5}
nodes = [{'id': k, 'n': cnt[k], 'per': dict(per[k]), 'corp': dict(corp[k].most_common(3)), 'gl': gl[k].most_common(1)[0][0] if gl[k] else '', 'y': ymax.get(k), 't': len(texts[k])} for k in sorted(keep, key=lambda k: -cnt[k])]
E = [{'a': a, 'b': b, 'n': n} for (a, b), n in edges.most_common() if n >= 3 and a in keep and b in keep]
json.dump({'nodes': nodes, 'edges': E, 'names': len(cnt), 'tokens': sum(cnt.values()), 'texts': len(seq)}, open(out, 'w', encoding='utf-8'), ensure_ascii=False)
print('names', len(cnt), '| shown (5 or more):', len(nodes), '| order pairs seen 3 times or more:', len(E), '| texts with a king\'s name:', len(seq))
print('strongest pairs:', '; '.join(f'{a} -> {b} {n}' for (a, b), n in edges.most_common(6)))
print('sample glosses:', [(n['id'], n['gl']) for n in nodes[8:12]])
