"""Egyptian corpus: what is being counted (lemma before the numeral), fraction notations.
usage: python3 -I numvalues2.py <aes_tokens_cache.json.gz> <aes_deutung_token.jsonl.gz>
"""
import sys, gzip, json, re, collections

tok_p, deut_p = sys.argv[1], sys.argv[2]
C = collections.Counter
with gzip.open(tok_p, 'rt', encoding='utf-8') as f:
    T = json.load(f)
gl = collections.defaultdict(C); wf_tr = collections.defaultdict(C)
WATCH = ('ḥsb', 'rʾ-8', 'rʾ-16', 'rʾ-32', 'rʾ-64', 'ḫꜣ', '1/64', '1/2', '1-3/4', '2.t', '1+1')
with gzip.open(deut_p, 'rt', encoding='utf-8') as f:
    for line in f:
        r = json.loads(line)
        lid = r.get('lemmaID')
        if lid: gl[lid][(r.get('cotext_translation') or '').strip()] += 1
        if r.get('lemma_form') == '1...n':
            w = re.sub(r'[\[\]⸢⸣()\?{}〈〉<>\s⸮]', '', r.get('written_form') or '')
            if w in WATCH: wf_tr[w][(r.get('cotext_translation') or '').strip()[:40]] += 1
g = lambda lid: (gl[lid].most_common(1)[0][0][:22] if gl.get(lid) else '')
clean = lambda w: re.sub(r'[\[\]⸢⸣()\?{}〈〉<>\s⸮]', '', w or '')
FR = re.compile(r'^(rʾ-\d+|\d+/\d+|ḥsb|\d+-\d+/\d+)$')
prev_all = C(); prev_v = collections.defaultdict(C); next_v = collections.defaultdict(C)
prev_fr = C(); corp_fr = C(); fr_forms = C(); n_int = 0; n_fr = 0
corp_v = collections.defaultdict(C)
for tid, t in T.items():
    toks = t['tok']; pos0 = 0
    sents = []
    for L in t['sl']:
        sents.append(toks[pos0:pos0 + L]); pos0 += L
    if pos0 < len(toks): sents.append(toks[pos0:])
    for s in sents:
        for i, tk in enumerate(s):
            if tk[1] != '1...n': continue
            cw = clean(tk[3])
            p = (s[i - 1][0], s[i - 1][1]) if i > 0 else ('', '<Satzanfang>')
            nx = (s[i + 1][0], s[i + 1][1]) if i + 1 < len(s) else ('', '<Satzende>')
            if re.fullmatch(r'\d+', cw):
                v = int(cw); n_int += 1
                prev_all[p] += 1
                if v in (1, 2, 3, 4, 7, 10, 1000): prev_v[v][p] += 1; next_v[v][nx] += 1; corp_v[v][t['corpus']] += 1
            elif FR.match(cw):
                n_fr += 1; prev_fr[p] += 1; corp_fr[t['corpus']] += 1; fr_forms[cw] += 1
print('integers', n_int, '| fraction tokens', n_fr)
print('fraction notations:', fr_forms.most_common(30))
print('fractions by corpus:', corp_fr.most_common(8))
print('before fractions:', ' ; '.join(f'{lf} ({g(l)}) {n}' for (l, lf), n in prev_fr.most_common(14)))
print('\nbefore integers (what is counted), top 30:')
cum = 0
for (l, lf), n in prev_all.most_common(30):
    cum += n
    print(f'  {lf:12s} {g(l):24s} {n:5d} {n/n_int:6.1%}  cum {cum/n_int:.1%}')
for v in (1, 2, 3, 4, 7, 10, 1000):
    tot = sum(prev_v[v].values())
    print(f'\nvalue {v} (n={tot}); corpora: ' + ', '.join(f'{c} {n}' for c, n in corp_v[v].most_common(4)))
    print('   before:', ' ; '.join(f'{lf} ({g(l)}) {n/tot:.0%}' for (l, lf), n in prev_v[v].most_common(6)))
    print('   after :', ' ; '.join(f'{lf} ({g(l)}) {n/tot:.0%}' for (l, lf), n in next_v[v].most_common(4)))
print('\ntranslations of selected written forms:')
for w in WATCH:
    print(f'  {w:8s}', wf_tr[w].most_common(4))
