import json, sys, collections, math, statistics, gzip
import numpy as np
from scipy.stats import spearmanr
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
texts_p, toks_p, v2_p = sys.argv[1:4]
TX = json.load(gzip.open(texts_p, 'rt', encoding='utf-8')); TK = json.load(gzip.open(toks_p, 'rt', encoding='utf-8'))
B = json.load(open(v2_p, encoding='utf-8'))['B']; R = {r['text']: r for r in B}
NW = sum(len(t['tok']) for t in TK.values())
print(f"scored texts {len(B)} of {len(TK)}; words in scored texts {sum(r['n'] for r in B)} of {NW} = {sum(r['n'] for r in B)/NW:.1%}")
lv = collections.Counter(r['level'] for r in B); wl = collections.Counter()
for r in B: wl[r['level']] += r['n']
print('texts per level', [lv[i] for i in (1,2,3,4)], 'words per level', [wl[i] for i in (1,2,3,4)], 'median words per text per level', [statistics.median(r['n'] for r in B if r['level']==i) for i in (1,2,3,4)])
print('composition of each level by corpus (top 5):')
for i in (1,2,3,4):
    c = collections.Counter(r['corpus'] for r in B if r['level']==i); print('  L%d' % i, ', '.join(f'{k} {v} ({v/lv[i]:.0%})' for k, v in c.most_common(5)))
MAIN = {'bbawarchive': 'Verwaltung', 'bbawbriefe': 'Briefe', 'bbawpyramidentexte': 'Jenseits/Ritual', 'tb': 'Jenseits/Ritual', 'bbawtotenlit': 'Jenseits/Ritual', 'sawmedizin': 'Wissen', 'bbawtempelbib': 'Wissen',
        'sawlit': 'Literatur', 'bbawgrabinschriften': 'Grab/Privat', 'bbawgraeberspzt': 'Grab/Privat', 'tuebingerstelen': 'Grab/Privat', 'bbawamarna': 'Koenig/Geschichte', 'bbawramessiden': 'Koenig/Geschichte',
        'bbawhistbiospzt': 'Koenig/Geschichte', 'bbawfelsinschriften': 'Koenig/Geschichte', 'smaek': 'Sonstige'}
rng = np.random.default_rng(20261112)
print('main themes (B): texts all | words all | scored | median D [5-95%] | level shares')
res = []
for mt in sorted(set(MAIN.values())):
    rr = [r for r in B if MAIN[r['corpus']] == mt]
    if len(rr) < 10: continue
    v = np.array([r['D'] for r in rr]); m = np.median(rng.choice(v, (2000, len(v))), axis=1); c = collections.Counter(r['level'] for r in rr)
    res.append((float(np.median(v)), mt, sum(1 for t in TK.values() if MAIN[t['corpus']] == mt), sum(len(t['tok']) for t in TK.values() if MAIN[t['corpus']] == mt), len(rr), np.percentile(m, 5), np.percentile(m, 95), [c.get(i, 0) for i in (1,2,3,4)]))
for md, mt, nt, nw, n, lo, hi, c in sorted(res): print(f"  {mt:18s} {nt:5d} | {nw:6d} | {n:4d} | {md:+.2f} [{lo:+.2f}, {hi:+.2f}] | {'/'.join(f'{x/n:.0%}' for x in c)}")
# sign-only vs B
def mattr(seq, w):
    c = collections.Counter(seq[:w]); tot = len(c); n = 1
    for i in range(w, len(seq)):
        a = seq[i-w]; c[a] -= 1
        if c[a] == 0: del c[a]
        c[seq[i]] += 1; tot += len(c); n += 1
    return tot/n/w
SG = collections.Counter(s for t in TX.values() for s in t['signs']); NS = sum(SG.values())
S = [(tid, sum(-math.log2(SG[x]/NS) for x in t['signs'])/len(t['signs']), mattr(t['signs'], 50)) for tid, t in TX.items() if len(t['signs']) >= 100]
a = np.array([x[1] for x in S]); b = np.array([x[2] for x in S]); DS = {x[0]: float(d) for x, d in zip(S, ((a-a.mean())/a.std() + (b-b.mean())/b.std())/2)}
both = [t for t in DS if t in R]
print(f"\nsign-only score: texts {len(S)}, overlap with B {len(both)}; Spearman text level {spearmanr([R[t]['D'] for t in both], [DS[t] for t in both])[0]:.2f}")
gm = []
for c in sorted(set(R[t]['corpus'] for t in both)):
    tt = [t for t in both if R[t]['corpus'] == c]
    if len(tt) >= 10: gm.append((c, len(tt), statistics.median(R[t]['D'] for t in tt), statistics.median(DS[t] for t in tt)))
for g in sorted(gm, key=lambda g: g[3]): print(f'  {g[0]:22s} n={g[1]:4d} words {g[2]:+.2f} | signs {g[3]:+.2f}')
print('  group-level Spearman:', round(spearmanr([g[2] for g in gm], [g[3] for g in gm])[0], 2), 'groups', len(gm))
print('\nexamples per level (three longest, B):')
for L in (1,2,3,4):
    for r in sorted([r for r in B if r['level'] == L], key=lambda r: -r['n'])[:4]: print(f"  L{L} {r['corpus']:20s} n={r['n']:5d} D={r['D']:+.2f} sl={r['sl']} | {r['name'][:110]}")
# content-word clustering
form = {}
docs = []
for tid, t in TK.items():
    d = []
    for k in t['tok']:
        if k[0] and k[2] in ('substantive', 'verb', 'adjective'): d.append(k[0]); form.setdefault(k[0], k[1])
    if len(d) >= 60: docs.append((tid, d, t['corpus']))
vec = TfidfVectorizer(analyzer=lambda d: d, min_df=5, sublinear_tf=True); X = vec.fit_transform([d for _, d, _ in docs]); voc = vec.get_feature_names_out()
labels = [c for _, _, c in docs]
for k in (8, 12, 16):
    km = KMeans(n_clusters=k, n_init=5, random_state=0).fit(X)
    pur = sum(max(collections.Counter(l for l, c in zip(labels, km.labels_) if c == j).values()) for j in set(km.labels_))/len(labels)
    print(f'\ncontent-word clustering k={k}: docs {X.shape} ARI={adjusted_rand_score(labels, km.labels_):.2f} NMI={normalized_mutual_info_score(labels, km.labels_):.2f} purity={pur:.2f} baseline={max(collections.Counter(labels).values())/len(labels):.2f}')
    if k != 12: continue
    out = []
    for j in range(k):
        mem = [i for i, l in enumerate(km.labels_) if l == j]
        cc = collections.Counter(docs[i][2] for i in mem).most_common(3)
        rr = [R[docs[i][0]] for i in mem if docs[i][0] in R]; c = collections.Counter(r['level'] for r in rr)
        ep = collections.Counter(TK[docs[i][0]]['date'] for i in mem).most_common(2)
        out.append((statistics.median(r['D'] for r in rr), len(mem), '/'.join(f"{c.get(i,0)/len(rr):.0%}" for i in (1,2,3,4)), ', '.join(f'{c_} {n}' for c_, n in cc), ', '.join(f'{e} {n}' for e, n in ep), ' '.join(form[voc[i]] for i in np.argsort(-km.cluster_centers_[j])[:11])))
    for md, n, ls, cc, ep, terms in sorted(out): print(f'  {n:4d} | D {md:+.2f} | {ls} | {cc} | {ep} | {terms}')
