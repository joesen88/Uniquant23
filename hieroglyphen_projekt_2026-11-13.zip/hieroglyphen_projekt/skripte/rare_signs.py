import json, sys, glob, os, re, collections, statistics, random, math, html
aes_dir, conc_p, uni_p, out_p = sys.argv[1:5]
random.seed(20261112)
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*')
def base(s): return re.sub(r'(?<=\d)[A-Za-z]+$', '', s)
id2name = {}
for line in open(conc_p, encoding='utf-8'):
    p = line.rstrip('\n').split('\t')
    if len(p) == 2: id2name[p[1]] = html.unescape(p[0])
cp = collections.defaultdict(dict)
for line in open(uni_p, encoding='utf-8'):
    if line.startswith('U+'):
        p = line.rstrip('\n').split('\t')
        if len(p) == 3: cp[p[0]][p[1]] = p[2]
UNI = {}
for u, d in cp.items():
    if 'kEH_JSesh' in d: UNI.setdefault(d['kEH_JSesh'], (u, d.get('kEH_Desc', ''), d.get('kEH_Func', ''), d.get('kEH_FVal', '')))
TOK = []; TEXTS = collections.defaultdict(list); LEMALL = collections.Counter(); LEMLIT = collections.Counter(); NSENT = collections.Counter(); 
for p in sorted(glob.glob(os.path.join(aes_dir, '_aes_*.json'))):
    d = json.load(open(p, encoding='utf-8'))
    for sid, s in d.items():
        c = s['corpus']; has = False
        for k in s.get('token', []):
            lid = str(k.get('lemmaID') or '')
            if lid: LEMALL[lid] += 1; LEMLIT[lid] += (c == 'sawlit')
            if not k.get('hiero'): continue
            sg = SIGN.findall(k['hiero'])
            if not sg: continue
            r = {'c': c, 't': s['text'], 'sid': sid, 'lid': lid, 'lf': k.get('lemma_form') or '', 'pos': k.get('pos') or '', 'tr': k.get('cotext_translation') or '', 'wf': k.get('written_form') or '',
                 'h': k['hiero'], 'sg': sg, 'b': [base(x) for x in sg], 'line': k.get('lineCount') or '', 'st': s.get('sentence_translation') or ''}
            TOK.append(r); TEXTS[s['text']].append(r); has = True
        if has: NSENT[c] += 1
print('tokens with signs', len(TOK), 'texts', len(TEXTS))
LIT = set(b for r in TOK if r['c'] == 'sawlit' for b in r['b']); MED = set(b for r in TOK if r['c'] == 'sawmedizin' for b in r['b'])
def is_pt(r): return r['c'] == 'bbawpyramidentexte' or (r['c'] == 'bbawgraeberspzt' and re.search(r'\bPT\b', id2name.get(r['t'], '')))
SETS = {'PT': [r for r in TOK if is_pt(r)], 'RIT': [r for r in TOK if r['c'] == 'bbawtotenlit']}
BYLEM = collections.defaultdict(list)
for r in TOK:
    if r['lid']: BYLEM[r['lid']].append(r)
def nm(t): 
    n = id2name.get(t, t); return n.split(':', 1)[1] if ':' in n else n
OUT = {}
for key, recs in SETS.items():
    ntok = sum(len(r['b']) for r in recs); occ = collections.defaultdict(list)
    for r in recs:
        for i, b in enumerate(r['b']):
            if b not in LIT: occ[b].append((r, i))
    print(f'\n===== {key}: sign tokens {ntok}, rare signs {len(occ)}, rare tokens {sum(len(v) for v in occ.values())} = {sum(len(v) for v in occ.values())/ntok:.2%}')
    agg = collections.Counter(); posagg = collections.Counter(); lemcount = []; rows = []
    for b, v in sorted(occ.items(), key=lambda x: -len(x[1])):
        var = collections.Counter(r['sg'][i] for r, i in v); top = var.most_common(1)[0][0]; u = UNI.get(top) or UNI.get(b) or ('', '', '', '')
        where = collections.Counter('allein' if len(r['b']) == 1 else 'Ende' if i == len(r['b']) - 1 else 'Anfang' if i == 0 else 'Mitte' for r, i in v)
        lem = collections.Counter(r['lid'] for r, i in v); info = {r['lid']: (r['lf'], r['tr']) for r, i in v}
        texts = collections.Counter(nm(r['t']) for r, i in v); prev = collections.Counter(r['b'][i-1] for r, i in v if i > 0)
        lems = []
        for lid, n in lem.most_common(4):
            allr = BYLEM.get(lid, []) if lid else []; without = [x for x in allr if b not in x['b']]; sp = collections.Counter(x['h'] for x in without).most_common(1)
            withsp = collections.Counter(r['h'] for r, i in v if r['lid'] == lid).most_common(1)[0][0]
            lems.append({'lid': lid, 'lf': info[lid][0], 'tr': info[lid][1], 'n': n, 'spelling': withsp, 'attested_with_signs': len(allr), 'without_this_sign': len(without), 'usual_other_spelling': sp[0][0] if sp else '', 'in_literary_words': LEMLIT.get(lid, 0), 'in_all_words': LEMALL.get(lid, 0)})
        n = len(v); nwo = sum(1 for r, i in v if r['lid'] and any(b not in x['b'] for x in BYLEM[r['lid']])); nlit = sum(1 for r, i in v if r['lid'] and LEMLIT.get(r['lid'], 0) > 0); nolem = sum(1 for r, i in v if not r['lid'])
        agg['n'] += n; agg['lemma_also_spelled_without'] += nwo; agg['lemma_in_literary'] += nlit; agg['no_lemma'] += nolem; posagg.update(where); lemcount.append(len(lem))
        for r, i in v: agg['pos_' + r['pos']] += 1
        ex = v[0][0]
        rows.append({'set': key, 'base': b, 'variants': dict(var), 'class': 2 if b in MED else 3, 'n': n, 'unicode': u[0], 'desc': u[1], 'func': u[2], 'fval': u[3], 'where': dict(where), 'texts': texts.most_common(4), 'ntexts': len(texts),
                     'lemmas': lems, 'nlemmas': len(lem), 'prev': prev.most_common(3), 'example': {'text': nm(ex['t']), 'line': ex['line'], 'word': ex['wf'], 'hiero': ex['h'], 'sentence': ex['st'][:220]}})
        l0 = lems[0]
        print(f"{b:6s} K{2 if b in MED else 3} n={n:3d} txt={len(texts):2d} {'/'.join(f'{k}{c}' for k, c in where.most_common(3)):22s} lem={len(lem)} | {l0['lf'][:16]} ({l0['tr'][:26]}) x{l0['n']} [{l0['spelling'][:26]}] ohne:{l0['without_this_sign']}/{l0['attested_with_signs']} {('→ ' + l0['usual_other_spelling'][:22]) if l0['usual_other_spelling'] else ''} lit:{l0['in_literary_words']} | {u[2][:28]} | {u[1][:46]} | {texts.most_common(1)[0][0][:40]}"[:330])
    N = agg['n']
    print(f"  SUMMARY {key}: position {dict(posagg)} | signs tied to 1 lemma: {sum(1 for x in lemcount if x == 1)}/{len(lemcount)}, <=2 lemmas: {sum(1 for x in lemcount if x <= 2)}/{len(lemcount)}")
    print(f"  occurrences whose word is elsewhere written without the sign: {agg['lemma_also_spelled_without']}/{N}; whose word also occurs in literary texts: {agg['lemma_in_literary']}/{N}; without lemma: {agg['no_lemma']}/{N}")
    print('  word classes of host words:', {k[4:]: v for k, v in agg.most_common() if k.startswith('pos_')})
    OUT[key] = rows
    # anchor reach
    rare = set(occ); 
    tot = 0; near = collections.Counter(); sent_with = set(); texts_with = collections.Counter()
    bytext = collections.defaultdict(list)
    for r in recs: bytext[r['t']].append(r)
    for t, rr in bytext.items():
        seq = [b for r in rr for b in r['b']]; idx = [i for i, b in enumerate(seq) if b in rare]; tot += len(seq); texts_with[t] = len(idx)
        for k in (2, 5, 10, 20):
            mark = set()
            for i in idx: mark.update(range(max(0, i-k), min(len(seq), i+k+1)))
            near[k] += len(mark)
        for r in rr:
            if any(b in rare for b in r['b']): sent_with.add(r['sid'])
    ns = len(set(r['sid'] for r in recs))
    print(f"  REACH: share of sign positions within ±2/5/10/20 of a rare sign: {[f'{near[k]/tot:.1%}' for k in (2,5,10,20)]}; sentences containing one: {len(sent_with)}/{ns} = {len(sent_with)/ns:.1%}; texts without any: {sum(1 for v in texts_with.values() if v == 0)}/{len(texts_with)}")
    print('  rare-sign tokens per text:', sorted(((nm(t)[:38], v, sum(len(r['b']) for r in bytext[t])) for t, v in texts_with.items()), key=lambda x: -x[1])[:8])
    # frequency-matched comparison of combinatorial freedom (only meaningful for RIT)
    if key == 'RIT':
        st = collections.defaultdict(lambda: {'n': 0, 'lem': set(), 'L': collections.Counter(), 'R': collections.Counter(), 'last': 0, 'texts': set()})
        for t, rr in bytext.items():
            seq = [(b, r, i) for r in rr for i, b in enumerate(r['b'])]
            for j, (b, r, i) in enumerate(seq):
                s = st[b]; s['n'] += 1; s['lem'].add(r['lid'] or r['wf']); s['texts'].add(t); s['last'] += (i == len(r['b']) - 1)
                if j > 0: s['L'][seq[j-1][0]] += 1
                if j + 1 < len(seq): s['R'][seq[j+1][0]] += 1
        def H(c):
            n = sum(c.values()); return -sum(v/n*math.log2(v/n) for v in c.values()) if n else 0.0
        comp = []
        for b in rare:
            s = st[b]
            if s['n'] < 5: continue
            ctr = [x for x, y in st.items() if x not in rare and 0.7*s['n'] <= y['n'] <= 1.4*s['n']]
            if len(ctr) < 3: continue
            f = lambda y: (len(y['lem'])/y['n'], H(y['L']), H(y['R']), len(y['texts']), y['last']/y['n'])
            cm = [statistics.median(f(st[x])[q] for x in ctr) for q in range(5)]; comp.append((b, s['n'], f(s), cm, len(ctr)))
        print(f"  COMBINATORICS (rare signs with n>=5: {len(comp)}; controls = non-rare signs of similar frequency in the same corpus)")
        for q, lab in enumerate(('distinct words per occurrence', 'entropy of left neighbour (bits)', 'entropy of right neighbour (bits)', 'number of texts', 'share word-final')):
            a = [c[2][q] for c in comp]; b_ = [c[3][q] for c in comp]; print(f"    {lab:36s} rare median {statistics.median(a):.2f} | controls median {statistics.median(b_):.2f} | rare lower in {sum(1 for x, y in zip(a, b_) if x < y)}/{len(comp)}")
        hub = sorted(((len(set(y['L']) | set(y['R'])), x, y['n'], len(y['texts']), y['last']/y['n']) for x, y in st.items()), reverse=True)[:12]
        print('    signs with most distinct neighbours (hub candidates):', [(x, n, f'{d} neighbours', f'{t} texts', f'{l:.0%} final') for d, x, n, t, l in hub])
        print('    rare signs: median distinct neighbours', statistics.median(len(set(st[b]['L']) | set(st[b]['R'])) for b in rare), '| all non-rare:', statistics.median(len(set(y['L']) | set(y['R'])) for x, y in st.items() if x not in rare))
json.dump(OUT, open(out_p, 'w', encoding='utf-8'), ensure_ascii=False)
