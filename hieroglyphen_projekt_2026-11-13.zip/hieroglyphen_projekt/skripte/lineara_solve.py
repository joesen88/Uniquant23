"""Linear A fraction values: how far do hard constraints shrink the search space, and does the published solution satisfy them?
usage: python3 -I lineara_solve.py <LinearAInscriptions.js>
Premises as in Corazza et al. 2021: J=1/2, E=1/4, F=1/8; 36 admissible values; L series divisive (L2=L/2, L3=L/3, L4=L/4, L6=L/6).
Unknowns here: B, D, K, H, A and the base L = 1/n.
"""
import sys, json, re, math, unicodedata, collections, itertools
from fractions import Fraction as Fr
import numpy as np
C = collections.Counter
s = open(sys.argv[1], encoding='utf-8').read()
i = s.index('new Map(') + len('new Map(')
body = re.sub(r'\\u\{([0-9A-Fa-f]+)\}', lambda m: chr(int(m.group(1), 16)), s[i:])
arr, _ = json.JSONDecoder().raw_decode(re.sub(r',\s*([\]}])', r'\1', body).lstrip())
NAME = {chr(cp): unicodedata.name(chr(cp)).split()[-1] for cp in range(0x10740, 0x10756)}
UNC = '\U0001076b'
print('where the rare compounds stand (sign layer, certain readings):')
for key, v in arr:
    for w, t in zip(v.get('words', []), v.get('transliteratedWords', [])):
        if w and all(ch in NAME for ch in w) and len(w) >= 2:
            sig = ' '.join(NAME[ch] for ch in w)
            if sig in ('H K', 'A B B', 'E J', 'L E', 'J J', 'D D D D', 'F K', 'E L6', 'J A', 'J H'):
                print(f'   {sig:8s} in {key:12s} ({v.get("site")}, {v.get("support")}) rendered there as {t!r}')

VALS = [Fr(5, 6), Fr(2, 3), Fr(1, 3), Fr(1, 5), Fr(1, 6), Fr(3, 20)] + [Fr(1, d) for d in (7, 9, 10, 12, 15, 16, 20, 24, 30, 32, 36, 40, 48, 50, 60, 64, 70, 72, 80, 84, 90, 96, 108, 100, 120, 160, 200, 240, 300, 320)]
assert len(VALS) == 36
V = np.array([float(x) for x in VALS])
J, E, F = 0.5, 0.25, 0.125
nv = len(V); tol = 1e-12
B = V[:, None, None, None]; Dd = V[None, :, None, None]; H = V[None, None, :, None]; A = V[None, None, None, :]
ne = lambda x, y: np.abs(x - y) > tol
counts = collections.OrderedDict((k, 0) for k in ('raw', 'distinct', 'order (published list)', 'below 1', 'economy', 'plus H>K', 'plus A>B', 'plus both'))
pub = {'B': Fr(1, 5), 'D': Fr(1, 6), 'K': Fr(1, 10), 'H': Fr(1, 16), 'A': Fr(1, 24), 'n': 10}
best_examples = []
for kK, K in enumerate(V):
    for n in range(2, 54):
        L2, L3, L4, L6 = 1 / (2 * n), 1 / (3 * n), 1 / (4 * n), 1 / (6 * n)
        if L6 < 1 / 320 - tol: continue
        counts['raw'] += nv ** 4
        fixed = [J, E, F, K, L2, L3, L4, L6]
        if len({round(x, 12) for x in fixed}) < len(fixed): continue
        ok = np.ones((nv, nv, nv, nv), dtype=bool)
        for X in (B, Dd, H, A):
            for f in fixed: ok &= ne(X, f)
        ok &= ne(B, Dd) & ne(B, H) & ne(B, A) & ne(Dd, H) & ne(Dd, A) & ne(H, A)
        counts['distinct'] += int(ok.sum())
        # order as in the published list: J > E > F > K > L2 > L4 ; J > A ; J > H ; E > B
        if not (K < F - tol and L2 < K - tol): continue
        ok &= (A < J - tol) & (H < J - tol) & (B < E - tol)
        counts['order (published list)'] += int(ok.sum())
        # attested compounds stay below 1: D D D D, B B, J B, JE B, A B B, J A, J H, H K, J K ...
        ok &= (4 * Dd < 1 - tol) & (0.75 + B < 1 - tol) & (A + 2 * B < 1 - tol) & (H + K < 1 - tol)
        counts['below 1'] += int(ok.sum())
        # economy: the sum of an attested compound is not the value of a single sign
        singles = [J, E, F, K, L2, L3, L4, L6]
        combos = [2 * Dd, 4 * Dd, 2 * B, J + B, 0.75 + B, E + B, A + 2 * B, J + A, J + H, H + K + 0 * B, np.full((1, 1, 1, 1), K + L2), np.full((1, 1, 1, 1), J + K),
                  np.full((1, 1, 1, 1), E + L2), np.full((1, 1, 1, 1), F + K), np.full((1, 1, 1, 1), E + L4), np.full((1, 1, 1, 1), E + L6), np.full((1, 1, 1, 1), J + L2)]
        for c in combos:
            for f in singles: ok &= ne(c, f)
            for X in (B, Dd, H, A): ok &= ne(c, X)
        n_e = int(ok.sum()); counts['economy'] += n_e
        hk = ok & (H > K + tol); ab = ok & (A > B + tol)
        counts['plus H>K'] += int(hk.sum()); counts['plus A>B'] += int(ab.sum()); counts['plus both'] += int((hk & ab).sum())
        if abs(K - 0.1) < tol and n == 10:
            ib, idd, ih, ia = (VALS.index(pub[x]) for x in ('B', 'D', 'H', 'A'))
            print(f'\npublished solution (B=1/5, D=1/6, K=1/10, H=1/16, A=1/24, L=1/10): passes distinct/order/below-1/economy: {bool(ok[ib, idd, ih, ia])}; passes H>K: {bool(hk[ib, idd, ih, ia])}; passes A>B: {bool(ab[ib, idd, ih, ia])}')
            sub = ok[ib, idd]
            print(f'   with B, D, K, L fixed at the published values: {int(sub.sum())} admissible (H, A) pairs; H>K leaves {int((sub & (V[:, None] > K + tol)).sum())}')
print('\nsearch space under successive hard constraints:')
prev = None
for k, v in counts.items():
    bits = f'{math.log2(prev / v):5.2f} bits gained' if prev and v else ''
    print(f'   {k:26s} {v:14,d}  = 2^{math.log2(v):5.2f}   {bits}' if v else f'   {k:26s} 0')
    if k in ('raw', 'distinct', 'order (published list)', 'below 1', 'economy'): prev = v
print(f'   total reduction by the published hard rules: {math.log2(counts["raw"] / counts["economy"]):.2f} of {math.log2(counts["raw"]):.2f} bits')
