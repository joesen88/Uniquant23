import json, re, sys, os, glob
from playwright.sync_api import sync_playwright
gdir, out_p = sys.argv[1:3]
SHAPE = re.compile(r'<(path|rect|line|circle|ellipse|polygon|polyline)\b[^>]*?(?:/>|>\s*</\1>)', re.S)
BADCOL = re.compile(r'''(fill|stroke)\s*[:=]\s*["']?\s*(#(?!000000\b|000\b|ffffff\b|fff\b|FFFFFF\b|FFF\b)[0-9a-fA-F]{3,6}|red|blue|green)''')
def clean(t):
    body = t[t.index('>', t.index('<svg')) + 1:t.rindex('</svg>')]
    body = re.sub(r'<metadata.*?</metadata>', '', body, flags=re.S); body = re.sub(r'<!--.*?-->', '', body, flags=re.S)
    body = re.sub(r'<(sodipodi|inkscape):[^>]*?/>', '', body, flags=re.S); body = re.sub(r'<(sodipodi|inkscape):.*?</\1:[^>]*>', '', body, flags=re.S)
    def keep(m):
        s = m.group(0)
        if re.search(r'''id=["'][^"']*zone''', s, re.I) or BADCOL.search(s): return ''
        return s
    body = SHAPE.sub(keep, body)
    if 'url(#' not in body and 'xlink:href' not in body:
        body = re.sub(r'<defs.*?</defs>', '', body, flags=re.S); body = re.sub(r'<defs[^>]*/>', '', body); body = re.sub(r'''\sid=(["'])[^"']*\1''', '', body)
    body = re.sub(r'''\s(sodipodi|inkscape):[\w-]+=(["'])[^"']*\2''', '', body)
    body = re.sub(r'(fill|stroke)\s*:\s*(#000000|#000|black)\b', r'\1:currentColor', body); body = re.sub(r'''(fill|stroke)=(["'])(#000000|#000|black)\2''', r'\1="currentColor"', body)
    body = re.sub(r'(fill|stroke)\s*:\s*(#ffffff|#fff|white)\b', r'\1:var(--panel)', body, flags=re.I); body = re.sub(r'''(fill|stroke)=(["'])(#ffffff|#fff|white)\2''', r'\1="var(--panel)"', body, flags=re.I)
    return re.sub(r'\s+', ' ', body).strip()
G = {os.path.basename(p)[:-4]: clean(open(p, encoding='utf-8', errors='ignore').read()) for p in sorted(glob.glob(os.path.join(gdir, '*.svg')))}
doc = '<!DOCTYPE html><html><body>' + ''.join(f'<svg width="20" height="20" style="overflow:hidden"><g id="b-{c}">{b}</g></svg>' for c, b in G.items()) + '</body></html>'
open('/tmp/bbox.html', 'w', encoding='utf-8').write(doc)
with sync_playwright() as p:
    b = p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox']); pg = b.new_page(); pg.goto('file:///tmp/bbox.html')
    boxes = pg.evaluate("() => Object.fromEntries([...document.querySelectorAll('g[id^=\"b-\"]')].map(g => { const r = g.getBBox(); return [g.id.slice(2), [r.x, r.y, r.width, r.height]]; }))"); b.close()
out = {}; big = 0; empty = []
for c, body in G.items():
    x, y, w, h = boxes.get(c, [0, 0, 0, 0])
    if w <= 0 or h <= 0: empty.append(c); continue
    sc = 0.01 if max(w, h) > 60 else 1.0; big += sc != 1.0
    out[c] = {'body': body, 'x': x, 'y': y, 'w': w, 'h': h, 'scale': sc}
json.dump(out, open(out_p, 'w', encoding='utf-8'))
import statistics
print('glyphs', len(out), 'rescaled x0.01:', big, 'empty:', empty, '| median height', round(statistics.median(v['h']*v['scale'] for v in out.values()), 1), '| max height', round(max(v['h']*v['scale'] for v in out.values()), 1), '| examples', {c: (round(out[c]['w']*out[c]['scale'], 1), round(out[c]['h']*out[c]['scale'], 1)) for c in ('A1', 'V31', 'X1', 'D58', 'W10', 'M17', 'O194', 'Z1', 'N35')})
