"""The 2/n table of the Rhind papyrus: which rule explains the scribes' choice?
usage: python3 -I rhind_2n.py
All decompositions of 2/n into 2-4 distinct unit fractions with denominators <= 999 are enumerated exactly.
"""
import sys, math, itertools, random, collections
from fractions import Fraction as Fr
import numpy as np

C = collections.Counter
D = 999
TABLE = {3: (2, 6), 5: (3, 15), 7: (4, 28), 9: (6, 18), 11: (6, 66), 13: (8, 52, 104), 15: (10, 30), 17: (12, 51, 68), 19: (12, 76, 114),
         21: (14, 42), 23: (12, 276), 25: (15, 75), 27: (18, 54), 29: (24, 58, 174, 232), 31: (20, 124, 155), 33: (22, 66), 35: (30, 42),
         37: (24, 111, 296), 39: (26, 78), 41: (24, 246, 328), 43: (42, 86, 129, 301), 45: (30, 90), 47: (30, 141, 470), 49: (28, 196),
         51: (34, 102), 53: (30, 318, 795), 55: (30, 330), 57: (38, 114), 59: (36, 236, 531), 61: (40, 244, 488, 610), 63: (42, 126),
         65: (39, 195), 67: (40, 335, 536), 69: (46, 138), 71: (40, 568, 710), 73: (60, 219, 292, 365), 75: (50, 150), 77: (44, 308),
         79: (60, 237, 316, 790), 81: (54, 162), 83: (60, 332, 415, 498), 85: (51, 255), 87: (58, 174), 89: (60, 356, 534, 890),
         91: (70, 130), 93: (62, 186), 95: (60, 380, 570), 97: (56, 679, 776), 99: (66, 198), 101: (101, 202, 303, 606)}
bad = [n for n, t in TABLE.items() if sum(Fr(1, d) for d in t) != Fr(2, n) or len(set(t)) != len(t)]
print(f'table: {len(TABLE)} entries, odd n from {min(TABLE)} to {max(TABLE)}; entries whose sum is not exactly 2/n: {bad}')
print('  terms used:', sorted(C(len(t) for t in TABLE.values()).items()), '| largest denominator in the table:', max(max(t) for t in TABLE.values()))


def two_terms(p, q, start, D):
    lo = max(start, q // p + 1); hi = min(D, (2 * q) // p)
    if lo > hi: return []
    c = np.arange(lo, hi + 1, dtype=np.int64)
    den = p * c - q; num = q * c
    ok = (den > 0) & (num % np.where(den > 0, den, 1) == 0)
    c = c[ok]; d = num[ok] // den[ok]
    keep = (d > c) & (d <= D)
    return list(zip(c[keep].tolist(), d[keep].tolist()))


def decomps(P, Q, D=D, kmax=4):
    """all tuples of 2..kmax distinct denominators <= D (ascending) with sum of reciprocals = P/Q"""
    g = math.gcd(P, Q); P //= g; Q //= g
    out = [(c, d) for c, d in two_terms(P, Q, 1, D)]
    if kmax >= 3:
        for a in range(Q // P + 1, min(D, 3 * Q // P) + 1):
            p1 = P * a - Q; q1 = Q * a
            if p1 <= 0: continue
            g = math.gcd(p1, q1); p1 //= g; q1 //= g
            out += [(a, c, d) for c, d in two_terms(p1, q1, a + 1, D)]
    if kmax >= 4:
        for a in range(Q // P + 1, min(D, 4 * Q // P) + 1):
            p1 = P * a - Q; q1 = Q * a
            if p1 <= 0: continue
            g = math.gcd(p1, q1); p1 //= g; q1 //= g
            for b in range(max(a + 1, q1 // p1 + 1), min(D, 3 * q1 // p1) + 1):
                p2 = p1 * b - q1; q2 = q1 * b
                if p2 <= 0 or p2 * D < 2 * q2: continue
                g = math.gcd(p2, q2)
                out += [(a, b, c, d) for c, d in two_terms(p2 // g, q2 // g, b + 1, D)]
    return out


def tau(m):
    return sum(2 if i * i != m else 1 for i in range(1, int(m ** 0.5) + 1) if m % i == 0)


def feats(t, n):
    return {'terms': len(t), 'max': t[-1], 'sum': sum(t), 'first': t[0], 'odd': sum(d % 2 for d in t),
            'nonmult': sum(1 for d in t[1:] if d % n), 'round1': -tau(t[0]), 'first_odd': t[0] % 2}


CAND = {}; total = 0
for n in TABLE:
    c = decomps(2, n); CAND[n] = c; total += len(c)
    assert TABLE[n] in c, (n, TABLE[n])
print(f'all decompositions with 2-4 terms and denominators <= {D}: {total} for the 50 fractions; per fraction: median {int(np.median([len(c) for c in CAND.values()]))}, min {min(len(c) for c in CAND.values())}, max {max(len(c) for c in CAND.values())}')
F = {n: [feats(t, n) for t in CAND[n]] for n in TABLE}
SF = {n: feats(TABLE[n], n) for n in TABLE}
isprime = lambda m: m > 1 and all(m % i for i in range(2, int(m ** 0.5) + 1))
cls = {n: ('multiple of 3' if n % 3 == 0 else ('prime' if isprime(n) else 'other composite')) for n in TABLE}
print('  classes:', dict(C(cls.values())))


def match(keyf, ns=None):
    """for each n: is the scribes' choice the unique minimum of the key? returns list of n matched, and ranks"""
    hit = []; ranks = {}
    for n in (ns or TABLE):
        ks = [keyf(f) for f in F[n]]; sk = keyf(SF[n])
        better = sum(1 for k in ks if k < sk); same = sum(1 for k in ks if k == sk)
        ranks[n] = better + 1
        if better == 0 and same == 1: hit.append(n)
    return hit, ranks


def show(name, keyf):
    hit, ranks = match(keyf)
    by = C(cls[n] for n in hit)
    print(f'  {name:58s} {len(hit):2d}/50   mult.of 3: {by["multiple of 3"]:2d}/17  primes: {by["prime"]:2d}/24  other: {by["other composite"]}/9   median rank of the scribes\' choice {int(np.median(list(ranks.values())))}')
    return hit


print('\nnamed rules: in how many of the 50 cases is the scribes\' decomposition the unique best one?')
greedy = [n for n in TABLE if TABLE[n] == ((n + 1) // 2, n * (n + 1) // 2)]
print(f'  {"greedy (largest unit fraction first)":58s} {len(greedy):2d}/50   {dict(C(cls[n] for n in greedy))}')
h_tm = show('fewest terms, then smallest largest denominator', lambda f: (f['terms'], f['max']))
show('smallest largest denominator', lambda f: (f['max'], f['terms']))
show('smallest sum of denominators', lambda f: (f['sum'],))
show('fewest terms, then smallest sum', lambda f: (f['terms'], f['sum']))
show('fewest odd denominators, then terms, then largest', lambda f: (f['odd'], f['terms'], f['max']))
show('smallest first denominator, then fewest terms', lambda f: (f['first'], f['terms'], f['max']))

# Pareto efficiency in (terms, largest denominator)
par = [n for n in TABLE if not any((f['terms'] <= SF[n]['terms'] and f['max'] <= SF[n]['max']) and (f['terms'] < SF[n]['terms'] or f['max'] < SF[n]['max']) for f in F[n])]
print(f'\nscribes\' choice is not beaten in both number of terms and largest denominator at once: {len(par)}/50; beaten: {sorted(set(TABLE) - set(par))}')
fam = [n for n in TABLE if SF[n]['nonmult'] == 0]
print(f'all later denominators are multiples of n (form 1/a + 1/(n*k) ...): {len(fam)}/50; exceptions: {sorted(set(TABLE) - set(fam))}')
# literature check: largest denominator minimal inside this family, for the 19 'large' primes
large = [p for p in TABLE if cls[p] == 'prime' and p >= 13 and p not in (23, 101)]
okp = []
for p in large:
    famc = [f for f in F[p] if f['nonmult'] == 0]
    if SF[p]['max'] == min(f['max'] for f in famc): okp.append(p)
print(f'large primes ({len(large)}): scribes\' largest denominator is the minimum within that family in {len(okp)}: misses {sorted(set(large) - set(okp))}')
okall = [p for p in large if SF[p]['max'] == min(f['max'] for f in F[p])]
print(f'  ... and the minimum among all decompositions in {len(okall)}')

# systematic search: lexicographic rules from 1-3 features
names = ['terms', 'max', 'sum', 'first', 'odd', 'nonmult', 'round1', 'first_odd']
rules = [r for k in (1, 2, 3) for r in itertools.permutations(names, k)]
res = {}
for r in rules:
    hit, _ = match(lambda f, r=r: tuple(f[x] for x in r))
    res[r] = set(hit)
best = sorted(res.items(), key=lambda kv: -len(kv[1]))[:6]
print(f'\nsearch over {len(rules)} lexicographic rules (1-3 criteria): best ones')
for r, hit in best:
    by = C(cls[n] for n in hit)
    print(f'  {" > ".join(r):40s} {len(hit):2d}/50  (mult.of 3 {by["multiple of 3"]}/17, primes {by["prime"]}/24, other {by["other composite"]}/9)')
# weighted cost: log(max) + a*terms + b*odd
wres = {}
for a in [x / 10 for x in range(0, 31)]:
    for b in [x / 10 for x in range(0, 21)]:
        hit, _ = match(lambda f, a=a, b=b: round(math.log(f['max']) + a * f['terms'] + b * f['odd'], 9))
        wres[(a, b)] = set(hit)
(a, b), hit = max(wres.items(), key=lambda kv: len(kv[1]))
by = C(cls[n] for n in hit)
print(f'weighted cost log(largest) + a*terms + b*odd: best a={a}, b={b}: {len(hit)}/50 (mult.of 3 {by["multiple of 3"]}/17, primes {by["prime"]}/24, other {by["other composite"]}/9); not explained: {sorted(set(TABLE) - hit)}')
# cross-validation of "pick the best rule on half, test on the other half"
rng = random.Random(0); ns = list(TABLE); cv_l = []; cv_w = []
for _ in range(300):
    rng.shuffle(ns); tr, te = set(ns[:25]), set(ns[25:])
    r_best = max(res, key=lambda r: len(res[r] & tr)); cv_l.append(len(res[r_best] & te) / 25)
    w_best = max(wres, key=lambda k: len(wres[k] & tr)); cv_w.append(len(wres[w_best] & te) / 25)
print(f'out of sample (rule chosen on 25 fractions, tested on the other 25; 300 splits): lexicographic {np.mean(cv_l):.1%}, weighted {np.mean(cv_w):.1%}')

# toolkit: fixed patterns
tk = {}
for n in TABLE:
    if n % 3 == 0: tk[n] = (2 * n // 3, 2 * n)
exp3 = [n for n in tk if tk[n] == TABLE[n]]
print(f'\npattern for multiples of 3, 2/(3k) = 1/(2k) + 1/(6k): {len(exp3)}/17')
scaled = {}
for n in TABLE:
    if cls[n] != 'other composite': continue
    for p in (5, 7, 11, 13, 17, 19):
        if n % p == 0 and n != p and tuple(d * (n // p) for d in TABLE[p]) == TABLE[n]: scaled[n] = p
print('other composites written as a multiple of an earlier entry (n: base):', scaled, '| not:', sorted(n for n in TABLE if cls[n] == 'other composite' and n not in scaled))
for n in (35, 91, 95, 55):
    two = sorted(t for t in CAND[n] if len(t) == 2)
    print(f'   2/{n}: all two-term forms {two}; scribes: {TABLE[n]}')

# the user's time quantum
q = decomps(75, 1012)
print(f'\n75/1012: {len(q)} decompositions with 2-4 terms and denominators <= {D}: by terms {dict(C(len(t) for t in q))}')
for t in sorted(q, key=lambda t: (len(t), t[-1]))[:6]: print('   ', t, 'check', sum(Fr(1, d) for d in t) == Fr(75, 1012))
