"""Control for the blind numeral analysis: Roman numerals in Latin technical texts.
usage: python3 -I roman_control.py <file-or-dir> [<file-or-dir> ...]
[1] blind: character stream (case-sensitive), which characters repeat beyond the script's usual doubling?
[2] numeral tokens (all-capital tokens made of the letters found in [1] and their in-token neighbours): caps, order.
"""
import sys, os, re, collections, itertools

C = collections.Counter
paths = []
for p in sys.argv[1:]:
    if os.path.isdir(p):
        for root, _, files in os.walk(p):
            paths += [os.path.join(root, f) for f in sorted(files) if f.endswith('.txt')]
    else:
        paths.append(p)
text = ''
for p in paths:
    with open(p, encoding='utf-8', errors='replace') as f:
        text += f.read() + '\n'
words = re.findall(r"[^\W\d_]+", text)
print(f'{len(paths)} files, {len(words)} word tokens, {sum(len(w) for w in words)} letters')
runs = lambda seq: [(s, len(list(g))) for s, g in itertools.groupby(seq)]
hist = collections.defaultdict(C); occ = C()
for w in words:
    for s, L in runs(w):
        hist[s][L] += 1; occ[s] += L
K = lambda h, sup=3: sum(1 for L, c in h.items() if c >= sup)
rank = sorted(hist, key=lambda s: (-K(hist[s]), -max(hist[s]), -occ[s]))
print('\n[1] characters by number of distinct run lengths (each seen >= 3 times):')
for s in rank[:12]:
    print(f'  {s!r:5s} occ {occ[s]:7d}  distinct lengths {K(hist[s])}  runs by length: ' + ' '.join(f'{L}:{hist[s][L]}' for L in sorted(hist[s])))
print('  how many characters have k distinct run lengths:', sorted(C(K(hist[s]) for s in hist).items()))
counters_all = [s for s in rank if K(hist[s]) >= 3]
counters = [s for s in counters_all if K(hist[s]) >= 4]
print('  >= 3 distinct run lengths:', counters_all, '| >= 4 (used as counters):', counters)

# numeral tokens: all-capital tokens of length >= 2 that contain a counter; inventory of letters
caps_tok = [w for w in words if len(w) >= 2 and w.isupper() and any(c in counters for c in w)]
inv = C(c for w in caps_tok for c in w)
allcap = C(c for w in words if len(w) >= 2 and w.isupper() for c in w)
print('\n[2] capital-letter tokens containing a counter:', len(caps_tok), '| letters in them:', inv.most_common(14))
# closed set: letters that occur in tokens made only of counters and one other letter
cand = C()
for w in caps_tok:
    others = set(w) - set(counters)
    if len(others) == 1: cand[next(iter(others))] += 1
print('  tokens = counters + exactly one other letter, that letter:', cand.most_common(10))
alphabet = set(counters) | {c for c, n in cand.most_common(3)}
print('  numeral alphabet used below:', sorted(alphabet))
num = [w for w in words if len(w) >= 2 and all(c in alphabet for c in w)]
print('  numeral tokens (length >= 2):', len(num), '| most frequent:', C(num).most_common(14))
h2 = collections.defaultdict(C)
pair = C()
for w in num:
    rs = runs(w)
    for s, L in rs: h2[s][L] += 1
    for (a, la), (b, lb) in zip(rs, rs[1:]): pair[(a, b)] += 1
print('  run lengths inside numeral tokens:')
for s in sorted(alphabet, key=lambda s: -sum(h2[s].values())):
    print(f'    {s}: ' + ' '.join(f'{L}:{h2[s][L]}' for L in sorted(h2[s])))
print('  adjacent runs A->B (count) and reverse:')
done = set()
edges = collections.defaultdict(set); indeg = C()
for (a, b), n in sorted(pair.items(), key=lambda kv: -kv[1]):
    if (b, a) in done or (a, b) in done: continue
    done.add((a, b)); m = pair[(b, a)]
    hi, lo = (a, b) if n >= m else (b, a)
    if n + m >= 3 and lo not in edges[hi]:
        edges[hi].add(lo); indeg[lo] += 1
    print(f'    {hi} before {lo}: {max(n, m):5d}   reverse: {min(n, m):5d}  = {min(n, m)/(n+m):.1%}')
# topological order of the majority directions (pairs with >= 3 cases)
nodes = [s for s in alphabet if s in edges or indeg[s]]
order = []; deg = {s: indeg[s] for s in nodes}; unique = True
while len(order) < len(nodes):
    free = [s for s in nodes if s not in order and deg[s] == 0]
    if not free: break
    if len(free) > 1: unique = False
    s = sorted(free)[0]; order.append(s)
    for t in edges[s]: deg[t] -= 1
print('  rank order (topological sort of majority directions):', ' > '.join(order), '| unique:', unique)
# values from caps: tight additive rule value(next) = (cap+1) * value
val = {}; v = 1
for s in reversed(order):
    val[s] = v
    cap = max(L for L, c in h2[s].items() if c >= 2) if any(c >= 2 for c in h2[s].values()) else 1
    v = v * (cap + 1)
print('  values from the cap rule (cap = longest run seen at least twice):', {s: val[s] for s in order})
TRUE = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
def parse(w, val):
    t = 0
    for i, c in enumerate(w):
        if i + 1 < len(w) and val[c] < val[w[i + 1]]: t -= val[c]
        else: t += val[c]
    return t
if all(c in TRUE for c in alphabet):
    same = sum(1 for w in num if parse(w, val) == parse(w, TRUE))
    print(f'  tokens whose value under the blind rule equals the standard reading: {same}/{len(num)} = {same/len(num):.1%}')
    sub = sum(1 for w in num if any(TRUE[a] < TRUE[b] for a, b in zip(w, w[1:])))
    print(f'  tokens with a lower sign before a higher one (subtractive): {sub}/{len(num)} = {sub/len(num):.1%}')
    add4 = C(w for w in num if re.search(r'IIII|XXXX|CCCC', w)); sub4 = C(w for w in num if re.search(r'IV|IX|XL|XC|CD|CM', w))
    print(f'  additive four-forms (IIII, XXXX, CCCC): {sum(add4.values())} tokens; subtractive forms (IV, IX, XL, XC ...): {sum(sub4.values())} tokens')
