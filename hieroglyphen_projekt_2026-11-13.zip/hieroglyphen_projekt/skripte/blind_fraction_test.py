"""Blind test of the fraction-value method on a known system (Egyptian), then the same scores on Linear A.
usage: python3 -I blind_fraction_test.py <aes_tokens_cache.json.gz>
Criteria fixed before looking at the outcome:
  hard: order from adjacency (larger first), sum of an attested compound < 1, values distinct, compound sum is not a sign value
  soft: S_simple = sum log2(denominator) (lower = simpler), S_coh = log2(lcm of denominators) (lower = more coherent),
        S_ratio = share of sign pairs with an integer ratio (higher = more regular), S_freq = rank correlation frequency ~ value
"""
import sys, gzip, json, re, math, itertools, random, collections
from fractions import Fraction as Fr
import numpy as np
C = collections.Counter
T = json.load(gzip.open(sys.argv[1], 'rt', encoding='utf-8'))
clean = lambda w: re.sub(r'[\[\]⸢⸣()\?{}〈〉<>\s⸮]', '', w or '')
SIX = ['1/2', '1/4', '1/8', '1/16', '1/32', '1/64']
freq = collections.defaultdict(C); comp = C(); pair = C()
for t in T.values():
    toks = t['tok']; p0 = 0
    for L in t['sl']:
        s = toks[p0:p0 + L]; p0 += L
        run = []
        for tk in s + [(None, None, None, None)]:
            w = clean(tk[3]) if tk[1] == '1...n' else None
            if w in SIX:
                run.append(w); freq[t['corpus']][w] += 1
            else:
                if len(run) >= 2:
                    comp[tuple(run)] += 1
                    for a, b in zip(run, run[1:]): pair[(a, b)] += 1
                run = []
print('[1] Egyptian test system: six notations', SIX)
print('  compounds (directly adjacent fraction tokens):', comp.most_common(14))
fw = rv = 0
for (a, b), n in pair.items():
    if a == b: continue
    if SIX.index(a) < SIX.index(b): fw += n
    else: rv += n
print(f'  adjacent pairs: larger before smaller {fw}, smaller before larger {rv}, same sign twice {sum(n for (a, b), n in pair.items() if a == b)}')
# blind order: majority direction, topological sort
edges = collections.defaultdict(set); indeg = C()
for a, b in itertools.combinations(SIX, 2):
    x, y = pair[(a, b)], pair[(b, a)]
    if x + y == 0: continue
    hi, lo = (a, b) if x >= y else (b, a)
    edges[hi].add(lo); indeg[lo] += 1
order = []; deg = {s: indeg[s] for s in SIX}; unique = True
while len(order) < 6:
    free = [s for s in SIX if s not in order and deg[s] == 0]
    if len(free) != 1: unique = False
    s = free[0]; order.append(s)
    for t2 in edges[s]: deg[t2] -= 1
print('  order recovered blind:', ' > '.join(order), '| unique:', unique, '| correct:', order == SIX)

def spearman(xs, ys):
    def rank(v):
        o = sorted(range(len(v)), key=lambda i: v[i]); r = [0] * len(v)
        for k, i in enumerate(o): r[i] = k
        return r
    rx, ry = rank(xs), rank(ys); n = len(xs)
    return 1 - 6 * sum((a - b) ** 2 for a, b in zip(rx, ry)) / (n * (n * n - 1))
print('\n[2] does frequency follow size? rank correlation between frequency and true value, by text group')
for c in ('bbawarchive', 'sawlit', 'bbawbriefe', 'sawmedizin'):
    f = [freq[c][x] for x in SIX]; n = sum(f)
    present = [(x, k) for x, k in zip(SIX, f) if k]
    if len(present) >= 3:
        print(f'  {c:14s} n={n:4d}  counts {dict(present)}  correlation {spearman([float(Fr(x)) for x, _ in present], [k for _, k in present]):+.2f}')
LA_f = {'J': 136, 'E': 76, 'F': 19, 'B': 41, 'D': 42, 'K': 34, 'H': 16, 'A': 18, 'L2': 30, 'L3': 2, 'L4': 4, 'L6': 2}
LA_v = {'J': Fr(1, 2), 'E': Fr(1, 4), 'F': Fr(1, 8), 'B': Fr(1, 5), 'D': Fr(1, 6), 'K': Fr(1, 10), 'H': Fr(1, 16), 'A': Fr(1, 24), 'L2': Fr(1, 20), 'L3': Fr(1, 30), 'L4': Fr(1, 40), 'L6': Fr(1, 60)}
print(f'  Linear A (published values, 12 signs): correlation {spearman([float(LA_v[k]) for k in LA_f], [LA_f[k] for k in LA_f]):+.2f}')

VALS = sorted(set([Fr(5, 6), Fr(3, 4), Fr(2, 3), Fr(1, 2), Fr(1, 3), Fr(1, 4), Fr(1, 5), Fr(1, 6), Fr(3, 20), Fr(1, 8)] + [Fr(1, d) for d in (7, 9, 10, 12, 15, 16, 20, 24, 30, 32, 36, 40, 48, 50, 60, 64, 70, 72, 80, 84, 90, 96, 108, 100, 120, 160, 200, 240, 300, 320)]), reverse=True)
nv = len(VALS); V = np.array([float(x) for x in VALS]); DEN = np.array([x.denominator for x in VALS], dtype=np.int64)
RATIO = np.array([[(VALS[i] / VALS[j]).denominator == 1 for j in range(nv)] for i in range(nv)])
print(f'\n[3] candidate values: {nv} (from 5/6 down to 1/320)')
truth = [VALS.index(Fr(x)) for x in SIX]

def evaluate(idx, compounds, label):
    vals = V[idx]; k = idx.shape[1]
    ok = np.ones(len(idx), dtype=bool)
    for cset in compounds:
        ssum = vals[:, list(cset)].sum(axis=1)
        ok &= ssum < 1 - 1e-12
        for j in range(k): ok &= np.abs(ssum - vals[:, j]) > 1e-12
    idx = idx[ok]; vals = vals[ok]
    den = DEN[idx]
    s_simple = np.log2(den).sum(axis=1)
    s_coh = np.log2(np.lcm.reduce(den, axis=1))
    s_ratio = np.zeros(len(idx)); npairs = 0
    for a, b in itertools.combinations(range(k), 2):
        s_ratio += RATIO[idx[:, a], idx[:, b]]; npairs += 1
    s_ratio /= npairs
    return idx, {'simple (lower better)': (s_simple, -1), 'coherent (lower better)': (s_coh, -1), 'integer ratios (higher better)': (s_ratio, +1), 'simple + coherent (lower better)': (s_simple + s_coh, -1)}

def report(idx, scores, tidx, label):
    row = np.where((idx == np.array(tidx)).all(axis=1))[0]
    print(f'  {label}: {len(idx):,} assignments pass the hard rules; the true one is among them: {len(row) == 1}')
    if len(row) != 1: return
    r = row[0]
    for name, (sc, sign) in scores.items():
        better = int((sc * sign > sc[r] * sign + 1e-9).sum()); tie = int((np.abs(sc - sc[r]) <= 1e-9).sum())
        best = idx[np.argmax(sc * sign)]
        print(f'     {name:34s} true assignment: {better:,} better, {tie:,} tied -> top {100 * (better + 1) / len(idx):.3f} %   best under this score: {[str(VALS[i]) for i in best]}')

pos = {x: i for i, x in enumerate(SIX)}
compounds = [tuple(sorted(pos[x] for x in set(c))) for c in comp if len(set(c)) == len(c)]
compounds = sorted(set(compounds))
print('  attested compounds used for the sum rules:', [[SIX[i] for i in c] for c in compounds])
allidx = np.array(list(itertools.combinations(range(nv), 6)), dtype=np.int64)
idx, sc = evaluate(allidx, compounds, 'free')
report(idx, sc, truth, 'all six values unknown')
pre = [i for i in range(nv) if VALS[i] < Fr(1, 8)]
sub = np.array([[truth[0], truth[1], truth[2]] + list(c) for c in itertools.combinations(pre, 3)], dtype=np.int64)
idx2, sc2 = evaluate(sub, compounds, 'premise')
report(idx2, sc2, truth, 'first three given as premise (like J, E, F), last three unknown')

print('\n[4] Linear A: where does the published solution stand under the same scores? (random sample of assignments passing the hard rules)')
P36 = [Fr(5, 6), Fr(2, 3), Fr(1, 3), Fr(1, 5), Fr(1, 6), Fr(3, 20)] + [Fr(1, d) for d in (7, 9, 10, 12, 15, 16, 20, 24, 30, 32, 36, 40, 48, 50, 60, 64, 70, 72, 80, 84, 90, 96, 108, 100, 120, 160, 200, 240, 300, 320)]
pv = np.array([float(x) for x in P36]); pd = np.array([x.denominator for x in P36], dtype=np.int64)
rng = np.random.default_rng(0); M = 6_000_000
b, d, k, h, a = (rng.integers(0, 36, M) for _ in range(5)); n = rng.integers(2, 54, M)
def la_pass(b, d, k, h, a, n):
    B, Dv, K, H, A = pv[b], pv[d], pv[k], pv[h], pv[a]
    L2, L3, L4, L6 = 1 / (2 * n), 1 / (3 * n), 1 / (4 * n), 1 / (6 * n)
    J, E, F = 0.5, 0.25, 0.125; tol = 1e-12
    allv = np.stack([np.full_like(B, J), np.full_like(B, E), np.full_like(B, F), B, Dv, K, H, A, L2, L3, L4, L6], axis=1)
    srt = np.sort(allv, axis=1); ok = (np.diff(srt, axis=1) > tol).all(axis=1)
    ok &= (K < F - tol) & (L2 < K - tol) & (A < J - tol) & (H < J - tol) & (B < E - tol)
    ok &= (4 * Dv < 1 - tol) & (0.75 + B < 1 - tol) & (A + 2 * B < 1 - tol)
    for c in (2 * Dv, 4 * Dv, 2 * B, J + B, 0.75 + B, E + B, A + 2 * B, J + A, J + H, K + L2, J + K, E + L2, F + K, E + L4, E + L6, J + L2):
        ok &= (np.abs(allv - c[:, None]) > tol).all(axis=1)
    den = np.stack([np.full_like(b, 2), np.full_like(b, 4), np.full_like(b, 8), pd[b], pd[d], pd[k], pd[h], pd[a], 2 * n, 3 * n, 4 * n, 6 * n], axis=1)
    return ok, allv, den
ok, allv, den = la_pass(b, d, k, h, a, n)
allv, den = allv[ok], den[ok]
def la_scores(allv, den):
    s_simple = np.log2(den).sum(axis=1); s_coh = np.log2(np.lcm.reduce(den, axis=1))
    r = np.zeros(len(den)); npairs = 0
    for i, j in itertools.combinations(range(12), 2):
        hi = np.maximum(den[:, i], den[:, j]); lo = np.minimum(den[:, i], den[:, j])
        r += (hi % lo == 0); npairs += 1
    return {'simple (lower better)': (s_simple, -1), 'coherent (lower better)': (s_coh, -1), 'integer ratios (higher better)': (r / npairs, +1), 'simple + coherent (lower better)': (s_simple + s_coh, -1)}
S = la_scores(allv, den)
pb = [P36.index(Fr(1, 5)), P36.index(Fr(1, 6)), P36.index(Fr(1, 10)), P36.index(Fr(1, 16)), P36.index(Fr(1, 24))]
okp, pvv, pdd = la_pass(*[np.array([x]) for x in pb], np.array([10]))
SP = la_scores(pvv, pdd)
print(f'  sample: {len(den):,} assignments passing the hard rules (acceptance {len(den)/M:.1%}); published solution passes: {bool(okp[0])}')
for name in S:
    sc, sign = S[name]; p = SP[name][0][0]
    better = int((sc * sign > p * sign + 1e-9).sum())
    print(f'     {name:34s} published solution {p:7.2f}; sample median {np.median(sc):7.2f}; share of sample that scores better: {100 * better / len(sc):.4f} %')
