"""Wider search over readings of G_Optimal for the value 0.67094 reported in the paper (reverse engineering of the definition).
usage: python3 -I corazza_measures_probe2.py"""
import itertools, math, collections
from fractions import Fraction as Fr
C = collections.Counter
def reps(vals, kmax, maxmult, below1):
    r = C(); n = len(vals)
    for k in range(1, kmax + 1):
        for c in itertools.combinations_with_replacement(range(n), k):
            if max(C(c).values()) > maxmult: continue
            s = sum(vals[i] for i in c)
            if below1 and s >= 1: continue
            r[s] += 1
    return r
def variants(vals):
    out = {}
    for kmax in (2, 3, 4, 5):
        for maxmult in (1, 2, 3, 4):
            if maxmult > kmax: continue
            for below1 in (True, False):
                r = reps(vals, kmax, maxmult, below1)
                dsets = {'signs': sorted({v.denominator for v in vals}), 'all': list(range(2, max(v.denominator for v in vals) + 1)),
                         'sums': sorted({s.denominator for s in r if s < 1} | {v.denominator for v in vals})}
                for dn, D in dsets.items():
                    for reduced in (False, True):
                        inc = []; amb1 = []; amb2 = []; tot_un = tot_am = tot_sl = tot_rep = 0
                        for d in D:
                            ks = [k for k in range(1, d) if (not reduced or math.gcd(k, d) == 1)]
                            if not ks: continue
                            un = sum(1 for k in ks if Fr(k, d) not in r); am = sum(1 for k in ks if r.get(Fr(k, d), 0) > 1)
                            inc.append(un / len(ks)); amb1.append(am / len(ks)); amb2.append(am / (len(ks) - un) if len(ks) > un else 0.0)
                            tot_un += un; tot_am += am; tot_sl += len(ks); tot_rep += len(ks) - un
                        m = lambda x: sum(x) / len(x)
                        key = (kmax, maxmult, below1, dn, reduced)
                        out[key + ('mean inc + mean amb/slots',)] = m(inc) + m(amb1)
                        out[key + ('mean inc + mean amb/represented',)] = m(inc) + m(amb2)
                        out[key + ('mean inc only',)] = m(inc)
                        out[key + ('mean amb/slots only',)] = m(amb1)
                        out[key + ('mean amb/represented only',)] = m(amb2)
                        out[key + ('pooled inc + pooled amb/slots',)] = tot_un / tot_sl + tot_am / tot_sl
                        out[key + ('pooled inc + pooled amb/represented',)] = tot_un / tot_sl + (tot_am / tot_rep if tot_rep else 0)
                        out[key + ('half sum of means',)] = (m(inc) + m(amb1)) / 2
    return out
core = [Fr(1, 2), Fr(1, 4), Fr(1, 8), Fr(1, 5), Fr(1, 6), Fr(1, 10), Fr(1, 20), Fr(1, 30), Fr(1, 40), Fr(1, 60)]
cands = {'H,A = 1/32, 1/36': core + [Fr(1, 32), Fr(1, 36)], 'core only (10 signs)': core, 'H,A = 1/16, 1/24': core + [Fr(1, 16), Fr(1, 24)]}
res = {name: variants(v) for name, v in cands.items()}
print('readings within 0.002 of 0.67094 for the solution with H,A = 1/32, 1/36:')
hits = sorted(((abs(g - 0.67094), k, g) for k, g in res['H,A = 1/32, 1/36'].items()), key=lambda x: x[0])
for dist, k, g in hits[:12]:
    print(f'   {g:.5f}  (off by {dist:.5f})  kmax={k[0]} maxmult={k[1]} below1={k[2]} denominators={k[3]} reduced={k[4]} {k[5]} | final solution under the same reading: {res["H,A = 1/16, 1/24"][k]:.5f}')
print('number of readings tried:', len(res['H,A = 1/32, 1/36']))
