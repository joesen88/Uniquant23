"""Egyptian corpus: number values (from written_form), contexts of spelled-out number words.
usage: python3 -I numvalues.py <aes_tokens_cache.json.gz> <aes_deutung_token.jsonl.gz>
"""
import sys, gzip, json, re, collections, math
from fractions import Fraction

tok_p, deut_p = sys.argv[1], sys.argv[2]
C = collections.Counter
with gzip.open(tok_p, 'rt', encoding='utf-8') as f:
    T = json.load(f)

gl = collections.defaultdict(C)
with gzip.open(deut_p, 'rt', encoding='utf-8') as f:
    for line in f:
        r = json.loads(line)
        lid = r.get('lemmaID')
        if lid:
            gl[lid][(r.get('cotext_translation') or '').strip()] += 1


def gloss(lid, k=1):
    c = gl.get(lid)
    return ' / '.join(x[0][:24] for x in c.most_common(k)) if c else ''


def clean(w):
    return re.sub(r'[\[\]⸢⸣()\?{}〈〉<>\s]', '', w or '')


N = 0
byc = C(); numc = C(); rawforms = C(); ints = C(); fracs = C(); other = C()
ints_c = collections.defaultdict(C)
spelled = collections.defaultdict(lambda: {'n': 0, 'corp': C(), 'prev': C(), 'next': C(), 'lf': ''})
DIGIT_LEMMA = re.compile(r'\d')
sel = C(); sel_gl = collections.defaultdict(C)
SEL = ('psw', 'sqd', 'sṯꜣ.t', 'ḫt-n-nwḥ', 'jtr.w', 'ḥsb', 'rmn', 'tꜣ', 'ḫꜣ-tꜣ', 'wꜥ', 'tp-rʾ', 'wꜣḥ-tp', 'nb.t', 'ꜥqꜣ', 'mtr', 'tnw', 'ṯnw', 'rḫ.t', 'wp.t', 'dmḏ.yt')
for tid, t in T.items():
    corp = t['corpus']
    toks = t['tok']; pos0 = 0
    sents = []
    for L in t['sl']:
        sents.append(toks[pos0:pos0 + L]); pos0 += L
    if pos0 < len(toks):
        sents.append(toks[pos0:])
    for s in sents:
        for i, tk in enumerate(s):
            lid, lf, pos, w = tk[0], tk[1], tk[2], tk[3]
            N += 1; byc[corp] += 1
            if lf in SEL:
                sel[(lf, lid)] += 1
            if pos != 'numeral':
                continue
            numc[corp] += 1
            if lf and DIGIT_LEMMA.search(lf):
                cw = clean(w)
                rawforms[w] += 1
                if lf == '1...n':
                    if re.fullmatch(r'\d+', cw):
                        ints[int(cw)] += 1; ints_c[corp][int(cw)] += 1
                    elif re.fullmatch(r'\d+/\d+', cw):
                        a, b = cw.split('/')
                        if int(b):
                            fracs[Fraction(int(a), int(b))] += 1
                    else:
                        other[cw] += 1
            else:
                d = spelled[lid]
                d['n'] += 1; d['lf'] = lf; d['corp'][corp] += 1
                if i > 0: d['prev'][(s[i - 1][0], s[i - 1][1])] += 1
                if i + 1 < len(s): d['next'][(s[i + 1][0], s[i + 1][1])] += 1

print(f'tokens {N} | numeral tokens {sum(numc.values())} = {sum(numc.values())/N:.2%}')
print('numeral share by corpus:')
for c, n in byc.most_common():
    print(f'  {c:22s} {n:8d} tokens  numerals {numc[c]:6d} = {numc[c]/n:.2%}')

print('\nwritten forms of digit lemmas: distinct', len(rawforms), '| top:', rawforms.most_common(40))
NI = sum(ints.values()); NF = sum(fracs.values()); NO = sum(other.values())
print(f'\n1...n parsed: integers {NI} ({len(ints)} values), fractions {NF}, unparsed {NO}')
print('unparsed top:', other.most_common(40))
print('integer counts 0..40:', [(v, ints[v]) for v in range(0, 41)])
print('round numbers:', [(v, ints[v]) for v in (50, 60, 70, 80, 90, 100, 110, 120, 150, 200, 300, 360, 365, 400, 500, 600, 700, 800, 900, 1000, 2000, 3000, 5000, 10000, 100000, 1000000)])
print('largest:', sorted(ints.items(), reverse=True)[:12])
# power law over 1..9 and 2..9
def slope(pairs):
    xs = [math.log(a) for a, b in pairs if b > 0]; ys = [math.log(b) for a, b in pairs if b > 0]
    n = len(xs); mx = sum(xs) / n; my = sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs); sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    b = sxy / sxx; r2 = (sxy ** 2) / (sxx * sum((y - my) ** 2 for y in ys))
    return b, r2
for lo, hi in ((1, 9), (2, 9), (1, 19)):
    b, r2 = slope([(v, ints[v]) for v in range(lo, hi + 1)])
    print(f'  log-log slope of frequency vs value {lo}..{hi}: {b:.2f} (R2 {r2:.2f})')
def bump(v):
    lo, hi = ints[v - 1], ints[v + 1]
    g = math.sqrt(lo * hi) if lo and hi else float('nan')
    return ints[v], lo, hi, (ints[v] / g if g == g and g else float('nan'))
for v in (4, 7, 10, 12, 20, 30, 40, 50, 100):
    print(f'  roundness {v}: count {bump(v)[0]}, neighbours {bump(v)[1]}/{bump(v)[2]}, ratio to geometric mean of neighbours {bump(v)[3]:.2f}')
fd = C()
for v, c in ints.items():
    if v > 0: fd[int(str(v)[0])] += c
tot = sum(fd.values())
print('first digit shares 1..9:', ' '.join(f'{fd[d]/tot:.1%}' for d in range(1, 10)), '| Benford:', ' '.join(f'{math.log10(1+1/d):.1%}' for d in range(1, 10)))
# first digit without 1..9 single-digit values
fd2 = C()
for v, c in ints.items():
    if v >= 10: fd2[int(str(v)[0])] += c
tot2 = sum(fd2.values())
print(f'first digit, values >= 10 only (n={tot2}):', ' '.join(f'{fd2[d]/tot2:.1%}' for d in range(1, 10)))
print('fractions:', [(str(k), v) for k, v in sorted(fracs.items(), key=lambda kv: -kv[1])[:30]])
un = sum(c for k, c in fracs.items() if k.numerator == 1); dy = sum(c for k, c in fracs.items() if k.numerator == 1 and (k.denominator & (k.denominator - 1)) == 0)
if NF: print(f'  unit fractions {un}/{NF} = {un/NF:.1%}; dyadic unit fractions {dy}/{NF} = {dy/NF:.1%}; 2/3: {fracs.get(Fraction(2,3),0)}; other non-unit: {[(str(k), v) for k, v in fracs.items() if k.numerator != 1 and k != Fraction(2,3)]}')
print('\nvalues by corpus (top 14 values each, n):')
for c, cc in sorted(ints_c.items(), key=lambda kv: -sum(kv[1].values()))[:9]:
    n = sum(cc.values())
    print(f'  {c:22s} n={n:6d}  ' + ' '.join(f'{v}:{k/n:.0%}' for v, k in cc.most_common(14)))

print('\nspelled-out number words (pos numeral, lemma without digits):')
for lid, d in sorted(spelled.items(), key=lambda kv: -kv[1]['n']):
    print(f"  {d['lf']:10s} [{lid}] n={d['n']:4d}  gloss: {gloss(lid, 2)}")
    print('      corpora:', ', '.join(f'{c} {n}' for c, n in d['corp'].most_common(5)))
    print('      before :', ' ; '.join(f'{lf} ({gloss(l)}) {n}' for (l, lf), n in d['prev'].most_common(5)))
    print('      after  :', ' ; '.join(f'{lf} ({gloss(l)}) {n}' for (l, lf), n in d['next'].most_common(5)))

print('\nselected lemma forms:')
for (lf, lid), n in sorted(sel.items(), key=lambda kv: (kv[0][0], -kv[1])):
    print(f'  {lf:10s} [{lid}] {n:6d}  {gloss(lid, 3)}')
