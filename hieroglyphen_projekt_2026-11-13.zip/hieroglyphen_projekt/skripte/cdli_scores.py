"""Scores for the cuneiform fraction signs under the rules of the Egyptian test, plus phrase-level check for the integers.
usage: python3 -I cdli_scores.py <cdli_ur3.jsonl.gz>"""
import sys, gzip, json, re, collections, itertools, math
from fractions import Fraction as Fr
import numpy as np
C = collections.Counter
EL = re.compile(r'^(\d+)(?:/(\d+))?\(([^()]+)\)(.*)$'); GL = re.compile(r'^(?:\{[^{}]*\})+')
D = ['1/3(disz)', '1/2(disz)', '2/3(disz)', '5/6(disz)']; TRUE = [Fr(1, 3), Fr(1, 2), Fr(2, 3), Fr(5, 6)]
texts = [json.loads(l) for l in gzip.open(sys.argv[1], 'rt', encoding='utf-8')]
pair = C(); fr = C(); phrases = []
for t in texts:
    for o in t['o']:
        for cl, body in o:
            if not cl: continue
            cur = []
            for tok in body.split() + ['|']:
                m = EL.match(tok)
                if m:
                    cnt, den, name, suf = m.groups(); suf = GL.sub('', suf)
                    cur.append((1, f'{cnt}/{den}({name})', True) if den else (int(cnt), name, False))
                    if not suf: continue
                if cur:
                    phrases.append(cur)
                    for e in cur:
                        if e[2]: fr[e[1]] += 1
                    for a, b in zip(cur, cur[1:]):
                        if a[2] and b[2]: pair[(a[1], b[1])] += 1
                cur = []
VALS = sorted(set([Fr(5, 6), Fr(3, 4), Fr(2, 3), Fr(1, 2), Fr(1, 3), Fr(1, 4), Fr(1, 5), Fr(1, 6), Fr(3, 20), Fr(1, 8)] + [Fr(1, d) for d in (7, 9, 10, 12, 15, 16, 20, 24, 30, 32, 36, 40, 48, 50, 60, 64, 70, 72, 80, 84, 90, 96, 108, 100, 120, 160, 200, 240, 300, 320)]), reverse=True)
nv = len(VALS); V = np.array([float(x) for x in VALS]); DEN = np.array([x.denominator for x in VALS], dtype=np.int64)
RATIO = np.array([[(VALS[i] / VALS[j]).denominator == 1 or (VALS[j] / VALS[i]).denominator == 1 for j in range(nv)] for i in range(nv)])
def scores(idx):
    den = DEN[idx]; k = idx.shape[1]
    simple = np.log2(den).sum(axis=1); coh = np.log2(np.lcm.reduce(den, axis=1))
    r = np.zeros(len(idx)); npairs = 0
    for a, b in itertools.combinations(range(k), 2): r += RATIO[idx[:, a], idx[:, b]]; npairs += 1
    return {'simple (small denominators)': (simple, -1), 'coherent (small common denominator)': (coh, -1), 'integer ratios': (r / npairs, +1), 'simple + coherent': (simple + coh, -1)}
def report(idx, tidx, label, names):
    sc = scores(idx)
    row = np.where((idx == np.array(tidx)).all(axis=1))[0]
    print(f'  {label}: {len(idx):,} candidates pass the hard rules; the true one among them: {len(row) == 1}')
    for name, (s, sign) in sc.items():
        best = idx[np.argmax(s * sign)]
        line = f'     {name:36s} best: {[str(VALS[i]) for i in best]}'
        if len(row) == 1:
            r = row[0]; better = int((s * sign > s[r] * sign + 1e-9).sum()); tie = int((np.abs(s - s[r]) <= 1e-9).sum())
            line += f' | true: {better:,} better, {tie:,} tied -> top {100 * (better + 1) / len(idx):.3f} % (worst case within ties: {100 * (better + tie) / len(idx):.3f} %)'
        print(line)
print('[B1] adjacent pairs among the four signs:', {k: v for k, v in pair.items() if k[0] in D and k[1] in D}, '| tokens:', {s: fr[s] for s in D})
tidx = [VALS.index(v) for v in TRUE]
# (i) rules exactly as in the Egyptian test: every attested adjacency of two different signs is a compound, majority gives the order
perm = np.array(list(itertools.permutations(range(nv), 4)), dtype=np.int64); pv = V[perm]
ok = np.ones(len(perm), dtype=bool); comp = set(); order = []
for a, b in itertools.combinations(range(4), 2):
    x, y = pair[(D[a], D[b])], pair[(D[b], D[a])]
    if x + y == 0: continue
    comp.add((a, b))
    if x != y:
        hi, lo = (a, b) if x > y else (b, a); order.append((D[hi], D[lo], max(x, y), min(x, y)))
        ok &= pv[:, hi] > pv[:, lo] + 1e-12
for a, b in comp:
    s = pv[:, a] + pv[:, b]; ok &= s < 1 - 1e-12
    for j in range(4): ok &= np.abs(s - pv[:, j]) > 1e-12
print('\n[B2-literal] rules exactly as in the Egyptian test (every attested adjacency counts):')
print('   order relations:', order, '| compounds:', [(D[a], D[b]) for a, b in sorted(comp)])
print('   true values violate:', [(D[a], D[b], str(TRUE[a] + TRUE[b])) for a, b in sorted(comp) if TRUE[a] + TRUE[b] >= 1 or TRUE[a] + TRUE[b] in TRUE])
report(perm[ok], tidx, 'assignments (ordered)', D)
# (ii) with the scale-free support rule no adjacency qualifies -> no order, no compounds -> value sets
sets = np.array(list(itertools.combinations(range(nv), 4)), dtype=np.int64)
print('\n[B2/B3-R2] with the support rule (pair >= 3 and >= 1/1000 of the rarer sign): no compounds, no order; value sets:')
report(sets, sorted(tidx), 'value sets', D)
coh = scores(sets)['coherent (small common denominator)'][0]
print('     sets with the smallest common denominator:', [[str(VALS[i]) for i in s] for s in sets[np.abs(coh - coh.min()) < 1e-9]])
def spearman(xs, ys):
    def rank(v):
        o = sorted(range(len(v)), key=lambda i: v[i]); r = [0] * len(v)
        for k, i in enumerate(o): r[i] = k
        return r
    rx, ry = rank(xs), rank(ys); n = len(xs)
    return 1 - 6 * sum((a - b) ** 2 for a, b in zip(rx, ry)) / (n * (n * n - 1))
print(f'     frequency ~ value (rank correlation, all texts): {spearman([float(v) for v in TRUE], [fr[s] for s in D]):+.2f}   frequencies {[fr[s] for s in D]}')
# (iii) the area fractions: a second, additive system inside the same corpus
I = ['1/2(iku)', '1/4(iku)']; print('\n[iku] adjacent pairs:', {k: v for k, v in pair.items() if k[0] in I or k[1] in I})
p2 = np.array(list(itertools.permutations(range(nv), 2)), dtype=np.int64); v2 = V[p2]
ok2 = (v2[:, 0] > v2[:, 1]) & (v2.sum(axis=1) < 1 - 1e-12)
report(p2[ok2], [VALS.index(Fr(1, 2)), VALS.index(Fr(1, 4))], 'area fractions, ordered pairs', I)

# ---------- integers: phrase-level agreement of a single blind chain with the textbook reading ----------
CHAIN = {'disz': 1, 'ban2': 10, 'barig': 60, 'asz': 300, 'u': 3000, 'gesz2': 18000, "gesz'u": 180000, 'szar2': 1080000, "szar'u": 10800000}
SV = {'disz': 1, 'u': 10, 'gesz2': 60, "gesz'u": 600, 'szar2': 3600, "szar'u": 36000}
tot = agree = 0; kinds = C(); viol = 0
RANK = ["szar'u", 'szar2', "gesz'u", 'gesz2', 'u', 'asz', 'barig', 'ban2', 'disz']
for ph in phrases:
    if any(e[2] for e in ph) or any(e[1] not in CHAIN for e in ph): continue
    signs = [e[1] for e in ph]
    cap = any(s in ('asz', 'barig', 'ban2') for s in signs)
    if cap:
        # textbook capacity reading: everything from asz upwards counts gur (300 sila3), barig 60, ban2 10, disz 1
        tb = sum(c * (300 * (SV[s] if s in SV and s != 'disz' else 1) if s in ('asz', 'u', 'gesz2', "gesz'u", 'szar2', "szar'u") else {'barig': 60, 'ban2': 10, 'disz': 1}[s]) for c, s, _ in ph)
    else:
        tb = sum(c * SV[s] for c, s, _ in ph)
    bl = sum(c * CHAIN[s] for c, s, _ in ph)
    tot += 1; agree += (tb == bl); kinds[('capacity' if cap else ('counting, units only' if set(signs) == {'disz'} else 'counting, with tens or sixties'), tb == bl)] += 1
    if any(RANK.index(a) > RANK.index(b) for a, b in zip(signs, signs[1:])): viol += 1
print(f'\n[A3] integer phrases written with the nine signs of the chain: {tot:,}; lower sign before higher: {viol:,} = {viol/tot:.2%}')
print(f'     one value per sign along the blind chain reproduces the textbook value in {agree:,} = {agree/tot:.1%}')
for k, n in sorted(kinds.items()): print(f'       {k[0]:32s} agrees={k[1]!s:5s} {n:,}')
