import sys, os, re, json, glob, gzip, collections, math, lzma, bz2, random, unicodedata, array
import numpy as np
bdir, aes_dir = sys.argv[1:3]; random.seed(20261112)
SEG = re.compile(r'''<seg id=['"]([^'"]+)['"][^>]*>(.*?)</seg>''', re.S)
def norm(text, strip_marks):
    t = text.lower()
    if strip_marks: t = ''.join(c for c in unicodedata.normalize('NFD', t) if unicodedata.category(c) != 'Mn')
    else: t = unicodedata.normalize('NFC', t)
    t = t.replace('ـ', '')
    return [w for w in re.split(r'[^\w]+', ''.join(c if unicodedata.category(c)[0] == 'L' else ' ' for c in t)) if w]
LANG = {'Deutsch': ('German', False), 'Englisch': ('English', False), 'Latein': ('Latin', False), 'Griechisch': ('Greek', True), 'Hebraeisch': ('Hebrew', True), 'Arabisch': ('Arabic', True), 'Koptisch': ('Coptic-NT', True)}
V = {}
for nm_, (f, sm) in LANG.items():
    V[nm_] = {i: norm(x, sm) for i, x in SEG.findall(open(os.path.join(bdir, f + '.xml'), encoding='utf-8').read())}
common = sorted(set.intersection(*[set(i for i, w in v.items() if w) for v in V.values()])); print('verses common to all seven languages (New Testament):', len(common))
def comp_bits(seqs, wide=False):
    ids = {}; 
    if wide:
        a = array.array('H', (ids.setdefault(s, len(ids) + 1) for q in seqs for s in list(q) + ['\n'])); raw = a.tobytes()
    else: raw = bytes(ids.setdefault(s, len(ids) + 1) for q in seqs for s in list(q) + ['\n'])
    return 8*min(len(lzma.compress(raw, preset=9 | lzma.PRESET_EXTREME)), len(bz2.compress(raw, 9)))
S = {}
print('\nlanguage | letters in use (>=0.01%) | letters per word | words per verse | letters per verse | bits per letter (single-letter entropy) | bits per word (product) | compressed: bits per letter | bits per verse')
for nm_, v in V.items():
    vs = [v[i] for i in common]; ch = collections.Counter(c for w in (x for q in vs for x in q) for c in w); NL = sum(ch.values()); NWd = sum(len(q) for q in vs)
    H = -sum(n/NL*math.log2(n/NL) for n in ch.values()); inv = sum(1 for n in ch.values() if n/NL >= 1e-4); cb = comp_bits([' '.join(q) for q in vs])
    S[nm_] = np.array([sum(-math.log2(ch[c]/NL) for w in q for c in w) for q in vs])
    print(f"  {nm_:11s} {inv:3d} | {NL/NWd:5.2f} | {NWd/len(vs):5.1f} | {NL/len(vs):6.1f} | {H:4.2f} | {H*NL/NWd:5.1f} | {cb/NL:4.2f} | {cb/len(vs):6.1f}")
    if nm_ == 'Koptisch':
        dem = {c: n for c, n in ch.items() if 0x03E2 <= ord(c) <= 0x03EF}; print(f"      Coptic letters not taken from Greek: {len(dem)} ({' '.join(sorted(dem))}) = {sum(dem.values())/NL:.1%} of all letters; Greek-derived letters in use: {sum(1 for c, n in ch.items() if 0x2C80 <= ord(c) <= 0x2CFF and n/NL >= 1e-4)}")
names = list(S); C = np.corrcoef([S[n] for n in names]); print('\ncorrelation of the per-verse information sums between languages: min', round(float(C[np.triu_indices(7, 1)].min()), 3), 'max', round(float(C[np.triu_indices(7, 1)].max()), 3))
def retrieval(a, b, n=2000):
    x, y = S[a], S[b]; k = np.polyfit(y, x, 1); pred = np.polyval(k, y); idx = random.sample(range(len(x)), n); ranks = []
    for i in idx: d = np.abs(pred - x[i]); ranks.append(int((d < d[i]).sum()) + 1)
    return np.mean(np.array(ranks) == 1), float(np.median(ranks))
for a, b in (('Englisch', 'Deutsch'), ('Latein', 'Hebraeisch'), ('Arabisch', 'Deutsch')):
    t1, med = retrieval(a, b); print(f'  find the same verse in {b} from its information sum in {a}: correct in {t1:.2%} of cases (chance {1/len(common):.3%}), median rank {med:.0f} of {len(common)}')
# anchors: words with (almost) the same verse sets, Latin vs Hebrew, whole Bible
def anchors(A, B, lo=3, hi=120):
    ids = sorted(set(i for i, w in V[A].items() if w) & set(i for i, w in V[B].items() if w)); inv = collections.defaultdict(set); invB = collections.defaultdict(set)
    for i in ids:
        for w in set(V[A][i]): inv[w].add(i)
        for w in set(V[B][i]): invB[w].add(i)
    out = []
    for w, vs in inv.items():
        if not lo <= len(vs) <= hi: continue
        c = collections.Counter(u for i in vs for u in set(V[B][i])); best = max(((n/len(vs | invB[u]), u) for u, n in c.most_common(8)), default=(0, ''))
        if best[0] >= 0.8: out.append((best[0], w, best[1], len(vs)))
    return out, len(ids), sum(1 for w, vs in inv.items() if lo <= len(vs) <= hi)
raw = open(os.path.join(bdir, 'Latin.xml'), encoding='utf-8').read(); capc = collections.Counter(); totc = collections.Counter()
for i, x in SEG.findall(raw):
    for m in re.finditer(r"[A-Za-z]+", x): totc[m.group(0).lower()] += 1; capc[m.group(0).lower()] += m.group(0)[0].isupper()
isname = lambda w: totc[w] > 0 and capc[w]/totc[w] >= 0.8
for B in ('Hebraeisch', 'Arabisch', 'Griechisch', 'Deutsch'):
    an, nv, cand = anchors('Latein', B); nn = sum(1 for a in an if isname(a[1]))
    print(f"\nanchors Latein->{B}: {len(an)} word pairs with near-identical verse sets (of {cand} Latin words occurring in 3-120 verses; {nv} verses) | names among them: {nn} = {nn/max(len(an),1):.0%} | names among all candidates: {sum(1 for w in [1] for _ in [0])*0 + np.mean([isname(w) for w, vs in [(a[1], 0) for a in an]] or [0]):.0%}")
    print('   ', ' '.join(f'{w}={u}' for _, w, u, n in sorted(an, key=lambda a: -a[3])[:14]))
    if B == 'Hebraeisch': AN = an
    if B == 'Deutsch': print('    non-name anchors:', ' '.join(f'{w}={u}' for _, w, u, n in sorted([a for a in an if not isname(a[1])], key=lambda a: -a[3])[:14]))
allcand = [w for w in totc if 3 <= totc[w] <= 120]; print('    share of names among all Latin words of that frequency range:', f'{np.mean([isname(w) for w in allcand]):.0%}')
# recover Hebrew letter values from name anchors (IBM Model 1 on characters, NULL generates extra Latin letters)
pairs = [(list(u) + ['#'], list(w)) for _, w, u, n in AN if isname(w)]; hs = sorted(set(h for p in pairs for h in p[0])); ls = sorted(set(l for p in pairs for l in p[1]))
t = {h: {l: 1/len(ls) for l in ls} for h in hs}
for it in range(30):
    cnt = {h: collections.Counter() for h in hs}
    for hw, lw in pairs:
        for l in lw:
            z = sum(t[h][l] for h in hw)
            for h in hw: cnt[h][l] += t[h][l]/z
    for h in hs:
        s = sum(cnt[h].values()) or 1; t[h] = {l: cnt[h][l]/s for l in ls}
GOLD = {'ב': 'bv', 'ג': 'g', 'ד': 'd', 'ה': 'hae', 'ו': 'uvo', 'ז': 'z', 'ח': 'ha', 'ט': 't', 'י': 'ije', 'כ': 'ck', 'ך': 'ck', 'ל': 'l', 'מ': 'm', 'ם': 'm', 'נ': 'n', 'ן': 'n', 'ס': 's', 'פ': 'pf', 'ף': 'pf', 'צ': 's', 'ץ': 's', 'ק': 'ck', 'ר': 'r', 'ש': 's', 'ת': 't', 'א': 'aeiou', 'ע': 'aeiou'}
res = [(h, max(t[h], key=t[h].get), t[h][max(t[h], key=t[h].get)]) for h in hs if h != '#']; ok = [h for h, l, p in res if h in GOLD and l in GOLD[h]]
print(f"\nHebrew letter values recovered from {len(pairs)} name pairs alone: {len(ok)} of {sum(1 for h, l, p in res if h in GOLD)} letters correct | " + ' '.join(f'{h}={l}' for h, l, p in res))
# Egyptian <-> German translation (AES)
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*'); base = lambda s: re.sub(r'(?<=\d)[A-Za-z]+$', '', s); E = []
for p in sorted(glob.glob(os.path.join(aes_dir, '_aes_*.json'))):
    d = json.load(open(p, encoding='utf-8'))
    for s in d.values():
        tk = [k for k in s.get('token', []) if k.get('_id') and (k.get('lemma_form') or '') != '[...]']; hs_ = [[base(x) for x in SIGN.findall(k['hiero'])] for k in tk if k.get('hiero')]
        tr = norm(re.sub(r'\[[^\]]*\]|\([^)]*\)', ' ', s.get('sentence_translation') or ''), False)
        if len(tk) >= 3 and len(hs_) >= 0.9*len(tk) and len(tr) >= 2: E.append((hs_, tr))
sg = collections.Counter(x for h, _ in E for w in h for x in w); NSg = sum(sg.values()); NWe = sum(len(h) for h, _ in E); He = -sum(n/NSg*math.log2(n/NSg) for n in sg.values())
ch = collections.Counter(c for _, tr in E for w in tr for c in w); NLg = sum(ch.values()); NWg = sum(len(tr) for _, tr in E); Hg = -sum(n/NLg*math.log2(n/NLg) for n in ch.values())
cbe = comp_bits([[x for w in h for x in w + ['_']] for h, _ in E], wide=True); cbg = comp_bits([' '.join(tr) for _, tr in E])
se = np.array([sum(-math.log2(sg[x]/NSg) for w in h for x in w) for h, _ in E]); sgm = np.array([sum(-math.log2(ch[c]/NLg) for w in tr for c in w) for _, tr in E])
print(f"\nEGYPTIAN vs its German translation, {len(E)} sentences with complete sign data:")
print(f"  Egyptian: signs in use (>=0.01%) {sum(1 for n in sg.values() if n/NSg >= 1e-4)} of {len(sg)} | signs per word {NSg/NWe:.2f} | words per sentence {NWe/len(E):.1f} | signs per sentence {NSg/len(E):.1f} | bits per sign {He:.2f} | bits per word (product) {He*NSg/NWe:.1f} | compressed: bits per sign {cbe/NSg:.2f} | bits per sentence {cbe/len(E):.1f}")
print(f"  German:   letters {sum(1 for n in ch.values() if n/NLg >= 1e-4)} | letters per word {NLg/NWg:.2f} | words per sentence {NWg/len(E):.1f} | letters per sentence {NLg/len(E):.1f} | bits per letter {Hg:.2f} | bits per word (product) {Hg*NLg/NWg:.1f} | compressed: bits per letter {cbg/NLg:.2f} | bits per sentence {cbg/len(E):.1f}")
print(f"  ratio Egyptian/German: signs per sentence vs letters {NSg/NLg:.2f} | compressed bits per sentence {cbe/cbg:.2f} | single-sign information sums {se.sum()/sgm.sum():.2f} | correlation of the per-sentence sums {np.corrcoef(se, sgm)[0,1]:.2f}")
