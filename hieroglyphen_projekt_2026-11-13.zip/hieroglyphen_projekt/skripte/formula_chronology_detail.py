"""Details for the formula chronology: what is added or replaced between New Kingdom and late versions of Book of the Dead spells,
which Pyramid Text passages return in the Book of the Dead, and which five-lemma formulas return in the Amarna texts.
usage: python3 -I formula_chronology_detail.py <aes_tokens_cache.json.gz>"""
import sys, gzip, json, collections, difflib, math, itertools
C = collections.Counter
T = json.load(gzip.open(sys.argv[1], 'rt', encoding='utf-8'))
uid = itertools.count(1); FORM = {}; POS = {}; unk = lambda x: x.startswith('?'); texts = {}
for tid, t in T.items():
    sents = []; p0 = 0; toks = t['tok']
    for L in t['sl'] + ([len(toks) - sum(t['sl'])] if sum(t['sl']) < len(toks) else []):
        s = []
        for tk in toks[p0:p0 + L]:
            if tk[0]:
                k = str(tk[0]); s.append(k); FORM.setdefault(k, tk[1]); POS.setdefault(k, tk[2])
            else: s.append('?%d' % next(uid))
        p0 += L
        if s: sents.append(s)
    texts[tid] = (t['corpus'], t['date'], sents)
ngr = lambda s, n: [tuple(s[i:i + n]) for i in range(len(s) - n + 1)]
ids = lambda f: [tid for tid, (c, d, s) in texts.items() if f(c, d)]
PT = ids(lambda c, d: c == 'bbawpyramidentexte'); NK = ids(lambda c, d: c == 'tb' and d == 'NK'); LATE = ids(lambda c, d: c == 'tb' and d == 'TIP - Roman times'); AM = ids(lambda c, d: c == 'bbawamarna')
flat = lambda tid: [x for s in texts[tid][2] for x in s]
grams = lambda tid: set(g for s in texts[tid][2] for g in ngr(s, 4) if not any(unk(x) for x in g))
f = lambda x: str(FORM.get(x, x))
def pairs(early, late):
    inv = collections.defaultdict(set)
    for tid in early:
        for g in grams(tid): inv[g].add(tid)
    out = []
    for tid in late:
        share = C()
        for g in grams(tid):
            for e in inv.get(g, ()): share[e] += 1
        if share and share.most_common(1)[0][1] >= 5: out.append((share.most_common(1)[0][0], tid))
    return out
def gaps(e, l):
    a, b = flat(e), flat(l)
    blocks = [m for m in difflib.SequenceMatcher(None, a, b, autojunk=False).get_matching_blocks() if m.size >= 3]
    for m1, m2 in zip(blocks, blocks[1:]):
        ga = a[m1.a + m1.size:m2.a]; gb = b[m1.b + m1.size:m2.b]
        if len(ga) > 15 or len(gb) > 15 or (not ga and not gb): continue
        if any(unk(x) for x in ga) or any(unk(x) for x in gb): continue
        yield ga, gb, a[max(0, m1.a + m1.size - 3):m1.a + m1.size], a[m2.a:m2.a + 3]
add = C(); drop = C(); sub = C(); addpos = C(); droppos = C(); lens = C(); ex_add = []
for e, l in pairs(NK, LATE):
    for ga, gb, left, right in gaps(e, l):
        add.update(gb); drop.update(ga)
        for x in gb: addpos[POS.get(x, '?')] += 1
        for x in ga: droppos[POS.get(x, '?')] += 1
        if len(ga) == 1 and len(gb) == 1: sub[(ga[0], gb[0])] += 1
        if not ga and len(ex_add) < 8: ex_add.append(' '.join(f(x) for x in left) + '  [+ ' + ' '.join(f(x) for x in gb) + ']  ' + ' '.join(f(x) for x in right))
net = C({k: add[k] - drop[k] for k in set(add) | set(drop)})
print('[Book of the Dead, New Kingdom -> late] words in the gaps: added', sum(add.values()), 'dropped', sum(drop.values()))
print('  largest net additions (lemma: added - dropped):', [(f(k), add[k], drop[k]) for k, v in net.most_common(14)])
print('  largest net omissions:', [(f(k), add[k], drop[k]) for k, v in sorted(net.items(), key=lambda kv: kv[1])[:10]])
tot_a, tot_d = sum(addpos.values()), sum(droppos.values())
print('  by word class (added / dropped):', [(p, addpos[p], droppos[p]) for p, _ in (addpos + droppos).most_common(9)])
print('  examples of pure additions (context [+ added] context):')
for x in ex_add: print('     ', x[:150])
print('  single-word replacements (earlier -> later, count; reverse count):')
seen = set()
for (a, b), n in sub.most_common(40):
    if (b, a) in seen: continue
    seen.add((a, b)); print(f'      {f(a):14s} -> {f(b):14s} {n:4d}   reverse {sub[(b, a)]:4d}')
    if len(seen) >= 14: break
# PT -> BD pairs: which passages
print('\n[Pyramid Texts -> Book of the Dead] text pairs with at least 5 shared sequences:')
for e, l in pairs(PT, NK) + pairs(PT, LATE):
    a, b = flat(e), flat(l)
    blocks = sorted((m for m in difflib.SequenceMatcher(None, a, b, autojunk=False).get_matching_blocks() if m.size >= 4), key=lambda m: -m.size)
    if blocks:
        m = blocks[0]; print(f'   {texts[l][1]:18s} shared blocks {len(blocks)}, longest {m.size} lemmas: ' + ' '.join(f(x) for x in a[m.a:m.a + min(m.size, 14)]))
# Amarna: which five-lemma formulas of the Pyramid Texts
cnt = C(g for tid in PT for s in texts[tid][2] for g in ngr(s, 5) if not any(unk(x) for x in g)); F5 = {g for g, c in cnt.items() if c >= 5}
am = C(g for tid in AM for s in texts[tid][2] for g in ngr(s, 5) if g in F5)
print('\n[Amarna] five-lemma formulas of the Pyramid Texts found there:', len(am), '->', [(' '.join(f(x) for x in g), cnt[g], n) for g, n in am.most_common(8)])
