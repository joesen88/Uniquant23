"""cdli_sums2.py with the unit ratio as a parameter; writes the equations to a pickle.\nusage: python3 -I cdli_sums_param.py <cdli_ur3.jsonl.gz> <ratio> <out.pkl>"""

import sys, gzip, json, re, collections, itertools
from fractions import Fraction as Fr
import numpy as np
C = collections.Counter
EL = re.compile(r'^(\d+)(?:/(\d+))?\(([^()]+)\)(.*)$'); GL = re.compile(r'^(?:\{[^{}]*\})+')
def parse_line(body):
    items = []; cur = None
    for t in body.split():
        m = EL.match(t)
        if m:
            cnt, den, name, suf = m.groups(); suf = GL.sub('', suf)
            el = (1, f'{cnt}/{den}({name})', True) if den else (int(cnt), name, False)
            if cur is None:
                cur = []; items.append(('P', cur))
            cur.append(el)
            if suf: items.append(('W', suf)); cur = None
        else:
            items.append(('W', t)); cur = None
    return items
SIGNS = ['1/3(disz)', '1/2(disz)', '2/3(disz)', '5/6(disz)']
TRUE = [Fr(1, 3), Fr(1, 2), Fr(2, 3), Fr(5, 6)]
S = {'disz': 1, 'asz': 1, 'u': 10, 'gesz2': 60, "gesz'u": 600, 'szar2': 3600}
RR = int(sys.argv[2])
WU = {'gu2': 60 * RR, 'ma-na': RR, 'gin2': 1}
TOT = re.compile(r'^szunigin2?$|^szu[-+]nigin2?$')
def add(ph, scale, vals, qf):
    """integer value of a phrase in units of `scale`; fraction signs go to qf. returns (value, bad)"""
    v = 0; bad = False
    for cnt, s, fr in ph:
        if fr:
            if s in SIGNS: qf[s] += scale
            else: bad = True
        elif s in vals: v += cnt * vals[s] * scale
        else: bad = True
    return v, bad
def quantities(it):
    out = []; i = 0; n = len(it)
    W = lambda k: it[k][1] if k < n and it[k][0] == 'W' else None
    P = lambda k: it[k][1] if k < n and it[k][0] == 'P' else None
    while i < n:
        ph = P(i)
        if ph is None: i += 1; continue
        qf = C(); qi = 0; bad = False; kind = None; j = i
        if W(i + 1) in ('gu2', 'ma-na'):
            kind = 'w'; last = None
            while P(j) is not None and W(j + 1) in WU:
                sc = WU[W(j + 1)]
                if last is not None and sc >= last: break
                v, b = add(P(j), sc, S, qf); qi += v; bad |= b; last = sc; j += 2
            if P(j) is not None and (W(j + 1) or '').split('-')[0] == 'sze': bad = True
        elif W(i + 1) == 'sila3' or any(s in ('barig', 'ban2') for _, s, _ in ph):
            kind = 'c'
            if any(s in ('asz', 'gesz2', "gesz'u", 'szar2') for _, s, _ in ph): bad = True
            hascap = any(s in ('barig', 'ban2') for _, s, _ in ph)
            v, b = add(ph, RR, {'barig': 60, 'ban2': 10, 'disz': 1, 'u': 10}, qf); qi += v; bad |= b
            if hascap and any(s == 'u' for _, s, _ in ph): bad = True
            j = i + 2 if W(i + 1) == 'sila3' else i + 1
            if P(j) is not None and W(j + 1) == 'gin2':
                v, b = add(P(j), 1, S, qf); qi += v; bad |= b; j += 2
        elif W(i + 1) == 'gin2':
            kind = 'g'; v, b = add(ph, 1, S, qf); qi += v; bad |= b; j = i + 2
            if P(j) is not None and (W(j + 1) or '').split('-')[0] == 'sze': bad = True
        else:
            i += 1; continue
        if i > 0 and W(i - 1) == 'la2': bad = True
        if W(j) is not None and (W(j).startswith('igi-') or W(j) == 'la2'): bad = True
        com = W(j)
        out.append({'v': qi, 'f': qf, 'bad': bad, 'kind': kind, 'com': com, 'tot': i > 0 and W(i - 1) is not None and bool(TOT.match(W(i - 1)))})
        i = max(j, i + 1)
    return out
eqs = []; stat = C()
with gzip.open(sys.argv[1], 'rt', encoding='utf-8') as f:
    for line in f:
        t = json.loads(line)
        for o in t['o']:
            if not all(cl for cl, _ in o): continue
            stat['objects with all lines clean'] += 1
            qs = [q for cl, body in o for q in quantities(parse_line(body))]
            if not any(q['tot'] for q in qs): continue
            stat['  with at least one total quantity'] += 1
            bycom = collections.defaultdict(list)
            for q in qs:
                if q['com']: bycom[q['com']].append(q)
            for com, L in bycom.items():
                tots = [k for k, q in enumerate(L) if q['tot']]
                if len(tots) != 1: continue
                k = tots[0]; items = L[:k]; T = L[k]
                if len(items) < 2: continue
                stat['commodity blocks: one total, >= 2 items before it'] += 1
                if T['bad'] or any(q['bad'] for q in items): stat['  dropped: la2 / igi-n-gal2 / sze / other signs'] += 1; continue
                c = C()
                for q in items: c.update(q['f'])
                c.subtract(T['f'])
                nsig = sum(len(q['f']) for q in items) + len(T['f'])
                eqs.append(([c[s] for s in SIGNS], T['v'] - sum(q['v'] for q in items), t['p'], nsig, com, T['kind'], t['prov']))

import pickle
pickle.dump([(e[0], e[1], e[2], e[3], e[4], e[5]) for e in eqs], open(sys.argv[3], 'wb'))
