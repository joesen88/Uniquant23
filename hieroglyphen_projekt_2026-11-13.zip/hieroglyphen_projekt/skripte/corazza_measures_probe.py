"""Which reading of G_Optimal reproduces the value the paper reports (0.67094 for the best solution, H/A = 1/32, 1/36)?
usage: python3 -I corazza_measures_probe.py"""
import itertools, math, collections
from fractions import Fraction as Fr
C = collections.Counter
def reps(vals, kmax=4, repeat=True, below1=True):
    r = C()
    for k in range(1, kmax + 1):
        it = itertools.combinations_with_replacement(range(len(vals)), k) if repeat else itertools.combinations(range(len(vals)), k)
        for c in it:
            s = sum(vals[i] for i in c)
            if below1 and s >= 1: continue
            r[s] += 1
    return r
def g_optimal(vals, dset='signs', repeat=True, kmax=4, reduced=False, amb_over='slots', combine='avg_each'):
    r = reps(vals, kmax, repeat)
    if dset == 'signs': D = sorted({v.denominator for v in vals})
    elif dset == 'all': D = list(range(2, max(v.denominator for v in vals) + 1))
    elif dset == 'sums': D = sorted({s.denominator for s in r} | {v.denominator for v in vals})
    inc = []; amb = []
    for d in D:
        ks = [k for k in range(1, d) if (not reduced or math.gcd(k, d) == 1)]
        if not ks: continue
        un = sum(1 for k in ks if Fr(k, d) not in r); am = sum(1 for k in ks if r.get(Fr(k, d), 0) > 1)
        inc.append(un / len(ks) if reduced else un / (d - 1))
        den_a = (len(ks) - un) if amb_over == 'represented' else (len(ks) if reduced else d - 1)
        amb.append(am / den_a if den_a else 0.0)
    return sum(inc) / len(inc) + sum(amb) / len(amb), sum(inc) / len(inc), sum(amb) / len(amb), len(D)
core = [Fr(1, 2), Fr(1, 4), Fr(1, 8), Fr(1, 5), Fr(1, 6), Fr(1, 10), Fr(1, 20), Fr(1, 30), Fr(1, 40), Fr(1, 60)]
best = core + [Fr(1, 32), Fr(1, 36)]; final = core + [Fr(1, 16), Fr(1, 24)]
print('target from the paper: 0.67094 for H/A = 1/32, 1/36; final solution (1/16, 1/24) is said to be worse')
for dset in ('signs', 'all', 'sums'):
    for repeat in (True, False):
        for reduced in (False, True):
            for amb_over in ('slots', 'represented'):
                g, i, a, nd = g_optimal(best, dset, repeat, 4, reduced, amb_over)
                g2 = g_optimal(final, dset, repeat, 4, reduced, amb_over)[0]
                flag = '  <== matches' if abs(g - 0.67094) < 5e-5 else ''
                print(f'  denominators={dset:6s} repeat={repeat!s:5s} reduced={reduced!s:5s} ambiguity over {amb_over:11s}: best-reported {g:.5f} (incompl. {i:.5f} + ambig. {a:.5f}, {nd} denominators) | final {g2:.5f}{flag}')
