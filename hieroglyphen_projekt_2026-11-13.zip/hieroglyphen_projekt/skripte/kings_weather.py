"""Follow-up to kings_cycles.py after the objection that weather systems also carry personal names.
Fixed before running:
  The 'named phenomenon' reading predicts (a) weather words near kings' names at least twice as often as near private persons' names and
  (b) family relations rare once the title 'son of Re' is left out (less than half the rate of private persons).
  It is refuted on this evidence if kinship without the title is at least half the persons' rate AND weather words are not twice as frequent.
usage: python3 -I kings_weather.py <dir with _aes_*.json>"""
import sys, os, json, re, collections
C = collections.Counter
d = sys.argv[1]
KIN = re.compile(r'\b(Sohn|Tochter|Mutter|Vater|Ehefrau|Gemahlin|Gattin|Bruder|Schwester|Kind)\b|gebären|geboren')
WEATHER = re.compile(r'Sturm|Unwetter|Gewitter|Donner|Blitz|Regen|Wolke|Hagel|\bWind|beben|Überschwemmung\b|Flut\b')
tot = collections.defaultdict(C); hit = collections.defaultdict(lambda: collections.defaultdict(C)); kinw = C(); wx = C(); maxyear = {}
for fn in sorted(os.listdir(d)):
    if not fn.startswith('_aes_'): continue
    data = json.load(open(os.path.join(d, fn), encoding='utf-8'))
    for sid, s in data.items():
        toks = s['token']; pt = s['corpus'] == 'bbawpyramidentexte'
        tr = [tk.get('cotext_translation') or '' for tk in toks]
        title = [tk.get('pos') == 'epitheton_title' for tk in toks]
        kin = [bool(KIN.search(x)) and not title[i] for i, x in enumerate(tr)]
        wea = [bool(WEATHER.search(x)) for x in tr]
        named = [tk.get('name') in ('person_name', 'kings_name') for tk in toks]
        ry = [i for i, x in enumerate(tr) if 'Regierungsjahr' in x]
        for i, tk in enumerate(toks):
            nm = tk.get('name')
            c = {'kings_name': 'kings', 'person_name': 'persons', 'gods_name': 'gods'}.get(nm)
            if not c: continue
            for scope in (('all',) if pt else ('all', 'without Pyramid Texts')):
                tot[scope][c] += 1
                k = any(kin[max(0, i - 3):i + 4])
                if k: hit[scope]['kinship word (titles left out) within three words'][c] += 1
                if k and any(named[j] for j in range(max(0, i - 6), min(len(toks), i + 7)) if j != i): hit[scope]['... and another named person within six words'][c] += 1
                if any(wea[max(0, i - 5):i + 6]): hit[scope]['weather or flood word within five words'][c] += 1
            if c == 'kings':
                for j in range(max(0, i - 3), min(len(toks), i + 4)):
                    if kin[j]: kinw[tr[j][:22]] += 1
                for j in range(max(0, i - 5), min(len(toks), i + 6)):
                    if wea[j]: wx[tr[j][:22]] += 1
                for r in ry:
                    if r < i:
                        for t2 in toks[r + 1:r + 3]:
                            w = re.sub(r'[\[\]⸢⸣()\?{}〈〉<>\s⸮]', '', t2.get('written_form') or '')
                            if t2.get('lemma_form') == '1...n' and w.isdigit(): maxyear[tk.get('lemma_form')] = max(maxyear.get(tk.get('lemma_form'), 0), int(w))
    del data
for scope in ('all', 'without Pyramid Texts'):
    print(f'\n({scope}) tokens:', dict(tot[scope]))
    for m in hit[scope]:
        sh = {c: hit[scope][m][c] / tot[scope][c] for c in ('kings', 'persons', 'gods')}
        print(f'   {m:52s} kings {sh["kings"]:6.1%} | persons {sh["persons"]:6.1%} | gods {sh["gods"]:6.1%}')
print('\nkinship words next to kings\' names (titles left out):', kinw.most_common(10))
print('weather words next to kings\' names:', wx.most_common(10))
print('highest year count written next to a king\'s name, per name:', sorted(maxyear.items(), key=lambda kv: -kv[1])[:10])
