import json, sys, glob, os, re, gzip, collections, math, statistics
import numpy as np
from scipy.stats import spearmanr
aes_dir, uni_p, cache_p, latroot = sys.argv[1:5]
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*')
def base(s): return re.sub(r'(?<=\d)[A-Za-z]+$', '', s)
if os.path.exists(cache_p): W = json.load(gzip.open(cache_p, 'rt', encoding='utf-8'))
else:
    W = {}
    for p in sorted(glob.glob(os.path.join(aes_dir, '_aes_*.json'))):
        d = json.load(open(p, encoding='utf-8'))
        for s in d.values():
            for k in s.get('token', []):
                if k.get('hiero'):
                    sg = [base(x) for x in SIGN.findall(k['hiero'])]
                    if sg: W.setdefault(s['text'], {'corpus': s['corpus'], 'w': []})['w'].append(sg)
    json.dump(W, gzip.open(cache_p, 'wt', encoding='utf-8'))
cp = collections.defaultdict(dict)
for line in open(uni_p, encoding='utf-8'):
    if line.startswith('U+'):
        p = line.rstrip('\n').split('\t')
        if len(p) == 3: cp[p[0]][p[1]] = p[2]
CONS = set('ꜣꞽjyꜥwbpfmnrhḥḫẖzsšḳqkgtṯdḏl'); STD = {}
for u, d in cp.items():
    if 'kEH_JSesh' not in d: continue
    b = base(d['kEH_JSesh']); f = d.get('kEH_Func', ''); v = d.get('kEH_FVal', '').strip()
    kind = 'Klassifikator' if f.startswith('Classifier') else 'Logogramm' if f.startswith('Logogram') else ('1 Konsonant' if (len(v) == 1 and v in CONS) else 'mehrere Konsonanten') if f.startswith('Phon') else 'anderes'
    if b not in STD or d['kEH_JSesh'] == b: STD[b] = (kind, v)
words = [tuple(w) for t in W.values() for w in t['w']]; NW = len(words); spell = collections.Counter(words); NS = len(spell)
freq = collections.Counter(s for w in words for s in w); NT = sum(freq.values()); order = [s for s, _ in freq.most_common()]
print(f'words with signs {NW}, distinct spellings {NS}, sign occurrences {NT}, signs {len(freq)}')
print('\n[A] how many signs are needed to write the words? (k most frequent signs -> share of word tokens / of distinct spellings written entirely with them)')
rank = {s: i for i, s in enumerate(order)}; need = np.array([max(rank[s] for s in w) + 1 for w in words]); needs = np.array([max(rank[s] for s in w) + 1 for w in spell])
for k in (10, 24, 30, 50, 100, 200, 400): print(f'   k={k:4d}: {np.mean(need <= k):6.1%} of word tokens | {np.mean(needs <= k):6.1%} of distinct spellings')
print('   signs needed for 50/80/90/95/99% of word tokens:', [int(np.quantile(need, q, method='higher')) for q in (0.5, 0.8, 0.9, 0.95, 0.99)])
# Latin calibration
TOKRE = re.compile(r"[A-Za-z]+"); lw = []
for f_ in ('bible/psalms.txt', 'bible/matthew.txt', 'bible/mark.txt', 'bible/luke.txt', 'bible/john.txt'):
    for line in open(os.path.join(latroot, f_), encoding='utf-8', errors='ignore'):
        if 'Latin Library' in line: continue
        lw += [m.group(0).lower() for m in TOKRE.finditer(line)]
lf = collections.Counter(ch for w in lw for ch in w); lorder = [c for c, _ in lf.most_common()]; lrank = {c: i for i, c in enumerate(lorder)}; lneed = np.array([max(lrank[c] for c in w) + 1 for w in lw])
print(f'   LATIN (Vulgate, {len(lw)} words, {len(lf)} letters): ' + ', '.join(f'k={k}: {np.mean(lneed <= k):.1%}' for k in (5, 10, 15, 20, 23, 24)))
ltypes = set(lw); lshare = sorted(((sum(1 for w in ltypes if c in w)/len(ltypes), c) for c in lf), reverse=True)
print('   Latin letters by share of distinct word forms containing them:', ' '.join(f'{c}{s:.0%}' for s, c in lshare))
# B ranking by share of distinct spellings containing the sign
cont = collections.Counter(); posc = collections.defaultdict(collections.Counter)
for w, n in spell.items():
    for s in set(w): cont[s] += 1
for w in words:
    if len(w) >= 3:
        for i, s in enumerate(w): posc[s]['A' if i == 0 else 'E' if i == len(w) - 1 else 'M'] += 1
rk = sorted(cont.items(), key=lambda x: -x[1])
print('\n[B] signs ranked by share of distinct spellings containing them (blind) | standard label and value | position initial/medial/final')
line = []
for i, (s, c) in enumerate(rk[:48]):
    k, v = STD.get(s, ('ohne Angabe', '')); pc = posc[s]; tt = sum(pc.values()) or 1
    line.append(f"{i+1:2d} {s:5s} {c/NS:5.1%} {k[:13]:13s} {v[:6]:6s} {pc['A']/tt:.0%}/{pc['M']/tt:.0%}/{pc['E']/tt:.0%}")
for i in range(0, 48, 3): print('   ' + ' || '.join(line[i:i+3]))
vals = np.array([c/NS for _, c in rk[:80]]); drops = sorted(((vals[i]/vals[i+1], i + 1) for i in range(5, 60)), reverse=True)[:5]
print('   largest relative drops between neighbouring ranks 6-60 (ratio, after rank):', [(round(r, 2), i) for r, i in drops])
for thr in (0.05, 0.02, 0.01, 0.005):
    ss = [s for s, c in rk if c/NS >= thr]; kc = collections.Counter(STD.get(s, ('ohne Angabe', ''))[0] for s in ss)
    print(f'   signs contained in >= {thr:.1%} of distinct spellings: {len(ss):3d} -> {dict(kc.most_common())}')
print(f"   Latin letters contained in >= 5% / 2% / 1% of distinct word forms: {sum(1 for s, c in lshare if s >= 0.05)} / {sum(1 for s, c in lshare if s >= 0.02)} / {sum(1 for s, c in lshare if s >= 0.01)} of {len(lshare)}")
# C the standard's own one-consonant signs
one = sorted(((freq[s], s, STD[s][1]) for s in freq if STD.get(s, ('', ''))[0] == '1 Konsonant'), reverse=True)
print(f"\n[C] signs with a one-consonant value in the Unicode sign list that occur in the corpus: {len(one)}; with >=500 occurrences: {sum(1 for n, s, v in one if n >= 500)}; with >=100: {sum(1 for n, s, v in one if n >= 100)}; distinct values among those >=100: {len(set(v for n, s, v in one if n >= 100))}")
print('   ', ' '.join(f'{s}={v}:{n}' for n, s, v in one[:44]))
by = collections.Counter()
for s, n in freq.items(): by[STD.get(s, ('ohne Angabe', ''))[0]] += n
print('    share of all sign occurrences by standard label:', {k: f'{v/NT:.1%}' for k, v in by.most_common()})
val = collections.defaultdict(list)
for n, s, v in one:
    if n >= 100: val[v].append((s, n))
print('    values written with more than one frequent sign:', {v: x for v, x in val.items() if len(x) > 1})
# D blind variant detection: negative correlation of rates across texts among frequent signs
top = order[:60]; T = [(tid, collections.Counter(s for w in t['w'] for s in w)) for tid, t in W.items()]; T = [(tid, c) for tid, c in T if sum(c.values()) >= 400]
M = np.array([[c[s]/sum(c.values()) for s in top] for _, c in T]); R = spearmanr(M)[0]; pairs = sorted(((R[i, j], top[i], top[j]) for i in range(len(top)) for j in range(i + 1, len(top))))[:14]
print(f'\n[D] blind search for interchangeable signs: most negative correlations of usage rates across {len(T)} texts (pairs among the 60 most frequent signs)')
print('   ', ' | '.join(f"{a}({STD.get(a, ('', ''))[1]})~{b}({STD.get(b, ('', ''))[1]}) {r:+.2f}" for r, a, b in pairs))
