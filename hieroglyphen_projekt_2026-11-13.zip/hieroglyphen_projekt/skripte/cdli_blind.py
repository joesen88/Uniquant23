"""Blind numeral and fraction analysis of Ur III administrative texts; criteria in cdli_prereg.txt.
usage: python3 -I cdli_blind.py <cdli_ur3.jsonl.gz> [min sign frequency]"""
import sys, gzip, json, re, collections, itertools, math
from fractions import Fraction as Fr
import numpy as np
C = collections.Counter
EL = re.compile(r'^(\d+)(?:/(\d+))?\(([^()]+)\)(.*)$')
GL = re.compile(r'^(?:\{[^{}]*\})+')

def parse_line(body):
    items = []; cur = None
    for t in body.split():
        m = EL.match(t)
        if m:
            cnt, den, name, suf = m.groups(); suf = GL.sub('', suf)
            el = (1, f'{cnt}/{den}({name})', True) if den else (int(cnt), name, False)
            if cur is None:
                cur = []; items.append(('P', cur))
            cur.append(el)
            if suf:
                items.append(('W', suf)); cur = None
        else:
            items.append(('W', t)); cur = None
    return items

texts = []
with gzip.open(sys.argv[1], 'rt', encoding='utf-8') as f:
    for line in f: texts.append(json.loads(line))
nel = C(); pair = C(); same = C(); after = collections.defaultdict(lambda: collections.defaultdict(C)); glob = collections.defaultdict(C)
nphr = 0; ncl = 0
fr_n = C(); fr_prev = collections.defaultdict(C); fr_next = collections.defaultdict(C); fr_pair = C(); fr_word = collections.defaultdict(C); fr_pos = collections.defaultdict(C)
PARSED = []   # per text: list of objects: list of (clean, items)
for t in texts:
    objs = []
    for o in t['o']:
        lines = []
        for clean, body in o:
            it = parse_line(body) if clean else None
            lines.append((clean, it, body))
            if not clean: continue
            ncl += 1
            for k, x in enumerate(it):
                if x[0] != 'P': continue
                ph = x[1]; nphr += 1
                nxt = it[k + 1][1] if k + 1 < len(it) else '<end>'
                for i, (cnt, s, fr) in enumerate(ph):
                    nel[s] += 1
                    if fr:
                        fr_n[s] += 1
                        fr_prev[s][ph[i - 1][1] if i else '<start>'] += 1
                        fr_next[s][ph[i + 1][1] if i + 1 < len(ph) else '<word>'] += 1
                        if i + 1 == len(ph): fr_word[s][nxt] += 1
                        fr_pos[s]['last' if i + 1 == len(ph) else 'inner'] += 1
                    else:
                        glob[s][cnt] += 1
                for (c1, a, f1), (c2, b, f2) in zip(ph, ph[1:]):
                    if f1 and f2: fr_pair[(a, b)] += 1
                    if f1 or f2: continue
                    if a == b: same[a] += 1; continue
                    pair[(a, b)] += 1; after[a][b][c2] += 1
        objs.append(lines)
    PARSED.append(objs)
print(f'texts {len(texts):,}; clean lines {ncl:,}; number phrases {nphr:,}; number elements {sum(nel.values()):,}; different signs {len(nel)}')
print('integer signs by frequency:', [(s, n) for s, n in nel.most_common(40) if '/' not in s])

def cap_r1(h): 
    v = [L for L, c in h.items() if c >= 2]; return max(v) if v else None
def cap_r2(h):
    n = sum(h.values()); v = [L for L, c in h.items() if c >= 2 and c / n >= 1e-3]; return max(v) if v else None

MINF = int(sys.argv[2]) if len(sys.argv) > 2 else 0   # optional: ignore signs with fewer occurrences (not part of the registered rule)
def order_graph(rule):
    edges = {}
    for a, b in itertools.combinations(sorted(nel), 2):
        if '/' in a or '/' in b: continue
        if nel[a] < MINF or nel[b] < MINF: continue
        x, y = pair[(a, b)], pair[(b, a)]
        if x + y < 3 or x == y: continue
        if rule == 'R2' and (x + y) < min(nel[a], nel[b]) / 1000: continue
        hi, lo = (a, b) if x > y else (b, a)
        edges[(hi, lo)] = (max(x, y), min(x, y))
    return edges
def find_cycle(edges):
    adj = collections.defaultdict(list)
    for a, b in edges: adj[a].append(b)
    color = {}; stack = []
    def dfs(u):
        color[u] = 1; stack.append(u)
        for v in adj[u]:
            if color.get(v) == 1: return stack[stack.index(v):] + [v]
            if v not in color:
                r = dfs(v)
                if r: return r
        color[u] = 2; stack.pop(); return None
    for u in list(adj):
        if u not in color:
            r = dfs(u)
            if r: return r
    return None
def covers(edges):
    adj = collections.defaultdict(set)
    for a, b in edges: adj[a].add(b)
    out = []
    for a, b in edges:
        seen = set(); todo = [c for c in adj[a] if c != b]; found = False
        while todo:
            u = todo.pop()
            if u == b: found = True; break
            if u in seen: continue
            seen.add(u); todo.extend(adj[u])
        if not found: out.append((a, b))
    return out
TRUTH = {('u', 'disz'): 10, ('gesz2', 'u'): 6, ("gesz'u", 'gesz2'): 10, ('szar2', "gesz'u"): 6, ("szar'u", 'szar2'): 10, ('u', 'asz'): 10,
         ('asz', 'barig'): 5, ('barig', 'ban2'): 6, ('ban2', 'disz'): 10, ("bur'u", 'bur3'): 10, ('bur3', 'esze3'): 3, ('esze3', 'iku'): 6}
for rule, capf in (('R1', cap_r1), ('R2', cap_r2)):
    E = order_graph(rule)
    print(f'\n[A] rule {rule}: {len(E)} ordered sign pairs')
    cyc = find_cycle(E)
    if cyc:
        print('   contradiction in the order (cycle):', ' > '.join(cyc), '| pair counts:', [(a, b, E.get((a, b))) for a, b in zip(cyc, cyc[1:])])
        # drop the weakest edge of each cycle until none is left (reported, not part of the registered rule)
        dropped = []
        while cyc:
            w = min(zip(cyc, cyc[1:]), key=lambda e: E[e][0]); dropped.append((w, E[w])); del E[w]; cyc = find_cycle(E)
        print('   weakest edges removed to continue:', dropped)
    cov = covers(E)
    hit = 0; rows = []
    for hi, lo in sorted(cov, key=lambda e: -E[e][0]):
        h = after[hi][lo]; cap = capf(h); rad = cap + 1 if cap else None
        tr = TRUTH.get((hi, lo))
        mark = '' if tr is None else ('OK' if tr == rad else f'WRONG (textbook {tr})')
        if tr is not None and tr == rad: hit += 1
        rows.append((hi, lo, E[(hi, lo)], rad, mark, ' '.join(f'{L}:{h[L]}' for L in sorted(h))))
    for hi, lo, (fw, rv), rad, mark, hs in rows:
        print(f'   {hi:8s} > {lo:8s} order {fw:6d}:{rv:<4d} radix {str(rad):4s} {mark:22s} counts of {lo} after {hi}: {hs[:150]}')
    missing = [k for k in TRUTH if k not in cov]
    print(f'   textbook relations recovered with the right radix: {hit}/{len(TRUTH)}; textbook relations not found as cover relations: {missing}')
print('\n[A] global counts per sign (how often each count n occurs), with caps R1/R2:')
for s, n in nel.most_common(30):
    if '/' in s: continue
    h = glob[s]
    print(f'   {s:8s} n={n:7d} cap R1 {cap_r1(h)} R2 {cap_r2(h)}   ' + ' '.join(f'{L}:{h[L]}' for L in sorted(h))[:170])
print('   same sign in two adjacent elements:', same.most_common(8))

# ---------------- fractions ----------------
print('\n[B] fraction signs (opaque symbols; names shown only for the reader)')
inv = [s for s, n in fr_n.most_common() if n >= 30]
for s in inv:
    print(f'   {s:12s} n={fr_n[s]:6d}  before it: {fr_prev[s].most_common(5)}  position: {dict(fr_pos[s])}  word after: {fr_word[s].most_common(8)}')
print('   rarer fraction signs:', [(s, n) for s, n in fr_n.most_common() if n < 30])
print('   adjacent fraction signs (compounds):', fr_pair.most_common(12))
json.dump({'inv': inv, 'fr_n': dict(fr_n), 'fr_pair': {f'{a}|{b}': n for (a, b), n in fr_pair.items()}}, open('/tmp/cdli_fr_inv.json', 'w'))

S = {'disz': 1, 'asz': 1, 'u': 10, 'gesz2': 60, "gesz'u": 600, 'szar2': 3600}
def ival(ph):
    v = 0
    for cnt, s, fr in ph:
        if fr or s not in S: return None
        v += cnt * S[s]
    return v
ctxh = collections.defaultdict(lambda: collections.defaultdict(C)); bare = collections.defaultdict(C); exact = collections.defaultdict(C)
for objs in PARSED:
    for lines in objs:
        for clean, it, body in lines:
            if not clean: continue
            used = set()
            for i in range(len(it) - 1):
                if it[i][0] == 'P' and it[i + 1][0] == 'W':
                    p1, w1 = it[i][1], it[i + 1][1]
                    last = p1[-1]
                    nfr = sum(1 for e in p1 if e[2])
                    ctx = last[1] if last[2] else ('none' if nfr == 0 else None)
                    if i + 3 < len(it) and it[i + 2][0] == 'P' and it[i + 3][0] == 'W':
                        v2 = ival(it[i + 2][1]); w2 = it[i + 3][1]
                        if v2 is not None and ctx is not None and nfr <= 1:
                            ctxh[(w1, w2)][ctx][v2] += 1; used.add(i + 2)
                            continue
                    if ctx is not None and ctx != 'none': exact[w1][ctx] += 1
            for i in range(len(it) - 1):
                if it[i][0] == 'P' and it[i + 1][0] == 'W' and i not in used:
                    v = ival(it[i][1])
                    if v is not None: bare[it[i + 1][1]][v] += 1
print('\n[B4] unit-word pairs  [phrase] W_hi [integer phrase] W_lo, by number of cases after a fraction sign')
rank = sorted(ctxh, key=lambda k: -sum(sum(h.values()) for c, h in ctxh[k].items() if c != 'none'))
for (w1, w2) in rank[:10]:
    d = ctxh[(w1, w2)]; nfrc = sum(sum(h.values()) for c, h in d.items() if c != 'none')
    if nfrc < 100: break
    print(f'  {w1} -> {w2}: {nfrc} cases after a fraction sign, {sum(d["none"].values())} after whole units, {sum(bare[w2].values())} bare "{w2}" amounts')
    for c in ['none'] + [s for s in inv if s in d]:
        h = d[c]; n = sum(h.values())
        if n < 20: continue
        print(f'     after {c:12s} n={n:6d} cap R1 {cap_r1(h)} R2 {cap_r2(h)}   ' + ' '.join(f'{v}:{h[v]}' for v in sorted(h))[:230])
    h = bare[w2]
    print(f'     bare {w2:13s} n={sum(h.values()):6d} cap R1 {cap_r1(h)} R2 {cap_r2(h)}   ' + ' '.join(f'{v}:{h[v]}' for v in sorted(h)[:70])[:330])
    print('     with remainder / exact, per sign:', {s: (sum(d[s].values()), exact[w1][s]) for s in inv if s in d or exact[w1][s]})
