"""What is there, and how often? Overview of the corpus by genre, of the most repeated word sequences, and of everything
that surrounds a king's name (titles before, formulas after, gods, verbs, nouns in the same sentence).
Descriptive, no test. Meanings are the editors' German glosses (standard reading).
usage: python3 -I structure_overview.py <dir with _aes_*.json>"""
import sys, os, json, collections
C = collections.Counter
d = sys.argv[1]
words = C(); texts = collections.defaultdict(set); tri = {'PT': C(), 'other': C()}; gl = collections.defaultdict(C)
bef = {'PT': C(), 'other': C()}; aft = {'PT': C(), 'other': C()}; cat = {'PT': collections.defaultdict(C), 'other': collections.defaultdict(C)}; has = {'PT': C(), 'other': C()}
nk = C(); ns = C(); names = collections.defaultdict(C); kcorp = C(); kdate = C()
for fn in sorted(os.listdir(d)):
    if not fn.startswith('_aes_'): continue
    data = json.load(open(os.path.join(d, fn), encoding='utf-8'))
    for s in data.values():
        toks = [t for t in s['token'] if t.get('lemma_form') and t.get('lemma_form') != '[...]']
        c = s['corpus']; sc = 'PT' if c == 'bbawpyramidentexte' else 'other'; words[c] += len(toks); texts[c].add(s['text'])
        lem = [t['lemma_form'] for t in toks]
        for t in toks:
            if t.get('cotext_translation'): gl[t['lemma_form']][t['cotext_translation'][:30]] += 1
        for i in range(len(lem) - 2): tri[sc][(lem[i], lem[i + 1], lem[i + 2])] += 1
        ki = [i for i, t in enumerate(toks) if t.get('name') == 'kings_name']
        if not ki: continue
        ns[sc] += 1
        for i in ki:
            nk[sc] += 1; names[sc][lem[i]] += 1; kcorp[c] += 1; kdate[s.get('date') or 'undated'] += 1
            for x in {t['lemma_form'] for t in toks[max(0, i - 3):i] if t.get('name') != 'kings_name'}: bef[sc][x] += 1
            for x in {t['lemma_form'] for t in toks[i + 1:i + 4] if t.get('name') != 'kings_name'}: aft[sc][x] += 1
        seen = collections.defaultdict(set)
        for t in toks:
            k = 'god' if t.get('name') == 'gods_name' else 'place' if t.get('name') == 'place_name' else 'person' if t.get('name') == 'person_name' else 'number' if t.get('pos') == 'numeral' else t.get('pos')
            seen[k].add(t['lemma_form'])
        for k, v in seen.items():
            has[sc][k] += 1
            for x in v: cat[sc][k][x] += 1
    del data
G = lambda x: (gl[x].most_common(1)[0][0] if gl[x] else '?')
tot = sum(words.values())
print(f'[A] corpus: {tot} words in {sum(len(v) for v in texts.values())} texts, {len(words)} sub-corpora. Largest and smallest by words:')
for c, n in words.most_common(8): print(f'   {c:26s} {n:7d} words {n / tot:6.1%}  texts {len(texts[c]):5d}')
for c, n in words.most_common()[-4:]: print(f'   {c:26s} {n:7d} words {n / tot:6.2%}  texts {len(texts[c]):5d}')
for sc in ('other', 'PT'):
    print(f'[B] most repeated three-word sequences, {"Pyramid Texts" if sc == "PT" else "all other texts"}:')
    for k, n in tri[sc].most_common(7 if sc == 'other' else 4): print(f'   {n:5d}  {" ".join(k):34s} = {" / ".join(G(x) for x in k)}')
print(f'[C] kings\' names: {dict(nk)} tokens in {dict(ns)} sentences; different names: PT {len(names["PT"])}, other {len(names["other"])}')
print('   by sub-corpus:', dict(kcorp.most_common(7))); print('   by period:', dict(kdate.most_common()))
for sc in ('other', 'PT'):
    lab = 'Pyramid Texts' if sc == 'PT' else 'other texts'
    print(f'   most frequent names ({lab}):', ', '.join(f'{x} {n}' for x, n in names[sc].most_common(5)))
    print(f'   up to three words before the name ({lab}):', '; '.join(f'{x} "{G(x)}" {n / nk[sc]:.0%}' for x, n in bef[sc].most_common(8)))
    print(f'   up to three words after the name ({lab}):', '; '.join(f'{x} "{G(x)}" {n / nk[sc]:.0%}' for x, n in aft[sc].most_common(8)))
    print(f'   sentences with a king\'s name that also contain ({lab}):', ', '.join(f'{k} {has[sc][k] / ns[sc]:.0%}' for k in ('epitheton_title', 'god', 'verb', 'substantive', 'place', 'person', 'number')))
    for k in ('god', 'verb', 'substantive'):
        print(f'      {k}s:', '; '.join(f'{x} "{G(x)}" {n / ns[sc]:.0%}' for x, n in cat[sc][k].most_common(8)))
