import json, sys
d = json.load(open(sys.argv[1], encoding='utf-8'))
n = 0
for sid, s in d.items():
    toks = [k for k in s.get('token', []) if k.get('hiero')]
    if len(toks) >= 4:
        print({k: (v if k != 'token' else '...') for k, v in s.items()})
        for k in toks[:3]: print('   ', k)
        n += 1
    if n >= 2: break
