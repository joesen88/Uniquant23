import json, sys, glob, os, re, collections, math, lzma, random, array, statistics
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
root, out = sys.argv[1], sys.argv[2]; random.seed(20261112)
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*')
T = collections.OrderedDict()
gl = {}; posof = {}
for p in sorted(glob.glob(os.path.join(root,'_aes_*.json'))):
    d = json.load(open(p,encoding='utf-8'))
    for sid, s in d.items():
        t = T.setdefault(s['text'], {'corpus': s['corpus'], 'date': s.get('date'), 'lem': [], 'sl': [], 'signs': []})
        n = 0
        for k in s.get('token', []):
            if not k.get('_id'): continue
            l = k.get('lemma_form') or k.get('written_form') or '?'
            if l == '[...]': continue
            t['lem'].append(l); n += 1
            gl.setdefault(l, (k.get('cotext_translation') or '')[:28]); posof.setdefault(l, k.get('pos'))
            if k.get('hiero'): t['signs'] += SIGN.findall(k['hiero'])
        if n: t['sl'].append(n)
G = collections.Counter(l for t in T.values() for l in t['lem']); NT = sum(G.values())
surp = {l: -math.log2(c/NT) for l, c in G.items()}
top200 = set(l for l, _ in G.most_common(200))
def mattr(seq, w):
    if len(seq) < w: return None
    c = collections.Counter(seq[:w]); tot = len(c); n = 1
    for i in range(w, len(seq)):
        a = seq[i-w]; c[a] -= 1
        if c[a] == 0: del c[a]
        c[seq[i]] += 1; tot += len(c); n += 1
    return tot/n/w
rows = []
for tid, t in T.items():
    L = t['lem']
    if len(L) < 30: continue
    rows.append({'text': tid, 'corpus': t['corpus'], 'date': t['date'], 'n': len(L), 'sl': statistics.median(t['sl']),
                 'surp': sum(surp[l] for l in L)/len(L), 'cov': sum(1 for l in L if l in top200)/len(L), 'mattr': mattr(L, 30)})
def z(key, f=lambda x: x):
    v = np.array([f(r[key]) for r in rows], float); return (v - v.mean())/v.std()
D = (z('surp') + z('sl', math.log2) + z('mattr'))/3
qs = np.quantile(D, [0.25, 0.5, 0.75])
for r, dv in zip(rows, D): r['D'] = float(dv); r['level'] = int(1 + sum(dv > q for q in qs))
json.dump(rows, open(out, 'w', encoding='utf-8'), ensure_ascii=False)
print('texts', len(T), '| scored (>=30 words):', len(rows), '| level cut points', [round(float(q),2) for q in qs])
print('correlations between the three components:', np.round(np.corrcoef([[r['surp'] for r in rows],[math.log2(r['sl']) for r in rows],[r['mattr'] for r in rows]]),2).tolist())
N = 8000
def stream(c):
    ids = [tid for tid, t in T.items() if t['corpus'] == c]; random.shuffle(ids)
    return [l for tid in ids for l in T[tid]['lem']]
def keyness(c, k=5):
    ci = collections.Counter(l for t in T.values() if t['corpus'] == c for l in t['lem']); ni = sum(ci.values()); nj = NT - ni; a0 = 2000.0
    sc = []
    for l, y in ci.items():
        if y < 15 or posof.get(l) not in ('substantive','verb','adjective','entity_name'): continue
        a = a0*G[l]/NT; yj = G[l]-y
        d = math.log((y+a)/(ni+a0-y-a)) - math.log((yj+a)/(nj+a0-yj-a)); v = 1/(y+a) + 1/(yj+a)
        sc.append((d/math.sqrt(v), l))
    return [f'{l} ({gl[l]})' for _, l in sorted(sc, reverse=True)[:k]]
print('\nper corpus: texts | words | median sentence length | mean surprisal bits | MATTR-500 | at N=8000: LZMA bits/word, repeated 6-grams | median difficulty D | level shares 1-4 | distinctive words')
order = []
for c in sorted(set(t['corpus'] for t in T.values())):
    ts = [t for t in T.values() if t['corpus'] == c]; st = stream(c); n = len(st)
    sl = [x for t in ts for x in t['sl']]
    rr = [r for r in rows if r['corpus'] == c]
    lv = collections.Counter(r['level'] for r in rr)
    m5 = mattr(st, 500)
    if n >= N:
        tok = st[:N]; ids = {}; arr = array.array('I', (ids.setdefault(x, len(ids)) for x in tok))
        bits = 8*len(lzma.compress(arr.tobytes(), preset=6))/N
        six = collections.Counter(tuple(tok[i:i+6]) for i in range(N-5)); rep = sum(v for v in six.values() if v >= 2)/(N-5)
    else: bits = rep = float('nan')
    medD = statistics.median(r['D'] for r in rr) if rr else float('nan')
    order.append((medD, c))
    print(f"{c:20s} {len(ts):5d} | {n:6d} | {statistics.median(sl):4.1f} | {sum(surp[l] for l in st)/n:5.2f} | {m5 if m5 else float('nan'):.3f} | {bits:5.2f} {rep:6.1%} | {medD:+.2f} | " + '/'.join(f"{lv.get(i,0)/max(len(rr),1):.0%}" for i in (1,2,3,4)) + f" (n={len(rr)}) | " + '; '.join(keyness(c)))
print('\norder simple -> complex by median D:', [c for _, c in sorted(order)])
# level x epoch
ep = collections.defaultdict(collections.Counter)
for r in rows: ep[r['date']][r['level']] += 1
print('levels by epoch:', {k: [v.get(i,0) for i in (1,2,3,4)] for k, v in ep.items()})
# clustering: are themes recoverable without labels?
def clus(docs, labels, analyzer_tokens, k):
    X = TfidfVectorizer(analyzer=lambda d: d, min_df=5, sublinear_tf=True).fit_transform(docs)
    km = KMeans(n_clusters=k, n_init=5, random_state=0).fit(X)
    pur = sum(max(collections.Counter(l for l, c in zip(labels, km.labels_) if c == j).values()) for j in set(km.labels_))/len(labels)
    return X.shape, adjusted_rand_score(labels, km.labels_), normalized_mutual_info_score(labels, km.labels_), pur
docs = [(t['lem'], t['corpus']) for t in T.values() if len(t['lem']) >= 80]
sh, ari, nmi, pur = clus([d for d, _ in docs], [c for _, c in docs], None, 12)
print(f'\nclustering on words (texts>=80 words): {sh} ARI={ari:.2f} NMI={nmi:.2f} purity={pur:.2f}; majority-class baseline={max(collections.Counter(c for _, c in docs).values())/len(docs):.2f}')
docs = [(t['signs'] + [a+'_'+b for a, b in zip(t['signs'], t['signs'][1:])], t['corpus']) for t in T.values() if len(t['signs']) >= 150]
sh, ari, nmi, pur = clus([d for d, _ in docs], [c for _, c in docs], None, 12)
print(f'clustering on signs only (texts>=150 signs): {sh} ARI={ari:.2f} NMI={nmi:.2f} purity={pur:.2f}; majority-class baseline={max(collections.Counter(c for _, c in docs).values())/len(docs):.2f}; corpora present={len(set(c for _, c in docs))}')
