"""Extract Ur III administrative texts (Sumerian) from the CDLI bulk dump into a compact cache.
usage: python3 -I cdli_extract.py <dir with cdliatf_unblocked.atf + cdli_catalogue_[1-4]of4.csv> <out.jsonl.gz>
Each output record: {"p": P-number, "prov": provenience, "o": [[ [clean, line], ... ] per object]}
clean = 1 if the line has none of [ ] < > # ? ! "..." "($", no token x, no unknown count n(...)."""
import sys, os, csv, io, re, json, gzip, collections
C = collections.Counter
d, out = sys.argv[1], sys.argv[2]
raw = b''.join(open(os.path.join(d, f'cdli_catalogue_{i}of4.csv'), 'rb').read() for i in (1, 2, 3, 4))
csv.field_size_limit(10**9)
cat = {}
for r in csv.DictReader(io.StringIO(raw.decode('utf-8', errors='replace'))):
    try: pid = int(r['id_text'])
    except Exception: continue
    if 'Ur III' in r['period'] and r['genre'].startswith('Administrative'):
        cat[pid] = r['provenience']
del raw
LINE = re.compile(r"^[0-9]+[a-z']*\.(?:[a-z0-9]+\.)?\s+(.*\S)\s*$")
DIRTY = re.compile(r"[\[\]<>#?!]|\.\.\.|\(\$|(?:^|\s)n\(|(?:^|[\s\-])[xX](?:$|[\s\-])")
OBJ = ('@tablet', '@envelope', '@object', '@bulla', '@tag', '@prism', '@barrel', '@cylinder', '@brick', '@cone', '@sealing', '@fragment')
SURF = ('@obverse', '@reverse', '@left', '@right', '@top', '@bottom', '@edge', '@face', '@surface')
stat = C(); rec = None
def flush(fo):
    global rec
    if rec and rec['lang'] == 'sux':
        objs = [o for o in rec['o'] if o]
        if objs:
            fo.write(json.dumps({'p': rec['p'], 'prov': rec['prov'], 'o': objs}, ensure_ascii=False) + '\n')
            stat['texts'] += 1; stat['objects'] += len(objs)
            for o in objs:
                stat['lines'] += len(o); stat['clean lines'] += sum(c for c, _ in o)
    rec = None
with gzip.open(out, 'wt', encoding='utf-8') as fo, open(os.path.join(d, 'cdliatf_unblocked.atf'), encoding='utf-8', errors='replace') as f:
    seal = False
    for line in f:
        if line.startswith('&'):
            flush(fo); seal = False
            m = re.match(r'&P(\d+)', line)
            pid = int(m.group(1)) if m else None
            rec = {'p': pid, 'prov': cat[pid], 'lang': None, 'o': [[]]} if pid in cat else None
            continue
        if rec is None: continue
        if line.startswith('#atf:'):
            m = re.search(r'lang\s+(\S+)', line)
            if m and rec['lang'] is None: rec['lang'] = m.group(1).strip().rstrip(',')
            continue
        if line.startswith('@'):
            if line.startswith('@seal'): seal = True
            elif line.startswith(OBJ): seal = False; rec['o'].append([])
            elif line.startswith(SURF): seal = False
            continue
        if seal: stat['seal lines skipped'] += 1; continue
        m = LINE.match(line)
        if not m: continue
        body = m.group(1)
        rec['o'][-1].append([0 if DIRTY.search(body) else 1, body])
    flush(fo)
print('catalogue: Ur III administrative entries', len(cat))
for k, v in stat.items(): print(f'  {k}: {v:,}')
