import sys, collections
for p in sys.argv[1:]:
    props = collections.Counter(); cps = set(); func = collections.Counter(); vals = collections.defaultdict(dict)
    for line in open(p, encoding='utf-8'):
        if line.startswith('#') or not line.strip(): continue
        f = line.rstrip('\n').split('\t')
        if len(f) < 3: continue
        cp, prop, val = f[0], f[1], f[2]
        cps.add(cp); props[prop] += 1; vals[cp][prop] = val
        if prop == 'kEH_Func':
            for x in val.split('|') if '|' in val else [val]: func[x.strip()[:40]] += 1
    blocks = collections.Counter('base' if int(c[2:],16) <= 0x1342F else ('ctrl' if int(c[2:],16) < 0x13460 else 'extA') for c in cps)
    print(p.split('/')[-1], 'codepoints', len(cps), dict(blocks))
    print('  props', dict(props))
    print('  kEH_Func values (top)', func.most_common(12))
    ex = [c for c in sorted(cps) if 'kEH_FVal' in vals[c]][:4]
    for c in ex: print('  ', c, vals[c])
