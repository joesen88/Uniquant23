import sys, os, re, json, glob, gzip, collections, math, random, statistics, unicodedata
import numpy as np
ety_p, aes_dir, uni_p = sys.argv[1:4]; random.seed(20261112)
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*'); base = lambda s: re.sub(r'(?<=\d)[A-Za-z]+$', '', s)
VOW = set('ⲁⲉⲏⲓⲟⲩⲱ')
def cop(s):
    s = s.lower().replace('ϯ', 'ⲧⲓ'); return [c for c in s if 0x2C80 <= ord(c) <= 0x2CFF or 0x03E2 <= ord(c) <= 0x03EF]
ET = collections.defaultdict(set)
for i, line in enumerate(open(ety_p, encoding='utf-8')):
    p = line.rstrip('\n').split('\t')
    if i == 0 or len(p) < 4 or p[2] in ('NA', ''): continue
    c = cop(p[1])
    if len(c) >= 2: ET[p[2]].add(tuple(c))
SP = collections.defaultdict(collections.Counter); NAMES = []; POSTOK = []
for f in sorted(glob.glob(os.path.join(aes_dir, '_aes_*.json'))):
    d = json.load(open(f, encoding='utf-8'))
    for s in d.values():
        for k in s.get('token', []):
            if not k.get('hiero'): continue
            sg = [base(x) for x in SIGN.findall(k['hiero'])]; lid = str(k.get('lemmaID') or '')
            if not sg or not lid: continue
            if lid in ET: SP[lid][tuple(sg)] += 1
            if k.get('pos') == 'entity_name' and k.get('name') and len(sg) >= 2: NAMES.append((lid, sg[-1], k['name']))
            if k.get('pos') in ('verb', 'substantive') and len(sg) >= 2: POSTOK.append((lid, sg[-1], k['pos']))
lem = sorted(SP); random.shuffle(lem); cut = int(0.8*len(lem)); TR, TE = lem[:cut], lem[cut:]
def pairs(L): return [(list(sp), list(c)) for l in L for sp, _ in SP[l].most_common(2) for c in ET[l]]
PTR, PTE = pairs(TR), pairs(TE)
print(f'Coptic words with an Egyptian ancestor in the dictionary: {len(ET)} lemmas; with hieroglyphic spellings in the corpus: {len(SP)}; training pairs {len(PTR)} ({len(TR)} lemmas), held-out pairs {len(PTE)} ({len(TE)} lemmas)')
def em(P, allowed=None, iters=30):
    letters = sorted(set(c for _, w in P for c in w)); t = collections.defaultdict(lambda: {c: 1/len(letters) for c in letters})
    Pm = [([s for s in sp if allowed is None or s in allowed] + ['#'], w) for sp, w in P]
    for it in range(iters):
        cnt = collections.defaultdict(collections.Counter)
        for sp, w in Pm:
            for c in w:
                z = sum(t[s][c] for s in sp)
                for s in sp: cnt[s][c] += t[s][c]/z
        t = collections.defaultdict(lambda: {c: 1e-6 for c in letters})
        for s, cc in cnt.items():
            tot = sum(cc.values()) + 1e-6*len(letters); t[s] = {c: (cc.get(c, 0) + 1e-6)/tot for c in letters}
    mass = collections.Counter(); occ = collections.Counter()
    for sp, w in Pm:
        for s in sp: occ[s] += 1
        for c in w:
            z = sum(t[s][c] for s in sp)
            for s in sp: mass[s] += t[s][c]/z
    return t, mass, occ, letters
def xent(P, t, allowed=None):
    tot = collections.Counter(); n = collections.Counter()
    for sp, w in P:
        ss = [s for s in sp if (allowed is None or s in allowed) and s in t] + ['#']
        for c in w:
            if c not in t['#']: continue
            p = sum(t[s][c] for s in ss)/len(ss); k = 'V' if c in VOW else 'C'; tot[k] -= math.log2(p); n[k] += 1
    return tot, n
t, mass, occ, letters = em(PTR); w8 = {s: mass[s]/occ[s] for s in occ if s != '#'}
cp = collections.defaultdict(dict)
for line in open(uni_p, encoding='utf-8'):
    if line.startswith('U+'):
        p = line.rstrip('\n').split('\t')
        if len(p) == 3: cp[p[0]][p[1]] = p[2]
CONS = set('ꜣꞽjyꜥwbpfmnrhḥḫẖzsšḳqkgtṯdḏl'); STD = {}
for u, d in cp.items():
    if 'kEH_JSesh' not in d: continue
    b = base(d['kEH_JSesh']); f = d.get('kEH_Func', ''); v = d.get('kEH_FVal', '').strip()
    kind = 'Klassifikator' if f.startswith('Classifier') else 'Logogramm' if f.startswith('Logogram') else ('1 Konsonant' if (len(v) == 1 and v in CONS) else 'mehrere Konsonanten') if f.startswith('Phon') else 'anderes'
    if b not in STD or d['kEH_JSesh'] == b: STD[b] = (kind, v)
GOLD = {'n': 'ⲛ', 'r': 'ⲣⲗ', 'm': 'ⲙ', 'p': 'ⲡⲃ', 'b': 'ⲃⲡ', 'f': 'ϥⲃ', 's': 'ⲥ', 'š': 'ϣ', 'ḥ': 'ϩ', 'h': 'ϩ', 'ḫ': 'ϣϩϧ', 'ẖ': 'ϩϧ', 'k': 'ⲕϭ', 'ḳ': 'ⲕϭ', 'g': 'ϭⲕ', 't': 'ⲧ', 'd': 'ⲧ', 'ṯ': 'ϫⲧ', 'ḏ': 'ϫⲧ'}
print('\n[1] values learned from Coptic alone, for signs the standard lists with one consonant (>=15 training occurrences): sign standard -> learned letter (probability), share of occurrences with a sound counterpart')
ok = []; rows = []
for s in sorted(occ, key=lambda s: -occ[s]):
    if s == '#' or occ[s] < 15 or STD.get(s, ('', ''))[0] != '1 Konsonant': continue
    best = sorted(t[s].items(), key=lambda x: -x[1])[:2]; v = STD[s][1]
    if v in GOLD: ok.append(best[0][0] in GOLD[v]); mark = '' if best[0][0] in GOLD[v] else ' !'
    else: mark = ' (Vokal/Halbvokal, nicht gewertet)'
    rows.append(f"{s} {v}->{best[0][0]} {best[0][1]:.2f} w={w8[s]:.2f}{mark}")
print('   ' + ' | '.join(rows)); print(f'    consonant signs with the expected Coptic letter: {sum(ok)} of {len(ok)}')
print('\n[2] share of occurrences with a sound counterpart, by standard label (signs with >=15 training occurrences):')
for kind in ('1 Konsonant', 'mehrere Konsonanten', 'Logogramm', 'Klassifikator'):
    v = [w8[s] for s in w8 if occ[s] >= 15 and STD.get(s, ('', ''))[0] == kind]; print(f'    {kind:20s} n={len(v):3d} median {statistics.median(v):.2f} | quartiles {np.quantile(v, 0.25):.2f}-{np.quantile(v, 0.75):.2f}')
snd = [w8[s] for s in w8 if occ[s] >= 15 and STD.get(s, ('', ''))[0] in ('1 Konsonant', 'mehrere Konsonanten')]; cls = [w8[s] for s in w8 if occ[s] >= 15 and STD.get(s, ('', ''))[0] == 'Klassifikator']
auc = np.mean([a > b for a in snd for b in cls]); print(f'    a sound sign has a higher value than a classifier in {auc:.0%} of pairs')
print('    classifiers with the lowest values:', ' '.join(f'{s}:{w8[s]:.2f}' for s in sorted((s for s in w8 if occ[s] >= 40 and STD.get(s, ("", ""))[0] == 'Klassifikator'), key=lambda s: w8[s])[:10]))
print('\n[3] how much of the Coptic word is explained on held-out words, when only the K strongest sound signs may carry sound')
rank = sorted((s for s in occ if s != '#'), key=lambda s: -mass[s]); t0, _, _, _ = em(PTR, allowed=set()); b, n = xent(PTE, t0, allowed=set()); H0 = {k: b[k]/n[k] for k in n}; H0all = sum(b.values())/sum(n.values())
print(f"    K=0 (no sign carries sound): {H0all:.2f} bits per Coptic letter (consonants {H0['C']:.2f}, vowels {H0['V']:.2f})")
for K in (10, 24, 32, 50, 100, 200, len(rank)):
    al = set(rank[:K]); tk, _, _, _ = em(PTR, allowed=al); b, n = xent(PTE, tk, allowed=al); h = sum(b.values())/sum(n.values())
    print(f"    K={K:4d}: {h:.2f} bits per letter -> explained {1 - h/H0all:5.1%} | consonants {1 - (b['C']/n['C'])/H0['C']:5.1%} | vowels {1 - (b['V']/n['V'])/H0['V']:5.1%}")
print(f"    share of all sign occurrences in the spellings covered by the K strongest signs: " + ', '.join(f"K={K}: {sum(occ[s] for s in rank[:K])/sum(v for s, v in occ.items() if s != '#'):.0%}" for K in (10, 24, 32, 50, 100, 200)))
# meaning layer: does the last sign predict the category?
def predict(tokens, label):
    L = sorted(set(l for l, _, _ in tokens)); random.shuffle(L); tr = set(L[:int(0.7*len(L))]); m = collections.defaultdict(collections.Counter); maj = collections.Counter()
    for l, s, y in tokens:
        if l in tr: m[s][y] += 1; maj[y] += 1
    te = [(s, y) for l, s, y in tokens if l not in tr]; mj = maj.most_common(1)[0][0]
    acc = np.mean([(m[s].most_common(1)[0][0] if s in m else mj) == y for s, y in te]); base_ = np.mean([y == mj for s, y in te])
    print(f'    {label}: {len(tokens)} occurrences, categories {dict(collections.Counter(y for _, _, y in tokens).most_common(5))}; predicted from the last sign on unseen words: {acc:.0%} correct (always guessing the largest category: {base_:.0%})')
print('\n[4] meaning layer:'); predict(NAMES, 'kind of name'); predict(POSTOK, 'verb or noun')
