import sys, os, re, json, glob, gzip, collections, math, random, statistics, unicodedata
import numpy as np
ety_p, aes_dir, uni_p = sys.argv[1:4]; random.seed(20261112)
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*'); base = lambda s: re.sub(r'(?<=\d)[A-Za-z]+$', '', s)
VOW = set('ⲁⲉⲏⲓⲟⲩⲱ')
def cop(s):
    s = s.lower().replace('ϯ', 'ⲧⲓ'); return [c for c in s if 0x2C80 <= ord(c) <= 0x2CFF or 0x03E2 <= ord(c) <= 0x03EF]
ET = collections.defaultdict(set)
for i, line in enumerate(open(ety_p, encoding='utf-8')):
    p = line.rstrip('\n').split('\t')
    if i == 0 or len(p) < 4 or p[2] in ('NA', ''): continue
    c = cop(p[1])
    if len(c) >= 2: ET[p[2]].add(tuple(c))
SP = collections.defaultdict(collections.Counter); NAMES = []; POSTOK = []
for f in sorted(glob.glob(os.path.join(aes_dir, '_aes_*.json'))):
    d = json.load(open(f, encoding='utf-8'))
    for s in d.values():
        for k in s.get('token', []):
            if not k.get('hiero'): continue
            sg = [base(x) for x in SIGN.findall(k['hiero'])]; lid = str(k.get('lemmaID') or '')
            if not sg or not lid: continue
            if lid in ET: SP[lid][tuple(sg)] += 1
            if k.get('pos') == 'entity_name' and k.get('name') and len(sg) >= 2: NAMES.append((lid, sg[-1], k['name']))
            if k.get('pos') in ('verb', 'substantive') and len(sg) >= 2: POSTOK.append((lid, sg[-1], k['pos']))
lem = sorted(SP); random.shuffle(lem); cut = int(0.8*len(lem)); TR, TE = lem[:cut], lem[cut:]
def pairs(L): return [(list(sp), list(c)) for l in L for sp, _ in SP[l].most_common(2) for c in ET[l]]
PTR, PTE = pairs(TR), pairs(TE)
print(f'Coptic words with an Egyptian ancestor in the dictionary: {len(ET)} lemmas; with hieroglyphic spellings in the corpus: {len(SP)}; training pairs {len(PTR)} ({len(TR)} lemmas), held-out pairs {len(PTE)} ({len(TE)} lemmas)')
def em(P, allowed=None, iters=30):
    letters = sorted(set(c for _, w in P for c in w)); t = collections.defaultdict(lambda: {c: 1/len(letters) for c in letters})
    Pm = [([s for s in sp if allowed is None or s in allowed] + ['#'], w) for sp, w in P]
    for it in range(iters):
        cnt = collections.defaultdict(collections.Counter)
        for sp, w in Pm:
            for c in w:
                z = sum(t[s][c] for s in sp)
                for s in sp: cnt[s][c] += t[s][c]/z
        t = collections.defaultdict(lambda: {c: 1e-6 for c in letters})
        for s, cc in cnt.items():
            tot = sum(cc.values()) + 1e-6*len(letters); t[s] = {c: (cc.get(c, 0) + 1e-6)/tot for c in letters}
    mass = collections.Counter(); occ = collections.Counter()
    for sp, w in Pm:
        for s in sp: occ[s] += 1
        for c in w:
            z = sum(t[s][c] for s in sp)
            for s in sp: mass[s] += t[s][c]/z
    return t, mass, occ, letters
def xent(P, t, allowed=None):
    tot = collections.Counter(); n = collections.Counter()
    for sp, w in P:
        ss = [s for s in sp if (allowed is None or s in allowed) and s in t] + ['#']
        for c in w:
            if c not in t['#']: continue
            p = sum(t[s][c] for s in ss)/len(ss); k = 'V' if c in VOW else 'C'; tot[k] -= math.log2(p); n[k] += 1
    return tot, n
t, mass, occ, letters = em(PTR); w8 = {s: mass[s]/occ[s] for s in occ if s != '#'}

def lcs(a, b):
    m = [[0]*(len(b) + 1) for _ in range(len(a) + 1)]
    for i, x in enumerate(a):
        for j, y in enumerate(b): m[i+1][j+1] = m[i][j] + 1 if x == y else max(m[i][j+1], m[i+1][j])
    return m[-1][-1]
EQ = {'ⲗ': 'ⲣ', 'ϭ': 'ⲕ', 'ϧ': 'ϩ'}
canon = lambda c: EQ.get(c, c)
def decode(P, val, allowed):
    tp = npred = ngold = 0
    for sp, w in P:
        pred = []
        for s_ in sp:
            if s_ in allowed and s_ in val and val[s_] not in VOW:
                c = canon(val[s_])
                if not pred or pred[-1] != c: pred.append(c)
        gold = [canon(c) for c in w if c not in VOW]
        tp += lcs(pred, gold); npred += len(pred); ngold += len(gold)
    r = tp/max(ngold, 1); p = tp/max(npred, 1); return r, p, (2*r*p/(r + p) if r + p else 0)
best = {s_: max(t[s_], key=t[s_].get) for s_ in occ if s_ != '#'}; rank = sorted(best, key=lambda s_: -mass[s_])
print('\n[5] consonants of unseen Coptic words predicted from the hieroglyphic spelling, when the K strongest signs carry sound and all others are silent: K | recovered | precision | F1')
for K in (5, 10, 16, 24, 32, 50, 75, 100, 150, 200, len(rank)):
    r, p, f = decode(PTE, best, set(rank[:K])); print(f'    K={K:4d}: {r:5.1%} | {p:5.1%} | {f:.3f}')
ctrl = []
for rep in range(200):
    ks = rank[:50]; vs = [best[k] for k in ks]; random.shuffle(vs); ctrl.append(decode(PTE, dict(zip(ks, vs)), set(ks))[2])
print(f'    control, values of the 50 strongest signs shuffled among them: F1 {np.mean(ctrl):.3f} ± {np.std(ctrl):.3f}')
gold_c = collections.Counter(c for _, w in PTE for c in w); nv = sum(v for c, v in gold_c.items() if c in VOW); print(f'    letters of the held-out Coptic words: {sum(gold_c.values())}, of which vowels {nv/sum(gold_c.values()):.0%}')
