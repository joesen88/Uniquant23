"""Several 'number spaces' as views of one whole: when do their informations add up?
usage: python3 -I views_information.py <aes_tokens_cache.json.gz>
Part 1: dates as (season, month, day): entropies, dependence, coverage of the 360-day grid.
Part 2: counting numbers: probabilities of intervals (orders of magnitude, tens/units digits), cost of notations.
"""
import sys, gzip, json, re, collections, math, random

C = collections.Counter
T = json.load(gzip.open(sys.argv[1], 'rt', encoding='utf-8'))
clean = lambda w: re.sub(r'[\[\]⸢⸣()\?{}〈〉<>\s⸮]', '', w or '')
SEAS = ['ꜣḫ.t', 'pr.t', 'šm.w']


def ival(tk):
    if tk[1] != '1...n': return None
    cw = clean(tk[3])
    return int(cw) if re.fullmatch(r'\d+', cw) else None


dates = []; ints = C(); n_last = 0; with_year = 0
for t in T.values():
    toks = t['tok']; p0 = 0; sents = []
    for L in t['sl']:
        sents.append(toks[p0:p0 + L]); p0 += L
    if p0 < len(toks): sents.append(toks[p0:])
    for s in sents:
        for i, tk in enumerate(s):
            v = ival(tk)
            if v is not None: ints[v] += 1
            if tk[1] == 'ꜣbd' and i + 3 < len(s):
                m = ival(s[i + 1])
                if m is None or not 1 <= m <= 4: continue
                if s[i + 2][1] not in SEAS: continue
                d = None
                if s[i + 3][1] == 'sw' and i + 4 < len(s):
                    d = ival(s[i + 4])
                elif s[i + 3][0] == '39740':
                    d = 30; n_last += 1
                if d is None or not 1 <= d <= 30: continue
                y = ival(s[i - 1]) if i >= 2 and s[i - 2][1] == 'rnp.t-zp' else None
                if y is not None: with_year += 1
                dates.append((SEAS.index(s[i + 2][1]), m, d, y))


def H(xs):
    c = C(xs); n = len(xs)
    h = -sum(k / n * math.log2(k / n) for k in c.values())
    return h, h + (len(c) - 1) / (2 * n * math.log(2))      # plug-in, Miller-Madow


N = len(dates)
S = [a for a, b, c, y in dates]; M = [b for a, b, c, y in dates]; D = [c for a, b, c, y in dates]
print(f'[1] dates with season, month and day: {N} (day 30 written as a word: {n_last}; with regnal year: {with_year})')
print('  seasons:', sorted(C(S).items()), '| months:', sorted(C(M).items()))
print('  days:', sorted(C(D).items()))
hs, hm, hd = H(S), H(M), H(D); hj = H(list(zip(S, M, D)))
print(f'  entropy (plug-in / corrected) season {hs[0]:.2f}/{hs[1]:.2f} of {math.log2(3):.2f} | month {hm[0]:.2f}/{hm[1]:.2f} of 2.00 | day {hd[0]:.2f}/{hd[1]:.2f} of {math.log2(30):.2f}')
print(f'  sum of the three: {hs[0]+hm[0]+hd[0]:.2f} bits; full grid log2(360) = {math.log2(360):.2f}; joint entropy of the sample (plug-in) {hj[0]:.2f} of max log2(N) = {math.log2(N):.2f}')
rng = random.Random(0)


def tc(S, M, D):
    return H(S)[0] + H(M)[0] + H(D)[0] - H(list(zip(S, M, D)))[0]


def mi(a, b):
    return H(a)[0] + H(b)[0] - H(list(zip(a, b)))[0]


obs = {'total correlation': tc(S, M, D), 'season-month': mi(S, M), 'season-day': mi(S, D), 'month-day': mi(M, D)}
null = collections.defaultdict(list); distinct = []
for _ in range(2000):
    s2 = S[:]; m2 = M[:]; d2 = D[:]
    rng.shuffle(s2); rng.shuffle(m2); rng.shuffle(d2)
    null['total correlation'].append(tc(s2, m2, d2)); null['season-month'].append(mi(s2, m2)); null['season-day'].append(mi(s2, d2)); null['month-day'].append(mi(m2, d2))
    distinct.append(len(set(zip(s2, m2, d2))))
for k, v in obs.items():
    xs = sorted(null[k]); mean = sum(xs) / len(xs); p = sum(1 for x in xs if x >= v) / len(xs)
    print(f'  {k:18s} observed {v:.3f} bits | if independent: mean {mean:.3f}, 95 % below {xs[int(0.95*len(xs))]:.3f} | p = {p:.3f}')
dd = sorted(distinct)
print(f'  different days of the year hit: {len(set(zip(S, M, D)))} of 360 | if independent: mean {sum(dd)/len(dd):.0f}, range {dd[int(0.025*len(dd))]}..{dd[int(0.975*len(dd))]}')
moy = C((a, b) for a, b in zip(S, M)); exp = N / 12
chi = sum((moy[(a, b)] - exp) ** 2 / exp for a in range(3) for b in range(1, 5))
print(f'  dates per month of the year (12 cells, expected {exp:.1f}):', [moy[(a, b)] for a in range(3) for b in range(1, 5)], f'chi2 = {chi:.1f} (df 11; 5 % limit 19.7)')
top = C(zip(S, M, D)).most_common(6)
print('  most frequent single dates (season, month, day):', [((SEAS[a], b, c), n) for (a, b, c), n in top])
ys = [y for a, b, c, y in dates if y is not None]
print('  regnal years: n', len(ys), 'max', max(ys), 'median', sorted(ys)[len(ys)//2], '| share <= 10:', round(sum(1 for y in ys if y <= 10)/len(ys), 2))

print('\n[2] counting numbers as probabilities of intervals')
tot = sum(ints.values())
for lo, hi in ((1, 9), (10, 99), (100, 999), (1000, 9999), (10000, 10**9)):
    c = sum(k for v, k in ints.items() if lo <= v <= hi)
    print(f'  {lo}..{hi if hi < 10**9 else "∞"}: {c} = {c/tot:.2%}')
two = [(v // 10, v % 10) for v, k in ints.items() if 10 <= v <= 99 for _ in range(k)]
Tn = [a for a, b in two]; U = [b for a, b in two]
print(f'  two-digit numbers: {len(two)}; tens digit:', sorted(C(Tn).items()), '| units digit:', sorted(C(U).items()))
ht, hu, hj2 = H(Tn)[0], H(U)[0], H(two)[0]
m_obs = ht + hu - hj2; xs = []
for _ in range(2000):
    u2 = U[:]; rng.shuffle(u2); xs.append(mi(Tn, u2))
xs.sort()
print(f'  H(tens) {ht:.2f} + H(units) {hu:.2f} = {ht+hu:.2f} bits; joint {hj2:.2f}; shared {m_obs:.3f} bits | if independent: mean {sum(xs)/len(xs):.3f}, 95 % below {xs[int(0.95*len(xs))]:.3f}')
for tdig in range(1, 10):
    sub = [b for a, b in two if a == tdig]
    if sub: print(f'    tens digit {tdig}: n={len(sub):4d}  share of round numbers (units 0): {sum(1 for b in sub if b == 0)/len(sub):.0%}')
# cost of notations
def digits(n): return [int(c) for c in str(n)]
cost_eg = lambda n: sum(digits(n))
cost_pos = lambda n: len(str(n))
def cost_rom(n):
    th, rest = divmod(n, 1000)
    return th + sum((d if d < 5 else 1 + d - 5) for d in digits(rest))
cost_bin = lambda n: n.bit_length()
Hn = -sum(k / tot * math.log2(k / tot) for k in ints.values())
for name, f in (('Egyptian additive (one sign per unit of each power of ten)', cost_eg), ('Roman additive', cost_rom), ('positional decimal', cost_pos), ('binary digits', cost_bin)):
    mean = sum(f(v) * k for v, k in ints.items() if v > 0) / tot
    print(f'  mean signs per number, {name}: {mean:.2f}')
print(f'  entropy of the numbers actually used: {Hn:.2f} bits per number ({len(ints)} different values, {tot} numbers)')
for a in (1.0, 2.0):
    Z = sum(v ** -a for v in range(1, 10**6))
    ce = -sum(k / tot * math.log2(v ** -a / Z) for v, k in ints.items() if 0 < v < 10**6)
    print(f'  cost if numbers were coded for a 1/n^{a:.0f} law: {ce:.2f} bits per number')
