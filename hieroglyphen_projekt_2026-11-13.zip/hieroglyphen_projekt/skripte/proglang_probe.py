import json, sys, glob, os, re, collections, math, lzma, random, tokenize, io, array
root = sys.argv[1]; random.seed(20261112)
texts = collections.OrderedDict(); corp = {}
for p in sorted(glob.glob(os.path.join(root,'_aes_*.json'))):
    d = json.load(open(p,encoding='utf-8'))
    for sid, s in d.items():
        texts.setdefault(s['text'], []).append(s); corp[s['text']] = s['corpus']
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*')
lem = lambda t: t.get('lemma_form') or t.get('written_form') or '?'
# ---------------- 1) control-structure markers (interpretation layer)
c = collections.Counter(); cm = collections.Counter(); init2 = collections.Counter(); nsent = collections.Counter()
schema = 0; cases = 0
for tid, S in texts.items():
    med = corp[tid] == 'sawmedizin'
    firsts = []
    for s in S:
        T = [t for t in s.get('token', []) if t.get('_id')]
        nsent['all'] += 1; nsent['med'] += med
        if not T: firsts.append(('', '')); continue
        L = [lem(t) for t in T]; W = [t.get('written_form') or '' for t in T]
        firsts.append((L[0], ' '.join(L[:2]), ' '.join(W)))
        def add(k):
            c[k] += 1
            if med: cm[k] += 1
        if L[0] == 'jr': add('sentence starts with jr (if / as for)')
        if L[0] == 'jr' and 'pw' in L: add('jr ... pw (as for X, it is Y: definition)')
        if any('.ḫr' in w for w in W): add('sentence has a .ḫr form (then one shall ...)')
        if any('.kꜣ' in w for w in W) or 'kꜣ' in L[:1]: add('sentence has a .kꜣ form / kꜣ (then ...)')
        if L[0] in ('k.t', 'ky', 'k.t-pẖr.t') : add('sentence starts with ky / k.t (another ...: alternative)')
        if 'r-pw' in L: add('contains r-pw (or)')
        for i in range(len(T)-1):
            if L[i] == 'zp' and re.fullmatch(r'\d+', W[i+1] or ''):
                add('zp N (N times)')
                if W[i+1] == '2': add('zp 2 (ditto: repeat)')
            if L[i] == 'hrw' and i >= 1 and L[i-1] == 'r' and re.fullmatch(r'\d+', W[i+1] or ''): add('r hrw N (for N days)')
        if med: init2[' '.join(L[:2])] += 1
    for i, f in enumerate(firsts):
        if len(f) == 3 and f[1].startswith('jr ḫꜣi̯'):
            cases += 1
            nxt = ' || '.join(x[2] for x in firsts[i:i+8] if len(x) == 3)
            if 'ḏd.ḫr' in nxt and ('jri̯.ḫr' in nxt or 'jr.ḫr' in nxt): schema += 1
print('sentences: all', nsent['all'], 'medical', nsent['med'])
for k, v in c.most_common(): print(f'   {k:58s} all {v:6d}   medical {cm.get(k,0):5d}')
print('   medical cases opening with "jr ḫꜣi̯=k" (if you examine):', cases, '| followed within 8 sentences by ḏd.ḫr (then say) and jri̯.ḫr (then make):', schema)
print('   top sentence openings in the medical corpus:', init2.most_common(10))
# ---------------- 2) code vs language statistics at equal length
def stats(tokens, N):
    tok = tokens[:N]; n = len(tok)
    cnt = collections.Counter(tok); V = len(cnt)
    H1 = -sum(v/n*math.log2(v/n) for v in cnt.values())
    big = collections.Counter(zip(tok, tok[1:])); H2 = -sum(v/(n-1)*math.log2(v/cnt[a]) for (a,b), v in big.items())
    top20 = sum(v for _, v in cnt.most_common(20))/n
    hap = sum(1 for v in cnt.values() if v == 1)/n
    ids = {t:i for i,t in enumerate(cnt)}; arr = array.array('I', (ids[t] for t in tok))
    bits = 8*len(lzma.compress(arr.tobytes(), preset=6))/n
    six = collections.Counter(tuple(tok[i:i+6]) for i in range(n-5))
    rep = sum(v for v in six.values() if v >= 2)/max(n-5,1)
    return V, top20, hap, H1, H2, bits, rep
def py_stream(limit):
    out = []; files = sorted(glob.glob(os.path.join(os.path.dirname(os.__file__), '*.py'))); random.shuffle(files)
    for f in files:
        try:
            src = open(f, 'rb').read()
            for t in tokenize.tokenize(io.BytesIO(src).readline):
                if t.type in (tokenize.COMMENT, tokenize.NL, tokenize.ENCODING, tokenize.ENDMARKER): continue
                if t.type == tokenize.STRING or t.type in (getattr(tokenize,'FSTRING_START',-1), getattr(tokenize,'FSTRING_MIDDLE',-2), getattr(tokenize,'FSTRING_END',-3)): out.append('STR')
                elif t.type == tokenize.NEWLINE: out.append('NEWLINE')
                elif t.type == tokenize.INDENT: out.append('INDENT')
                elif t.type == tokenize.DEDENT: out.append('DEDENT')
                else: out.append(t.string)
        except Exception: continue
        if len(out) >= limit: break
    return out
order = list(texts); random.shuffle(order)
def egy(kind, corpus=None):
    out = []
    for tid in order:
        if corpus and corp[tid] != corpus: continue
        for s in texts[tid]:
            if kind == 'de':
                out += re.findall(r'\w+', (s.get('sentence_translation') or '').lower())
            else:
                for t in s.get('token', []):
                    if not t.get('_id'): continue
                    if kind == 'lemma': out.append(lem(t))
                    elif kind == 'sign' and t.get('hiero'): out += SIGN.findall(t['hiero'])
    return out
N = 150000
streams = [('Python (stdlib tokens)', py_stream(N+1000)), ('German (corpus translations)', egy('de')), ('Egyptian words (lemmas)', egy('lemma')), ('Egyptian signs', egy('sign'))]
print('\ncode vs language at N =', N, 'tokens: types | top-20 share | hapax share | H1 | H2 | LZMA bits/token | share in repeated 6-grams')
for name, st in streams:
    V, t20, hap, H1, H2, bits, rep = stats(st, N)
    print(f'   {name:30s} n={min(len(st),N):6d} {V:6d} | {t20:5.1%} | {hap:5.1%} | {H1:5.2f} | {H2:5.2f} | {bits:5.2f} | {rep:5.1%}')
M = 40000
print('\nEgyptian words by genre at N =', M)
for g in ('sawmedizin','bbawpyramidentexte','bbawgrabinschriften','tb','sawlit','bbawbriefe'):
    st = egy('lemma', g)
    if len(st) < M: print('   ', g, 'too short', len(st)); continue
    V, t20, hap, H1, H2, bits, rep = stats(st, M)
    print(f'   {g:22s} {V:6d} | {t20:5.1%} | {hap:5.1%} | {H1:5.2f} | {H2:5.2f} | {bits:5.2f} | {rep:5.1%}')
V, t20, hap, H1, H2, bits, rep = stats(streams[0][1], M); print(f'   {"Python at same N":22s} {V:6d} | {t20:5.1%} | {hap:5.1%} | {H1:5.2f} | {H2:5.2f} | {bits:5.2f} | {rep:5.1%}')
