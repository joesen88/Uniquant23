"""What is attested first? Fraction signs and their runs by period, for Linear A (context field of the database) and for Egyptian (date label of the text).
usage: python3 -I chronology_first.py <LinearAInscriptions.js> <aes_tokens_cache.json.gz>"""
import sys, json, re, gzip, unicodedata, collections
C = collections.Counter
# ---------- Linear A ----------
s = open(sys.argv[1], encoding='utf-8').read()
i = s.index('new Map(') + len('new Map(')
body = re.sub(r'\\u\{([0-9A-Fa-f]+)\}', lambda m: chr(int(m.group(1), 16)), s[i:])
arr, _ = json.JSONDecoder().raw_decode(re.sub(r',\s*([\]}])', r'\1', body).lstrip())
NAME = {chr(cp): unicodedata.name(chr(cp)).split()[-1] for cp in range(0x10740, 0x10756)}; UNC = '\U0001076b'
def period(v):
    c = v.get('context') or ''
    if c.startswith('MM'): return '1 MM II-III (dated)'
    if c.startswith('LMI') and not c.startswith('LMIII'): return '3 LM I (dated)'
    if c == '' and v.get('site') == 'Phaistos': return '2 Phaistos, no date in the database'
    if c == '': return '4 other sites, no date'
    return '5 later'
ins = C(); sign = collections.defaultdict(C); run = collections.defaultdict(C); withfr = C()
for key, v in arr:
    p = period(v); ins[p] += 1; has = False
    for w in v.get('words', []):
        if w and any(ch in NAME for ch in w) and all(ch in NAME or ch == UNC for ch in w):
            sig = [NAME[ch] for ch in w if ch in NAME]; has = True
            for x in sig: sign[p][x] += 1
            if len(sig) >= 2: run[p][' '.join(sig) + (' (?)' if UNC in w else '')] += 1
    withfr[p] += has
print('[Linear A] inscriptions by period, with fraction signs, sign counts, runs')
for p in sorted(ins):
    print(f'  {p[2:]:34s} {ins[p]:5d} inscriptions, {withfr[p]:3d} with fractions | signs: ' + ', '.join(f'{k} {n}' for k, n in sign[p].most_common()) )
    if run[p]: print(f'  {"":34s} runs: ' + ', '.join(f'{k} {n}' for k, n in run[p].most_common()))
early = set(sign['1 MM II-III (dated)']) | set(sign['2 Phaistos, no date in the database']); late = set(sign['3 LM I (dated)'])
print('  signs in the early groups:', sorted(early), '| only later:', sorted(late - early), '| only early:', sorted(early - late))
# ---------- Egyptian ----------
T = json.load(gzip.open(sys.argv[2], 'rt', encoding='utf-8'))
clean = lambda w: re.sub(r'[\[\]⸢⸣()\?{}〈〉<>\s⸮]', '', w or '')
ORDER = ['OK & FIP', 'MK & SIP', 'NK', 'TIP - Roman times', 'unknown']
ntok = C(); ntext = C(); nnum = C(); frac = collections.defaultdict(C); runs = collections.defaultdict(C)
isfr = lambda w: bool(re.fullmatch(r'\d+/\d+', w)) or w.startswith('rʾ-') or w in ('gs', 'ḥsb')
for tid, t in T.items():
    d = t.get('date') or 'unknown'; ntext[d] += 1; toks = t['tok']; ntok[d] += len(toks); p0 = 0
    for L in t['sl']:
        sent = toks[p0:p0 + L]; p0 += L; cur = []
        for tk in sent + [(None, None, None, None)]:
            w = clean(tk[3]) if tk[1] == '1...n' else None
            if tk[1] == '1...n': nnum[d] += 1
            if w and isfr(w): frac[d][w] += 1; cur.append(w)
            else:
                if len(cur) >= 2: runs[d][' + '.join(cur)] += 1
                cur = []
print('\n[Egyptian] by period: texts, words, numerals, fraction notations (count), runs of fraction notations')
first = {}; firstrun = {}
for d in ORDER:
    fr = frac[d]; print(f'  {d:18s} {ntext[d]:5d} texts {ntok[d]:8,d} words {nnum[d]:6,d} numerals | fractions {sum(fr.values()):5d}: ' + ', '.join(f'{k} {n}' for k, n in fr.most_common(12)))
    if runs[d]: print(f'  {"":18s} runs {sum(runs[d].values())}: ' + ', '.join(f'{k} x{n}' for k, n in runs[d].most_common(8)))
    if d != 'unknown':
        for k in fr: first.setdefault(k, d)
        for k in runs[d]: firstrun.setdefault(k, d)
print('  first period of each notation:', {d: sorted(k for k, v in first.items() if v == d) for d in ORDER[:4]})
print('  runs first seen per period:', {d: len([k for k, v in firstrun.items() if v == d]) for d in ORDER[:4]})
# extension: a later run that contains an earlier run as a contiguous part
ext = []
for k, d in firstrun.items():
    for k2, d2 in firstrun.items():
        if k != k2 and ORDER.index(d2) > ORDER.index(d) and (' + ' + k + ' + ' in ' + ' + k2 + ' + '): ext.append((k, d, k2, d2))
print('  later runs that extend an earlier run:', ext[:12], '| number:', len(ext))
