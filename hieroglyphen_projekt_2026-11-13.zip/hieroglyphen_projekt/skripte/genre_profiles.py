import sys, os, re, json, gzip, glob, collections, math, lzma, random, unicodedata, array, statistics
import numpy as np
import simplemma
bdir, latroot, toks_p, texts_p = sys.argv[1:5]; ud_dirs = sys.argv[5:]; random.seed(20261112)
SEG = re.compile(r'''<seg id=['"]b\.([A-Z0-9]+)\.(\d+)\.(\d+)['"][^>]*>(.*?)</seg>''', re.S)
def norm(text, sm):
    t = text.lower()
    if sm: t = ''.join(c for c in unicodedata.normalize('NFD', t) if unicodedata.category(c) != 'Mn')
    t = t.replace('ـ', ''); return [w for w in re.split(r'[^\w]+', ''.join(c if unicodedata.category(c)[0] == 'L' else ' ' for c in t)) if w]
numforms = collections.Counter(); allforms = collections.Counter()
for d in ud_dirs:
    for p in glob.glob(os.path.join(d, '*.conllu')):
        for line in open(p, encoding='utf-8'):
            if line[:1].isdigit():
                c = line.split('\t'); f = c[1].lower().replace('v', 'u').replace('j', 'i'); allforms[f] += 1; numforms[f] += c[3] == 'NUM'
LATNUM = {f for f, n in numforms.items() if n >= 2 and n/allforms[f] >= 0.5}
DE = re.compile(r'^(?:ein|zwei|zwan|drei|vier|fünf|sechs|sech|sieben|sieb|acht|neun|zehn|elf|zwölf|zig|ßig|und|hundert|tausend)+$')
AR = re.compile(r'^(?:و|ف|ب|ل|ك)*(?:ال)?(?:واحد|احدى|احد|اثنا|اثني|اثنان|اثنين|اثنتا|اثنتي|اثنتان|ثلاث|ثلاثة|ثلث|ثلاثون|ثلاثين|اربع|اربعة|اربعون|اربعين|خمس|خمسة|خمسون|خمسين|ست|ستة|ستون|ستين|سبع|سبعة|سبعون|سبعين|ثماني|ثمانية|ثمان|ثمانون|ثمانين|تسع|تسعة|تسعون|تسعين|عشر|عشرة|عشرون|عشرين|مية|ماية|ميتان|ميتين|ميات|الف|الفا|الفان|الفين|الاف|الوف)$')
ZH = set('一二三四五六七八九十百千萬兩零')
ISNUM = {'Latein': lambda w: w.replace('v', 'u').replace('j', 'i') in LATNUM, 'Deutsch': lambda w: bool(DE.match(w)) and w not in ('ein', 'und'), 'Arabisch': lambda w: bool(AR.match(w)), 'Chinesisch': lambda w: all(c in ZH for c in w)}
GEN = {'Bauanleitung': [('EXO', 25, 30), ('EXO', 36, 39), ('1KI', 6, 7), ('2CH', 3, 4), ('EZE', 40, 43)], 'Ritualvorschrift': [('LEV', 1, 16), ('NUM', 28, 29)], 'Listen': [('NUM', 1, 4), ('NUM', 7, 7), ('NUM', 26, 26), ('1CH', 1, 9), ('EZR', 2, 2), ('NEH', 7, 7)],
       'Hymnen': [('PSA', 1, 150)], 'Erzaehlung': [('GEN', 12, 50)], 'Lehre': [('PRO', 1, 31)]}
def mattr(seq, w=200):
    c = collections.Counter(seq[:w]); tot = len(c); n = 1
    for i in range(w, len(seq)):
        a = seq[i - w]; c[a] -= 1
        if c[a] == 0: del c[a]
        c[seq[i]] += 1; tot += len(c); n += 1
    return tot/n/w
def feats(units, isnum, N=6000):
    sel = []; n = 0
    for u in units:
        if u: sel.append(u); n += len(u[1] if isinstance(u, tuple) else u)
        if n >= N: break
    seqs = [u[1] if isinstance(u, tuple) else u for u in sel]; keys = [u[0] if isinstance(u, tuple) else 0 for u in sel]; toks = [w for s in seqs for w in s][:N]
    if len(toks) < N: return None
    g = collections.Counter(tuple(toks[i:i + 5]) for i in range(len(toks) - 4)); cov = [False]*len(toks)
    for i in range(len(toks) - 4):
        if g[tuple(toks[i:i + 5])] >= 2:
            for j in range(i, i + 5): cov[j] = True
    jac = [len(set(a) & set(b))/len(set(a) | set(b)) for a, b, ka, kb in zip(seqs, seqs[1:], keys, keys[1:]) if ka == kb and len(a) >= 3 and len(b) >= 3]
    c = collections.Counter(toks); ids = {}; raw = array.array('I', (ids.setdefault(w, len(ids)) for w in toks)).tobytes(); H = -sum(v/N*math.log2(v/N) for v in c.values())
    return [sum(cov)/N, float(np.mean(jac)) if jac else 0.0, sum(v for _, v in c.most_common(10))/N, mattr(toks), sum(1 for w in toks if isnum(w))/N, 8*len(lzma.compress(raw, preset=9))/N/H]
FN = ['Wiederholung', 'Nachbar-Aehnlichkeit', 'Top-10', 'Vielfalt', 'Zahlwoerter', 'Kompression']
F = {}
for lang, (fn, sm) in {'Latein': ('Latin', False), 'Deutsch': ('German', False), 'Arabisch': ('Arabic', True), 'Chinesisch': ('Chinese-tok', False)}.items():
    V = collections.defaultdict(list)
    for b, ch, v, x in SEG.findall(open(os.path.join(bdir, fn + '.xml'), encoding='utf-8').read()):
        V[(b, int(ch))].append(norm(x, sm) if lang != 'Chinesisch' else [t for t in x.split() if all(unicodedata.category(c) == 'Lo' for c in t)])
    for g, parts in GEN.items():
        units = [u for b, a, e in parts for ch in range(a, e + 1) for u in V.get((b, ch), [])]; F[(lang, g)] = feats(units, ISNUM[lang])
print('features: ' + ' | '.join(FN))
for g in GEN: print(f'  Latein {g:17s} ' + ' '.join(f'{x:6.3f}' for x in F[('Latein', g)]) + '   || Chinesisch ' + ' '.join(f'{x:6.3f}' for x in F[('Chinesisch', g)]) + '   || Arabisch ' + ' '.join(f'{x:6.3f}' for x in F[('Arabisch', g)]))
langs = ['Latein', 'Deutsch', 'Arabisch', 'Chinesisch']; gens = list(GEN); Z = {}; PAR = {}
for l in langs:
    M = np.array([F[(l, g)] for g in gens]); mu, sd = M.mean(0), M.std(0) + 1e-9; PAR[l] = (mu, sd)
    for g, row in zip(gens, (M - mu)/sd): Z[(l, g)] = row
ok = 0; conf = collections.Counter()
for l in langs:
    cen = {g: np.mean([Z[(o, g)] for o in langs if o != l], 0) for g in gens}
    for g in gens:
        pr = min(gens, key=lambda h: np.linalg.norm(Z[(l, g)] - cen[h])); ok += pr == g; conf[(g, pr)] += 1
print(f'\ncross-language check: genre of a held-out language recognised from the other three: {ok}/{len(langs)*len(gens)}; confusions: {[(a, b, n) for (a, b), n in conf.items() if a != b]}')
CEN = {g: np.mean([Z[(l, g)] for l in langs], 0) for g in gens}
def place(name, z): 
    d = sorted((float(np.linalg.norm(z - CEN[g])), g) for g in gens); print(f'  {name:34s} -> {d[0][1]:17s} ({d[0][0]:.2f}), dann {d[1][1]} ({d[1][0]:.2f}) | ' + ' '.join(f'{x:+.1f}' for x in z))
# Latin textbooks
def latunits(files):
    out = []
    for f in files:
        try: t = open(os.path.join(latroot, f), encoding='utf-8', errors='ignore').read()
        except FileNotFoundError: continue
        t = '\n'.join(l for l in t.split('\n') if 'Latin Library' not in l and 'Classics Page' not in l)
        out += [norm(s, False) for s in re.split(r'[.;:?!]', t)]
    return [u for u in out if u]
LX = {'Vitruv (Bautechnik)': [f'vitruvius{i}.txt' for i in (3, 4, 5, 10)], 'Vitruv Buch 9 (Astronomie)': ['vitruvius9.txt'], 'Hyginus (Astronomie)': [f'hyginus/hyginus{i}.txt' for i in range(1, 5)], 'Manilius (Astrologie, Vers)': [f'manilius{i}.txt' for i in range(1, 6)], 'Censorinus (Zeitrechnung)': ['censorinus.txt'],
      'Apicius (Rezepte)': [f'apicius/apicius{i}.txt' for i in range(1, 6)], 'Frontinus (Wasserleitungen)': ['frontinus/aqua1.txt', 'frontinus/aqua2.txt'], 'Columella (Landbau)': ['columella/columella.rr1.txt', 'columella/columella.rr2.txt'], 'Caesar (Bericht)': [f'caesar/gall{i}.txt' for i in range(1, 4)]}
print('\nLatin textbooks placed among the six genres (nearest genre and distance; then the six standardised features):')
mu, sd = PAR['Latein']; LATF = {}
for name, files in LX.items():
    f = feats(latunits(files), ISNUM['Latein'])
    if f: LATF[name] = f; place(name, (np.array(f) - mu)/sd)
    else: print('  ', name, 'too short')
print('  raw: ' + ' | '.join(f"{k}: Zahlw. {v[4]:.1%}, Wiederh. {v[0]:.1%}" for k, v in LATF.items()))
# Egyptian groups
TK = json.load(gzip.open(toks_p, 'rt', encoding='utf-8')); TX = json.load(gzip.open(texts_p, 'rt', encoding='utf-8'))
EGN = {'bbawpyramidentexte': 'Pyramidentexte', 'tb': 'Totenbuch', 'bbawtotenlit': 'Ritualpapyri', 'bbawtempelbib': 'Priesterhandbuecher', 'sawmedizin': 'Medizin', 'sawlit': 'Literatur', 'bbawarchive': 'Verwaltungsarchive', 'bbawbriefe': 'Briefe', 'bbawramessiden': 'Koenigsinschriften', 'bbawgrabinschriften': 'Grabinschriften', 'bbawamarna': 'Amarna'}
EF = {}
for c, name in EGN.items():
    runs = []
    for rep in range(5):
        ids = [t for t, v in TK.items() if v['corpus'] == c]; random.shuffle(ids); units = []
        for t in ids:
            tk = TK[t]['tok']; p = 0
            for n in TX[t]['sl']:
                units.append((t, [(k[1] or k[3], k[2] == 'numeral') for k in tk[p:p + n]])); p += n
        f = feats([(t, [w for w in u]) for t, u in units], lambda w: w[1])
        if f: runs.append(f)
    if runs: EF[name] = np.mean(runs, 0)
M = np.array(list(EF.values())); mu, sd = M.mean(0), M.std(0) + 1e-9
print('\nEgyptian text groups placed among the six genres:')
for name, f in EF.items(): place(name, (f - mu)/sd)
print('  raw: ' + ' | '.join(f"{k}: Zahlw. {v[4]:.1%}, Wiederh. {v[0]:.1%}, Nachbar {v[1]:.2f}" for k, v in EF.items()))
