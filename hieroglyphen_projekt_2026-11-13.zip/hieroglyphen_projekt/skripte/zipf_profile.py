import sys, os, re, json, gzip, collections, math, statistics
import numpy as np, simplemma
root, toks_p = sys.argv[1:3]
TOKRE = re.compile(r"[A-Za-z]+")
def read(paths, cap_total, cap_each=None):
    out = []
    for p in paths:
        try: txt = open(os.path.join(root, p), encoding='utf-8', errors='ignore').read()
        except FileNotFoundError: continue
        seq = []
        for line in txt.split('\n'):
            if 'Latin Library' in line or 'Classics Page' in line: continue
            first = True
            for m in TOKRE.finditer(line):
                w = m.group(0); pre = line[:m.start()].rstrip(' "\'([0123456789'); seq.append((w, first or (pre[-1:] in '.?!:;' if pre else True))); first = False
        if cap_each: seq = seq[:cap_each]
        out += seq
        if len(out) >= cap_total: break
    return out[:cap_total]
REL = read(['bible/psalms.txt', 'bible/matthew.txt', 'bible/mark.txt', 'bible/luke.txt', 'bible/john.txt', 'bible/genesis.txt'], 112391)
LIT = read([f'caesar/gall{i}.txt' for i in range(1, 8)], 47783) + read([f'vergil/aen{i}.txt' for i in range(1, 13)], 47783) + read([f'ovid/ovid.met{i}.txt' for i in range(1, 16)], 47783) + read(['cicero/cat1.txt', 'cicero/cat2.txt', 'cicero/cat3.txt', 'cicero/cat4.txt', 'cicero/amic.txt', 'cicero/arch.txt', 'cicero/cael.txt', 'cicero/att1.txt', 'cicero/att2.txt', 'cicero/fam1.txt', 'cicero/brut.txt'], 47783)
TEC = read([f'vitruvius{i}.txt' for i in (10, 9, 1)], 18696)[:18696] + read([f'apicius/apicius{i}.txt' for i in range(1, 6)], 18696) + read(['cato/cato.agri.txt', 'isidore/4.txt', 'isidore/3.txt', 'frontinus/aqua1.txt'], 18696)
capm = collections.Counter(); tot = collections.Counter(); cap = collections.Counter()
for seq in (REL, LIT, TEC):
    for w, ini in seq:
        l = w.lower(); tot[l] += 1
        if w[0].isupper(): cap[l] += 1; capm[l] += (not ini)
name = {l for l in tot if capm[l] >= 1 and cap[l]/tot[l] >= 0.8}; cache = {}
def lem(w):
    l = w.lower()
    if l in name: return 'N:' + l
    if l not in cache: cache[l] = simplemma.lemmatize(l, lang='la').lower()
    return cache[l]
S = {'Latein Vulgata': ([lem(w) for w, _ in REL], lambda x: x.startswith('N:')), 'Latein Literatur': ([lem(w) for w, _ in LIT], lambda x: x.startswith('N:')), 'Latein Technik': ([lem(w) for w, _ in TEC], lambda x: x.startswith('N:'))}
TK = json.load(gzip.open(toks_p, 'rt', encoding='utf-8')); pos = {}
for nm_, c in (('Aegyptisch Pyramidentexte', 'bbawpyramidentexte'), ('Aegyptisch Literatur', 'sawlit'), ('Aegyptisch Medizin', 'sawmedizin')):
    seq = []
    for t in TK.values():
        if t['corpus'] == c:
            for k in t['tok']:
                if k[0]: seq.append(k[0]); pos.setdefault(k[0], k[2])
    S[nm_] = (seq, lambda x: pos.get(x) == 'entity_name')
N = 45000
print(f'profile on the first {N} words of each corpus: lemmas | hapax share of lemmas | tokens covered by top 10 / 100 / 1000 | Zipf slope (ranks 5-500) | entropy bits/word | tokens in rare class (count<=2) | names among rare-class lemmas | median distinct successors per occurrence in count bins 4-7 / 16-31 / 64-127')
for nm_, (seq, isname) in S.items():
    seq = seq[:N]; c = collections.Counter(seq); f = np.array(sorted(c.values(), reverse=True), float); V = len(f)
    cov = [f[:k].sum()/N for k in (10, 100, 1000)]; r = np.arange(1, V + 1); m = (r >= 5) & (r <= 500); slope = np.polyfit(np.log10(r[m]), np.log10(f[m]), 1)[0]
    H = -sum(v/N*math.log2(v/N) for v in f); rare = [l for l, v in c.items() if v <= 2]; rt = sum(c[l] for l in rare)/N; rn = sum(1 for l in rare if isname(l))/len(rare)
    succ = collections.defaultdict(set)
    for a, b in zip(seq, seq[1:]): succ[a].add(b)
    bins = []
    for lo, hi in ((4, 7), (16, 31), (64, 127)):
        v = [len(succ[l])/c[l] for l in c if lo <= c[l] <= hi]; bins.append(statistics.median(v) if v else float('nan'))
    print(f"  {nm_:26s} {V:5d} | {sum(1 for v in f if v == 1)/V:5.1%} | {cov[0]:5.1%} / {cov[1]:5.1%} / {cov[2]:5.1%} | {slope:+.2f} | {H:5.2f} | {rt:5.1%} | {rn:4.0%} | {bins[0]:.2f} / {bins[1]:.2f} / {bins[2]:.2f}")
