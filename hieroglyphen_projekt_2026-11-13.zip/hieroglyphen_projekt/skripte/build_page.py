import json, re, sys, os, html
rare_p, gdir, out_p = sys.argv[1:4]
D = json.load(open(rare_p, encoding='utf-8')); SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*')
def base(s): return re.sub(r'(?<=\d)[A-Za-z]+$', '', s)
E = lambda s: html.escape(str(s), quote=True)
BOX = json.load(open(gdir, encoding='utf-8')); G = {}; refs = 0
def glyph(code):
    if code in G: return G[code]
    for c in [code] + ([base(code)] if base(code) != code else []):
        if c in BOX:
            v = BOX[c]
            G[code] = {'id': 's-' + re.sub(r'\W', '', c), 'vb': '%.5g %.5g %.5g %.5g' % (v['x'], v['y'], v['w'], v['h']), 'w': v['w']*v['scale'], 'h': v['h']*v['scale'], 'ob': '0 0 %.5g %.5g' % (v['w'], v['h']), 'body': v['body'], 'exact': c == code}
            return G[code]
    G[code] = None; return None
def one(code, k, hl=False, label=False):
    g = glyph(code)
    if not g: return f'<span class="nog{" hl" if hl else ""}" title="keine Zeichnung in der Quelle">{E(code)}</span>'
    s = f'<svg class="g{" hl" if hl else ""}" width="{g["w"]*k:.1f}" height="{g["h"]*k:.1f}" viewBox="{g["ob"]}" role="img" aria-label="{E(code)}"><title>{E(code)}</title><use href="#{g["id"]}"/></svg>'
    return s
def seq(hiero, k=1.5, rare=()):
    return '<span class="seq">' + ''.join(one(c, k, base(c) in rare) for c in SIGN.findall(hiero)) + '</span>'
POSW = {'Anfang': 'am Wortanfang', 'Mitte': 'im Wortinneren', 'Ende': 'am Wortende', 'allein': 'als ganzes Wort'}
def card(r):
    b = r['base']; var = sorted(r['variants'].items(), key=lambda x: -x[1]); codes = ', '.join(v for v, _ in var)
    where = sorted(r['where'].items(), key=lambda x: -x[1]); wtxt = ', '.join(f'{n}× {POSW[k]}' for k, n in where)
    setname = 'Pyramidentexte' if r['set'] == 'PT' else 'Ritualpapyri'
    big = ''.join(f'<figure>{one(v, 3.0)}<figcaption>{E(v)}</figcaption></figure>' for v, _ in var[:2])
    words = ''
    for l in r['lemmas'][:3]:
        wo, al = l['without_this_sign'], l['attested_with_signs']
        alt = (f'<div class="row"><span class="lab">sonst geschrieben</span>{seq(l["usual_other_spelling"])}<span class="note">{wo} von {al} Belegen ohne dieses Zeichen</span></div>' if l['usual_other_spelling'] else '<div class="row"><span class="lab">sonst geschrieben</span><span class="note">kein Beleg ohne dieses Zeichen</span></div>')
        lit = f'in der Literatur {l["in_literary_words"]}× belegt' if l['in_literary_words'] else 'in der Literatur nicht belegt'
        words += f'<div class="word"><p class="lem"><i class="tl">{E(l["lf"])}</i> <span class="tr">„{E(l["tr"])}“</span> <span class="cnt">{l["n"]}×</span> <span class="note">Wort {lit}</span></p><div class="row"><span class="lab">hier geschrieben</span>{seq(l["spelling"], 1.5, (b,))}</div>{alt}</div>'
    more = f'<p class="note">und {r["nlemmas"] - 3} weitere Wörter</p>' if r['nlemmas'] > 3 else ''
    texts = '; '.join(f'{E(t)} ({n})' for t, n in r['texts'][:2]); ex = r['example']
    desc = f'<p class="desc"><span class="lab">Bild</span> {E(r["desc"])}</p>' if r['desc'] else ''
    exs = f'<p class="ex"><span class="lab">Beispiel</span> {E(ex["sentence"])}{"…" if len(ex["sentence"]) >= 220 else ""}</p>' if ex['sentence'] else ''
    return (f'<article class="sign" data-set="{r["set"]}" data-n="{r["n"]}" data-code="{E(b)}"><div class="pic">{big}</div><div class="body"><header><h3>{E(codes)}</h3>'
            f'<span class="chip c{r["class"]}">{"auch in der Medizin" if r["class"] == 2 else "weder Literatur noch Medizin"}</span><span class="chip set">{setname}</span>'
            f'<span class="meta">{r["n"]} Vorkommen in {r["ntexts"]} {"Text" if r["ntexts"] == 1 else "Texten"} · {wtxt}</span></header>{words}{more}{desc}{exs}<p class="src"><span class="lab">Texte</span> {texts}</p></div></article>')
rows = sorted(D['PT'], key=lambda r: -r['n']) + sorted(D['RIT'], key=lambda r: -r['n'])
cards = '\n'.join(card(r) for r in rows)
SW = [('ktw.t', 'Feuerstelle', 'V31-X1-M17-X1-O194-O194-O194', 'V31-X1-G43-X1-N33A', ('O194',)), ('kꜣp.t', 'Feuerung', 'V31-G1-Q3-X1-R6', 'V31-G1-Q3-X1-R5-R5-R5', ('R6',)), ('jꜥb', 'vereinigen', 'M17-D36-D58-O30U', 'M17-D36-D58-W10', ('O30',))]
swaps = ''.join(f'<div class="swap"><p class="lem"><i class="tl">{E(a)}</i> <span class="tr">„{E(t)}“</span></p><div class="row"><span class="lab">Ostgiebel</span>{seq(x, 1.9, rr)}</div><div class="row"><span class="lab">Ostwand</span>{seq(y, 1.9)}</div></div>' for a, t, x, y, rr in SW)
SY = {}
for g in G.values():
    if g: SY[g['id']] = '<symbol id="%s" viewBox="%s">%s</symbol>' % (g['id'], g['vb'], g['body'])
symbols = ''.join(SY.values())
nP, nR = len(D['PT']), len(D['RIT']); oP, oR = sum(r['n'] for r in D['PT']), sum(r['n'] for r in D['RIT'])
page = f'''<!DOCTYPE html>
<html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Hieroglyphen-Randzeichen</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Gentium+Plus:ital,wght@0,400;0,700;1,400&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root{{ /* layout: one reading column; each sign is a row with the drawing left and its words right */
  --paper:#f3f5f2; --panel:#ffffff; --ink:#1b2422; --muted:#5d6b67; --line:#d5dcd8; --accent:#1f4fa3; --accent-soft:#e3ebf8; --ochre:#8a5a00; --ochre-soft:#f6ecd6;
  --display:"Gentium Plus","Noto Serif",Georgia,serif; --body:"IBM Plex Sans","Segoe UI",system-ui,sans-serif; }}
@media (prefers-color-scheme: dark){{ :root:not([data-theme="light"]){{ color-scheme:dark; --paper:#141917; --panel:#1c2321; --ink:#e7ece9; --muted:#9aa8a3; --line:#33403c; --accent:#8fb4ff; --accent-soft:#1f2d47; --ochre:#e0b35a; --ochre-soft:#3a2f17; }} }}
:root[data-theme="dark"]{{ color-scheme:dark; --paper:#141917; --panel:#1c2321; --ink:#e7ece9; --muted:#9aa8a3; --line:#33403c; --accent:#8fb4ff; --accent-soft:#1f2d47; --ochre:#e0b35a; --ochre-soft:#3a2f17; }}
*{{box-sizing:border-box}} html{{-webkit-text-size-adjust:100%}}
body{{margin:0;background:var(--paper);color:var(--ink);font-family:var(--body);font-size:16px;line-height:1.5}}
main{{max-width:980px;margin:0 auto;padding:32px 20px 64px;display:flex;flex-direction:column;gap:28px}}
h1{{font-family:var(--display);font-weight:700;font-size:2.1rem;line-height:1.15;margin:0;text-wrap:balance}}
h2{{font-family:var(--display);font-weight:700;font-size:1.35rem;margin:0;text-wrap:balance}}
h3{{font-family:var(--body);font-weight:600;font-size:1.05rem;margin:0;font-variant-numeric:tabular-nums}}
p{{margin:0}} .lede{{max-width:66ch;color:var(--muted)}} .lede b{{color:var(--ink);font-weight:600}}
.facts{{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px}}
.fact{{background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:14px 16px;display:flex;flex-direction:column;gap:4px}}
.fact b{{font-size:1.5rem;font-weight:600;font-variant-numeric:tabular-nums}} .fact span{{color:var(--muted);font-size:.9rem}}
section{{display:flex;flex-direction:column;gap:14px}}
.swaps{{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px}}
.swap{{background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:14px 16px;display:flex;flex-direction:column;gap:8px}}
.bar{{display:flex;flex-wrap:wrap;gap:8px;align-items:center}}
.bar button{{font:inherit;font-size:.9rem;padding:6px 12px;border-radius:999px;border:1px solid var(--line);background:var(--panel);color:var(--ink);cursor:pointer}}
.bar button[aria-pressed="true"]{{background:var(--accent);border-color:var(--accent);color:var(--paper)}}
.bar button:focus-visible{{outline:2px solid var(--accent);outline-offset:2px}} .bar .sep{{width:1px;height:22px;background:var(--line)}}
.list{{display:flex;flex-direction:column;gap:10px}}
.sign{{background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:16px;display:grid;grid-template-columns:132px 1fr;gap:18px}}
.sign[hidden]{{display:none}}
.pic{{display:flex;gap:10px;align-items:flex-end;justify-content:center;flex-wrap:wrap;align-content:flex-start}}
figure{{margin:0;display:flex;flex-direction:column;align-items:center;gap:6px}} figcaption{{font-size:.75rem;color:var(--muted);font-variant-numeric:tabular-nums}}
.body{{display:flex;flex-direction:column;gap:10px;min-width:0}}
header{{display:flex;flex-wrap:wrap;gap:6px 10px;align-items:center}} .meta{{color:var(--muted);font-size:.9rem;flex-basis:100%}}
.chip{{font-size:.75rem;padding:2px 8px;border-radius:999px;border:1px solid var(--line);color:var(--muted)}}
.chip.c2{{background:var(--ochre-soft);color:var(--ochre);border-color:transparent}} .chip.c3{{background:var(--accent-soft);color:var(--accent);border-color:transparent}}
.word{{display:flex;flex-direction:column;gap:6px;padding-top:10px;border-top:1px solid var(--line)}}
.lem{{display:flex;flex-wrap:wrap;gap:4px 10px;align-items:baseline}} .tl{{font-family:var(--display);font-size:1.15rem}} .cnt{{font-variant-numeric:tabular-nums;font-weight:600}}
.row{{display:flex;flex-wrap:wrap;gap:6px 12px;align-items:flex-end}} .lab{{font-size:.75rem;letter-spacing:.04em;text-transform:uppercase;color:var(--muted);min-width:118px}}
.note{{color:var(--muted);font-size:.85rem}} .desc,.ex,.src{{font-size:.9rem;color:var(--muted)}} .desc .lab,.ex .lab,.src .lab{{display:inline-block;min-width:0;margin-right:8px}}
.seq{{display:inline-flex;flex-wrap:wrap;gap:4px;align-items:flex-end}} .g{{color:var(--ink);display:block;max-width:100%}} .g.hl{{color:var(--accent)}}
.nog{{font-size:.7rem;border:1px dashed var(--muted);color:var(--muted);padding:6px 4px;border-radius:3px;font-variant-numeric:tabular-nums}} .nog.hl{{color:var(--accent);border-color:var(--accent)}}
footer{{color:var(--muted);font-size:.85rem;max-width:72ch;display:flex;flex-direction:column;gap:6px}} a{{color:var(--accent)}}
@media (max-width:560px){{ .sign{{grid-template-columns:1fr}} .pic{{justify-content:flex-start}} .lab{{min-width:0;flex-basis:100%}} h1{{font-size:1.7rem}} }}
</style></head><body>
<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>{symbols}</defs></svg>
<main>
<div style="display:flex;flex-direction:column;gap:12px"><h1>Randzeichen der Pyramidentexte und Ritualpapyri</h1>
<p class="lede">Alle Zeichen, die in den literarischen Texten des Korpus nicht vorkommen: <b>{nP} Zeichen mit {oP} Vorkommen</b> in der Pyramidentext-Stichprobe (0,56 % von 3.562) und <b>{nR} Zeichen mit {oR} Vorkommen</b> in den späten Ritualpapyri (0,30 % von 119.662). Blau markiert ist jeweils das Randzeichen im Wort. Die Wortzuordnung und die Übersetzungen stammen aus der Standardlesung des Korpus.</p></div>
<div class="facts"><div class="fact"><b>291 von 364</b><span>Vorkommen in den Ritualpapyri stehen in einem Wort, das anderswo ohne dieses Zeichen geschrieben ist</span></div>
<div class="fact"><b>44 von 71</b><span>Zeichen der Ritualpapyri sind an genau ein Wort gebunden</span></div>
<div class="fact"><b>43 von 71</b><span>kommen höchstens zweimal vor</span></div>
<div class="fact"><b>3,2 %</b><span>aller Zeichenpositionen liegen höchstens fünf Zeichen von einem Randzeichen entfernt</span></div></div>
<section><h2>Gleiche Stelle, zwei Fassungen</h2><p class="lede">Spruch 273–274 liegt in zwei Fassungen vor. An drei Stellen steht in der einen ein Randzeichen und in der anderen ein gewöhnliches Zeichen. Der Abgleich läuft rein über die Zeichenfolge.</p><div class="swaps">{swaps}</div></section>
<section><h2>Alle Randzeichen</h2>
<div class="bar" role="group" aria-label="Filter und Sortierung"><button type="button" id="f-all" aria-pressed="true">Alle</button><button type="button" id="f-pt" aria-pressed="false">Pyramidentexte ({nP})</button><button type="button" id="f-rit" aria-pressed="false">Ritualpapyri ({nR})</button><span class="sep"></span><button type="button" id="s-n" aria-pressed="true">nach Häufigkeit</button><button type="button" id="s-code" aria-pressed="false">nach Zeichencode</button></div>
<div class="list" id="list">{cards}</div></section>
<footer><p>Daten: AES-Korpus (S. Schweitzer, auf Grundlage des Thesaurus Linguae Aegyptiae). Zeichenformen: JSesh, Glyphen überwiegend von Serge J.-P. Thomas. Bildbeschreibungen: Unicode-Datei Unikemet (englisch). Varianten desselben Zeichens (etwa O16 und O16C) sind zusammengefasst.</p><p>Ein gestricheltes Kästchen bedeutet, dass die Quelle für diesen Code keine Zeichnung enthält.</p></footer>
</main>
<script>
(function(){{var list=document.getElementById('list'),items=[].slice.call(list.children),orig=items.slice(),set='all';
function press(ids,on){{ids.forEach(function(i){{document.getElementById(i).setAttribute('aria-pressed',i===on?'true':'false')}})}}
function filt(s,id){{set=s;items.forEach(function(a){{a.hidden=!(s==='all'||a.dataset.set===s)}});press(['f-all','f-pt','f-rit'],id)}}
function sort(byCode,id){{var arr=byCode?orig.slice().sort(function(a,b){{return a.dataset.code.localeCompare(b.dataset.code,'de',{{numeric:true}})}}):orig;arr.forEach(function(a){{list.appendChild(a)}});press(['s-n','s-code'],id)}}
document.getElementById('f-all').onclick=function(){{filt('all','f-all')}};document.getElementById('f-pt').onclick=function(){{filt('PT','f-pt')}};document.getElementById('f-rit').onclick=function(){{filt('RIT','f-rit')}};
document.getElementById('s-n').onclick=function(){{sort(false,'s-n')}};document.getElementById('s-code').onclick=function(){{sort(true,'s-code')}};}})();
</script></body></html>'''
open(out_p, 'w', encoding='utf-8').write(page)
print('glyphs used', sum(1 for g in G.values() if g), 'missing', sorted(c for c, g in G.items() if not g), 'with internal refs', refs, '| page bytes', len(page.encode('utf-8')), '| cards', len(rows))
