"""G_Optimal as reconstructed from the paper (reading that reproduces its reported 0.67094):
  incompleteness: for every denominator d = 2..D (D = largest sign denominator) the share of k/d, k = 1..d-1, that no sum of at most four
                  signs (repetition allowed, sum < 1) reaches; averaged over the denominators
  ambiguity:      same slots, share of values with more than one representation of minimal length; averaged over the denominators
  G_Optimal = incompleteness + ambiguity (lower is better)
usage: python3 -I corazza_goptimal.py      (validation against the numbers reported in the paper)"""
import itertools, math, collections
from fractions import Fraction as Fr
C = collections.Counter
def g_optimal(vals, kmax=4):
    vals = list(vals); n = len(vals); D = max(v.denominator for v in vals)
    best = {}                                  # value -> (minimal length, number of multisets of that length)
    for k in range(1, kmax + 1):
        for c in itertools.combinations_with_replacement(range(n), k):
            s = sum(vals[i] for i in c)
            if s >= 1: continue
            b = best.get(s)
            if b is None: best[s] = [k, 1]
            elif b[0] == k: b[1] += 1
    inc = amb = 0.0
    for d in range(2, D + 1):
        un = am = 0
        for k in range(1, d):
            b = best.get(Fr(k, d))
            if b is None: un += 1
            elif b[1] > 1: am += 1
        inc += un / (d - 1); amb += am / (d - 1)
    return (inc + amb) / (D - 1), inc / (D - 1), amb / (D - 1)
if __name__ == '__main__':
    P36 = [Fr(5, 6), Fr(2, 3), Fr(1, 3), Fr(1, 5), Fr(1, 6), Fr(3, 20)] + [Fr(1, d) for d in (7, 9, 10, 12, 15, 16, 20, 24, 30, 32, 36, 40, 48, 50, 60, 64, 70, 72, 80, 84, 90, 96, 108, 100, 120, 160, 200, 240, 300, 320)]
    core = [Fr(1, 2), Fr(1, 4), Fr(1, 8), Fr(1, 5), Fr(1, 6), Fr(1, 10), Fr(1, 20), Fr(1, 30), Fr(1, 40), Fr(1, 60)]
    rows = []
    for h, a in itertools.combinations([v for v in P36 if v not in core and v < Fr(1, 2)], 2):
        rows.append((g_optimal(core + [h, a]), h, a))
    rows.sort(key=lambda r: r[0][0])
    print('published core plus every pair of values for H and A (unordered), sorted by G_Optimal:')
    for (g, i, am), h, a in rows[:8]: print(f'   {g:.5f}  (incompleteness {i:.5f}, ambiguity {am:.5f})   H/A = {h}, {a}')
    pos = [k for k, r in enumerate(rows) if {r[1], r[2]} == {Fr(1, 16), Fr(1, 24)}][0]
    print(f'   published pair 1/16, 1/24: {rows[pos][0][0]:.5f}, position {pos + 1} of {len(rows)}')
    print('   paper: best value 0.67094 for the pair 1/32, 1/36; range 0.67094-0.72676 for its 28 solutions with B = 1/5, D = 1/6')
    print(f'   core alone (ten signs): {g_optimal(core)[0]:.5f}')
