import json, sys, gzip, re, collections, math, random
import numpy as np
texts_p, conc_p, uni_p = sys.argv[1:4]
random.seed(20261112)
TX = json.load(gzip.open(texts_p, 'rt', encoding='utf-8'))
cp = collections.defaultdict(dict)
for line in open(uni_p, encoding='utf-8'):
    if line.startswith('U+'):
        p = line.rstrip('\n').split('\t')
        if len(p) == 3: cp[p[0]][p[1]] = p[2]
desc = {}
for u, d in cp.items():
    if 'kEH_JSesh' in d: desc.setdefault(d['kEH_JSesh'], (d.get('kEH_Func', '') + ((' = ' + d['kEH_FVal']) if d.get('kEH_FVal') else '') + ' | ' + d.get('kEH_Desc', ''))[:80])
C = collections.defaultdict(collections.Counter); DF = collections.defaultdict(collections.Counter); SEQ = collections.defaultdict(list)
for t in TX.values():
    if t['signs']: C[t['corpus']].update(t['signs']); DF[t['corpus']].update(set(t['signs'])); SEQ[t['corpus']].append(t['signs'])
big = ['sawlit', 'sawmedizin', 'bbawtotenlit', 'bbawamarna', 'bbawgrabinschriften', 'bbawtempelbib']
print('[A] coverage: share of the sign tokens of ROW that are signs also occurring in COLUMN')
print('    ' + ' '*22 + ' '.join(f'{c[:10]:>10s}' for c in big))
for r in big: print(f'    {r:22s}' + ' '.join(f"{sum(n for s, n in C[r].items() if s in C[c])/sum(C[r].values()):10.2%}" for c in big))
core = set.intersection(*[set(C[c]) for c in big]); allc = sum((C[c] for c in C), collections.Counter()); tot = sum(allc.values())
print(f'    signs present in all six groups: {len(core)} of {len(allc)} types; they cover {sum(allc[s] for s in core)/tot:.1%} of all {tot} sign tokens')
cum = np.cumsum(sorted(allc.values(), reverse=True))/tot
print('    most frequent signs needed for 50/80/90/95/99% of tokens:', [int(np.searchsorted(cum, q) + 1) for q in (0.5, 0.8, 0.9, 0.95, 0.99)], '| types occurring once or twice:', sum(1 for v in allc.values() if v <= 2))
# B distribution distance, size matched 100k, text-level sampling
def take(tl, n):
    o = []
    for s in tl:
        o += s
        if len(o) >= n: break
    return collections.Counter(o[:n])
def js(a, b):
    na, nb = sum(a.values()), sum(b.values()); d = 0.0
    for s in set(a) | set(b):
        p, q = a.get(s, 0)/na, b.get(s, 0)/nb; m = (p + q)/2
        if p: d += 0.5*p*math.log2(p/m)
        if q: d += 0.5*q*math.log2(q/m)
    return d
res = collections.defaultdict(list)
for it in range(100):
    sl = SEQ['sawlit'][:]; random.shuffle(sl); half = sum(map(len, sl))//2; a = []; b = []; acc = 0
    for s in sl: (a if acc < half else b).append(s); acc += len(s)
    sm = SEQ['sawmedizin'][:]; random.shuffle(sm); hm = sum(map(len, sm))//2; ma = []; mb = []; acc = 0
    for s in sm: (ma if acc < hm else mb).append(s); acc += len(s)
    sr = random.sample(SEQ['bbawtotenlit'], len(SEQ['bbawtotenlit']))
    la, lb, m1, m2, r1 = take(a, 70000), take(b, 70000), take(ma, 70000), take(mb, 70000), take(sr, 70000)
    res['literary half vs literary half'].append(js(la, lb)); res['medical half vs medical half'].append(js(m1, m2))
    res['literary vs medical'].append(js(la, m1)); res['literary vs ritual'].append(js(la, r1)); res['medical vs ritual'].append(js(m1, r1))
print('\n[B] Jensen-Shannon divergence of sign distributions (bits, 70k tokens each, 100 text-level resamples; 0 = identical, 1 = disjoint)')
for k, v in res.items(): print(f'    {k:32s} {np.mean(v):.3f} ± {np.std(v):.3f}')
# C keyness with informative Dirichlet prior
def key(target, ref, mindf=8, a0=5000.0):
    T, Rf = C[target], C[ref]; nT, nR = sum(T.values()), sum(Rf.values()); both = T + Rf; nB = nT + nR; out = []
    for s, y in T.items():
        if DF[target][s] < mindf: continue
        a = a0*both[s]/nB; yr = Rf.get(s, 0)
        d = math.log((y + a)/(nT + a0 - y - a)) - math.log((yr + a)/(nR + a0 - yr - a)); z = d/math.sqrt(1/(y + a) + 1/(yr + a))
        out.append((z, s, y, yr, (y/nT)/((yr + 0.5)/nR)))
    return sorted(out, reverse=True)
for tg in ('sawmedizin', 'bbawtotenlit'):
    k = key(tg, 'sawlit'); print(f'\n[C] signs over-represented in {tg} relative to literary (count there | count literary | rate ratio):')
    for z, s, y, yr, rr in k[:18]: print(f'    {s:6s} z={z:6.1f} {y:6d} | {yr:6d} | x{rr:6.1f}  {desc.get(s, "")}')
km = {s: (z, rr) for z, s, y, yr, rr in key('sawmedizin', 'sawlit')}; kr = {s: (z, rr) for z, s, y, yr, rr in key('bbawtotenlit', 'sawlit')}
sh = sorted([(min(km[s][0], kr[s][0]), s) for s in km if s in kr and km[s][0] > 3 and kr[s][0] > 3 and km[s][1] >= 1.5 and kr[s][1] >= 1.5], reverse=True)
print(f'\n[D] signs clearly over-represented in BOTH medical and ritual relative to literary (z>3 and rate ratio >=1.5 in both): {len(sh)} signs; token share in medical {sum(C["sawmedizin"][s] for _, s in sh)/sum(C["sawmedizin"].values()):.1%}, in ritual {sum(C["bbawtotenlit"][s] for _, s in sh)/sum(C["bbawtotenlit"].values()):.1%}, in literary {sum(C["sawlit"][s] for _, s in sh)/sum(C["sawlit"].values()):.1%}')
for z, s in sh[:16]: print(f'    {s:6s} med x{km[s][1]:4.1f} ritual x{kr[s][1]:4.1f} | {C["sawmedizin"][s]:5d} {C["bbawtotenlit"][s]:5d} {C["sawlit"][s]:5d}  {desc.get(s, "")}')
