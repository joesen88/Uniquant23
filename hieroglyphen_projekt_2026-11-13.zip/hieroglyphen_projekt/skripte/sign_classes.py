import json, sys, gzip, re, collections, statistics, random
import numpy as np
texts_p, toks_p, conc_p, uni_p, aes_dir = sys.argv[1:6]
random.seed(20261112); rng = np.random.default_rng(20261112)
TX = json.load(gzip.open(texts_p, 'rt', encoding='utf-8')); TK = json.load(gzip.open(toks_p, 'rt', encoding='utf-8'))
id2name = {}
for line in open(conc_p, encoding='utf-8'):
    p = line.rstrip('\n').split('\t')
    if len(p) == 2: id2name[p[1]] = p[0]
# sign descriptions
cp = collections.defaultdict(dict)
for line in open(uni_p, encoding='utf-8'):
    if line.startswith('U+'):
        p = line.rstrip('\n').split('\t')
        if len(p) == 3: cp[p[0]][p[1]] = p[2]
desc = {}
for u, d in cp.items():
    if 'kEH_JSesh' in d: desc.setdefault(d['kEH_JSesh'], (d.get('kEH_Func', '') + ((' = ' + d['kEH_FVal']) if d.get('kEH_FVal') else '') + ' | ' + d.get('kEH_Desc', ''))[:95])
# 0 residue check on one small raw file
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*')
d = json.load(open(aes_dir + '/_aes_tuebingerstelen.json', encoding='utf-8')); hs = [k['hiero'] for s in d.values() for k in s.get('token', []) if k.get('hiero')]
res = collections.Counter(x for h in hs for x in re.findall(r'[A-Za-z]+\d*[A-Za-z]*', SIGN.sub(' ', h)))
print('[0] raw hiero samples:', hs[:6]); print('    residue after removing Gardiner codes:', sum(res.values()), 'items vs', sum(len(SIGN.findall(h)) for h in hs), 'codes; top residue', res.most_common(8))
def cnt(pred):
    c = collections.Counter(); n = 0
    for tid, t in TX.items():
        if t['signs'] and pred(tid, t): c.update(t['signs']); n += 1
    return c, n
L, nL = cnt(lambda i, t: t['corpus'] == 'sawlit'); M, nM = cnt(lambda i, t: t['corpus'] == 'sawmedizin'); R, nR = cnt(lambda i, t: t['corpus'] == 'bbawtotenlit')
G, nG = cnt(lambda i, t: t['corpus'] == 'bbawgrabinschriften')
P4, n4 = cnt(lambda i, t: t['corpus'] == 'bbawpyramidentexte'); Pg, ng = cnt(lambda i, t: t['corpus'] == 'bbawgraeberspzt' and re.search(r'\bPT\b', id2name.get(i, '')))
print('\n[1] Pyramid-Text material with sign data:')
for tid, t in TX.items():
    if t['corpus'] == 'bbawpyramidentexte' and t['signs']: print('    ', id2name.get(tid, tid)[:80], '| signs', len(t['signs']), '| words', len(t['lem']))
print(f'    PT spells copied in Late Period tombs (title contains PT): texts {ng}, sign tokens {sum(Pg.values())}, types {len(Pg)}')
P = P4 + Pg
def part(name, Pc, ref=L, mid=M, show=0):
    N = sum(Pc.values()); c1 = {s: n for s, n in Pc.items() if s in ref}; c2 = {s: n for s, n in Pc.items() if s not in ref and s in mid}; c3 = {s: n for s, n in Pc.items() if s not in ref and s not in mid}
    print(f'    {name:44s} tokens {N:7d} types {len(Pc):4d} | class1 in literary: {len(c1):4d} types = {sum(c1.values())/N:7.2%} of tokens | class2 medical only: {len(c2):3d} types = {sum(c2.values())/N:6.2%} | class3 rest: {len(c3):3d} types = {sum(c3.values())/N:6.2%}')
    for lab, c in (('class2', c2), ('class3', c3)):
        if show and c:
            v = sorted(c.values()); print(f'      {lab}: median count {statistics.median(v)}, types with count<=2: {sum(1 for x in v if x <= 2)}/{len(v)}')
            for s, n in sorted(c.items(), key=lambda x: -x[1])[:show]: print(f'        {s:7s} {n:4d}x  {desc.get(s, "(no description found)")}')
    return c1, c2, c3
print('\n[2] three-class partition as proposed (reference = literary, second = medical):')
part('Pyramid Texts corpus (4 texts with signs)', P4); part('PT spells in Late Period tombs', Pg); pc = part('both PT samples together', P, show=14)
rc = part('late funerary/ritual papyri (stand-in)', R, show=14); part('Old Kingdom tomb inscriptions', G)
print(f'    sizes: literary {sum(L.values())} tokens {len(L)} types ({nL} texts); medical {sum(M.values())} tokens {len(M)} types ({nM} texts); ritual papyri {nR} texts')
print('\n[3] where do number / measure / calendar signs fall? (count in PT sample | ritual | literary | medical)')
for s in ['Z1', 'Z2', 'Z4', 'V20', 'V1', 'M12', 'D50', 'I8', 'C11', 'D11', 'D12', 'D13', 'D14', 'D15', 'D16', 'M4', 'N11', 'N5', 'U9', 'D42', 'S23', 'Y1', 'W24']:
    print(f'    {s:5s} {P.get(s,0):5d} | {R.get(s,0):6d} | {L.get(s,0):6d} | {M.get(s,0):6d}  {desc.get(s, "")[:70]}')
# 4 sampling baseline: probe of 100k tokens vs random half of literary (text level)
def seqs(corpus): return [t['signs'] for t in TX.values() if t['corpus'] == corpus and t['signs']]
SL, SM, SR = seqs('sawlit'), seqs('sawmedizin'), seqs('bbawtotenlit')
def take(tl, n):
    o = []; 
    for s in tl:
        o += s
        if len(o) >= n: break
    return o[:n]
out = collections.defaultdict(list)
for it in range(200):
    random.shuffle(SL); half = sum(len(s) for s in SL)//2; a = []; b = []; acc = 0
    for s in SL:
        (a if acc < half else b).append(s); acc += len(s)
    ref = set(x for s in b for x in s)
    for nm, tl in (('literary vs literary', a), ('ritual vs literary', random.sample(SR, len(SR))), ('medical vs literary', random.sample(SM, len(SM)))):
        pr = collections.Counter(take(tl, 100000)); ex = {s: n for s, n in pr.items() if s not in ref}
        out[nm].append((len(pr), len(ex), len(ex)/len(pr), sum(ex.values())/sum(pr.values())))
print('\n[4] sampling baseline, probe 100k sign tokens vs a random half of the literary corpus (200 text-level splits): types | types not in reference | share of types | share of tokens')
for nm, v in out.items(): v = np.array(v); print(f'    {nm:22s} {v[:,0].mean():6.0f} | {v[:,1].mean():5.1f} ± {v[:,1].std():4.1f} | {v[:,2].mean():6.1%} | {v[:,3].mean():6.2%} ± {v[:,3].std():.2%}')
# 5 token permutation null for ritual partition
ids = {}; arr = []
for c in (R, L, M):
    for s, n in c.items(): arr += [ids.setdefault(s, len(ids))]*n
arr = np.array(arr); nR_, nL_, nM_ = sum(R.values()), sum(L.values()), sum(M.values()); K = len(ids); ex = []
for it in range(200):
    rng.shuffle(arr); r = np.bincount(arr[:nR_], minlength=K); l = np.bincount(arr[nR_:nR_+nL_], minlength=K); m = np.bincount(arr[nR_+nL_:], minlength=K)
    ex.append((((r > 0) & (l == 0) & (m > 0)).sum(), r[(l == 0) & (m > 0)].sum(), ((r > 0) & (l == 0) & (m == 0)).sum(), r[(l == 0) & (m == 0)].sum(), (r > 0).sum()))
ex = np.array(ex); print(f'\n[5] if all three corpora drew from one common sign distribution (200 token shuffles): ritual types {ex[:,4].mean():.0f}; class2 {ex[:,0].mean():.1f} types / {ex[:,1].mean():.1f} tokens; class3 {ex[:,2].mean():.1f} types / {ex[:,3].mean():.1f} tokens')
print(f'    observed: ritual types {len(R)}; class2 {len(rc[1])} types / {sum(rc[1].values())} tokens; class3 {len(rc[2])} types / {sum(rc[2].values())} tokens')
# 6 word level on the full Pyramid Texts
gloss = {}
d = json.load(open(aes_dir + '/_aes_bbawpyramidentexte.json', encoding='utf-8'))
for s in d.values():
    for k in s.get('token', []):
        if k.get('lemmaID'): gloss.setdefault(str(k['lemmaID']), ((k.get('lemma_form') or ''), (k.get('cotext_translation') or '')[:30]))
def lem(corpus):
    c = collections.Counter(); pos = {}
    for t in TK.values():
        if t['corpus'] == corpus:
            for k in t['tok']:
                if k[0]: c[k[0]] += 1; pos.setdefault(k[0], k[2])
    return c, pos
WP, posP = lem('bbawpyramidentexte'); WL, _ = lem('sawlit'); WM, _ = lem('sawmedizin'); N = sum(WP.values())
w1 = {l: n for l, n in WP.items() if l in WL}; w2 = {l: n for l, n in WP.items() if l not in WL and l in WM}; w3 = {l: n for l, n in WP.items() if l not in WL and l not in WM}
print(f'\n[6] same partition on WORDS (lemma IDs) of the full Pyramid Texts: {N} words, {len(WP)} lemmas; literary {sum(WL.values())} words {len(WL)} lemmas; medical {sum(WM.values())} words {len(WM)} lemmas')
for lab, c in (('class1 in literary', w1), ('class2 medical only', w2), ('class3 rest', w3)):
    pp = collections.Counter(); 
    for l, n in c.items(): pp[posP.get(l, '')] += n
    tot = sum(c.values()); print(f'    {lab:20s} {len(c):5d} lemmas = {len(c)/len(WP):6.1%} | {tot:6d} words = {tot/N:6.2%} | by word class: ' + ', '.join(f'{k or "?"} {v/tot:.0%}' for k, v in pp.most_common(4)))
for lab, c in (('class2', w2), ('class3', w3)):
    print(f'    {lab} top:', '; '.join(f'{gloss.get(l, ("?", ""))[0]} ({gloss.get(l, ("", "?"))[1]}) {n}' for l, n in sorted(c.items(), key=lambda x: -x[1])[:16]))
num = [(l, n) for l, n in WP.items() if posP.get(l) == 'numeral']; print('    numeral lemmas in PT:', len(num), 'tokens', sum(n for _, n in num), '| of these also in literary:', sum(1 for l, _ in num if l in WL), 'lemmas /', sum(n for l, n in num if l in WL), 'tokens')
