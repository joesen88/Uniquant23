import sys, re, math, collections
src, tgt = sys.argv[1], sys.argv[2]
SIGN = re.compile(r'^(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*$')
uni = collections.Counter(); other = collections.Counter(); nwords = 0; nlines = 0
big = collections.Counter(); ctx = collections.Counter()
for line in open(src, encoding='utf-8'):
    nlines += 1
    prev = '<s>'
    for w in line.strip().split(' _ '):
        toks = [t for t in w.split() if t != '_']
        if not toks: continue
        nwords += 1
        for t in toks:
            if SIGN.match(t):
                uni[t] += 1; big[(prev, t)] += 1; ctx[prev] += 1; prev = t
            else:
                other[t] += 1; prev = '<x>'
n = sum(uni.values())
H1 = -sum(v/n*math.log2(v/n) for v in uni.values())
N2 = sum(big.values()); H2 = -sum(v/N2*math.log2(v/ctx[a]) for (a,b),v in big.items())
print('lines', nlines, 'words', nwords, 'sign tokens', n, 'sign types', len(uni), 'hapax', sum(1 for v in uni.values() if v == 1))
acc = 0
for i,(s,v) in enumerate(uni.most_common(),1):
    acc += v
    if acc/n >= 0.9: print('types for 90% coverage', i); break
print('H1', round(H1,3), 'H2', round(H2,3))
print('non-sign tokens top', other.most_common(12))
tw = 0
for line in open(tgt, encoding='utf-8'):
    tw += len([w for w in line.strip().split(' _ ') if w.strip()])
print('tgt words', tw)
