import json, sys, gzip, collections
TX = json.load(gzip.open(sys.argv[1], 'rt', encoding='utf-8'))
tok = collections.Counter(); sg = collections.Counter(); ty = collections.defaultdict(set); nt = collections.Counter(); nts = collections.Counter()
for t in TX.values():
    c = t['corpus']; tok[c] += len(t['lem']); sg[c] += len(t['signs']); ty[c].update(t['signs']); nt[c] += 1; nts[c] += 1 if t['signs'] else 0
print('corpus | texts | texts with signs | words | sign tokens | sign types | signs per word')
for c in sorted(tok, key=lambda c: -sg[c]): print(f'{c:22s} {nt[c]:5d} {nts[c]:5d} {tok[c]:7d} {sg[c]:7d} {len(ty[c]):5d} {sg[c]/max(tok[c],1):.2f}')
