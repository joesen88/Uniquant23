"""Topics found without meanings: NMF on word counts per text; names of the topics only afterwards from the glosses.
usage: python3 -I topics_nmf.py <aes_tokens_cache.json.gz> <aes_deutung_token.jsonl.gz>
"""
import sys, gzip, json, collections
import numpy as np
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.decomposition import NMF
from scipy.sparse import csr_matrix
C = collections.Counter
T = json.load(gzip.open(sys.argv[1], 'rt', encoding='utf-8'))
gl = collections.defaultdict(C)
for line in gzip.open(sys.argv[2], 'rt', encoding='utf-8'):
    r = json.loads(line)
    if r.get('lemmaID'): gl[r['lemmaID']][(r.get('cotext_translation') or '').strip()] += 1
docs = []; labs = []; name = {}
for tid, t in T.items():
    lem = []
    for tk in t['tok']:
        if not tk[0] or tk[2] == 'entity_name': continue
        if tk[2] == 'numeral': lem.append('NUM'); continue
        lem.append(tk[0]); name[tk[0]] = tk[1]
    if len(lem) >= 150: docs.append(lem); labs.append(t['corpus'])
df = C(w for d in docs for w in set(d))
vocab = [w for w, k in df.items() if k >= 5]; idx = {w: i for i, w in enumerate(vocab)}
rows, cols, vals = [], [], []
for r, d in enumerate(docs):
    for w, k in C(d).items():
        if w in idx: rows.append(r); cols.append(idx[w]); vals.append(k)
X = csr_matrix((vals, (rows, cols)), shape=(len(docs), len(vocab)))
X = TfidfTransformer(sublinear_tf=True).fit_transform(X)
K = 10
nmf = NMF(n_components=K, init='nndsvd', random_state=0, max_iter=400)
W = nmf.fit_transform(X); Hm = nmf.components_
dom = W.argmax(axis=1); labs = np.array(labs)
pur = sum(C(labs[dom == k]).most_common(1)[0][1] for k in range(K) if (dom == k).any()) / len(docs)
base = C(labs).most_common(1)[0][1] / len(docs)
print(f'{len(docs)} texts (>= 150 words), {len(vocab)} words, {K} topics; each text assigned to its strongest topic; agreement with the editors\' text groups: {pur:.1%} (largest group alone: {base:.1%})')
g = lambda w: 'Zahl' if w == 'NUM' else (gl[w].most_common(1)[0][0][:16] if gl.get(w) else '')
for k in np.argsort(-np.bincount(dom, minlength=K)):
    top = np.argsort(-Hm[k])[:9]
    grp = C(labs[dom == k]).most_common(3)
    print(f'\ntopic {k}: {int((dom == k).sum())} texts; groups: ' + ', '.join(f'{c} {n}' for c, n in grp))
    print('   ' + ' ; '.join(f'{name.get(vocab[i], "NUM")} ({g(vocab[i])})' for i in top))
