import sys, os, re, json, gzip, glob, collections, math, random
import numpy as np, simplemma
latroot, toks_p, texts_p, aes_dir = sys.argv[1:5]; ud_dirs = sys.argv[5:]; random.seed(20261112)
norm = lambda s: s.lower().replace('v', 'u').replace('j', 'i')
GROUP = {**{k: 'Geruest' for k in ('ADP', 'PRON', 'DET', 'CCONJ', 'SCONJ', 'PART', 'AUX', 'ADV', 'NUM', 'INTJ')}, **{k: 'Inhalt' for k in ('NOUN', 'VERB', 'ADJ')}, 'PROPN': 'Namen'}
FORM = collections.defaultdict(collections.Counter); LEM = collections.defaultdict(collections.Counter)
for d in ud_dirs:
    for p in glob.glob(os.path.join(d, '*.conllu')):
        for line in open(p, encoding='utf-8'):
            if line[:1].isdigit():
                c = line.split('\t')
                if '-' in c[0] or '.' in c[0] or c[3] not in GROUP: continue
                FORM[norm(c[1])][GROUP[c[3]]] += 1; LEM[norm(c[2])][GROUP[c[3]]] += 1
TOKRE = re.compile(r"[A-Za-z]+")
def read(paths, cap_total):
    out = []
    for p in paths:
        try: txt = open(os.path.join(latroot, p), encoding='utf-8', errors='ignore').read()
        except FileNotFoundError: continue
        for line in txt.split('\n'):
            if 'Latin Library' in line or 'Classics Page' in line: continue
            first = True
            for m in TOKRE.finditer(line):
                w = m.group(0); pre = line[:m.start()].rstrip(' "\'([0123456789'); out.append((w, first or (pre[-1:] in '.?!:;' if pre else True))); first = False
        if len(out) >= cap_total: break
    return out[:cap_total]
REL = read(['bible/psalms.txt', 'bible/matthew.txt', 'bible/mark.txt', 'bible/luke.txt', 'bible/john.txt', 'bible/genesis.txt'], 112391)
LIT = read([f'caesar/gall{i}.txt' for i in range(1, 8)], 47783) + read([f'vergil/aen{i}.txt' for i in range(1, 13)], 47783) + read([f'ovid/ovid.met{i}.txt' for i in range(1, 16)], 47783) + read(['cicero/cat1.txt', 'cicero/cat2.txt', 'cicero/cat3.txt', 'cicero/cat4.txt', 'cicero/amic.txt', 'cicero/arch.txt', 'cicero/cael.txt', 'cicero/att1.txt', 'cicero/att2.txt', 'cicero/fam1.txt', 'cicero/brut.txt'], 47783)
TEC = read([f'vitruvius{i}.txt' for i in (10, 9, 1)], 18696) + read([f'apicius/apicius{i}.txt' for i in range(1, 6)], 18696) + read(['cato/cato.agri.txt', 'isidore/4.txt', 'isidore/3.txt', 'frontinus/aqua1.txt'], 18696)
capm = collections.Counter(); tot = collections.Counter(); cap = collections.Counter()
for seq in (REL, LIT, TEC):
    for w, ini in seq:
        l = w.lower(); tot[l] += 1
        if w[0].isupper(): cap[l] += 1; capm[l] += (not ini)
name = {l for l in tot if capm[l] >= 1 and cap[l]/tot[l] >= 0.8}; cache = {}
def lat(w):
    l = w.lower()
    if l in name: return 'N:' + l, 'Namen'
    if l not in cache: cache[l] = simplemma.lemmatize(l, lang='la').lower()
    lm = cache[l]; c = FORM.get(norm(l)) or LEM.get(norm(lm))
    return lm, (c.most_common(1)[0][0] if c else 'Inhalt')
chunk = lambda S: [(l, g, i // 1000) for i, (l, g) in enumerate(S)]
R, L, T = chunk([lat(w) for w, _ in REL]), chunk([lat(w) for w, _ in LIT]), chunk([lat(w) for w, _ in TEC])
TK = json.load(gzip.open(toks_p, 'rt', encoding='utf-8'))
EG = {'pronoun': 'Geruest', 'preposition': 'Geruest', 'particle': 'Geruest', 'adverb': 'Geruest', 'numeral': 'Geruest', 'interjection': 'Geruest', 'substantive': 'Inhalt', 'verb': 'Inhalt', 'adjective': 'Inhalt', 'entity_name': 'Namen', 'epitheton_title': 'Namen'}
form = {}
def eg(corpus):
    out = []
    for tid, t in TK.items():
        if t['corpus'] == corpus:
            for k in t['tok']:
                if k[0] and k[2] in EG: out.append((k[0], EG[k[2]], tid)); form.setdefault(k[0], k[1])
    return out
P, EL, EM = eg('bbawpyramidentexte'), eg('sawlit'), eg('sawmedizin')
GR = ('Geruest', 'Inhalt', 'Namen'); BD = ('A', 'B', 'C'); CELLS = [(k, g, b) for k in (1, 2, 3) for g in GR for b in BD]
def build(Pt, A, B):
    Aset = set(x[0] for x in A); Bset = set(x[0] for x in B); c = collections.Counter(x[0] for x in Pt); N = len(Pt); band = {}; acc = 0; nb = collections.Counter(); thr = {}
    for l, n in c.most_common():
        b = 'A' if acc < N/3 else 'B' if acc < 2*N/3 else 'C'; band[l] = b; nb[b] += 1; thr[b] = n; acc += n
    cell = lambda x: (1 if x[0] in Aset else 2 if x[0] in Bset else 3, x[1], band[x[0]])
    toks = [(cell(x), x[0], x[2]) for x in Pt]
    return toks, nb, thr
def dist(toks):
    c = collections.Counter(t[0] for t in toks); n = len(toks); return np.array([c[x]/n for x in CELLS])
def js(p, q):
    m = (p + q)/2; f = lambda a, b: sum(x*math.log2(x/y) for x, y in zip(a, b) if x > 0); return 0.5*f(p, m) + 0.5*f(q, m)
H = lambda p: -sum(x*math.log2(x) for x in p if x > 0)
def marg(p, keep):
    c = collections.Counter()
    for x, v in zip(CELLS, p): c[tuple(x[i] for i in keep)] += v
    return np.array(list(c.values()))
C = {}
for nm_, (Pt, A, B) in {'Pyramidentexte': (P, EL, EM), 'Vulgata': (R, L, T), 'Aeg. Medizin': (EM, EL, P), 'Lat. Fachtexte': (T, L, R)}.items():
    toks, nb, thr = build(Pt, A, B); p = dist(toks); C[nm_] = (toks, p)
    lem = collections.defaultdict(collections.Counter)
    for cl, l, _ in toks: lem[cl][l] += 1
    print(f"\n{nm_}: {len(toks)} words | lemmas per band A/B/C: {nb['A']}/{nb['B']}/{nb['C']} (lowest frequency in band A: {thr['A']}, in B: {thr['B']})")
    print(f"  entropy after level 1 / 2 / 3: {H(marg(p, (0,))):.2f} / {H(marg(p, (0, 1))):.2f} / {H(p):.2f} bits (max 1.58 / 3.17 / 4.75) -> effective cells {2**H(marg(p, (0,))):.1f} / {2**H(marg(p, (0, 1))):.1f} / {2**H(p):.1f} | cells with >=1 word: {int((p > 0).sum())}/27, with >=0.5%: {int((p >= 0.005).sum())}/27, with <30 lemmas but >0: {sum(1 for x in CELLS if 0 < len(lem[x]) < 30)}")
    if nm_ in ('Pyramidentexte', 'Vulgata'):
        for k in (1, 2, 3):
            for g in GR:
                print(f"  K{k} {g:8s} " + ' | '.join(f"{b}: {p[CELLS.index((k, g, b))]:6.2%} ({len(lem[(k, g, b)]):4d} L) " + (' '.join((form.get(x, x) if nm_ == 'Pyramidentexte' else x) for x, _ in lem[(k, g, b)].most_common(3)))[:38] for b in BD))
names = list(C); print('\nJensen-Shannon divergence between the 27-cell distributions (bits; 0 = identical) | same for the 9-cell grid (levels 1-2)')
for i in range(4):
    for j in range(i + 1, 4):
        p, q = C[names[i]][1], C[names[j]][1]
        p9 = np.array([p[CELLS.index((k, g, 'A'))] + p[CELLS.index((k, g, 'B'))] + p[CELLS.index((k, g, 'C'))] for k in (1, 2, 3) for g in GR]); q9 = np.array([q[CELLS.index((k, g, 'A'))] + q[CELLS.index((k, g, 'B'))] + q[CELLS.index((k, g, 'C'))] for k in (1, 2, 3) for g in GR])
        print(f'  {names[i]:15s} vs {names[j]:15s} {js(p, q):.3f} | {js(p9, q9):.3f}')
for nm_ in ('Pyramidentexte', 'Vulgata'):
    toks = C[nm_][0]; units = sorted(set(t[2] for t in toks), key=str); v = []
    for it in range(60):
        random.shuffle(units); half = set(units[:len(units)//2]); a = [t for t in toks if t[2] in half]; b = [t for t in toks if t[2] not in half]; v.append(js(dist(a), dist(b)))
    print(f'  noise floor {nm_}: two random halves of the same corpus {np.mean(v):.4f} ± {np.std(v):.4f}')
# sign level
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*')
def base(s): return re.sub(r'(?<=\d)[A-Za-z]+$', '', s)
TX = json.load(gzip.open(texts_p, 'rt', encoding='utf-8')); Cs = collections.defaultdict(set)
for t in TX.values(): Cs[t['corpus']].update(base(x) for x in t['signs'])
LITs, MEDs = Cs['sawlit'], Cs['sawmedizin']; d = json.load(open(aes_dir + '/_aes_bbawtotenlit.json', encoding='utf-8'))
S = collections.defaultdict(collections.Counter); n = collections.Counter()
for s in d.values():
    for k in s.get('token', []):
        if not k.get('hiero'): continue
        sg = [base(x) for x in SIGN.findall(k['hiero'])]
        for i, b in enumerate(sg): S[b]['Anfang' if i == 0 else 'Ende' if i == len(sg) - 1 else 'Inneres'] += 1; n[b] += 1
N = sum(n.values()); band = {}; acc = 0; nb = collections.Counter()
for b, c in n.most_common():
    band[b] = 'A' if acc < N/3 else 'B' if acc < 2*N/3 else 'C'; nb[band[b]] += 1; acc += c
cell = collections.Counter(); cnt = collections.Counter()
for b, c in n.items():
    x = (1 if b in LITs else 2 if b in MEDs else 3, S[b].most_common(1)[0][0], band[b]); cell[x] += c; cnt[x] += 1
p = np.array(list(cell.values()))/N
print(f"\nSIGNS, ritual papyri: {N} occurrences, {len(n)} signs | signs per band A/B/C: {nb['A']}/{nb['B']}/{nb['C']} | cells used {len(cell)}/27 | entropy {H(p):.2f} bits -> effective cells {2**H(p):.1f}")
for k in (1, 2, 3):
    for g in ('Anfang', 'Inneres', 'Ende'):
        print(f"  K{k} {g:8s} " + ' | '.join(f"{b}: {cell[(k, g, b)]/N:6.2%} ({cnt[(k, g, b)]:3d} Z) " + ' '.join(x for x, _ in sorted(((x, c) for x, c in n.items() if (1 if x in LITs else 2 if x in MEDs else 3, S[x].most_common(1)[0][0], band[x]) == (k, g, b)), key=lambda t: -t[1])[:5]) for b in BD))
