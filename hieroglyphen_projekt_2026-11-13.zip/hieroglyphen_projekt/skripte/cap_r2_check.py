"""Does the scale-free cap rule R2 (count >= 2 and share >= 1/1000) leave the Egyptian and Roman results unchanged?
usage: python3 -I cap_r2_check.py <aes_schrift.jsonl.gz> <latin file-or-dir> [...]"""
import sys, os, gzip, json, re, collections, itertools
C = collections.Counter
runs = lambda seq: [(s, len(list(g))) for s, g in itertools.groupby(seq)]
def cap_r1(h, k=2):
    v = [L for L, c in h.items() if c >= k]; return max(v) if v else None
def cap_r2(h):
    n = sum(h.values()); v = [L for L, c in h.items() if c >= 2 and c / n >= 1e-3]; return max(v) if v else None
segs = []
with gzip.open(sys.argv[1], 'rt', encoding='utf-8') as f:
    for line in f:
        r = json.loads(line); cur = []
        for tk, z in zip(r['tok'], r['zeichen']):
            if z: cur.extend(z)
            else:
                if cur: segs.append(cur); cur = []
        if cur: segs.append(cur)
hist = collections.defaultdict(C)
for s in segs:
    for x, L in runs(s): hist[x][L] += 1
print('Egyptian sign stream (run lengths per sign):')
for s in ('Z1', 'V20', 'V1', 'M12'):
    h = hist[s]
    print(f'  {s:4s} runs {sum(h.values()):6d}  old rule (>=3 times) {cap_r1(h, 3)}, (>=2 times) {cap_r1(h, 2)}, R2 {cap_r2(h)}   ' + ' '.join(f'{L}:{h[L]}' for L in sorted(h)))
paths = []
for p in sys.argv[2:]:
    if os.path.isdir(p):
        for root, _, files in os.walk(p): paths += [os.path.join(root, f) for f in sorted(files) if f.endswith('.txt')]
    else: paths.append(p)
text = ''
for p in paths:
    with open(p, encoding='utf-8', errors='replace') as f: text += f.read() + '\n'
words = re.findall(r"[^\W\d_]+", text)
num = [w for w in words if len(w) >= 2 and all(c in 'IVXLCDM' for c in w)]
h2 = collections.defaultdict(C)
for w in num:
    for s, L in runs(w): h2[s][L] += 1
print(f'Roman numerals ({len(num)} tokens in {len(paths)} files):')
for s in 'IVXLCDM':
    h = h2[s]
    if h: print(f'  {s}    runs {sum(h.values()):6d}  old rule (>=2 times) {cap_r1(h, 2)}, R2 {cap_r2(h)}   ' + ' '.join(f'{L}:{h[L]}' for L in sorted(h)))
