"""Follow-up on the 2/n table: unique cases, large primes inside the 1/a + 1/(n*k) family.
usage: python3 -I rhind_2n_b.py
"""
import sys, math, itertools, random, collections, runpy
C = collections.Counter
import io, contextlib
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    G = runpy.run_path('/home/claude/scripts/rhind_2n.py')
TABLE, CAND, F, SF, cls, feats, tau = (G[k] for k in ('TABLE', 'CAND', 'F', 'SF', 'cls', 'feats', 'tau'))
few = sorted((len(CAND[n]), n) for n in TABLE)[:8]
print('fewest candidates (count, n):', few)
print('candidates by number of terms for n=101:', C(len(t) for t in CAND[101]), CAND[101][:3])
print('n with a unique candidate for the scribes\' number of terms:', [n for n in TABLE if sum(1 for t in CAND[n] if len(t) == len(TABLE[n])) == 1])
# primes: is there any 3-term decomposition <= 999 when the scribes used 4 terms? any 2-term <= 999 when they used 3+?
for n in TABLE:
    if cls[n] != 'prime': continue
    k = len(TABLE[n]); by = C(len(t) for t in CAND[n])
    two = [t for t in CAND[n] if len(t) == 2]
    print(f'  p={n:3d} scribes {k} terms {TABLE[n]} | available: 2-term {by[2]} {two if two else ""}, 3-term {by[3]}, 4-term {by[4]} | min largest denominator with 2/3/4 terms: ' + '/'.join(str(min((t[-1] for t in CAND[n] if len(t) == j), default="-")) for j in (2, 3, 4)))
large = [p for p in TABLE if cls[p] == 'prime' and p >= 13 and p not in (23, 101)]
print('\nlarge primes, family 1/a + sum 1/(p*a/x): scribes\' a, parts x, number of divisors of a, and rank inside the family')
names = ['terms', 'max', 'sum', 'first', 'odd', 'round1', 'first_odd', 'has_x1', 'all_even']
def feats2(t, n):
    f = feats(t, n); a = t[0]
    xs = [n * a // d for d in t[1:]]
    f['has_x1'] = int(1 in xs); f['all_even'] = int(any(d % 2 for d in t)); f['xs'] = xs
    return f
fam = {p: [(t, feats2(t, p)) for t in CAND[p] if all(d % p == 0 for d in t[1:]) and all((p * t[0]) % d == 0 for d in t[1:])] for p in large}
for p in large:
    sf = feats2(TABLE[p], p)
    cands = fam[p]
    r_tm = 1 + sum(1 for t, f in cands if (f['terms'], f['max']) < (sf['terms'], sf['max']))
    r_m = 1 + sum(1 for t, f in cands if f['max'] < sf['max'])
    best_m = min(cands, key=lambda tf: (tf[1]['max'], tf[1]['terms']))[0]
    same_terms = [t for t, f in cands if f['terms'] == sf['terms']]
    best_same = min(same_terms, key=lambda t: t[-1])
    a_tau = sorted(((tau(a), a) for a in range(p // 2 + 1, p)), reverse=True)[:3]
    print(f'  p={p:3d} a={TABLE[p][0]:3d} (divisors {tau(TABLE[p][0]):2d}; most divisors in range: {a_tau}) parts {sf["xs"]} | family size {len(cands):3d} | rank by (terms, largest) {r_tm:3d}, by largest {r_m:3d} | smallest largest overall {best_m} | with the same number of terms {best_same}')
rules = [r for k in (1, 2, 3) for r in itertools.permutations(names, k)]
res = {}
for r in rules:
    hit = set()
    for p in large:
        sf = feats2(TABLE[p], p); sk = tuple(sf[x] for x in r)
        ks = [tuple(f[x] for x in r) for t, f in fam[p]]
        if sum(1 for k in ks if k < sk) == 0 and sum(1 for k in ks if k == sk) == 1: hit.add(p)
    res[r] = hit
best = sorted(res.items(), key=lambda kv: -len(kv[1]))[:6]
print(f'\nrule search inside the family, 19 large primes, {len(rules)} rules:')
for r, hit in best: print(f'  {" > ".join(r):40s} {len(hit)}/19  misses {sorted(set(large) - hit)}')
rng = random.Random(0); cv = []
for _ in range(300):
    ns = large[:]; rng.shuffle(ns); tr, te = set(ns[:10]), set(ns[10:])
    rb = max(res, key=lambda r: len(res[r] & tr)); cv.append(len(res[rb] & te) / len(te))
print(f'out of sample (rule chosen on 10 primes, tested on 9): {sum(cv)/len(cv):.1%}')
# is the scribes' a always the number with the most divisors in (p/2, p)?
print('scribes\' a has the maximal number of divisors among p/2 < a < p:', sum(1 for p in large if tau(TABLE[p][0]) == max(tau(a) for a in range(p // 2 + 1, p))), 'of', len(large))
print('all denominators even in the scribes\' choice:', sum(1 for p in large if all(d % 2 == 0 for d in TABLE[p])), 'of', len(large), '| first denominator even:', sum(1 for p in large if TABLE[p][0] % 2 == 0))
