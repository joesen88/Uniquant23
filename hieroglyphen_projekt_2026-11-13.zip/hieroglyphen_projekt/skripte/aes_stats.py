import json, sys, re, math, glob, os, collections
root = sys.argv[1]
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*')
n_sent = n_tok = n_tok_h = n_sign = 0
texts = set(); dates = collections.Counter(); corp = collections.Counter(); corp_h = collections.Counter()
uni = collections.Counter(); big = collections.Counter(); ctx = collections.Counter()
forms = collections.Counter(); lemmas = collections.Counter(); pos = collections.Counter()
sent_with_h = 0; other = collections.Counter()
spell = collections.defaultdict(set)
for p in sorted(glob.glob(os.path.join(root, '_aes_*.json'))):
    d = json.load(open(p, encoding='utf-8'))
    for sid, s in d.items():
        n_sent += 1; texts.add(s.get('text')); dates[s.get('date')] += 1; corp[s.get('corpus')] += 1
        any_h = False; prev = '<s>'
        for t in s.get('token', []):
            n_tok += 1
            forms[t.get('written_form')] += 1
            if t.get('lemmaID'): lemmas[t['lemmaID']] += 1
            pos[t.get('pos')] += 1
            h = t.get('hiero')
            if h:
                n_tok_h += 1; any_h = True; corp_h[s.get('corpus')] += 1
                signs = SIGN.findall(h)
                rest = SIGN.sub('', h)
                for ch in set(rest): other[ch] += 1
                if t.get('lemmaID'): spell[t['lemmaID']].add(h)
                for sg in signs:
                    n_sign += 1; uni[sg] += 1; big[(prev, sg)] += 1; ctx[prev] += 1; prev = sg
                prev_w = prev
            else:
                prev = '<gap>'
        if any_h: sent_with_h += 1
def H(c):
    n = sum(c.values()); return -sum(v/n*math.log2(v/n) for v in c.values())
H1 = H(uni)
N2 = sum(big.values())
H2 = -sum(v/N2*math.log2(v/ctx[a]) for (a,b),v in big.items())
print('sentences', n_sent, 'texts', len(texts))
print('word tokens', n_tok, 'with hiero', n_tok_h, f'({n_tok_h/n_tok:.1%})', 'sentences with any hiero', sent_with_h)
print('distinct written forms', len(forms), 'distinct lemma IDs', len(lemmas))
print('sign tokens', n_sign, 'sign types', len(uni), 'hapax', sum(1 for v in uni.values() if v==1))
tot = n_sign; acc = 0; marks = {0.5:None,0.8:None,0.9:None,0.95:None,0.99:None}
for i,(sg,v) in enumerate(uni.most_common(),1):
    acc += v
    for m in marks:
        if marks[m] is None and acc/tot >= m: marks[m] = i
print('types needed for coverage', marks)
print('H1 (unigram, bits/sign)', round(H1,3), 'log2|V|', round(math.log2(len(uni)),3), 'H2 cond bigram', round(H2,3))
print('top 25 signs', uni.most_common(25))
print('corpus sentences', dict(corp))
print('corpus tokens with hiero', dict(corp_h))
print('dates top', dates.most_common(12))
print('pos', pos.most_common(12))
ns = sorted((len(v) for v in spell.values()), reverse=True)
print('lemmas with hiero spellings', len(ns), 'mean spellings/lemma', round(sum(ns)/len(ns),2), 'max', ns[:5])
print('non-sign chars in hiero field', other.most_common(20))
