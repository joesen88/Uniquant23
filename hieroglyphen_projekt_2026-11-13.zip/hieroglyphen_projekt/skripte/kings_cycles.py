"""Kings' names: used like names of persons or like names of recurring cycles? (criteria: kings_cycles_prereg.txt)
usage: python3 -I kings_cycles.py <dir with _aes_*.json>"""
# Note 2026-11-13: the regnal-year check below looks for the lemma ḥꜣ.t-zp and finds nothing; the lemma is rnp.t-zp.
# Valid counts: kings_weather.py (via the gloss 'Regierungsjahr') and regnal_years.py.
import sys, os, json, re, collections, statistics
C = collections.Counter
d = sys.argv[1]
SEASON = {'154850', '60300', '216'}
KIN = re.compile(r'\b(Sohn|Tochter|Mutter|Vater|Ehefrau|Gemahlin|Gattin|Bruder|Schwester|Kind)\b|gebären|geboren')
LIFE = re.compile(r'\bleben|lebendig|ewig|Ewigkeit|gerechtfertigt|Gerechtfertigter|Leben, Heil')
def cls(tk):
    nm = tk.get('name')
    if nm == 'kings_name': return 'kings'
    if nm == 'person_name': return 'persons'
    if nm == 'gods_name': return 'gods'
    if tk.get('lemmaID') in SEASON: return 'seasons'
    return None
tot = collections.defaultdict(C); hit = collections.defaultdict(lambda: collections.defaultdict(C))
epoch = collections.defaultdict(C); regyear = C()
for fn in sorted(os.listdir(d)):
    if not fn.startswith('_aes_'): continue
    data = json.load(open(os.path.join(d, fn), encoding='utf-8'))
    for sid, s in data.items():
        toks = s['token']; n = len(toks); pt = s['corpus'] == 'bbawpyramidentexte'
        isnum = [tk.get('lemma_form') == '1...n' or tk.get('pos') == 'numeral' for tk in toks]
        tr = [tk.get('cotext_translation') or '' for tk in toks]
        iskin = [bool(KIN.search(x)) for x in tr]; islife = [bool(LIFE.search(x)) or tk.get('lemma_form') in ('mꜣꜥ-ḫrw', 'ḏ.t', 'ꜥnḫ-wḏꜣ-snb') for x, tk in zip(tr, toks)]
        istitle = [tk.get('pos') == 'epitheton_title' for tk in toks]
        for i, tk in enumerate(toks):
            c = cls(tk)
            if not c: continue
            for scope in (('all',) if pt else ('all', 'without Pyramid Texts')):
                tot[scope][c] += 1
                if any(isnum[max(0, i - 2):i + 3]): hit[scope]['number within two words'][c] += 1
                if any(iskin[max(0, i - 3):i + 4]): hit[scope]['kinship word within three words'][c] += 1
                if any(islife[i + 1:i + 4]): hit[scope]['life formula in the next three words'][c] += 1
                if any(istitle[max(0, i - 3):i]): hit[scope]['title directly before'][c] += 1
            if c in ('kings', 'seasons') and s.get('date') in ('OK & FIP', 'MK & SIP', 'NK', 'TIP - Roman times'):
                epoch[(c, tk.get('lemma_form'))][s['date']] += 1
            if c == 'kings' and any((t.get('lemma_form') or '').startswith('ḥꜣ.t-zp') for t in toks[max(0, i - 10):i]): regyear['king name after a regnal-year formula'] += 1
    del data
for scope in ('all', 'without Pyramid Texts'):
    print(f'\n[1] company of the name ({scope}); tokens:', dict(tot[scope]))
    closer = C()
    for m in ('number within two words', 'kinship word within three words', 'life formula in the next three words', 'title directly before'):
        sh = {c: hit[scope][m][c] / tot[scope][c] for c in ('kings', 'persons', 'gods', 'seasons')}
        side = 'persons' if abs(sh['kings'] - sh['persons']) < abs(sh['kings'] - sh['seasons']) else 'seasons'; closer[side] += 1
        print(f'   {m:38s} kings {sh["kings"]:6.1%} | persons {sh["persons"]:6.1%} | gods {sh["gods"]:6.1%} | seasons {sh["seasons"]:6.1%}   -> kings closer to {side}')
    print('   kings closer to persons on', closer['persons'], 'of 4 measures, closer to seasons on', closer['seasons'])
print('\n   kings\' names that follow a regnal-year formula in the same sentence:', regyear['king name after a regnal-year formula'], 'of', tot['all']['kings'])
print('\n[2] return over time: share of a name\'s occurrences in its most frequent period')
conc = {}
for (c, name), e in epoch.items():
    n = sum(e.values())
    if c == 'seasons' or n >= 30: conc[(c, name)] = (max(e.values()) / n, n, dict(e))
ks = sorted((v[0] for k, v in conc.items() if k[0] == 'kings'))
print(f'   kings\' names with at least 30 dated occurrences: {len(ks)}; median share in one period {statistics.median(ks):.1%}; lowest {ks[0]:.1%}; names with 100 %: {sum(1 for x in ks if x == 1.0)}')
for k, v in sorted(conc.items(), key=lambda kv: kv[1][0]):
    if k[0] == 'seasons' or v[0] < 0.999: print(f'   {k[0]:8s} {k[1]:28s} {v[0]:6.1%} of {v[1]:5d}   {v[2]}')
