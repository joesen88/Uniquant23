"""Anchored test, wider version (written AFTER the registered weight-only version gave only 19 sums):
commodity-matched totals for weights (gu2, ma-na, gin2) and capacities (barig, ban2, sila3, gin2).
A quantity counts as a total if the word szunigin stands directly before it; items = same commodity word, earlier in the object.
usage: python3 -I cdli_sums2.py <cdli_ur3.jsonl.gz>"""
import sys, gzip, json, re, collections, itertools
from fractions import Fraction as Fr
import numpy as np
C = collections.Counter
EL = re.compile(r'^(\d+)(?:/(\d+))?\(([^()]+)\)(.*)$'); GL = re.compile(r'^(?:\{[^{}]*\})+')
def parse_line(body):
    items = []; cur = None
    for t in body.split():
        m = EL.match(t)
        if m:
            cnt, den, name, suf = m.groups(); suf = GL.sub('', suf)
            el = (1, f'{cnt}/{den}({name})', True) if den else (int(cnt), name, False)
            if cur is None:
                cur = []; items.append(('P', cur))
            cur.append(el)
            if suf: items.append(('W', suf)); cur = None
        else:
            items.append(('W', t)); cur = None
    return items
SIGNS = ['1/3(disz)', '1/2(disz)', '2/3(disz)', '5/6(disz)']
TRUE = [Fr(1, 3), Fr(1, 2), Fr(2, 3), Fr(5, 6)]
S = {'disz': 1, 'asz': 1, 'u': 10, 'gesz2': 60, "gesz'u": 600, 'szar2': 3600}
WU = {'gu2': 3600, 'ma-na': 60, 'gin2': 1}
TOT = re.compile(r'^szunigin2?$|^szu[-+]nigin2?$')
def add(ph, scale, vals, qf):
    """integer value of a phrase in units of `scale`; fraction signs go to qf. returns (value, bad)"""
    v = 0; bad = False
    for cnt, s, fr in ph:
        if fr:
            if s in SIGNS: qf[s] += scale
            else: bad = True
        elif s in vals: v += cnt * vals[s] * scale
        else: bad = True
    return v, bad
def quantities(it):
    out = []; i = 0; n = len(it)
    W = lambda k: it[k][1] if k < n and it[k][0] == 'W' else None
    P = lambda k: it[k][1] if k < n and it[k][0] == 'P' else None
    while i < n:
        ph = P(i)
        if ph is None: i += 1; continue
        qf = C(); qi = 0; bad = False; kind = None; j = i
        if W(i + 1) in ('gu2', 'ma-na'):
            kind = 'w'; last = None
            while P(j) is not None and W(j + 1) in WU:
                sc = WU[W(j + 1)]
                if last is not None and sc >= last: break
                v, b = add(P(j), sc, S, qf); qi += v; bad |= b; last = sc; j += 2
            if P(j) is not None and (W(j + 1) or '').split('-')[0] == 'sze': bad = True
        elif W(i + 1) == 'sila3' or any(s in ('barig', 'ban2') for _, s, _ in ph):
            kind = 'c'
            if any(s in ('asz', 'gesz2', "gesz'u", 'szar2') for _, s, _ in ph): bad = True
            hascap = any(s in ('barig', 'ban2') for _, s, _ in ph)
            v, b = add(ph, 60, {'barig': 60, 'ban2': 10, 'disz': 1, 'u': 10}, qf); qi += v; bad |= b
            if hascap and any(s == 'u' for _, s, _ in ph): bad = True
            j = i + 2 if W(i + 1) == 'sila3' else i + 1
            if P(j) is not None and W(j + 1) == 'gin2':
                v, b = add(P(j), 1, S, qf); qi += v; bad |= b; j += 2
        elif W(i + 1) == 'gin2':
            kind = 'g'; v, b = add(ph, 1, S, qf); qi += v; bad |= b; j = i + 2
            if P(j) is not None and (W(j + 1) or '').split('-')[0] == 'sze': bad = True
        else:
            i += 1; continue
        if i > 0 and W(i - 1) == 'la2': bad = True
        if W(j) is not None and (W(j).startswith('igi-') or W(j) == 'la2'): bad = True
        com = W(j)
        out.append({'v': qi, 'f': qf, 'bad': bad, 'kind': kind, 'com': com, 'tot': i > 0 and W(i - 1) is not None and bool(TOT.match(W(i - 1)))})
        i = max(j, i + 1)
    return out
eqs = []; stat = C()
with gzip.open(sys.argv[1], 'rt', encoding='utf-8') as f:
    for line in f:
        t = json.loads(line)
        for o in t['o']:
            if not all(cl for cl, _ in o): continue
            stat['objects with all lines clean'] += 1
            qs = [q for cl, body in o for q in quantities(parse_line(body))]
            if not any(q['tot'] for q in qs): continue
            stat['  with at least one total quantity'] += 1
            bycom = collections.defaultdict(list)
            for q in qs:
                if q['com']: bycom[q['com']].append(q)
            for com, L in bycom.items():
                tots = [k for k, q in enumerate(L) if q['tot']]
                if len(tots) != 1: continue
                k = tots[0]; items = L[:k]; T = L[k]
                if len(items) < 2: continue
                stat['commodity blocks: one total, >= 2 items before it'] += 1
                if T['bad'] or any(q['bad'] for q in items): stat['  dropped: la2 / igi-n-gal2 / sze / other signs'] += 1; continue
                c = C()
                for q in items: c.update(q['f'])
                c.subtract(T['f'])
                nsig = sum(len(q['f']) for q in items) + len(T['f'])
                eqs.append(([c[s] for s in SIGNS], T['v'] - sum(q['v'] for q in items), t['p'], nsig, com, T['kind'], t['prov']))
for k, v in stat.items(): print(f'  {k}: {v:,}')
holds = lambda e, vals: sum(ci * v for ci, v in zip(e[0], vals)) == e[1]
nofr = [e for e in eqs if not e[3]]; fr = [e for e in eqs if e[3]]; inf = [e for e in eqs if any(e[0])]
print(f'usable sums: {len(eqs):,}')
print(f'  without any fraction sign (parser check): {len(nofr):,}, exact {sum(1 for e in nofr if e[1] == 0):,} = {sum(1 for e in nofr if e[1] == 0)/max(1,len(nofr)):.1%}')
print(f'  with a fraction sign: {len(fr):,}; informative (net coefficient non-zero): {len(inf):,}; exact under the textbook values: {sum(1 for e in inf if holds(e, TRUE)):,} = {sum(1 for e in inf if holds(e, TRUE))/max(1,len(inf)):.1%}')
print('  informative sums by commodity word:', C(e[4] for e in inf).most_common(12))
print('  by kind of total (w weight, c capacity, g bare gin2):', C(e[5] for e in inf).most_common(), '| by provenience:', C(e[6].split(' (')[0] for e in inf).most_common(5))
print('\nper sign: sums in which only this sign has a non-zero net coefficient -> implied value (count)')
for k, s in enumerate(SIGNS):
    imp = C()
    for e in inf:
        cv = e[0]
        if cv[k] and not any(c for j, c in enumerate(cv) if j != k): imp[Fr(e[1], cv[k])] += 1
    tot = sum(imp.values())
    print(f'   sign {"abcd"[k]} (= {s}): {tot:5d} sums; implied: ' + ', '.join(f'{v} x{n} ({n/tot:.0%})' for v, n in imp.most_common(5)))
VALS = sorted(set([Fr(5, 6), Fr(3, 4), Fr(2, 3), Fr(1, 2), Fr(1, 3), Fr(1, 4), Fr(1, 5), Fr(1, 6), Fr(3, 20), Fr(1, 8)] + [Fr(1, d) for d in (7, 9, 10, 12, 15, 16, 20, 24, 30, 32, 36, 40, 48, 50, 60, 64, 70, 72, 80, 84, 90, 96, 108, 100, 120, 160, 200, 240, 300, 320)]), reverse=True)
SC = 302400
VI = np.array([int(v * SC) for v in VALS], dtype=np.int64)
perm = np.array(list(itertools.permutations(range(len(VALS)), 4)), dtype=np.int16); PV = VI[perm]
uniq = C((tuple(e[0]), e[1]) for e in inf)
cnt = np.zeros(len(perm), dtype=np.int64)
for (cvec, D), m in uniq.items():
    cnt += m * (PV @ np.array(cvec, dtype=np.int64) == D * SC)
order = np.argsort(-cnt, kind='stable')
trow = int(np.where((perm == np.array([VALS.index(v) for v in TRUE])).all(axis=1))[0][0])
print(f'\nall {len(perm):,} assignments of four distinct candidate values (signs a, b, c, d): exact sums out of {len(inf):,}')
for r in order[:6]:
    print(f'   {int(cnt[r]):5d}   {[str(VALS[i]) for i in perm[r]]}' + ('   <- textbook' if r == trow else ''))
print(f'  textbook assignment: {int(cnt[trow]):,} exact; assignments with more: {int((cnt > cnt[trow]).sum())}; with as many: {int((cnt == cnt[trow]).sum()) - 1}; runner-up: {int(cnt[order[1]]) if order[0] == trow else int(cnt[order[0]])}')
# best achievable when one sign is wrong: how strongly is each sign pinned?
for k in range(4):
    mask = np.ones(len(perm), dtype=bool)
    for j in range(4):
        if j != k: mask &= perm[:, j] == VALS.index(TRUE[j])
    sub = np.where(mask)[0]; sub = sub[np.argsort(-cnt[sub])]
    print(f'  sign {"abcd"[k]}: other three fixed at textbook, best values for this sign: ' + ', '.join(f'{VALS[perm[r][k]]} -> {int(cnt[r])}' for r in sub[:3]))
# split halves by P-number parity
for name, sel in (('even P-numbers', [e for e in inf if e[2] % 2 == 0]), ('odd P-numbers', [e for e in inf if e[2] % 2 == 1])):
    u2 = C((tuple(e[0]), e[1]) for e in sel); c2 = np.zeros(len(perm), dtype=np.int64)
    for (cvec, D), m in u2.items(): c2 += m * (PV @ np.array(cvec, dtype=np.int64) == D * SC)
    b = int(np.argmax(c2)); print(f'  {name}: {len(sel)} sums; best assignment {[str(VALS[i]) for i in perm[b]]} with {int(c2[b])}; unique: {int((c2 == c2[b]).sum()) == 1}')
