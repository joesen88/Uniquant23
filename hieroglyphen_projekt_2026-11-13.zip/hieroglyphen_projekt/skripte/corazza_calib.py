"""Calibration of the four evaluation measures of Corazza et al. 2021 (my reconstruction) on Egyptian and cuneiform fractions.
Criteria: corazza_calib_prereg.txt.
usage: python3 -I corazza_calib.py <aes_tokens_cache.json.gz> <path to corazza_goptimal.py>"""
import sys, gzip, json, re, math, itertools, collections, runpy
from fractions import Fraction as Fr
import numpy as np
C = collections.Counter
SC = 302400
VALS = sorted(set([Fr(5, 6), Fr(3, 4), Fr(2, 3), Fr(1, 2), Fr(1, 3), Fr(1, 4), Fr(1, 5), Fr(1, 6), Fr(3, 20), Fr(1, 8)] + [Fr(1, d) for d in (7, 9, 10, 12, 15, 16, 20, 24, 30, 32, 36, 40, 48, 50, 60, 64, 70, 72, 80, 84, 90, 96, 108, 100, 120, 160, 200, 240, 300, 320)]), reverse=True)
VI = np.array([int(v * SC) for v in VALS], dtype=np.int64); DENV = np.array([v.denominator for v in VALS], dtype=np.int64); VF = np.array([float(v) for v in VALS])
TYP = [Fr(5, 6), Fr(3, 4), Fr(2, 3), Fr(1, 2), Fr(1, 3), Fr(1, 4), Fr(1, 5), Fr(1, 6), Fr(3, 20), Fr(1, 8), Fr(1, 10), Fr(1, 16), Fr(1, 20), Fr(1, 32), Fr(1, 40), Fr(1, 64), Fr(1, 80), Fr(1, 160), Fr(1, 320)]
W = np.zeros((323, 322))
for q in range(2, 321):
    for D in range(2, 321):
        W[q, D] = sum(1.0 / (m * q - 1) for m in range(1, D // q + 1))

def ranks_rows(X):
    less = (X[:, None, :] < X[:, :, None]).sum(axis=2); eq = (X[:, None, :] == X[:, :, None]).sum(axis=2)
    return less + (eq + 1) / 2.0
def m1_freqdiv(vals, f, chunk=200000):
    """vals: (N, k) integer-scaled values; f: frequencies per sign -> 1 - Spearman(f, number of dividing other signs)"""
    rf = ranks_rows(np.array([f], dtype=np.float64))[0]; rfc = rf - rf.mean(); sf = math.sqrt((rfc ** 2).sum())
    out = np.empty(len(vals)); k = vals.shape[1]
    for a in range(0, len(vals), chunk):
        v = vals[a:a + chunk]; ncd = np.zeros(v.shape, dtype=np.float64)
        for i in range(k):
            for j in range(k):
                if i != j: ncd[:, i] += (v[:, i] % v[:, j] == 0)
        rn = ranks_rows(ncd); rnc = rn - rn.mean(axis=1, keepdims=True); sn = np.sqrt((rnc ** 2).sum(axis=1))
        with np.errstate(invalid='ignore', divide='ignore'):
            out[a:a + chunk] = 1 - np.where((sn > 0) & (sf > 0), (rnc * rfc).sum(axis=1) / (sn * sf), 0.0)
    return out
def m2_ambcombs(vals, runs):
    """runs: list of tuples of sign positions -> number of pairs of runs with equal sums"""
    sums = [vals[:, list(r)].sum(axis=1) for r in runs]; out = np.zeros(len(vals), dtype=np.int32)
    for a, b in itertools.combinations(range(len(runs)), 2): out += (sums[a] == sums[b])
    return out
def m3_typ(valfr_ok, idx):
    return (~valfr_ok[idx]).sum(axis=1)
def m4_goptimal(vals, dens, chunk=None):
    """vals: (N, k) integer-scaled sign values (scale SC), dens: (N, k) denominators -> G_Optimal (closed form of the validated reading)"""
    N, k = vals.shape
    ms = [c for L in range(1, 5) for c in itertools.combinations_with_replacement(range(k), L)]
    Mult = np.zeros((len(ms), k), dtype=np.int64); Len = np.array([len(c) for c in ms], dtype=np.int64)
    for r, c in enumerate(ms):
        for i in c: Mult[r, i] += 1
    chunk = chunk or max(1000, 12_000_000 // len(ms)); out = np.empty(N)
    for a in range(0, N, chunk):
        v = vals[a:a + chunk]; D = dens[a:a + chunk].max(axis=1)
        key = np.sort((v @ Mult.T) * 8 + Len[None, :], axis=1)
        s = key >> 3; L = key & 7
        first = np.ones(s.shape, dtype=bool); first[:, 1:] = s[:, 1:] != s[:, :-1]
        amb = np.zeros(s.shape, dtype=bool); amb[:, :-1] = (s[:, :-1] == s[:, 1:]) & (L[:, :-1] == L[:, 1:])
        good = first & ~amb & (s < SC)
        q = SC // np.gcd(s, SC); q = np.where(q > 320, 322, q)
        w = W[q, np.minimum(D, 320)[:, None]]
        out[a:a + chunk] = 1 - (w * good).sum(axis=1) / (D - 1)
    return out
def standing(g, row, label, lower=True):
    x = g if lower else -g; eps = 1e-9
    better = int((x < x[row] - eps).sum()); tie = int((np.abs(x - x[row]) <= eps).sum())
    pct = 100 * (better + tie) / len(g)
    print(f'     {label:44s} true value {g[row]:8.4f} | {better:,} better, {tie:,} tied of {len(g):,} -> within the best {pct:.3f} %  {"PASS" if pct <= 1 else "fail"}')
    return better, tie, pct
def pipeline(m1, m2, m3, m4, row, label):
    for name, mult in (('raw product', m1 * m2 * m3), ('shifted product', m1 * (1 + m2) * (1 + m3))):
        k = max(1, math.ceil(len(mult) * 5000 / 3794740)); cut = np.partition(mult, k - 1)[k - 1]
        keep = mult <= cut + 1e-12; n = int(keep.sum())
        if keep[row]:
            g = m4[keep]; r = int(np.where(np.where(keep)[0] == row)[0][0]); eps = 1e-9
            better = int((g < g[r] - eps).sum()); tie = int((np.abs(g - g[r]) <= eps).sum())
            print(f'     pipeline, {name:15s} ({label}): cut keeps {n:,} of {len(mult):,}; true assignment kept; by G_Optimal {better:,} better, {tie:,} tied -> best {100 * (better + tie) / n:.2f} % of the survivors')
        else:
            print(f'     pipeline, {name:15s} ({label}): cut keeps {n:,} of {len(mult):,}; true assignment NOT kept (its product {mult[row]:.4f}, cut {cut:.4f}; {int((mult < mult[row] - 1e-12).sum()):,} candidates have a smaller product)')

if __name__ == '__main__':
    g_py = runpy.run_path(sys.argv[2], run_name='x')['g_optimal']
    rng = np.random.default_rng(1)
    # --- check of the vectorised G_Optimal against the plain implementation
    for k in (4, 6, 10):
        idx = np.array([sorted(rng.choice(len(VALS), k, replace=False)) for _ in range(6)])
        a = m4_goptimal(VI[idx], DENV[idx]); b = [g_py([VALS[i] for i in r])[0] for r in idx]
        assert np.allclose(a, b, atol=1e-9), (k, a, b)
    print('vectorised G_Optimal agrees with the plain implementation on random sets of 4, 6 and 10 signs')

    # ================= Egyptian =================
    T = json.load(gzip.open(sys.argv[1], 'rt', encoding='utf-8'))
    clean = lambda w: re.sub(r'[\[\]⸢⸣()\?{}〈〉<>\s⸮]', '', w or '')
    SIX = ['1/2', '1/4', '1/8', '1/16', '1/32', '1/64']
    freq = collections.defaultdict(C); comp = C()
    for t in T.values():
        toks = t['tok']; p0 = 0
        for L in t['sl']:
            s = toks[p0:p0 + L]; p0 += L; run = []
            for tk in s + [(None, None, None, None)]:
                w = clean(tk[3]) if tk[1] == '1...n' else None
                if w in SIX: run.append(w); freq[t['corpus']][w] += 1
                else:
                    if len(run) >= 2: comp[tuple(run)] += 1
                    run = []
    pos = {x: i for i, x in enumerate(SIX)}
    compounds = sorted(set(tuple(sorted(pos[x] for x in set(c))) for c in comp if len(set(c)) == len(c)))
    def hard(idx):
        vals = VF[idx]; k = idx.shape[1]; ok = np.ones(len(idx), dtype=bool)
        for cset in compounds:
            ssum = vals[:, list(cset)].sum(axis=1); ok &= ssum < 1 - 1e-12
            for j in range(k): ok &= np.abs(ssum - vals[:, j]) > 1e-12
        return idx[ok]
    truth = [VALS.index(Fr(x)) for x in SIX]
    allidx = hard(np.array(list(itertools.combinations(range(len(VALS)), 6)), dtype=np.int64))
    pre = [i for i in range(len(VALS)) if VALS[i] < Fr(1, 8)]
    preidx = hard(np.array([truth[:3] + list(c) for c in itertools.combinations(pre, 3)], dtype=np.int64))
    f_all = [sum(freq[c][x] for c in freq) for x in SIX]
    f_nomed = [sum(freq[c][x] for c in freq if c != 'sawmedizin') for x in SIX]
    f_arch = [freq['bbawarchive'][x] for x in SIX]
    runs_eg = [tuple(pos[x] for x in c) for c in comp]
    print(f'\n[Egyptian] frequencies of 1/2 ... 1/64: all texts {f_all}; without medical recipes {f_nomed}; archives only {f_arch}; attested run types: {len(runs_eg)}')
    typ_pub = np.array([v in TYP for v in VALS]); typ_eg = np.array([v in TYP and v not in (Fr(1, 32), Fr(1, 64)) for v in VALS]); typ_cu = np.array([v in TYP and v != Fr(5, 6) for v in VALS])
    for label, idx in (('all six values unknown', allidx), ('three largest given as premise', preidx)):
        row = int(np.where((idx == np.array(truth)).all(axis=1))[0][0]); vals = VI[idx]
        print(f'  {label}: {len(idx):,} candidates')
        m1 = {}
        for fl, f in (('all texts', f_all), ('without medical recipes', f_nomed), ('archives only', f_arch)):
            m1[fl] = m1_freqdiv(vals, f); standing(m1[fl], row, f'M1 frequency vs divisors [{fl}]')
        m2 = m2_ambcombs(vals, runs_eg); standing(m2.astype(float), row, 'M2 runs with equal sums')
        m3p = m3_typ(typ_pub, idx); standing(m3p.astype(float), row, 'M3 typology, list as published (circular)')
        m3 = m3_typ(typ_eg, idx); standing(m3.astype(float), row, 'M3 typology, list without 1/32 and 1/64')
        m4 = m4_goptimal(vals, DENV[idx]); standing(m4, row, 'M4 G_Optimal')
        for fl in ('all texts', 'without medical recipes', 'archives only'): pipeline(m1[fl], m2, m3, m4, row, fl)

    # ================= cuneiform =================
    TRUE = [Fr(1, 3), Fr(1, 2), Fr(2, 3), Fr(5, 6)]; f_cu = [5324, 12053, 4050, 1761]
    perm = np.array(list(itertools.permutations(range(len(VALS)), 4)), dtype=np.int64)
    row = int(np.where((perm == np.array([VALS.index(v) for v in TRUE])).all(axis=1))[0][0]); vals = VI[perm]
    print(f'\n[cuneiform] signs 1/3, 1/2, 2/3, 5/6 with frequencies {f_cu}: {len(perm):,} ordered assignments')
    m1 = m1_freqdiv(vals, f_cu); standing(m1, row, 'M1 frequency vs divisors')
    print('     M2 runs with equal sums                     not testable: the four signs are never combined')
    m3p = m3_typ(typ_pub, perm); standing(m3p.astype(float), row, 'M3 typology, list as published (circular)')
    m3 = m3_typ(typ_cu, perm); standing(m3.astype(float), row, 'M3 typology, list without 5/6')
    m4 = m4_goptimal(vals, DENV[perm]); standing(m4, row, 'M4 G_Optimal')
    best = perm[np.argsort(m4, kind='stable')[:1]][0]
    print('       best set under G_Optimal:', sorted((str(VALS[i]) for i in best), key=lambda x: -Fr(x)), f'{m4.min():.4f}')
    pipeline(m1, np.zeros(len(perm), dtype=np.int32), m3, m4, row, 'Ur III')
    np.save('/tmp/corazza_cu_m.npy', np.stack([m1, m3, m4]))
