import sys, os, re, glob, collections
import simplemma
root = sys.argv[1]
TOKRE = re.compile(r"[A-Za-z]+")
def read(paths, cap_total, cap_each=None):
    out = []
    for p in paths:
        try: txt = open(os.path.join(root, p), encoding='utf-8', errors='ignore').read()
        except FileNotFoundError: continue
        seq = []
        for line in txt.split('\n'):
            if 'Latin Library' in line or 'Classics Page' in line: continue
            first = True
            for m in TOKRE.finditer(line):
                w = m.group(0); pre = line[:m.start()].rstrip(' "\'([0123456789')
                initial = first or (pre[-1:] in '.?!:;' if pre else True)
                seq.append((w, initial)); first = False
        if cap_each: seq = seq[:cap_each]
        out += seq
        if len(out) >= cap_total: break
    return out[:cap_total]
REL = read(['bible/psalms.txt', 'bible/matthew.txt', 'bible/mark.txt', 'bible/luke.txt', 'bible/john.txt', 'bible/genesis.txt'], 112391)
lit_files = [f'caesar/gall{i}.txt' for i in range(1, 8)]
LIT = read(lit_files, 47783) + read([f'vergil/aen{i}.txt' for i in range(1, 13)], 47783) + read([f'ovid/ovid.met{i}.txt' for i in range(1, 16)], 47783) + read(['cicero/cat1.txt', 'cicero/cat2.txt', 'cicero/cat3.txt', 'cicero/cat4.txt', 'cicero/amic.txt', 'cicero/arch.txt', 'cicero/cael.txt', 'cicero/att1.txt', 'cicero/att2.txt', 'cicero/fam1.txt', 'cicero/brut.txt'], 47783)
TEC = read([f'vitruvius{i}.txt' for i in (10, 9, 1)], 18696, 6232*3) [:18696] + read([f'apicius/apicius{i}.txt' for i in range(1, 6)], 18696) + read(['cato/cato.agri.txt', 'isidore/4.txt', 'isidore/3.txt', 'frontinus/aqua1.txt'], 18696)
print('tokens: religious', len(REL), 'literary', len(LIT), 'technical', len(TEC))
# proper-name heuristic over all three
capm = collections.Counter(); tot = collections.Counter(); cap = collections.Counter()
for seq in (REL, LIT, TEC):
    for w, ini in seq:
        l = w.lower(); tot[l] += 1
        if w[0].isupper(): cap[l] += 1; capm[l] += (not ini)
name = {l for l in tot if capm[l] >= 1 and cap[l]/tot[l] >= 0.8}
cache = {}
def lem(w):
    l = w.lower()
    if l in name: return 'N:' + l
    if l not in cache: cache[l] = simplemma.lemmatize(l, lang='la').lower()
    return cache[l]
R = collections.Counter(lem(w) for w, _ in REL); L = collections.Counter(lem(w) for w, _ in LIT); T = collections.Counter(lem(w) for w, _ in TEC)
def part(P, A, B, title):
    N = sum(P.values()); c1 = {k: v for k, v in P.items() if k in A}; c2 = {k: v for k, v in P.items() if k not in A and k in B}; c3 = {k: v for k, v in P.items() if k not in A and k not in B}
    print(f'\n{title}: {N} words, {len(P)} lemmas')
    for lab, c in (('class1 also in literary', c1), ('class2 not literary but technical', c2), ('class3 rest', c3)):
        t = sum(c.values()); nm = sum(v for k, v in c.items() if k.startswith('N:'))
        print(f'  {lab:34s} {len(c):5d} lemmas = {len(c)/len(P):6.1%} | {t:6d} words = {t/N:6.2%} | names among them {nm/max(t,1):.0%} | count<=2: {sum(1 for v in c.values() if v <= 2)}/{len(c)}')
    for lab, c in (('class2', c2), ('class3', c3)): print(f'  {lab} top:', ', '.join(f'{k} {v}' for k, v in sorted(c.items(), key=lambda x: -x[1])[:22]))
part(R, L, T, 'LATIN religious (Vulgate: Psalms, Gospels) vs literary (Caesar, Vergil, Ovid, Cicero) and technical (Vitruvius, Apicius, Cato, Isidore, Frontinus)')
part(T, L, R, 'LATIN technical vs literary and religious')
# character level
chars = lambda seq: collections.Counter(ch for w, _ in seq for ch in w.lower())
cr, cl = chars(REL), chars(LIT); print('\nletters in religious not in literary:', {c: n for c, n in cr.items() if c not in cl}, '| alphabet size religious', len(cr), 'literary', len(cl))
