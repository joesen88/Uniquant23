"""Do the texts document natural events (storms, earthquakes, floods)? Search the editors' German glosses and translations.
usage: python3 -I events_check.py <aes_deutung_token.jsonl.gz> <aes_deutung_satz.jsonl.gz> <aes_kontext.jsonl.gz>
"""
import sys, gzip, json, re, collections

C = collections.Counter
tok_p, satz_p, ctx_p = sys.argv[1:4]
CAT = {
    'Sturm/Gewitter/Donner': r'\bSturm|\bUnwetter|\bGewitter|\bDonner|\bdonnern|\bBlitz|\bHagel|\bOrkan|\bWirbelwind|\bWolkenbruch',
    'Regen/Wolken': r'\bRegen\b|\bregnen|\bWolke|\bBewölkung|\bGewölk',
    'Beben/Zittern (Erde)': r'\bErdbeben|\bbeben\b|\berbeben|\bErschütterung|\berzittern|\bzittern',
    'Flut/Überschwemmung': r'\bÜberschwemmung|\bNilflut|\bFlut\b|\bHochwasser|\büberschwemmen|\büberfluten|\bNilüberschwemmung',
    'Finsternis': r'\bFinsternis|\bVerfinsterung|\bDunkelheit',
    'Hunger/Seuche/Dürre': r'\bHungersnot|\bHunger\b|\bSeuche|\bPest\b|\bDürre',
}
RX = {k: re.compile(v) for k, v in CAT.items()}
corp = {}
with gzip.open(ctx_p, 'rt', encoding='utf-8') as f:
    for line in f:
        r = json.loads(line); corp[r['text']] = r['korpus']
ntok = C(); cnt = collections.defaultdict(C); lem = collections.defaultdict(C)
sent_cat = collections.defaultdict(set); sent_date = set(); sent_flood = set(); sent_text = {}
with gzip.open(tok_p, 'rt', encoding='utf-8') as f:
    for line in f:
        r = json.loads(line); c = corp.get(r['text'], '?'); ntok[c] += 1
        t = r.get('cotext_translation') or ''
        lf = r.get('lemma_form') or ''
        if lf == 'rnp.t-zp': sent_date.add(r['satz'])
        for k, rx in RX.items():
            if rx.search(t):
                cnt[k][c] += 1; lem[k][(lf, t[:30])] += 1; sent_cat[r['satz']].add(k)
        sent_text[r['satz']] = r['text']
N = sum(ntok.values())
print(f'tokens {N}')
for k in CAT:
    tot = sum(cnt[k].values())
    print(f'\n{k}: {tot} tokens = {1e5*tot/N:.0f} per 100k')
    print('   by group (per 100k of the group):', ', '.join(f'{c} {n} ({1e5*n/ntok[c]:.0f})' for c, n in cnt[k].most_common(7)))
    print('   words:', ' ; '.join(f'{lf} "{t}" {n}' for (lf, t), n in lem[k].most_common(9)))
ev = {s for s, ks in sent_cat.items() if ks & {'Sturm/Gewitter/Donner', 'Beben/Zittern (Erde)', 'Flut/Überschwemmung', 'Finsternis', 'Hunger/Seuche/Dürre'}}
both = ev & sent_date
print(f'\nsentences with an event word: {len(ev)}; sentences with a regnal-year date: {len(sent_date)}; with both: {len(both)}')
# texts that have both a date and an event word
tx_ev = C(sent_text[s] for s in ev); tx_date = {sent_text[s] for s in sent_date}
tb = [t for t in tx_ev if t in tx_date]
print(f'texts with an event word: {len(tx_ev)}; of these with a regnal-year date somewhere in the text: {len(tb)}; by group: {dict(C(corp[t] for t in tb))}')
show = collections.defaultdict(list)
with gzip.open(satz_p, 'rt', encoding='utf-8') as f:
    for line in f:
        r = json.loads(line); s = r['satz']; u = (r.get('uebersetzung') or '').replace('\n', ' ')
        if s in both: show['dated'].append((corp.get(r['text'], '?'), u[:260]))
        elif s in sent_cat and 'Beben/Zittern (Erde)' in sent_cat[s] and re.search(r'Erde|Land|Himmel|Berg', u): show['quake'].append((corp.get(r['text'], '?'), u[:200]))
        elif s in sent_cat and 'Sturm/Gewitter/Donner' in sent_cat[s]: show['storm'].append((corp.get(r['text'], '?'), u[:200]))
for k in ('dated', 'quake', 'storm'):
    print(f'\n[{k}] {len(show[k])} sentences; by group {dict(C(c for c, _ in show[k]).most_common(6))}')
    step = max(1, len(show[k]) // 9)
    for c, u in show[k][::step][:9]: print(f'   {c:20s} {u}')
