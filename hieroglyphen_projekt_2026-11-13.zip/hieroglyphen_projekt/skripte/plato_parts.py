"""Plato: 'n-th part' / 'n parts' constructions and selected passages.
usage: python3 -I plato_parts.py <tlg0059 dir>
"""
import sys, os, re, glob, unicodedata, collections, html

C = collections.Counter
ROUGH = '̔'
TOK = re.compile(r"[Ͱ-Ͽἀ-῿̀-ͯʼ’']+")
END = r'(?:οσ|ου|ω|ον|ε|η|ησ|ην|οι|ων|οισ|ουσ|α|ασ|αν|αι|αισ)'


def norm(tok):
    t = re.sub(r"[ʼ’']", '', tok)
    d = unicodedata.normalize('NFD', t).lower()
    rough = ROUGH in d[:5]
    plain = ''.join(ch for ch in d if unicodedata.category(ch) == 'Ll').replace('ς', 'σ')
    return plain, rough


def sections(path):
    s = open(path, encoding='utf-8').read()
    m = re.search(r'<body.*?</body>', s, flags=re.S)
    b = m.group(0) if m else s
    for tag in ('note', 'label', 'head', 'bibl', 'speaker'):
        b = re.sub(r'<%s\b[^>]*>.*?</%s>' % (tag, tag), ' ', b, flags=re.S)
    mark = lambda m: ' \x00' + m.group(1) + '\x00 '
    b = re.sub(r'<milestone[^>]*unit="section"[^>]*n="([^"]+)"[^>]*/>', mark, b)
    b = re.sub(r'<milestone[^>]*n="([^"]+)"[^>]*unit="section"[^>]*/>', mark, b)
    b = re.sub(r'<[^>]+>', ' ', b)
    b = html.unescape(b)
    parts = re.split(r'\x00([^\x00]+)\x00', b)
    out = [('0', parts[0])]
    for i in range(1, len(parts) - 1, 2):
        out.append((parts[i], parts[i + 1]))
    return out


CARD = {'δυο': 2, 'δυοιν': 2, 'δυειν': 2, 'τρεισ': 3, 'τρια': 3, 'τριων': 3, 'τρισι': 3, 'τρισιν': 3, 'τετταρα': 4, 'τετταρεσ': 4, 'τετταρασ': 4, 'τετταρων': 4,
        'πεντε': 5, 'επτα': 7, 'οκτω': 8, 'εννεα': 9, 'δεκα': 10, 'ενδεκα': 11, 'δωδεκα': 12}
ORD = {'δευτερ': 2, 'τριτ': 3, 'τεταρτ': 4, 'πεμπτ': 5, 'εκτ': 6, 'εβδομ': 7, 'ογδο': 8, 'ενατ': 9, 'δεκατ': 10, 'δωδεκατ': 12, 'εικοστ': 20, 'εκατοστ': 100}
ORD_RE = {k: re.compile('^' + k + END + '$') for k in ORD}
PART = re.compile(r'^(μερ(οσ|ουσ|ει|η|ων|εσι|εσιν)|μορι(ον|ου|ω|α|ων|οισ)|μοιρ(α|ασ|αν|αι|ων|αισ))$')

d = sys.argv[1]
titles = {}
hits = collections.defaultdict(list)
show = {('tlg034', s) for s in ('737e', '738a', '771a', '771b', '771c', '746d', '819b', '819c')}
shown = {}
for w in sorted(os.listdir(d)):
    wd = os.path.join(d, w)
    if not os.path.isdir(wd): continue
    t = open(os.path.join(wd, '__cts__.xml'), encoding='utf-8').read()
    m = re.search(r'<ti:title[^>]*>([^<]+)<', t); titles[w] = m.group(1) if m else w
    g = sorted(glob.glob(os.path.join(wd, '*grc*.xml')))
    if not g: continue
    for sec, txt in sections(g[-1]):
        if (w, sec) in show: shown[(w, sec)] = ' '.join(txt.split())[:700]
        raw = TOK.findall(txt)
        toks = [(norm(x), x) for x in raw]
        toks = [(p, r, x) for (p, r), x in toks if p]
        for i, (p, r, x) in enumerate(toks):
            kind = None; val = None
            if p in CARD or (r and p == 'εξ'):
                kind = 'cardinal'; val = CARD.get(p, 6)
            else:
                for k, v in ORD.items():
                    if ORD_RE[k].match(p) and (k != 'εκτ' or r):
                        kind = 'ordinal'; val = v; break
            if not kind: continue
            for j in (i + 1, i + 2, i - 1):
                if 0 <= j < len(toks) and PART.match(toks[j][0]):
                    lo, hi = max(0, min(i, j) - 4), min(len(toks), max(i, j) + 5)
                    hits[kind].append((titles[w], sec, val, ' '.join(t3[2] for t3 in toks[lo:hi])))
                    break
for kind in ('ordinal', 'cardinal'):
    hs = hits[kind]
    print(f'\n{kind} + part word: {len(hs)} | by value: {sorted(C(h[2] for h in hs).items())} | by work: {C(h[0] for h in hs).most_common(8)}')
    for h in hs[:60]:
        print(f'   {h[0][:12]:12s} {h[1]:6s} {h[2]:3d}  {h[3]}')
for (w, sec), txt in sorted(shown.items()):
    print(f'\n[{titles[w]} {sec}] {txt}')
