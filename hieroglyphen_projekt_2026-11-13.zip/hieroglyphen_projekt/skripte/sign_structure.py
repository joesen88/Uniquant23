import json, sys, gzip, re, collections, math, statistics
import numpy as np
texts_p, aes_dir, uni_p, rare_p = sys.argv[1:5]
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*')
def base(s): return re.sub(r'(?<=\d)[A-Za-z]+$', '', s)
TX = json.load(gzip.open(texts_p, 'rt', encoding='utf-8'))
C = collections.defaultdict(collections.Counter)
for t in TX.values(): C[t['corpus']].update(base(x) for x in t['signs'])
ALL = sum(C.values(), collections.Counter()); LIT, MED = set(C['sawlit']), set(C['sawmedizin'])
cp = collections.defaultdict(dict)
for line in open(uni_p, encoding='utf-8'):
    if line.startswith('U+'):
        p = line.rstrip('\n').split('\t')
        if len(p) == 3: cp[p[0]][p[1]] = p[2]
FUNC = {}
for u, d in cp.items():
    if 'kEH_JSesh' in d and d.get('kEH_Func'):
        f = d['kEH_Func']; FUNC.setdefault(d['kEH_JSesh'], 'Klassifikator' if f.startswith('Classifier') else 'Logogramm' if f.startswith('Logogram') else 'Lautzeichen' if f.startswith('Phon') else 'anderes')
d = json.load(open(aes_dir + '/_aes_bbawtotenlit.json', encoding='utf-8'))
S = collections.defaultdict(lambda: {'n': 0, 'pos': collections.Counter(), 'lem': set()}); occ = collections.Counter(); N = 0
for s in d.values():
    for k in s.get('token', []):
        if not k.get('hiero'): continue
        sg = [base(x) for x in SIGN.findall(k['hiero'])]
        for i, b in enumerate(sg):
            p = 'Anfang/allein' if i == 0 else 'Ende' if i == len(sg) - 1 else 'Inneres'
            st = S[b]; st['n'] += 1; st['pos'][p] += 1; st['lem'].add(str(k.get('lemmaID') or k.get('written_form'))); N += 1
            occ[(1 if b in LIT else 2 if b in MED else 3, p)] += 1
cls = lambda b: 1 if b in LIT else 2 if b in MED else 3
print(f'ritual papyri: {N} sign occurrences, {len(S)} sign types')
print('\n[1] 3x3 by sign type (subgroup = position the sign most often takes): types | share of all occurrences')
POS = ('Anfang/allein', 'Inneres', 'Ende')
for k in (1, 2, 3):
    row = []
    for p in POS:
        tt = [b for b, st in S.items() if cls(b) == k and st['pos'].most_common(1)[0][0] == p]; row.append(f"{p}: {len(tt):3d} Zeichen, {sum(S[b]['n'] for b in tt)/N:6.2%}")
    print(f'  Klasse {k}: ' + ' | '.join(row))
print('    by occurrence: ' + ' ; '.join(f"Klasse {k}: " + '/'.join(f"{occ[(k, p)]/max(sum(occ[(k, q)] for q in POS), 1):.0%}" for p in POS) for k in (1, 2, 3)) + '  (Anfang-allein / Inneres / Ende)')
print('\n[2] class 1 subgroups against the function given in the Unicode sign list (share of occurrences):')
for p in POS:
    tt = [b for b, st in S.items() if cls(b) == 1 and st['pos'].most_common(1)[0][0] == p]; c = collections.Counter()
    for b in tt: c[FUNC.get(b, 'ohne Angabe')] += S[b]['n']
    tot = sum(c.values()); print(f"  {p:14s} " + ', '.join(f'{k} {v/tot:.0%}' for k, v in c.most_common()) + ' | top signs: ' + ' '.join(b for b in sorted(tt, key=lambda b: -S[b]['n'])[:10]))
print('\n[3] bound to exactly one word, by frequency band (ritual papyri): rare signs | all other signs')
for lo, hi in ((1, 1), (2, 2), (3, 4), (5, 9), (10, 29), (30, 99), (100, 10**9)):
    a = [b for b, st in S.items() if cls(b) != 1 and lo <= st['n'] <= hi]; o = [b for b, st in S.items() if cls(b) == 1 and lo <= st['n'] <= hi]
    f = lambda x: f"{sum(1 for b in x if len(S[b]['lem']) == 1)}/{len(x)}" + (f" = {sum(1 for b in x if len(S[b]['lem']) == 1)/len(x):.0%}" if x else '')
    print(f"  n {lo}-{hi if hi < 10**9 else '...'}: rare {f(a):14s} | others {f(o)}")
R = [b for b in S if cls(b) != 1]
a = sum(1 for b in R if S[b]['n'] <= 2 and len(S[b]['lem']) == 1); b_ = sum(1 for b in R if S[b]['n'] <= 2 and len(S[b]['lem']) > 1); c_ = sum(1 for b in R if S[b]['n'] > 2 and len(S[b]['lem']) == 1); d_ = sum(1 for b in R if S[b]['n'] > 2 and len(S[b]['lem']) > 1)
print(f'\n[4] intersection among the {len(R)} rare signs: <=2 occurrences and one word {a} | <=2 and several words {b_} | >=3 and one word {c_} | >=3 and several words {d_}')
O = [b for b in S if cls(b) == 1]
print(f"    for comparison all {len(O)} other signs of the ritual papyri: <=2 occurrences {sum(1 for b in O if S[b]['n'] <= 2)} ({sum(1 for b in O if S[b]['n'] <= 2)/len(O):.0%}); bound to one word {sum(1 for b in O if len(S[b]['lem']) == 1)} ({sum(1 for b in O if len(S[b]['lem']) == 1)/len(O):.0%})")
print('\n[5] frequency spectrum: share of types occurring exactly 1 / 2 / 3 / 4 / 5+ times (Zipf prediction 50 / 17 / 8 / 5 / 20)')
for lab, v in (('rare signs (71)', [S[b]['n'] for b in R]), ('all signs, ritual papyri', [st['n'] for st in S.values()]), ('all signs, whole corpus', list(ALL.values()))):
    v = np.array(v); print(f"  {lab:28s} n={len(v):5d}: " + ' / '.join(f'{np.mean(v == m):.0%}' for m in (1, 2, 3, 4)) + f' / {np.mean(v >= 5):.0%}')
f = np.array(sorted(ALL.values(), reverse=True), float); T = f.sum(); V = len(f)
print(f'\n[6] same distribution cut with two different divisors (all signs, whole corpus: {V} types, {int(T)} occurrences)')
for bse in (10, 13):
    k = 0; rows = []
    while bse**k <= f.max():
        m = (f >= bse**k) & (f < bse**(k+1)); rows.append(f"[{bse**k}, {bse**(k+1)}): {int(m.sum())} Zeichen, {f[m].sum()/T:.1%} der Vorkommen, {m.sum()/math.log(bse):.0f} je e-Faltung"); k += 1
    print(f'  Teiler {bse}: ' + ' | '.join(rows))
r = np.arange(1, V + 1); idx = np.unique(np.round(np.logspace(0, np.log10(V), 60)).astype(int)) - 1; x = np.log10(r[idx]); y = np.log10(f[idx])
one = np.polyfit(x, y, 1); sse1 = ((np.polyval(one, x) - y)**2).sum(); best = None
for b in range(6, len(x) - 6):
    a1 = np.polyfit(x[:b], y[:b], 1); a2 = np.polyfit(x[b:], y[b:], 1); sse = ((np.polyval(a1, x[:b]) - y[:b])**2).sum() + ((np.polyval(a2, x[b:]) - y[b:])**2).sum()
    if best is None or sse < best[0]: best = (sse, int(r[idx][b]), a1[0], a2[0])
cum = np.cumsum(f)/T
print(f'  rank-frequency of signs: one slope {one[0]:+.2f}; two regimes: break at rank {best[1]}, slopes {best[2]:+.2f} / {best[3]:+.2f}, error reduced by {1 - best[0]/sse1:.0%}; signs up to the break cover {cum[best[1]-1]:.1%} of occurrences')
print('  conversion: one step of divisor 13 =', round(math.log(13)/math.log(10), 4), 'steps of divisor 10')
