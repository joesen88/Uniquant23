import re, sys, os, glob, collections
d, inc = sys.argv[1:3]
lex = open(os.path.join(d, 'lex.tex'), encoding='utf-8').read(); stmt = open(os.path.join(d, 'statements.tex'), encoding='utf-8').read(); std = open(os.path.join(d, 'std.tex'), encoding='utf-8').read()
def bnf(src, name):
    m = re.search(r'\\nontermdef\{' + re.escape(name) + r'\}(.*?)\\end\{bnf\}', src, re.S)
    return [x.strip() for x in re.split(r'\\br', m.group(1)) if x.strip()] if m else []
tok = bnf(lex, 'token'); print('token kinds:', len(tok), tok)
m = re.search(r'\{Keywords\}\{lex\.key\}(.*?)\\end\{multicolfloattable\}', lex, re.S); kw = re.findall(r'\\(?:keyword|tcode)\{([^}]*)\}', m.group(1)) if m else []; kw = [k.replace('\\', '') for k in kw]
print('keywords:', len(kw), kw[:12], '...')
m = re.search(r'\{Alternative representations\}\{lex\.digraph\}(.*?)\\end\{', lex, re.S)
op = bnf(lex, 'operator-or-punctuator'); raw = ' '.join(re.findall(r'\\terminal\{((?:[^{}]|\{[^{}]*\})*)\}', ' '.join(op)))
raw = raw.replace('\\caret', '^').replace('\\textasciitilde', '~').replace('\\~{}', '~').replace('\\{', '{').replace('\\}', '}').replace('\\%', '%').replace('\\&', '&').replace('\\#', '#').replace('\\$', '$').replace('\\textbackslash', '\\')
ops = [o for o in raw.split() if o and not o[0].isalpha() and 'keyword' not in o]; ops = sorted(set(re.sub(r'\{\}$', '', o) if len(o) > 2 else o for o in ops))
print('operators and punctuators:', len(ops), ops[:20], '...')
st = bnf(stmt, 'statement'); print('statement kinds:', len(st), [re.sub(r'\\\w+\{|\}|\\opt\{[^}]*', '', x)[:28] for x in st])
lit = bnf(lex, 'literal'); print('literal kinds:', len(lit), [re.sub(r'\\\w+\{|\}', '', x) for x in lit])
inc_ = re.findall(r'\\include\{(\w+)\}', std); print('top-level parts of the standard text:', len(inc_), inc_)
# tokenize libstdc++ headers
files = sorted(glob.glob(os.path.join(inc, 'bits', '*.h')) + glob.glob(os.path.join(inc, 'bits', '*.tcc')))
KW = set(kw) | {'and', 'or', 'not', 'xor', 'bitand', 'bitor', 'compl', 'and_eq', 'or_eq', 'xor_eq', 'not_eq'}
OPS = sorted(set(ops) | {'#', '##', '::', '->', '...', '<=>'}, key=len, reverse=True)
T = re.compile(r'(?P<lit>"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|\.?\d[\w.\']*)|(?P<id>[A-Za-z_]\w*)|(?P<op>' + '|'.join(re.escape(o) for o in OPS if o and not o[0].isalpha()) + r')')
seq = []
for f in files:
    s = open(f, encoding='utf-8', errors='ignore').read(); s = re.sub(r'/\*.*?\*/', ' ', s, flags=re.S); s = re.sub(r'//[^\n]*', ' ', s)
    for m in T.finditer(s):
        if m.lastgroup == 'id': seq.append(('Schluesselwort' if m.group(0) in KW else 'Bezeichner', m.group(0)))
        elif m.lastgroup == 'lit': seq.append(('Literal', m.group(0)))
        else: seq.append(('Operator/Trennzeichen', m.group(0)))
    if len(seq) >= 112391: break
seq = seq[:112391]; N = len(seq); c = collections.Counter(k for k, _ in seq); ty = collections.defaultdict(set)
for k, v in seq: ty[k].add(v)
print(f'\nC++ source ({len(files)} header files available, first {N} tokens): ' + ' | '.join(f'{k} {c[k]/N:.1%} ({len(ty[k])} types)' for k in ('Operator/Trennzeichen', 'Schluesselwort', 'Bezeichner', 'Literal')))
fr = collections.Counter(v for _, v in seq); acc = 0; a = []; b = 0
for v, n in fr.most_common():
    if acc < N/3: a.append(v)
    elif acc < 2*N/3: b += 1
    acc += n
print(f'  types: {len(fr)} | first third of all tokens made of {len(a)} types: {a} | second third: {b} types | hapax share {sum(1 for n in fr.values() if n == 1)/len(fr):.0%}')
closed = c['Operator/Trennzeichen'] + c['Schluesselwort']; print(f'  closed classes (keywords + operators + separators): {closed/N:.1%} of tokens with {len(ty["Operator/Trennzeichen"]) + len(ty["Schluesselwort"])} types; identifiers: {len(ty["Bezeichner"])} types')
depth = 0; mx = 0; opens = 0
for k, v in seq:
    if v in '({[': depth += 1; opens += 1; mx = max(mx, depth)
    elif v in ')}]': depth -= 1
print(f'  bracket tokens: {sum(1 for k, v in seq if v in "(){}[]")/N:.1%} of all tokens; maximum nesting depth {mx}')
