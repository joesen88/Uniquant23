"""Kings' names and star names: the same kind of name? (criteria: kings_stars_prereg.txt)
usage: python3 -I kings_stars.py <dir with _aes_*.json>"""
import sys, os, json, re, collections
C = collections.Counter
d = sys.argv[1]
STARS = {'30890', '500410', '127020', '851672', '133310', '247', '75770', '116440'}
SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*'); base = lambda s: re.sub(r'(?<=\d)[A-Za-z]+$', '', s)
KIN = re.compile(r'\b(Sohn|Tochter|Mutter|Vater|Ehefrau|Gemahlin|Gattin|Bruder|Schwester|Kind)\b|gebären|geboren')
LIFE = re.compile(r'\bleben|lebendig|ewig|Ewigkeit|gerechtfertigt|Gerechtfertigter|Leben, Heil')
PER = ('OK & FIP', 'MK & SIP', 'NK', 'TIP - Roman times')
MEAS = ('number within two words', 'kinship word within three words', 'life formula in the next three words', 'title directly before')
def cls(tk):
    if str(tk.get('lemmaID') or '') in STARS: return 'stars'
    return {'kings_name': 'kings', 'person_name': 'persons', 'gods_name': 'gods'}.get(tk.get('name'))
tot = collections.defaultdict(C); hit = collections.defaultdict(lambda: collections.defaultdict(C)); hier = C(); n14 = C(); n14names = collections.defaultdict(C)
epoch = collections.defaultdict(C); reg = C(); near = collections.defaultdict(C); nearcorp = C(); samples = []
for fn in sorted(os.listdir(d)):
    if not fn.startswith('_aes_'): continue
    data = json.load(open(os.path.join(d, fn), encoding='utf-8'))
    for sid, s in data.items():
        toks = s['token']; pt = s['corpus'] == 'bbawpyramidentexte'
        cl = [cls(tk) for tk in toks]
        if not any(cl): continue
        isnum = [tk.get('lemma_form') == '1...n' or tk.get('pos') == 'numeral' for tk in toks]
        tr = [tk.get('cotext_translation') or '' for tk in toks]
        iskin = [bool(KIN.search(x)) for x in tr]; islife = [bool(LIFE.search(x)) or tk.get('lemma_form') in ('mꜣꜥ-ḫrw', 'ḏ.t', 'ꜥnḫ-wḏꜣ-snb') for x, tk in zip(tr, toks)]
        istitle = [tk.get('pos') == 'epitheton_title' for tk in toks]
        for i, (tk, c) in enumerate(zip(toks, cl)):
            if not c: continue
            for scope in (('all',) if pt else ('all', 'without Pyramid Texts')):
                tot[scope][c] += 1
                if any(isnum[max(0, i - 2):i + 3]): hit[scope][MEAS[0]][c] += 1
                if any(iskin[max(0, i - 3):i + 4]): hit[scope][MEAS[1]][c] += 1
                if any(islife[i + 1:i + 4]): hit[scope][MEAS[2]][c] += 1
                if any(istitle[max(0, i - 3):i]): hit[scope][MEAS[3]][c] += 1
            h = tk.get('hiero')
            if h:
                hier[c] += 1
                if 'N14' in {base(x) for x in SIGN.findall(h)}: n14[c] += 1; n14names[c][tk.get('lemma_form')] += 1
                if c == 'stars' and len(samples) < 3: samples.append((tk.get('lemma_form'), h))
            if c in ('kings', 'stars') and s.get('date') in PER: epoch[(c, tk.get('lemma_form'))][s['date']] += 1
            if c in ('kings', 'stars'):
                if any((t.get('lemma_form') or '').startswith('rnp.t-zp') for t in toks[max(0, i - 10):i]): reg[c] += 1
                other = 'stars' if c == 'kings' else 'kings'
                if other in cl[max(0, i - 5):i + 6]:
                    near[c]['Pyramid Texts' if pt else 'other texts'] += 1
                    if c == 'kings' and not pt: nearcorp[s['corpus']] += 1
                near[c]['tokens Pyramid Texts' if pt else 'tokens other texts'] += 1
    del data
verdict = {}
print('tokens:', {k: dict(v) for k, v in tot.items()}); print('spelling samples of star names:', samples)
print('\n[C1] written with the star sign N14 (tokens with hieroglyphs)')
sh14 = {c: n14[c] / hier[c] if hier[c] else float('nan') for c in ('stars', 'kings', 'persons', 'gods')}
for c in sh14: print(f'   {c:8s} {n14[c]:5d} of {hier[c]:6d} = {sh14[c]:6.1%}   {dict(n14names[c].most_common(6))}')
verdict['C1'] = 'pro' if sh14['kings'] >= 0.5 * sh14['stars'] else 'against' if sh14['kings'] < 0.1 * sh14['stars'] else 'open'
main = 'without Pyramid Texts' if tot['without Pyramid Texts']['stars'] >= 50 else 'all'
for scope in ('all', 'without Pyramid Texts'):
    print(f'\n[C2] company of the name ({scope}{", main scope" if scope == main else ""})'); closer = C()
    for m in MEAS:
        sh = {c: hit[scope][m][c] / max(1, tot[scope][c]) for c in ('kings', 'persons', 'gods', 'stars')}
        side = 'persons' if abs(sh['kings'] - sh['persons']) < abs(sh['kings'] - sh['stars']) else 'stars'; closer[side] += 1
        print(f'   {m:38s} kings {sh["kings"]:6.1%} | persons {sh["persons"]:6.1%} | gods {sh["gods"]:6.1%} | stars {sh["stars"]:6.1%}   -> kings closer to {side}')
    print(f'   kings closer to persons on {closer["persons"]} of 4, closer to stars on {closer["stars"]}')
    if scope == main: verdict['C2'] = 'pro' if closer['stars'] >= 3 else 'against' if closer['persons'] >= 3 else 'open'
print('\n[C3] return over time (names with at least 30 dated tokens; returning = at least 5 tokens in two or more periods)')
ret = collections.defaultdict(list)
for (c, name), e in epoch.items():
    if sum(e.values()) >= 30: ret[c].append((sum(1 for v in e.values() if v >= 5) >= 2, name, dict(e)))
for c in ('stars', 'kings'):
    r = ret[c]; print(f'   {c}: {sum(1 for x in r if x[0])} of {len(r)} names return')
    for x in sorted(r, key=lambda x: -sum(x[2].values()))[:(9 if c == 'stars' else 0)]: print(f'      {x[1]:12s} {x[2]}')
    for x in r:
        if c == 'kings' and x[0]: print(f'      returning: {x[1]:20s} {x[2]}')
sr = sum(1 for x in ret['stars'] if x[0]) / max(1, len(ret['stars'])); kr = sum(1 for x in ret['kings'] if x[0]) / max(1, len(ret['kings']))
verdict['C3'] = 'no star name with 30 dated tokens' if not ret['stars'] else 'pro' if kr >= 0.5 * sr and kr > 0 else 'against' if kr < 0.1 * sr or kr == 0 else 'open'
print('\nwithout criterion:')
print('   name follows a regnal-year formula (rnp.t-zp within ten words before):', dict(reg), '| kings', tot['all']['kings'], 'stars', tot['all']['stars'])
for c in ('kings', 'stars'):
    for g in ('Pyramid Texts', 'other texts'):
        n = near[c]['tokens ' + g]; print(f'   {c:6s} with a {"star" if c == "kings" else "king"} name within five words, {g:14s}: {near[c][g]:4d} of {n:5d} = {near[c][g] / max(1, n):6.2%}')
print('   kings near star names outside the Pyramid Texts, by corpus:', dict(nearcorp))
pro = sum(1 for v in verdict.values() if v == 'pro'); con = sum(1 for v in verdict.values() if v == 'against')
print('\nverdict by the fixed rule:', verdict, '->', 'H supported' if pro >= 2 and con == 0 else 'H contradicted' if con >= 2 and pro == 0 else 'open')
