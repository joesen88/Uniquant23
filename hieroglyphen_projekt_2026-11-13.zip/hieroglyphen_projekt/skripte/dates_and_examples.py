import json, sys, glob, os, re, collections
from fractions import Fraction
root, conc = sys.argv[1], sys.argv[2]
names = {}
for line in open(conc, encoding='utf-8'):
    p = line.rstrip('\n').split('\t')
    if len(p) >= 2: names[p[-1]] = p[0][:70]
def num(t):
    wf = (t.get('written_form') or '').strip()
    if t.get('pos') == 'numeral' and re.fullmatch(r'\d+', wf): return int(wf)
    return None
SEASON = {'ꜣḫ.t': 0, 'pr.t': 1, 'šm.w': 2}
g = lambda t: (t.get('cotext_translation') or '')
dates = []; month_vals = collections.Counter(); day_vals = collections.Counter(); year_n = 0
dm_examples = []; mh_examples = []
by_epoch = collections.Counter(); doy = []
for p in sorted(glob.glob(os.path.join(root,'_aes_*.json'))):
    d = json.load(open(p,encoding='utf-8'))
    for sid, s in d.items():
        T = s.get('token', [])
        vals = [num(t) for t in T]
        for i, t in enumerate(T):
            lem = t.get('lemma_form') or ''
            if lem == 'ꜣbd' and i+1 < len(T) and vals[i+1] is not None: month_vals[vals[i+1]] += 1
            if 'Monatstag' in g(t) and i+1 < len(T) and vals[i+1] is not None: day_vals[vals[i+1]] += 1
            if lem == 'rnp.t-zp' and i+1 < len(T) and vals[i+1] is not None:
                year_n += 1
                # look ahead for month number + season (+ day)
                m = se = dy = None
                for j in range(i+2, min(i+10, len(T))):
                    lj = T[j].get('lemma_form') or ''
                    if lj == 'ꜣbd' and j+1 < len(T) and vals[j+1] is not None and m is None: m = vals[j+1]
                    if lj in SEASON and se is None: se = SEASON[lj]
                    if 'Monatstag' in g(T[j]) and j+1 < len(T) and vals[j+1] is not None and dy is None: dy = vals[j+1]
                if m and se is not None and 1 <= m <= 4:
                    rec = (s['text'], vals[i+1], se, m, dy, s.get('date'))
                    dates.append(rec); by_epoch[s.get('date')] += 1
                    if dy and 1 <= dy <= 30: doy.append((se*4 + m-1)*30 + dy)
            # examples
            if lem == 'dmḏ' and i+1 < len(T) and vals[i+1] is not None and len(dm_examples) < 400:
                prev = [v for v in vals[:i] if v is not None]
                for k in range(2, 16):
                    if len(prev) >= k and sum(prev[-k:]) == vals[i+1] and vals[i+1] > max(prev[-k:]):
                        dm_examples.append((names.get(s['text'], s['text'])[:60], prev[-k:], vals[i+1])); break
            if lem == 'mḥ' and i+1 < len(T) and vals[i+1] is not None:
                prev = [v for v in vals[:i] if v is not None]
                if len(prev) >= 2 and prev[-2] - prev[-1] == vals[i+1] and prev[-2] >= 5:
                    mh_examples.append((names.get(s['text'], s['text'])[:60], prev[-2:], vals[i+1], (s.get('sentence_translation') or '')[:150]))
print('regnal-year formulas (rnp.t-zp + number):', year_n)
print('month numbers after ꜣbd:', sorted(month_vals.items()))
print('day-of-month numbers: n', sum(day_vals.values()), 'max', max(day_vals) if day_vals else None, 'distinct', len(day_vals), 'share within 1..30:', round(sum(v for k,v in day_vals.items() if 1<=k<=30)/max(sum(day_vals.values()),1),3))
print('dated records with year + month + season:', len(dates), '| also with day:', len(doy), '| distinct texts:', len(set(r[0] for r in dates)))
print('by epoch:', dict(by_epoch))
if doy:
    print('civil day-of-year range', min(doy), max(doy), '| per season counts', collections.Counter((x-1)//120 for x in doy))
print('highest regnal years:', sorted({r[1] for r in dates})[-6:])
print('\nsum examples within one sentence after dmḏ (first 6 of', len(dm_examples), '):')
for e in dm_examples[:6]: print('  ', e)
print('\ndifference examples after mḥ (first 6 of', len(mh_examples), '):')
for e in mh_examples[:6]: print('  ', e)
