"""Linear A fraction values with an explicit tolerance: how many attested runs may contradict an assignment?
Every certain run of the database counts with its number of attestations (also H K, E J, J J, which were set aside before);
the twelve (or ten) values must still be distinct. Exact counts by integer arithmetic.
usage: python3 -I lineara_tolerance.py <lineara_loo.py>"""
import sys, runpy, math, itertools, collections
from fractions import Fraction as Fr
import numpy as np
M = runpy.run_path(sys.argv[1], run_name='loo')
P36, RUNS, EXTRA, setup, violations, PUB = (M[k] for k in ('P36', 'RUNS', 'EXTRA', 'setup', 'violations', 'PUB'))
def curve(core):
    thr = 120 if core else 240
    runs = [r for r in RUNS + [e for e in EXTRA if e[0] != 'A A'] if not (core and any(t in ('H', 'A') for t in r[3]))]
    total = sum(r[1] for r in runs)
    signs = ['J', 'E', 'F', 'K', 'L2', 'L3', 'L4', 'L6', 'B', 'D'] + ([] if core else ['H', 'A'])
    res = collections.defaultdict(lambda: [0, 0, 0, None, []]); pubV = None
    for n in range(2, 54):
        base = math.lcm(8, 12 * n)
        if not core and base > thr: continue
        lst = P36 if core else [v for v in P36 if math.lcm(base, v.denominator) <= thr]
        for K in lst:
            SC, val, den, shape, names = setup(n, K, {s: lst for s in ('B', 'D', 'H', 'A')}, core)
            vio = violations(val, SC, signs, runs)
            Wt = np.zeros(shape, dtype=np.int16)
            for name, att, tab, terms, orders in runs:
                bad = np.zeros((), dtype=bool)
                for k, a in vio.items():
                    if k[0] == name: bad = bad | a
                Wt += att * bad.astype(np.int16)
            ok = ~np.broadcast_to(vio[('all', 'distinct')], shape)
            L = np.full(shape, math.lcm(2, 4, 8, 2 * n, 3 * n, 4 * n, 6 * n), dtype=np.int64)
            for s in ['K'] + names: L = np.lcm(L, den[s])
            for t in range(0, 9):
                p = ok & (Wt <= t)
                if not p.any(): continue
                r = res[t]; r[0] += int(p.sum()); r[1] += int((p & (L < thr)).sum()); r[2] += int((p & (L == thr)).sum())
                lm = int(L[p].min())
                if r[3] is None or lm < r[3]: r[3] = lm; r[4] = []
                if lm == r[3] and len(r[4]) < 3:
                    for h in np.argwhere(p & (L == lm))[:3 - len(r[4])]:
                        r[4].append(', '.join([f'K {K}'] + [f'{s} {lst[i]}' for s, i in zip(names, h)] + [f'L 1/{n}']))
            if n == PUB['n'] and K == PUB['K']:
                i = tuple(lst.index(PUB[s]) for s in names); pubV = int(Wt[i])
    return total, res, pubV
for core, label in ((True, 'CORE (ten signs)'), (False, 'ALL TWELVE SIGNS (only assignments with common denominator <= 240 are enumerated)')):
    total, res, pubV = curve(core)
    print(f'\n{label}: {total} attestations of evaluable runs; published solution contradicts {pubV} of them = agreement {100 * (1 - pubV / total):.1f} %')
    print('  contradicted attestations allowed | agreement | assignments' + (' (exact)' if core else ' (<= 240 only)') + ' | smaller common denominator than published | same | smallest common denominator, examples')
    for t in range(0, 9):
        if t not in res: print(f'   {t}   {100 * (1 - t / total):5.1f} %   none'); continue
        n, b, e, lm, ex = res[t]
        print(f'   {t}   {100 * (1 - t / total):5.1f} %   {n:>11,}   {b:>7,}   {e:>7,}   {lm}: ' + ' | '.join(ex[:2]))
