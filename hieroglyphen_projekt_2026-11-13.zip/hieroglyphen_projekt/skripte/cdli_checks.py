"""Follow-up checks for the cuneiform calibration (explanations of deviations, no new criteria).
usage: python3 -I cdli_checks.py <cdli_ur3.jsonl.gz>"""
import sys, gzip, json, re, collections, itertools
C = collections.Counter
EL = re.compile(r'^(\d+)(?:/(\d+))?\(([^()]+)\)(.*)$'); GL = re.compile(r'^(?:\{[^{}]*\})+')
D = ['1/3(disz)', '1/2(disz)', '2/3(disz)', '5/6(disz)']
texts = [json.loads(l) for l in gzip.open(sys.argv[1], 'rt', encoding='utf-8')]
adj = []; la2 = C(); la2_after = C(); nine = C(); tot = C(); u_disz = C(); after_u = collections.defaultdict(C); prov_fr = collections.defaultdict(C)
first_el = C(); two_numbers = C()
for t in texts:
    pv = t['prov'].split(' (')[0]
    for o in t['o']:
        for cl, body in o:
            if not cl: continue
            toks = body.split()
            els = [EL.match(x) for x in toks]
            for i, m in enumerate(els):
                if not m: continue
                cnt, den, name, suf = m.groups(); suf = GL.sub('', suf)
                sign = f'{cnt}/{den}({name})' if den else name
                if den and sign in D: prov_fr[pv][sign] += 1
                if not den:
                    tot[name] += 1
                    if int(cnt) == 9: nine[name] += 1
                    # subtractive notation: "... la2 n(sign)"
                    if i > 0 and toks[i - 1] == 'la2': la2[(name, int(cnt))] += 1
                if i + 1 < len(toks) and els[i + 1] and not suf:
                    m2 = els[i + 1]; s2 = f'{m2.group(1)}/{m2.group(2)}({m2.group(3)})' if m2.group(2) else m2.group(3)
                    if sign in D and s2 in D: adj.append((t['p'], body))
                    if sign == 'u' and not m2.group(2): after_u[s2][int(m2.group(1))] += 1
print('[1] lines with two of the four fraction signs directly next to each other:', len(adj))
for p, b in adj[:14]: print(f'    P{p:06d}  {b[:120]}')
print('\n[2] subtractive notation "la2 n(sign)": counts by sign and n')
for s in ('disz', 'disz@t', 'asz', 'asz@c', 'u'):
    d = {n: c for (x, n), c in la2.items() if x == s}
    print(f'    {s:7s} elements {tot[s]:7d}; written count 9: {nine[s]:5d}; after la2: {sum(d.values()):5d}  by n: {dict(sorted(d.items()))}')
print('\n[3] what stands directly after u (integer signs), with counts of that sign:')
for s, h in sorted(after_u.items(), key=lambda kv: -sum(kv[1].values()))[:6]:
    print(f'    u -> {s:7s} {sum(h.values()):6d}   ' + ' '.join(f'{k}:{h[k]}' for k in sorted(h)))
print('\n[4] frequency of the four fraction signs by provenience (order 1/3, 1/2, 2/3, 5/6):')
for pv, c in sorted(prov_fr.items(), key=lambda kv: -sum(kv[1].values()))[:6]:
    print(f'    {pv:22s} {[c[s] for s in D]}')
