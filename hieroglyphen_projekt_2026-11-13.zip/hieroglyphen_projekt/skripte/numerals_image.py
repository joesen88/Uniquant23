import json, sys
B = json.load(open(sys.argv[1])); out_html, out_png = sys.argv[2:4]; k = 3.4; parts = []
def W(c): return B[c]['w']*B[c]['scale']*k
def Hh(c): return B[c]['h']*B[c]['scale']*k
def glyph(c, x, base):
    v = B[c]; w, h = W(c), Hh(c)
    parts.append(f'<svg x="{x:.1f}" y="{base - h:.1f}" width="{w:.1f}" height="{h:.1f}" viewBox="{v["x"]:.4g} {v["y"]:.4g} {v["w"]:.5g} {v["h"]:.5g}">{v["body"].replace("var(--panel)", "#ffffff")}</svg>'); return w
def run(c, n, x, base, per_row=None, gap=5):
    per_row = per_row or n; rows = [per_row]*(n // per_row) + ([n % per_row] if n % per_row else []); x0 = x; wmax = 0
    for ri, cnt in enumerate(rows):
        xx = x0; b = base - (len(rows) - 1 - ri)*(Hh(c) + 5)
        for i in range(cnt): xx += glyph(c, xx, b) + gap
        wmax = max(wmax, xx - gap - x0)
    return wmax
def text(x, y, s, cls='cap', anchor='middle'): parts.append(f'<text x="{x:.1f}" y="{y:.1f}" class="{cls}" text-anchor="{anchor}">{s}</text>')
text(40, 44, 'Ein Tag = 1.165.824 Zeitquanten', 'lab', 'start'); x = 60; base = 160
for c, n, cap, pr in (('C11', 1, '1.000.000', None), ('I8', 1, '100.000', None), ('D50', 6, '6 × 10.000', None), ('M12', 5, '5 × 1.000', None), ('V1', 8, '8 × 100', 4), ('V20', 2, '2 × 10', None), ('Z1', 4, '4 × 1', None)):
    w = run(c, n, x, base, pr); text(x + w/2, base + 26, cap); x += w + 44
text(40, 250, 'Ein Zeitquant = 75/1012 s = 1/22 + 1/44 + 1/253 + 1/506 s', 'lab', 'start'); x = 60; base = 380
for cap, groups in (('1/22', (('V20', 2), ('Z1', 2))), ('1/44', (('V20', 4), ('Z1', 4))), ('1/253', (('V1', 2), ('V20', 5), ('Z1', 3))), ('1/506', (('V1', 5), ('Z1', 6)))):
    x0 = x
    for c, n in groups: x += run(c, n, x, base) + 9
    w = x - 9 - x0; glyph('D21', x0 + w/2 - W('D21')/2, base - 46); text(x0 + w/2, base + 26, cap); x = x0 + w + 36
    if cap != '1/506': text(x, base - 8, '+', 'plus'); x += 36
text(40, 448, 'Der Mund über einer Zahl bedeutet „Teil“: 1 durch diese Zahl. Zeichenformen: JSesh.', 'note', 'start')
html = f'''<!DOCTYPE html><html><head><meta charset="utf-8"><style>body{{margin:0;background:#fff}} svg#c{{display:block}} .lab{{font:600 22px "DejaVu Sans",Arial,sans-serif;fill:#1b2422}} .cap{{font:15px "DejaVu Sans",Arial,sans-serif;fill:#5d6b67}} .plus{{font:24px "DejaVu Sans",Arial,sans-serif;fill:#5d6b67}} .note{{font:14px "DejaVu Sans",Arial,sans-serif;fill:#5d6b67}} svg svg{{color:#1b2422;overflow:visible}}</style></head><body><svg id="c" xmlns="http://www.w3.org/2000/svg" width="1000" height="470" viewBox="0 0 1000 470">{''.join(parts)}</svg></body></html>'''
open(out_html, 'w', encoding='utf-8').write(html)
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox']); pg = b.new_page(viewport={'width': 1000, 'height': 470}, device_scale_factor=2); pg.goto('file://' + out_html); pg.wait_for_timeout(500); pg.screenshot(path=out_png); b.close()
print('ok', len(html))
