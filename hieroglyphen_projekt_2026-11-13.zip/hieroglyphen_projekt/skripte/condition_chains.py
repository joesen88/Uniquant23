"""Chains of conditions in the corpus: share of conditional sentences, run lengths, stacked conditions.
usage: python3 -I condition_chains.py <aes_deutung_satz.jsonl.gz> <aes_kontext.jsonl.gz> <aes_deutung_token.jsonl.gz>
Conditional = the editors' German translation contains wenn/falls/sobald (word level).
"""
import sys, gzip, json, re, collections
C = collections.Counter
corp = {json.loads(l)['text']: json.loads(l)['korpus'] for l in gzip.open(sys.argv[2], 'rt', encoding='utf-8')}
rx = re.compile(r'\b(wenn|falls|sobald)\b', re.I)
rx_then = re.compile(r'\b(dann|so sollst du|sollst du|du sollst|musst du|werde|soll)\b', re.I)
n = C(); cond = C(); start = C(); stacked = C(); runs = collections.defaultdict(list); nwords = C()
cur_text = None; run = 0; cur_c = None
ex = collections.defaultdict(list)
for line in gzip.open(sys.argv[1], 'rt', encoding='utf-8'):
    r = json.loads(line); u = (r.get('uebersetzung') or '').replace('\n', ' '); c = corp.get(r['text'], '?')
    if r['text'] != cur_text:
        if run: runs[cur_c].append(run)
        cur_text = r['text']; run = 0; cur_c = c
    n[c] += 1
    k = len(rx.findall(u))
    if k:
        cond[c] += 1; run += 1
        if re.match(r'^\W*(Wenn|Falls|Sobald)\b', u): start[c] += 1
        if k >= 2: stacked[c] += 1
        if k >= 4 and len(ex[c]) < 2: ex[c].append((k, u[:330]))
    else:
        if run: runs[c].append(run)
        run = 0
if run: runs[cur_c].append(run)
print('group                 sentences  conditional  share   starts with Wenn   >=2 conditions   longest run of consecutive conditional sentences   runs >= 5')
for c, tot in n.most_common():
    if tot < 300: continue
    rs = runs[c]
    print(f'  {c:20s} {tot:7d}   {cond[c]:6d}   {cond[c]/tot:6.1%}   {start[c]:6d} ({start[c]/tot:5.1%})   {stacked[c]:5d}   longest {max(rs) if rs else 0:3d}   {sum(1 for x in rs if x >= 5):4d}')
T = sum(n.values()); print(f'all: {sum(cond.values())}/{T} = {sum(cond.values())/T:.1%}')
for c in ('sawmedizin', 'bbawpyramidentexte', 'sawlit', 'tb'):
    for k, u in ex[c]: print(f'\n[{c}] {k} conditions: {u}')
# medical case schema from the token layer: jr + ḫꜣi̯ (examine) ... ḏd.jn=k / ḏd.ḫr=k (you shall say) ... jri̯.ḫr=k (you shall make)
seq = collections.defaultdict(list)
for line in gzip.open(sys.argv[3], 'rt', encoding='utf-8'):
    r = json.loads(line)
    if corp.get(r['text']) == 'sawmedizin': seq[r['satz']].append(r.get('lemma_form') or '')
exam = sum(1 for s in seq.values() if s[:1] == ['jr'] and 'ḫꜣi̯' in s[:4])
jr_first = sum(1 for s in seq.values() if s[:1] == ['jr'])
print(f'\nmedical sentences: {len(seq)}; starting with jr (if / as for): {jr_first} = {jr_first/len(seq):.1%}; "if you examine ...": {exam}')
