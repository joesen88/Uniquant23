"""Egyptian corpus: sequences of consecutive number tokens that contain fraction notations (opaque symbols for the blind test).
usage: python3 -I eg_fraction_seqs.py <aes_tokens_cache.json.gz>
"""
import sys, gzip, json, re, collections
C = collections.Counter
T = json.load(gzip.open(sys.argv[1], 'rt', encoding='utf-8'))
clean = lambda w: re.sub(r'[\[\]⸢⸣()\?{}〈〉<>\s⸮]', '', w or '')
FR = re.compile(r'^(rʾ-\d+|\d+/\d+|ḥsb|gs)$')
seqs = C(); single = C(); pairs = C(); bycorp = collections.defaultdict(C); n_seq = 0
for t in T.values():
    toks = t['tok']; p0 = 0
    for L in t['sl']:
        s = toks[p0:p0 + L]; p0 += L
        i = 0
        while i < len(s):
            if s[i][1] in ('1...n', 'gs') and (s[i][2] == 'numeral'):
                j = i; run = []
                while j < len(s) and s[j][2] == 'numeral' and s[j][1] in ('1...n', 'gs'):
                    run.append(clean(s[j][3]) if s[j][1] == '1...n' else 'gs'); j += 1
                fr = [x for x in run if FR.match(x)]
                if fr:
                    n_seq += 1
                    for x in fr: bycorp[t['corpus']][x] += 1
                    if len(run) == 1: single[run[0]] += 1
                    else:
                        seqs[' '.join(run)] += 1
                        frs = [x for x in run if FR.match(x)]
                        for a, b in zip(frs, frs[1:]): pairs[(a, b)] += 1
                i = j
            else: i += 1
print('quantities containing a fraction notation:', n_seq, '| single fraction:', sum(single.values()), '| longer sequences:', sum(seqs.values()))
print('single:', single.most_common(20))
print('sequences (top 45):')
for k, v in seqs.most_common(45): print(f'   {v:4d}  {k}')
print('adjacent fraction pairs A then B:', sorted(pairs.items(), key=lambda kv: -kv[1])[:40])
for c, cc in sorted(bycorp.items(), key=lambda kv: -sum(kv[1].values())):
    print(f'{c:20s} n={sum(cc.values()):5d}  ' + ' '.join(f'{k}:{v}' for k, v in cc.most_common(12)))
