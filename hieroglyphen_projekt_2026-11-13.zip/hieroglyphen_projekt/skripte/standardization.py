"""How standardised is the wording? Share of 5-word sequences that recur in other texts of the same group
(equal sample size per group), fixed quantities, and the vocabulary of rule and exactness.
usage: python3 -I standardization.py <aes_tokens_cache.json.gz> <aes_deutung_token.jsonl.gz> <aes_kontext.jsonl.gz>
"""
import sys, gzip, json, re, random, collections
C = collections.Counter
T = json.load(gzip.open(sys.argv[1], 'rt', encoding='utf-8'))
BUDGET = 25000
by = collections.defaultdict(list)
for tid, t in T.items():
    lem = [tk[0] if tk[2] != 'numeral' else 'NUM' for tk in t['tok']]
    by[t['corpus']].append((tid, lem, t['sl']))
rng = random.Random(0)
print(f'equal samples of {BUDGET} words per group, 5 draws each; share of 5-word sequences that also occur in another text of the sample')
rows = []
for c, texts in by.items():
    if sum(len(l) for _, l, _ in texts) < BUDGET: continue
    vals = []; sv = []; nt = []
    for rep in range(5):
        tx = texts[:]; rng.shuffle(tx); pick = []; n = 0
        for x in tx:
            pick.append(x); n += len(x[1])
            if n >= BUDGET: break
        df = C(); occ = C()
        sdf = C(); socc = C()
        for tid, lem, sl in pick:
            grams = [tuple(lem[i:i + 5]) for i in range(len(lem) - 4) if None not in lem[i:i + 5]]
            occ.update(grams); df.update(set(grams))
            p0 = 0; ss = []
            for L in sl:
                s = tuple(lem[p0:p0 + L]); p0 += L
                if len(s) >= 4 and None not in s: ss.append(s)
            socc.update(ss); sdf.update(set(ss))
        tot = sum(occ.values()); rep2 = sum(k for g, k in occ.items() if df[g] >= 2)
        stot = sum(socc.values()); srep = sum(k for g, k in socc.items() if sdf[g] >= 2)
        vals.append(rep2 / tot); sv.append(srep / max(stot, 1)); nt.append(len(pick))
    rows.append((sum(vals) / 5, sum(sv) / 5, c, sum(nt) / 5))
for v, s, c, k in sorted(rows, reverse=True):
    print(f'  {c:22s} 5-word sequences shared with another text: {v:6.1%} | whole sentences (>=4 words) shared: {s:6.1%} | texts in sample: {k:.0f}')

corp = {json.loads(l)['text']: json.loads(l)['korpus'] for l in gzip.open(sys.argv[3], 'rt', encoding='utf-8')}
CAT = {'Vorschrift/Ritual/Brauch/Regel': r'\bVorschrift|\bRitual|\bBrauch|\bRegel\b|\bSatzung|\bGesetz|\bAnweisung|\bRichtlinie',
       'genau/richtig/Richtigkeit': r'\bgenau\b|\bRichtigkeit|\brichtig\b|\bkorrekt|\bexakt',
       'messen/wiegen/prüfen': r'\bmessen|\bwiegen|\bwägen|\bprüfen|\büberprüf|\bkontrollier|\bvermessen'}
RX = {k: re.compile(v) for k, v in CAT.items()}
cnt = collections.defaultdict(C); lem = collections.defaultdict(C); ntok = C()
for line in gzip.open(sys.argv[2], 'rt', encoding='utf-8'):
    r = json.loads(line); c = corp.get(r['text'], '?'); ntok[c] += 1; t = r.get('cotext_translation') or ''
    for k, rx in RX.items():
        if rx.search(t): cnt[k][c] += 1; lem[k][(r.get('lemma_form') or '', t[:32])] += 1
N = sum(ntok.values())
for k in CAT:
    tot = sum(cnt[k].values())
    print(f'\n{k}: {tot} = {1e5*tot/N:.0f} per 100k')
    print('   per 100k by group: ' + ', '.join(f'{c} {1e5*n/ntok[c]:.0f}' for c, n in sorted(cnt[k].items(), key=lambda kv: -kv[1] / ntok[kv[0]]) if ntok[c] > 10000))
    print('   words: ' + ' ; '.join(f'{lf} "{t}" {n}' for (lf, t), n in lem[k].most_common(9)))
