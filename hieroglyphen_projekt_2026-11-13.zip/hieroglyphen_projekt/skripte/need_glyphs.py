import json, sys, re
d = json.load(open(sys.argv[1], encoding='utf-8')); SIGN = re.compile(r'(?:Aa|NL|NU|[A-Z])\d+[A-Za-z]*'); need = set(['N33A', 'R5', 'W10', 'N33'])
for rows in d.values():
    for r in rows:
        need.update(r['variants']); need.update(SIGN.findall(r['example']['hiero']))
        for l in r['lemmas']: need.update(SIGN.findall(l['spelling'])); need.update(SIGN.findall(l['usual_other_spelling']))
print('\n'.join(sorted(need)))
