"""Fixed phase-conditioned observation targets in Quant, proposed and untrained.

q_elapsed is in Q. All levels and increments are xi=eta/Lq. No dimensional
input conversion, model import, phase estimation, or training occurs here.
Compile one operator per case from its observations/memberships, then reuse it
for candidates and sensitivities of that same case. Different cases require
their own operators. Prediction missingness cannot change loss support/weights.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = ROOT / "config/phase_targets_quant_v1.json"
PHASE_ORDER = ("nw", "early_rise", "late_rise", "hw", "early_fall", "late_fall")
COMPONENTS = ("level", "increment")


class InsufficientSupportError(ValueError):
    """A scalar loss is undefined when no target component is supported."""


def load_config(path=CONFIG_PATH):
    return json.loads(Path(path).read_text())


def _config(config):
    result = load_config()
    if config is not None:
        result.update(deepcopy(config))
    if tuple(result["phase_order"]) != PHASE_ORDER:
        raise ValueError("The declared six-phase order must be preserved")
    for key in ("lag_Q", "level_tolerance_xi", "increment_tolerance_xi",
                "minimum_membership_mass", "minimum_effective_samples",
                "maximum_interpolation_gap_factor"):
        if not np.isscalar(result[key]) or not np.isfinite(result[key]) or result[key] <= 0:
            raise ValueError(f"{key} must be one finite positive shared scalar")
    for key in ("level_phase_weights", "increment_phase_weights"):
        a = np.asarray(result[key], float)
        if a.shape != (6,) or not np.isfinite(a).all() or np.any(a <= 0):
            raise ValueError(f"{key} must have six positive finite entries")
    if result["nominal_step_Q"] is not None:
        if not np.isfinite(result["nominal_step_Q"]) or result["nominal_step_Q"] <= 0:
            raise ValueError("nominal_step_Q must be positive when supplied")
    return result


@dataclass
class _TimeStencil:
    q: np.ndarray
    left: np.ndarray
    right: np.ndarray
    fraction: np.ndarray
    available: np.ndarray
    time_weights: np.ndarray
    nominal_step_Q: float
    maximum_gap_Q: float

    def lagged(self, values):
        a = np.asarray(values, dtype=float)
        if a.shape[0] != len(self.q):
            raise ValueError("The first value dimension must match q_elapsed")
        answer = np.full(a.shape, np.nan, dtype=float)
        ix = np.flatnonzero(self.available)
        mix = self.fraction[ix].reshape((len(ix),)+(1,)*(a.ndim-1))
        left, right = a[self.left[ix]], a[self.right[ix]]
        interpolated = left + mix*(right-left)
        finite = np.isfinite(left) & np.isfinite(right)
        answer[ix] = np.where(finite, interpolated, np.nan)
        return answer

    def increment(self, values):
        a = np.asarray(values, dtype=float)
        return a-self.lagged(a)


def _stencil(q_elapsed, config):
    q = np.asarray(q_elapsed, dtype=float).copy()
    if q.ndim != 1 or len(q) < 2 or not np.isfinite(q).all() or np.any(np.diff(q) <= 0):
        raise ValueError("q_elapsed must be a finite strictly increasing vector")
    dt = np.diff(q)
    nominal = float(config["nominal_step_Q"] or np.median(dt))
    cap = config["maximum_interpolation_gap_factor"]*nominal
    permitted = dt <= cap
    w = np.zeros(len(q)); w[:-1] += np.where(permitted, dt/2, 0); w[1:] += np.where(permitted, dt/2, 0)
    query = q-config["lag_Q"]
    upper = np.searchsorted(q, query, side="left")
    left = np.zeros(len(q), dtype=int); right = left.copy()
    fraction = np.zeros(len(q)); available = np.zeros(len(q), dtype=bool)
    for i, j in enumerate(upper):
        if j < len(q) and q[j] == query[i]:
            left[i] = right[i] = j; available[i] = True
        elif 0 < j < len(q) and q[j]-q[j-1] <= cap:
            left[i], right[i] = j-1, j
            fraction[i] = (query[i]-q[j-1])/(q[j]-q[j-1])
            available[i] = True
    assert np.all(q[right[available]] <= q[available]), "A causal target must not use future samples"
    return _TimeStencil(q,left,right,fraction,available,w,nominal,float(cap))


def causal_increment(q_elapsed, values_xi, config=None):
    """Return xi(q)-xi(q-lag_Q), with NaN wherever endpoint support is absent."""
    return _stencil(q_elapsed,_config(config)).increment(values_xi)


class PhaseTargetOperator:
    """Observation-frozen linear rows and identical residual/Jacobian weights."""
    def __init__(self, q_elapsed, observation_xi, memberships, config=None):
        self.config = _config(config)
        self.stencil = _stencil(q_elapsed, self.config)
        self.observation_xi = np.asarray(observation_xi, float).copy()
        if self.observation_xi.ndim != 2 or self.observation_xi.shape[0] != len(self.stencil.q):
            raise ValueError("observation_xi must have shape [T,S]")
        if np.isinf(self.observation_xi).any():
            raise ValueError("Missing observations use NaN, not infinity")
        membership = np.asarray(memberships,float).copy()
        if membership.shape != self.observation_xi.shape+(6,) or not np.isfinite(membership).all():
            raise ValueError("memberships must be finite with shape [T,S,6]")
        if np.any(membership < 0) or np.any(membership > 1) or np.any(membership.sum(axis=-1) > 1+1e-12):
            raise ValueError("Memberships must lie in [0,1] with total at most one per station/time")
        self.memberships = membership
        self.target_features = (self.observation_xi, self.stencil.increment(self.observation_xi))
        self.coverage = []
        blocks = []
        for station in range(self.observation_xi.shape[1]):
            for phase in range(6):
                for component, name in enumerate(COMPONENTS):
                    finite = np.isfinite(self.target_features[component][:,station])
                    good = finite & (self.stencil.time_weights > 0)
                    mass = float(membership[good,station,phase].sum())
                    w = np.where(good,self.stencil.time_weights*membership[:,station,phase],0.)
                    duration = float(w.sum())
                    neff = float(duration**2/(w@w)) if duration > 0 else 0.
                    reasons = []
                    if duration <= 0: reasons.append("no_positive_observed_time_support")
                    if mass < self.config["minimum_membership_mass"]-1e-12: reasons.append("membership_mass_below_minimum")
                    if neff < self.config["minimum_effective_samples"]-1e-12: reasons.append("effective_samples_below_minimum")
                    supported = not reasons
                    weight = float(self.config[name+"_phase_weights"][phase])
                    row = dict(station_index=station,phase_index=phase,phase=PHASE_ORDER[phase],component=name,
                        supported=supported,missing_reasons=reasons,membership_mass=mass,effective_samples=neff,
                        weighted_duration_Q=duration,positive_weight_samples=int(np.count_nonzero(w)),
                        proposed_component_weight=weight)
                    self.coverage.append(row)
                    if supported:
                        ix = np.flatnonzero(w > 0)
                        blocks.append(dict(station=station,phase=phase,component=component,index=ix,
                            local_weights=w[ix]/duration,component_weight=weight,coverage=row))
        self.supported_station_indices = sorted(set(b["station"] for b in blocks))
        self.missing_station_indices = sorted(set(range(self.observation_xi.shape[1]))-set(self.supported_station_indices))
        self.blocks = blocks
        self.row_time_indices=[];self.row_station_indices=[];self.row_components=[];self.row_scales=[];self.row_targets=[]
        offset=0
        for b in blocks:
            station_phases = {x["phase"] for x in blocks if x["station"]==b["station"]}
            phase_component_total = sum(x["component_weight"] for x in blocks
                if x["station"]==b["station"] and x["phase"]==b["phase"])
            phase_weight = 1./len(station_phases)/len(self.supported_station_indices)
            component_fraction = b["component_weight"]/phase_component_total
            global_weight = component_fraction*phase_weight
            tolerance = self.config[COMPONENTS[b["component"]]+"_tolerance_xi"]
            scale = np.sqrt(global_weight*b["local_weights"])/tolerance
            b.update(row_start=offset,row_stop=offset+len(b["index"]),normalized_total_weight=global_weight)
            offset += len(b["index"])
            b["coverage"]["normalized_total_weight"] = global_weight
            b["coverage"]["normalized_phase_total_weight"] = phase_weight
            b["coverage"]["component_weight_within_phase"] = component_fraction
            self.row_time_indices.extend(b["index"])
            self.row_station_indices.extend([b["station"]]*len(b["index"]))
            self.row_components.extend([b["component"]]*len(b["index"]))
            self.row_scales.extend(scale)
            self.row_targets.extend(self.target_features[b["component"]][b["index"],b["station"]])
        self.row_time_indices=np.asarray(self.row_time_indices,dtype=int)
        self.row_station_indices=np.asarray(self.row_station_indices,dtype=int)
        self.row_components=np.asarray(self.row_components,dtype=int)
        self.row_scales=np.asarray(self.row_scales,dtype=float)
        self.row_targets=np.asarray(self.row_targets,dtype=float)

    def _selected_features(self, values):
        if not self.blocks:
            raise InsufficientSupportError("No supported target components; a zero loss would be misleading")
        a=np.asarray(values,float)
        if a.shape[:2]!=self.observation_xi.shape or a.ndim not in (2,3):
            raise ValueError("Values must have shape [T,S] or [T,S,P]")
        features=np.stack([a,self.stencil.increment(a)],axis=0)
        selected=features[self.row_components,self.row_time_indices,self.row_station_indices]
        if not np.isfinite(selected).all():
            raise ValueError("Prediction or sensitivity is nonfinite on the frozen observed target support")
        return selected

    def residual_vector(self,prediction_xi):
        a=np.asarray(prediction_xi,float)
        if a.ndim!=2:raise ValueError("prediction_xi must have shape [T,S]")
        return self.row_scales*(self._selected_features(a)-self.row_targets)

    def transform_sensitivity(self,J):
        a=np.asarray(J,float)
        if a.ndim!=3:raise ValueError("J must have shape [T,S,P]")
        return self.row_scales[:,None]*self._selected_features(a)

    def score(self,prediction_xi):
        if not self.blocks:
            return dict(status="insufficient_support",weighted_objective=None,weighted_rms=None,
                coverage=deepcopy(self.coverage),missing_station_indices=self.missing_station_indices)
        r=self.residual_vector(prediction_xi)
        rows=deepcopy(self.coverage)
        lookup={(v["station_index"],v["phase_index"],v["component"]):v for v in rows}
        for b in self.blocks:
            value=float(r[b["row_start"]:b["row_stop"]]@r[b["row_start"]:b["row_stop"]])
            entry=lookup[(b["station"],b["phase"],COMPONENTS[b["component"]])]
            normalized_mse=value/b["normalized_total_weight"]
            tolerance=self.config[COMPONENTS[b["component"]]+"_tolerance_xi"]
            entry.update(normalized_mse=normalized_mse,rmse_xi=float(np.sqrt(normalized_mse)*tolerance),
                         weighted_objective_contribution=value)
        for row in rows:
            if not row["supported"]:row.update(normalized_mse=None,rmse_xi=None,weighted_objective_contribution=None)
        return dict(status="scored_proposed_untrained_targets",weighted_objective=float(r@r),
            weighted_rms=float(np.linalg.norm(r)),residual_count=len(r),coverage=rows,
            supported_station_indices=self.supported_station_indices,missing_station_indices=self.missing_station_indices,
            nominal_step_Q=self.stencil.nominal_step_Q,maximum_gap_Q=self.stencil.maximum_gap_Q,
            prediction_does_not_select_support=True)


def build_target_operator(q_elapsed,observation_xi,memberships,config=None):
    """Compile one case's fixed support; reuse for candidates of that case only."""
    return PhaseTargetOperator(q_elapsed,observation_xi,memberships,config)


def residual_vector(q_elapsed,observation_xi,prediction_xi,memberships,config=None):
    return build_target_operator(q_elapsed,observation_xi,memberships,config).residual_vector(prediction_xi)


def transform_sensitivity(q_elapsed,observation_xi,J,memberships,config=None):
    return build_target_operator(q_elapsed,observation_xi,memberships,config).transform_sensitivity(J)


def score(q_elapsed,observation_xi,prediction_xi,memberships,config=None):
    return build_target_operator(q_elapsed,observation_xi,memberships,config).score(prediction_xi)


def consistency_check(output=ROOT/"review/phase_targets_quant_review.json"):
    """Small synthetic linear-operator checks; no Elbe fit or model execution."""
    checks=[]
    def check(name,passed,**details):
        checks.append(dict(name=name,passed=bool(passed),**details))
    q=np.arange(144,dtype=float)*4048
    angle=np.arange(144)/144*2*np.pi
    obs=np.column_stack([1e-8*np.sin(angle),1.2e-8*np.sin(angle+.2)+2e-9])
    membership=np.zeros((len(q),2,6))
    for station in range(2):
        position=(np.arange(144)/24+station*.1)%6
        for p in range(6):
            distance=np.abs((position-p+3)%6-3)
            membership[:,station,p]=np.maximum(0,1-distance)
    op=build_target_operator(q,obs,membership)
    check("perfect_prediction_zero",np.all(op.residual_vector(obs)==0))
    check("all_six_phases_supported_for_both_components",all(r["supported"] for r in op.coverage))
    inc=causal_increment(q,obs)
    check("causal_edges_are_nan_without_extrapolation",np.isnan(inc[:3]).all() and np.isfinite(inc[3:]).all())
    check("causal_increment_exact_on_native_grid",np.array_equal(inc[3:],obs[3:]-obs[:-3]))
    J=np.empty(obs.shape+(3,))
    J[:,:,0]=1e-9;J[:,:,1]=np.sin(angle)[:,None]*2e-9;J[:,:,2]=np.cos(angle*2)[:,None]*1e-9
    prediction=obs+np.einsum("tsp,p->ts",J,np.array([.2,-.1,.15]))
    analytical=op.transform_sensitivity(J)
    delta=1e-4
    finite=np.column_stack([(op.residual_vector(prediction+delta*J[:,:,j])-op.residual_vector(prediction-delta*J[:,:,j]))/(2*delta) for j in range(3)])
    relative=float(np.linalg.norm(finite-analytical)/np.linalg.norm(analytical))
    check("same_weighted_operator_for_sensitivity_and_residual",relative<1e-9,relative_finite_difference_error=relative)
    shifted=op.score(obs+2e-9)
    level_weights=np.asarray(op.config["level_phase_weights"],float)
    increment_weights=np.asarray(op.config["increment_phase_weights"],float)
    expected=4*float(np.mean(level_weights/(level_weights+increment_weights)))
    check("shared_level_tolerance_and_component_normalization",abs(shifted["weighted_objective"]-expected)<1e-12,
          objective=shifted["weighted_objective"],expected_objective=expected)
    phase_totals=[sum(b["normalized_total_weight"] for b in op.blocks if b["station"]==s and b["phase"]==p)
        for s in range(2) for p in range(6)]
    check("hierarchy_components_then_equal_phases_then_equal_stations",np.allclose(phase_totals,1/12,rtol=0,atol=1e-15),
          normalized_phase_weight_min=float(min(phase_totals)),normalized_phase_weight_max=float(max(phase_totals)))
    scaled=build_target_operator(q,obs*7.5,membership,{"level_tolerance_xi":7.5e-9,"increment_tolerance_xi":7.5e-9})
    check("common_unit_rescaling_preserves_loss",np.allclose(scaled.residual_vector(prediction*7.5),op.residual_vector(prediction),rtol=1e-11,atol=1e-13))
    sparse_membership=membership.copy();sparse_membership[:,:,5]=0
    sparse=build_target_operator(q,obs,sparse_membership)
    missing=sparse.score(obs)["coverage"]
    check("missing_phase_explicit_not_zero_error",all(not r["supported"] and r["rmse_xi"] is None for r in missing if r["phase_index"]==5))
    no_support=build_target_operator(q,obs,np.zeros_like(membership))
    check("empty_support_has_undefined_score",no_support.score(obs)["weighted_objective"] is None)
    bad=prediction.copy();bad[20,0]=np.nan
    try:op.residual_vector(bad);reject=False
    except ValueError:reject=True
    check("prediction_missingness_cannot_improve_support",reject)
    removed=np.ones(len(q),bool);removed[[37,38]]=False
    qg=q[removed];og=obs[removed];lag=causal_increment(qg,og)
    query_index=int(np.flatnonzero(qg==q[40])[0])
    check("large_timestamp_gap_not_interpolated",np.isnan(lag[query_index]).all())
    qi=np.arange(40,dtype=float)*5000
    affine=np.column_stack([1e-8+qi*2e-14,-1e-8+qi*3e-14])
    ai=causal_increment(qi,affine)
    err=float(np.max(np.abs(ai[3:]-np.array([2e-14,3e-14])*12144)))
    check("within_support_interpolation_on_actual_grid",err<1e-22,maximum_increment_error_xi=err)
    affine[6,0]=np.nan
    ai=causal_increment(qi,affine)
    check("nan_bracket_not_skipped_or_filled",np.isnan(ai[8,0]) and np.isfinite(ai[8,1]))
    check("stencil_never_uses_future_samples",np.all(op.stencil.q[op.stencil.right[op.stencil.available]]<=op.stencil.q[op.stencil.available]))
    status="passed_synthetic_operator_checks_proposed_untrained" if all(x["passed"] for x in checks) else "failed"
    result=dict(status=status,checks=checks,checks_passed=sum(x["passed"] for x in checks),checks_total=len(checks),
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        config_sha256=hashlib.sha256(CONFIG_PATH.read_bytes()).hexdigest(),
        config_status=op.config["status"],real_training_performed=False,real_model_or_old_trainer_modified=False,
        row_order=op.config["row_order"],nominal_step_Q=op.stencil.nominal_step_Q,
        normalization=op.config["normalization"],operator_reuse=op.config["operator_reuse"],
        common_tolerances=dict(level_xi=op.config["level_tolerance_xi"],increment_xi=op.config["increment_tolerance_xi"]),
        limits=["Synthetic algebra/coverage checks establish operator consistency, not improved Elbe accuracy.",
            "Phase memberships and station selection are supplied by the caller; no future-observation phase gate is inferred here.",
            "The increment is a past level difference, not water velocity, force, flux, or a high/low event-time target.",
            "Scores with different supported components or stations must not be compared without their coverage report.",
            "Numerical starting tolerances are shared constants, not estimated observation uncertainty."])
    Path(output).parent.mkdir(parents=True,exist_ok=True)
    Path(output).write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+"\n")
    print(json.dumps(dict(status=status,checks_passed=result["checks_passed"],checks_total=len(checks),output=str(output))))
    if status=="failed":raise AssertionError("A phase-target consistency check failed")
    return result


if __name__=="__main__":
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument("--self-check",action="store_true")
    args=parser.parse_args()
    if args.self_check:consistency_check()
    else:parser.print_help()
