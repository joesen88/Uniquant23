"""Archive the player and phase-target preparation without changing old fits."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent/'tide_deliverables/Elbe_Tide_Player_und_Phasentargets_Quant.zip'
FILES=[
 'report/Elbe_Tide_Player_Quant.html',
 'src/tide_player_template.html','src/build_tide_player_quant.py',
 'src/render_tide_player_from_export.py','src/check_tide_player_controller.cjs',
 'src/phase_targets_quant.py','src/score_tide_phase_targets.py','src/package_tide_player.py',
 'config/phase_targets_quant_v1.json',
 'data/visualization/tide_player_quant.json','data/visualization/tide_player_quant.npz',
 'review/tide_player_quant_review.json','review/tide_player_controller_review.json',
 'review/phase_targets_quant_review.json','review/phase_targets_quant_baseline.json',
 'vendor/plotly.min.js',
]

README='''ELBE: TIDE ABSPIELEN UND TARGETS JE TEILPHASE

STARTEN
report/Elbe_Tide_Player_Quant.html im Browser oeffnen. Die Datei enthaelt
Diagrammbibliothek und Daten; sie benoetigt keine Internetverbindung.
Fall auswaehlen, Abspielen anklicken. Der Zeitregler und die beiden
Schritttasten steuern denselben Zeitpunkt fuer alle sieben Pegel.
Ansicht: gemeinsam oder nebeneinander. Darstellung: Pegel oder Fehler.
Zukunft anzeigen ist anfangs aus; nachfolgende Kurvenpunkte werden tatsaechlich
aus den dargestellten Arrays entfernt. Die gemeinsame Werteskala bleibt fest.

WAS WIRD ANGEZEIGT?
Eingang: Nur Osteriff und Kollmar sind als gemessene Randpegel vorgegeben.
Gemessener Zielwert: Die tatsaechliche Pegelmessung als Vergleichsreferenz.
Ausgabe: Der gespeicherte Modellpegel am selben Zeitpunkt.
Fehler: Modellausgabe minus Messung.
Innenpegel: Brunsbuettel, Brokdorf, Glueckstadt und Krautsand.
Stoer: Im gespeicherten Vergleich maskiert. Keine erfundene Messung, kein
Fehler null. Ein dort vorhandener Modellwert ist keine Zielbeobachtung.
Die Tabelle zeigt zeitabhaengige Pegel-Eingaenge, nicht saemtliche internen
Zustaende. Geometrie, Anfangszustand und eingefrorene Parameter wirken weiter.
Perfekte Randpegel-Uebereinstimmung ist kein unabhaengiger Genauigkeitstest.

FAELLE
legacy_pickup: derselbe alte Lauf cloud_tau10_pickup wie in der Fehlergrafik;
151 Auswertezeitpunkte am 23.09.2026.
min_01: gespeicherter V3-Endstand, 147 Zeitpunkte, 25./26.09.2026.
p98_01: gespeicherter V3-Endstand, 148 Zeitpunkte, 29.01.2024.
Kalenderangaben im Player sind Europe/Berlin. Die beiden V3-Faelle gehoerten
zur Trainingsauswahl. Diese Beispiele belegen keine neue Prognoseguete.

QUANT-STATUS
Anzeige, exportierte Beobachtungen, Modellausgaben und Fehler: eta/Lq.
Zeit: Q; gespeicherter Abstand der Punkte 4048Q.
Neues Aenderungstarget: Delta-xi(q)=xi(q)-xi(q-12144Q), also eine
Pegeldifferenz, keine Geschwindigkeit und keine Kraft.
Die ersten drei Aenderungswerte sind in diesem ausgeschnittenen Export
nicht belegt; die Pegelwerte und ihre Modellfehler sind trotzdem vorhanden.
Keine unabhaengige Amplitudennormierung pro Station, Phase oder Fall.
Phase: phi im Ring [0,1), Phasor exp(2*pi*i*phi), Betrag1.
Exakte rationale q-Urspruenge bleiben Zeichenketten relativ zum JJ-Anker
2029-07-12T22:00:00Z. Lokale Differenzen werden vor Float-Umrechnung gebildet.
Der historische V3-Trainer und sein hydrodynamischer Kern verwenden weiterhin
ihre bisherigen SI-Schnittstellen. Das ist offen ausgewiesen. Der neue
Quant-Target-Operator ist eine additive Vorbereitung, kein neu trainierter
nativer Quant-Hydrodynamiksolver.

SECHS LOKALE TEILPHASEN
0 Niedrigwasserbereich: Pegelhoehe / Pegelaenderung = 3:1
1 Fruehes Steigen:      Pegelhoehe / Pegelaenderung = 1:3
2 Spaetes Steigen:      Pegelhoehe / Pegelaenderung = 1:2
3 Hochwasserbereich:   Pegelhoehe / Pegelaenderung = 3:1
4 Fruehes Fallen:      Pegelhoehe / Pegelaenderung = 1:3
5 Spaetes Fallen:      Pegelhoehe / Pegelaenderung = 1:2
Das sind vorgeschlagene Startgewichte, noch keine gelernten Naturkonstanten.
Beide Fehlerkomponenten verwenden eine gemeinsame feste Quant-Toleranz von
1e-9 in xi. Sie ist ein numerischer Startwert, keine behauptete Messgenauigkeit.
Komponenten werden innerhalb einer Phase auf ihr Verhaeltnis normiert;
belegte Phasen und anschliessend belegte Stationen erhalten gleiche Gewichte.
Die Gewichtung zwischen verschiedenen Faellen uebernimmt ein spaeterer
Trainer; bestehende Min/P98- und Ereigniscluster-Gewichte bleiben zu beachten.

PHASENDEFINITION
Oertliche beobachtete Niedrig- und Hochwasserpunkte verankern den Phasenring.
Die steigende und die fallende Halbtide duerfen verschieden lang sein.
Sechs periodische Kosinusgewichte ueberlappen weich; ihre Summe ist eins.
Die Klassifikation ist aus Messungen mit erweitertem Vor-/Nachkontext
abgeleitet und bleibt fuer den Vergleich von Modellkandidaten fest.
Die Filterung dient ausschliesslich der Ankererkennung. Die rohen Pegelwerte
bleiben Targets. Regeln und Anker stehen im Datenreview.
Die Phasen sind rueckblickende Labels; sie duerfen nicht als zur damaligen
Vorhersagezeit bereits bekannte Zukunftsinformation in ein Prognosemodell
gelangen. Eine Pegelwende ist keine gemessene Stroemungsumkehr.
Der Player spielt einen historischen Lauf mit vorgegebenen Randverlaeufen ab.
Das Ausblenden spaeterer Werte aendert diese Herkunft nicht.

WAS IST UMGESETZT, WAS NOCH NICHT?
Umgesetzt: Player, Quant-Exporte, lokale Phasen, fester linearer Target-
Operator fuer Pegel und Pegeldifferenz, identisch gewichtete Sensitivitaeten,
Baseline-Bewertung der drei gespeicherten Beispiele.
Noch nicht umgesetzt: Einbindung des neuen Ziels in einen neuen Optimierungslauf,
Neutraining, separate Extremzeit-Targets, neue Stroemungs-/Partikel-Messziele,
vollstaendige native Quant-Umstellung des alten Hydrodynamikkerns.
Es wurden keine alten Parameter, Modelle oder Messdateien ueberschrieben.
Geometrie bleibt das bestehende Modellprofil, kein neuer Quadratkern-Fit.

BEDIENUNGSPRUEFUNG
12 Controller-/Datenpruefungen bestanden: Play/Pause, Schritte, Slider,
Fallwechsel, Ansichten, Pegel/Fehler, echte Zukunftsausblendung, gemeinsame
Skalen, Eingangsrollen, fehlende Stoer-Messung, Aenderungsrand, Quant-Achsen.
Die Pruefung verwendet eine kontrollierte Node-Ausfuehrung mit minimalem DOM
und einem aufzeichnenden Diagrammadapter. Sie ist keine Pixel-/Browserpruefung.
Die lokale Chromium-Pruefung scheiterte an Prozess-/Socketbeschraenkungen.
Die automatische Browserfreigabe lehnte das Oeffnen der lokalen Dateiadresse
ab. Der grafische Browserlauf ist daher in dieser Umgebung nicht bestaetigt.
15 synthetische Checks des Target-Operators bestanden. Ergebnisse liegen unter
review/. Die alten Simulationen wurden nicht neu gerechnet.

WIEDERHOLEN
Den Player aus dem enthaltenen Export neu bauen:
  python src/render_tide_player_from_export.py
Die drei unveraenderten Beispiele nach den neuen Targets bewerten (NumPy):
  python src/score_tide_phase_targets.py
Target-Operator pruefen (NumPy):
  python src/phase_targets_quant.py --self-check
Controller und Datenvertrag pruefen (Node):
  node src/check_tide_player_controller.cjs
build_tide_player_quant.py leitet die Exporte aus dem bestehenden Hauptprojekt
ab und benoetigt die dortigen Quellarchive und SciPy. Diese umfangreichen
Archive werden hier nicht dupliziert. Ihre Hashes stehen im Review.

Die NPZ-Datei behaelt die numerische Genauigkeit; die JSON-Datei erhaelt alle
gespeicherten Gleitkommazahlen und verwendet null fuer fehlende Werte.
'''


def main():
    for rel in FILES:
        assert (ROOT/rel).is_file(), rel
    manifest={"status":"viewer_and_proposed_quant_targets_no_training",
        "new_training_runs":0,"browser_visual_validation":False,
        "files":[{"path":rel,"sha256":hashlib.sha256((ROOT/rel).read_bytes()).hexdigest(),
                  "bytes":(ROOT/rel).stat().st_size} for rel in FILES]}
    OUT.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for rel in FILES:z.write(ROOT/rel,rel)
        z.writestr('START_TIDE_PLAYER_QUANT.txt',README)
        z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
    with zipfile.ZipFile(OUT) as z:assert z.testzip() is None
    print(json.dumps({"path":str(OUT),"bytes":OUT.stat().st_size,"entries":len(FILES)+2,
                      "sha256":hashlib.sha256(OUT.read_bytes()).hexdigest()}))


if __name__=='__main__':main()
