"""Score frozen examples against proposed Quant targets; never run training."""
from pathlib import Path
import hashlib
import json
import numpy as np
from phase_targets_quant import build_target_operator, causal_increment

ROOT = Path(__file__).resolve().parents[1]
INNER = [1,2,4,5]


def main():
    source = ROOT / "data/visualization/tide_player_quant.json"
    payload = json.loads(source.read_text())
    rows = []
    for case in payload["cases"]:
        q = np.asarray(case["q_elapsed"],dtype=float)
        observation = np.asarray(case["observed_xi"],dtype=float)[:,INNER]
        prediction = np.asarray(case["model_xi"],dtype=float)[:,INNER]
        membership = np.asarray(case["phase_weights"],dtype=float)[:,INNER,:]
        assert np.isfinite(membership).all()
        # One observation-frozen operator for THIS case and candidate support.
        op = build_target_operator(q,observation,membership,config={"nominal_step_Q":4048})
        score = op.score(prediction)
        assert len(score["coverage"]) == 4*6*2
        assert all(c["supported"] for c in score["coverage"])
        assert np.array_equal(causal_increment(q,observation),
            np.asarray(case["target_increment_xi"],dtype=float)[:,INNER],equal_nan=True)
        assert np.array_equal(causal_increment(q,prediction),
            np.asarray(case["model_increment_xi"],dtype=float)[:,INNER],equal_nan=True)
        for component in score["coverage"]:
            component["station"] = payload["stations"][INNER[component["station_index"]]]["label"]
        rows.append({"case_id":case["id"],"model_label":case["model_label"],
                     "new_training_runs":0,"score":score})
    result = {"status":"frozen_examples_scored_no_parameter_change",
        "source_sha256":hashlib.sha256(source.read_bytes()).hexdigest(),
        "config_sha256":hashlib.sha256((ROOT/'config/phase_targets_quant_v1.json').read_bytes()).hexdigest(),
        "station_roles":"Only the four interior gauges are scored; prescribed boundaries and masked Stör excluded.",
        "metric":"weighted_rms is dimensionless and divided by fixed proposed Quant tolerances; physical errors are rmse_xi.",
        "interpretation":"Baseline examples only. Min/P98 were training cases; legacy_pickup is a different frozen model variant. No performance comparison between model generations is implied.",
        "new_training_runs":0,"cases":rows}
    target=ROOT/'review/phase_targets_quant_baseline.json'
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))
    print(json.dumps({"path":str(target),"cases":[{"id":r['case_id'],"supported_components":len(r['score']['coverage']),"weighted_rms":r['score']['weighted_rms']} for r in rows]}))


if __name__ == '__main__':
    main()
