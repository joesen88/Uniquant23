"""Build a local, self-contained player from frozen results; no solver or fit.

Legacy units are converted only at the observed-context import boundary.
All phase calculations, targets, display data and new objective inputs use
the common Quant basis. The original V3 trainer is not changed by this module.
"""
from __future__ import annotations

from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
from zoneinfo import ZoneInfo
import hashlib
import json

import numpy as np
from scipy.signal import find_peaks, savgol_filter

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data/visualization"
PANEL = ROOT.parent / "tide_case_sources/wet_dry_source/wet_dry_elbe/hydro/hydro_panel_5min.npz"
LEGACY = ROOT / "results/legacy_phase_context/phase_corrected_quant.npz"
FIELDS = OUT / "tide_space_time_quant.npz"
PHASE_REVIEW = ROOT / "review/legacy_phase_context_correction.json"
LQ = float(Fraction(11242217175, 506))
Q_PER_LEGACY_TIME = Fraction(1012, 75)
JJ = int(datetime(2029, 7, 12, 22, tzinfo=timezone.utc).timestamp())
TZ = ZoneInfo("Europe/Berlin")
STEP_Q = 4048
DELTA_Q = 12144
KEYS = ["osteriff", "brunsbuettel", "brokdorf", "stoer", "glueckstadt", "krautsand", "kollmar"]
NAMES = ["Osteriff", "Brunsbüttel", "Brokdorf", "Stör-Sperrwerk", "Glückstadt", "Krautsand", "Kollmar"]
PHASES = [
    {"key": "low_turn", "label": "Niedrigwasserbereich", "focus": "Tiefpunkt und Pegelverlauf"},
    {"key": "early_rise", "label": "Frühes Steigen", "focus": "Pegelanstieg und Höhe"},
    {"key": "late_rise", "label": "Spätes Steigen", "focus": "Annäherung an Hochwasser"},
    {"key": "high_turn", "label": "Hochwasserbereich", "focus": "Hochstand und Pegelverlauf"},
    {"key": "early_fall", "label": "Frühes Fallen", "focus": "Pegelabfall und Höhe"},
    {"key": "late_fall", "label": "Spätes Fallen", "focus": "Annäherung an Niedrigwasser"},
]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def native(value):
    """Strict JSON: retain precision, represent unavailable measurements as null."""
    if isinstance(value, np.ndarray):
        return native(value.tolist())
    if isinstance(value, (list, tuple)):
        return [native(x) for x in value]
    if isinstance(value, dict):
        return {str(k): native(v) for k, v in value.items()}
    if isinstance(value, (float, np.floating)):
        return float(value) if np.isfinite(value) else None
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    if isinstance(value, (int, np.integer)):
        return int(value)
    return value


def q_offsets(t, origin):
    numerator = (np.asarray(t, dtype=np.int64) - int(origin)) * 1012
    if np.any(numerator % 75):
        raise ValueError("Integer Quant grid required for these exports")
    return numerator // 75


def iso(t):
    return datetime.fromtimestamp(int(t), timezone.utc).isoformat().replace("+00:00", "Z")


def qratio(t):
    q = Fraction(int(t) - JJ) * Q_PER_LEGACY_TIME
    return f"{q.numerator}/{q.denominator}"


def time_from_origin(q_origin_ratio, elapsed):
    a = Fraction(q_origin_ratio) / Q_PER_LEGACY_TIME
    if a.denominator != 1:
        raise ValueError("Unexpected fractional source timestamp")
    offsets = [Fraction(int(q)) / Q_PER_LEGACY_TIME for q in elapsed]
    if any(x.denominator != 1 for x in offsets):
        raise ValueError("Unexpected source timestamp grid")
    return np.asarray([JJ + int(a) + int(x) for x in offsets], dtype=np.int64)


def increments(q, y):
    """Exact backward increment for the verified 4048-Q grids; no extrapolation."""
    q, y = np.asarray(q), np.asarray(y)
    if not np.all(np.diff(q) == STEP_Q):
        raise ValueError("Player input must keep the original Quant sample grid")
    result = np.full(y.shape, np.nan)
    span = DELTA_Q // STEP_Q
    for k in range(span, len(q)):
        good = np.isfinite(y[k-span:k+1]).all(axis=0)
        result[k, good] = y[k, good] - y[k-span, good]
    return result


def contiguous_runs(mask):
    changes = np.diff(np.r_[False, np.asarray(mask, bool), False].astype(int))
    return zip(np.flatnonzero(changes == 1), np.flatnonzero(changes == -1))


def local_phase(context_q, context_xi, target_q):
    """Measured local NW/HW anchors with fixed, documented filtering.

    The smoothing serves only anchor detection; raw measured stage remains the
    target. A half-cycle has to be bracketed by two genuine observed anchors.
    The labels are retrospective and must not be a live prediction input.
    """
    turns = np.full(len(target_q), np.nan)
    anchors = []
    minimum_distance = int(np.ceil(202400 / STEP_Q))
    for a, b in contiguous_runs(np.isfinite(context_xi)):
        if b-a < 40 or np.any(np.diff(context_q[a:b]) != STEP_Q):
            continue
        yy = savgol_filter(context_xi[a:b], 13, 3, mode="interp")
        highs, _ = find_peaks(yy, distance=minimum_distance, prominence=1e-8)
        lows, _ = find_peaks(-yy, distance=minimum_distance, prominence=1e-8)
        found = sorted([(int(i), "high") for i in highs] + [(int(i), "low") for i in lows])
        alternate = []
        for i, kind in found:
            if alternate and alternate[-1][1] == kind:
                prev = alternate[-1][0]
                better = yy[i] > yy[prev] if kind == "high" else yy[i] < yy[prev]
                if better:
                    alternate[-1] = (i, kind)
            else:
                alternate.append((i, kind))
        for i, kind in alternate:
            anchors.append({"q_elapsed": int(context_q[a+i]), "kind": kind,
                            "raw_xi": float(context_xi[a+i]), "detection_xi": float(yy[i])})
        for (i, ka), (j, kb) in zip(alternate[:-1], alternate[1:]):
            qa, qb = int(context_q[a+i]), int(context_q[a+j])
            if ka == kb or not (121440 <= qb-qa <= 526240):
                continue
            take = (target_q >= qa) & (target_q <= qb)
            start = 0.0 if ka == "low" else 0.5
            turns[take] = (start + 0.5*(target_q[take]-qa)/(qb-qa)) % 1.0
    weights = np.full((len(target_q), 6), np.nan)
    for i in np.flatnonzero(np.isfinite(turns)):
        d = (turns[i] - np.arange(6)/6 + .5) % 1 - .5
        w = np.where(np.abs(d) <= 1/6, .5*(1+np.cos(6*np.pi*d)), 0.0)
        weights[i] = w / w.sum()
    return turns, weights, anchors


def build_data():
    OUT.mkdir(parents=True, exist_ok=True)
    sources = [PANEL, LEGACY, FIELDS, PHASE_REVIEW]
    before = {str(p): sha(p) for p in sources}
    old_review = json.loads(PHASE_REVIEW.read_text())
    with np.load(LEGACY, allow_pickle=False) as z:
        qi = z["q_evaluation_elapsed"].copy()
        case_idx = list(map(str, z["case_ids"])).index("cloud_tau10_pickup")
        obs = z["observation_context_xi"][z["context_is_evaluation"]].copy()
        model = z["model_evaluation_xi"][case_idx].copy()
        legacy_error = z["error_evaluation_xi"][case_idx].copy()
        assert np.allclose(model-obs, legacy_error, atol=1e-22, rtol=1e-12, equal_nan=True)
    cases = [{
        "id": "legacy_pickup", "label": "23.09.2026 · bisheriger Fehlerfall",
        "model_label": "Gespeicherter Lauf cloud_tau10_pickup",
        "q_origin_ratio": old_review["q_origin_ratio"], "q_elapsed": qi,
        "observed_xi": obs, "model_xi": model, "error_xi": legacy_error,
        "source_note": "Derselbe gespeicherte Lauf wie in der Fehlergrafik; keine neue Berechnung.",
    }]
    with np.load(FIELDS, allow_pickle=False) as z:
        station_s = z["station_s_xi"].copy()
        for key, label in [("min_01", "Min-Fall · 25./26.09.2026"), ("p98_01", "P98-Fall · 29.01.2024")]:
            obs = z[f"{key}_observed_eta_xi"].copy()
            model = z[f"{key}_predicted_eta_at_stations_xi"].copy()
            cases.append({
                "id": key, "label": label, "model_label": "V3 · eingefrorener Endstand",
                "q_origin_ratio": str(z[f"{key}_q_origin_ratio"]),
                "q_elapsed": z[f"{key}_q_elapsed"].copy(),
                "observed_xi": obs, "model_xi": model, "error_xi": model-obs,
                "source_note": "Gespeicherter V3-Endstand mit bisherigem Trapezprofil; Fall gehörte zur Trainingsauswahl.",
            })
    stations = [{"key": k, "label": n, "short_label": n,
                 "role": "boundary_forcing" if i in (0,6) else "no_observation" if i == 3 else "comparison_only",
                 "s_xi": float(station_s[i])} for i, (k, n) in enumerate(zip(KEYS, NAMES))]
    with np.load(PANEL, allow_pickle=False) as z:
        panel_t = z["unix_utc"].copy()
        # Explicit legacy-import boundary. No legacy units enter targets below.
        panel_xi = np.column_stack([z[f"h_{k}_m_nhn"]/LQ for k in KEYS])
    audit = []
    native_export = {}
    for case in cases:
        q = case["q_elapsed"]
        t = time_from_origin(case["q_origin_ratio"], q)
        # Preserve original missing-data policy; Stör is not restored from panel.
        obs, model = case["observed_xi"], case["model_xi"]
        assert np.isnan(obs[:,3]).all()
        panel_idx = np.searchsorted(panel_t, t)
        assert np.array_equal(panel_t[panel_idx], t)
        valid = np.isfinite(obs)
        same = np.array_equal(panel_xi[panel_idx][valid], obs[valid])
        if not same:
            raise ValueError(f"Observed context differs from frozen targets: {case['id']}")
        # Measured support before and after: local phases need local extrema.
        context_selection = (panel_t >= t[0]-48*3600) & (panel_t <= t[-1]+48*3600)
        cq = q_offsets(panel_t[context_selection], int(t[0]))
        cy = panel_xi[context_selection]
        turns = np.full(obs.shape, np.nan)
        membership = np.full((*obs.shape,6), np.nan)
        station_audits = []
        for j, station in enumerate(stations):
            if station["role"] == "no_observation":
                station_audits.append({"station": station["key"], "status": "originally_masked"})
                continue
            ph, ww, anchors = local_phase(cq, cy[:,j], q)
            ph[~valid[:,j]], ww[~valid[:,j]] = np.nan, np.nan
            turns[:,j], membership[:,j] = ph, ww
            station_audits.append({"station": station["key"],
                "assigned": int(np.isfinite(ph).sum()), "total": len(q), "anchors": anchors})
        idx = np.full(obs.shape, np.nan)
        assigned = np.isfinite(turns)
        idx[assigned] = np.argmax(membership[assigned], axis=-1)
        focus = [[PHASES[int(idx[i,j])]["focus"] if assigned[i,j] else "Keine gemessene Phasenzuordnung"
                  for j in range(7)] for i in range(len(q))]
        labels = [datetime.fromtimestamp(int(x), TZ).strftime("%d.%m.%Y %H:%M %Z") for x in t]
        case.update({"time_label": f"{labels[0]} → {labels[-1]}", "local_labels": labels,
                     "phase_index": idx, "phase_weights": membership, "phase_turns": turns,
                     "phase_phasor_real": np.cos(2*np.pi*turns),
                     "phase_phasor_imag": np.sin(2*np.pi*turns),
                     "target_increment_xi": increments(q, obs),
                     "model_increment_xi": increments(q, model), "phase_focus": focus,
                     "input_notes": [
                         "Osteriff und Kollmar: gemessene Randpegel sind dem Lauf vorgegeben.",
                         "Die Übereinstimmung an diesen Randpegeln ist kein unabhängiger Genauigkeitsnachweis.",
                         "Brunsbüttel, Brokdorf, Glückstadt und Krautsand: Messungen dienen als Ziel und Vergleich; sie werden nicht als lokale Pegelvorgabe erzwungen.",
                         "Stör: im gespeicherten Lauf keine freigegebene Pegelmessung; Modellkurve allein ist kein Target.",
                         "Geometrie, eingefrorene Parameter und Anfangszustand wirken zusätzlich. Die Tabelle zeigt die zeitabhängigen Pegel-Eingaben.",
                         "Die Wiedergabe blendet Zeit ein. Der ursprüngliche Lauf ist eine Nachrechnung mit vorgegebenen Randverläufen, keine freie Wetter-/Tideprognose.",
                     ]})
        audit.append({"case_id": case["id"], "samples": len(q), "source_start_utc": iso(t[0]),
                      "source_end_utc": iso(t[-1]), "q_origin_ratio": case["q_origin_ratio"],
                      "observation_context_matches_exactly": same, "stations": station_audits,
                      "all_observed_points_have_local_phase": bool(np.isfinite(turns[valid]).all()),
                      "interior_target_samples": int(valid[:,[1,2,4,5]].sum())})
        for name in ["q_elapsed", "observed_xi", "model_xi", "error_xi", "phase_turns", "phase_weights",
                     "target_increment_xi", "model_increment_xi", "phase_phasor_real", "phase_phasor_imag"]:
            native_export[f"{case['id']}_{name}"] = case[name]
        native_export[f"{case['id']}_q_origin_ratio"] = np.asarray(case["q_origin_ratio"])
    values = np.concatenate([c[k].ravel() for c in cases for k in ("observed_xi", "model_xi")])
    lo, hi = float(np.nanmin(values)), float(np.nanmax(values))
    pad = .06*(hi-lo)
    max_error = max(float(np.nanmax(np.abs(c["error_xi"]))) for c in cases) * 1.1
    payload = {
        "schema_version": 1, "title": "Tide abspielen · Eingabe, Ziel und Modell",
        "metadata": {
            "time_anchor_utc": "2029-07-12T22:00:00Z",
            "quant_basis": "Gemeinsame feste Quantbasis: η/Lq und Zeit in Q; exakte rationale Zeitursprünge.",
            "original_training_units": "legacy_SI",
            "phase_targets_status": "Neue Teilphasen-Ziele: Vorbereitung. Die gespeicherten Läufe wurden damit noch nicht trainiert.",
            "phase_assignment_note": "Teilphasen aus beobachteten lokalen Tief-/Hochständen; rückblickende Zuordnung mit Messkontext. Keine bekannte Eingabe für eine laufende Prognose.",
            "run_type_note": "Rückblick mit vorgegebenen Randpegeln",
            "new_targets_units": "Pegel ξ=η/Lq; Änderung Δξ über 12144Q; Phasenphasor exp(2πiφ), Betrag1.",
            "original_training_note": "Anzeige und neue Target-Vorbereitung: Quant. Der gespeicherte V3-Lauf stammt aus dem bisherigen SI-Rechenkern.",
            "increment_horizon_Q": DELTA_Q,
            "no_new_training": True,
        },
        "units": {"stage_factor": 1e-8, "error_factor": 1e-9, "time_factor": 1e5},
        "limits": {"stage": [lo-pad, hi+pad], "error": [-max_error, max_error]},
        "stations": stations, "phases": PHASES, "cases": cases,
    }
    json_path = OUT / "tide_player_quant.json"
    json_path.write_text(json.dumps(native(payload), ensure_ascii=False, separators=(",", ":"), allow_nan=False))
    npz_path = OUT / "tide_player_quant.npz"
    np.savez_compressed(npz_path, **native_export, station_keys=np.asarray(KEYS))
    after = {str(p): sha(p) for p in sources}
    assert before == after
    review = {
        "status": "built_from_frozen_results_no_training", "source_hashes": before,
        "original_inputs_unchanged": True, "builder_sha256": sha(__file__),
        "json_sha256": sha(json_path), "npz_sha256": sha(npz_path),
        "common_scale_all_stations_and_cases": True, "stationwise_amplitude_normalization": False,
        "all_new_targets_quant": True, "old_training_native_quant": False,
        "phase_detector": {"scope": "retrospective_local_observation_labels_only",
            "context_each_side_Q": 2331648, "sample_step_Q": STEP_Q,
            "savgol_samples": 13, "savgol_degree": 3, "raw_targets_smoothed": False,
            "same_kind_peak_min_distance_Q": 202400, "prominence_xi": 1e-8,
            "half_cycle_duration_Q": [121440,526240],
            "membership": "periodic raised cosine; centres k/6, half-width1/6; partition of unity",
            "phase_time_precision": "anchors lie on the original4048Q grid; not exact physical turning times",
            "gap_policy": "no extrapolated phase, no missing-value restoration"},
        "cases": audit,
        "files": [str(json_path.relative_to(ROOT)),str(npz_path.relative_to(ROOT))],
    }
    (ROOT / "review/tide_player_quant_review.json").write_text(json.dumps(native(review), ensure_ascii=False, indent=2, allow_nan=False))
    return payload, review


def render_html():
    template = ROOT / "src/tide_player_template.html"
    if not template.exists():
        return None
    text = template.read_text()
    if text.count("__PLAYER_DATA_JSON__") != 1 or text.count("__PLOTLY_SOURCE__") != 1:
        raise ValueError("Expected exactly one data and one Plotly placeholder")
    data = (OUT / "tide_player_quant.json").read_text().replace("</", "<\\/")
    plotly = (ROOT / "vendor/plotly.min.js").read_text()
    text = text.replace("__PLAYER_DATA_JSON__", data).replace("__PLOTLY_SOURCE__", plotly)
    path = ROOT / "report/Elbe_Tide_Player_Quant.html"
    path.write_text(text)
    return path


if __name__ == "__main__":
    payload, review = build_data()
    html = render_html()
    print(json.dumps({"json": str(OUT / "tide_player_quant.json"), "html": str(html) if html else None,
        "cases": [{"id": c["case_id"], "samples": c["samples"],
                   "all_observed_points_have_local_phase": c["all_observed_points_have_local_phase"]} for c in review["cases"]]}))
