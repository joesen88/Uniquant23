"""Rebuild the offline viewer from its bundled Quant export; no model needed."""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
template=(ROOT/'src/tide_player_template.html').read_text()
data=(ROOT/'data/visualization/tide_player_quant.json').read_text().replace('</','<\\/')
plotly=(ROOT/'vendor/plotly.min.js').read_text()
assert template.count('__PLAYER_DATA_JSON__')==1 and template.count('__PLOTLY_SOURCE__')==1
html=template.replace('__PLAYER_DATA_JSON__',data).replace('__PLOTLY_SOURCE__',plotly)
out=ROOT/'report/Elbe_Tide_Player_Quant.html'
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(html)
print(out)
