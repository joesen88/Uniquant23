/* Offline controller/data contract checks. No browser, network or visual claim. */
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const template=fs.readFileSync(path.join(root,'src/tide_player_template.html'),'utf8');
const payload=fs.readFileSync(path.join(root,'data/visualization/tide_player_quant.json'),'utf8');
const data=JSON.parse(payload),ids=new Map(),timers=new Map();let timerId=0;
class Element{
 constructor(tag='div'){this.tagName=tag;this.children=[];this.listeners={};this.attributes={};this._text='';this.hidden=false;this.style={};this.classList={add:()=>{}};}
 set id(value){this._id=value;ids.set(value,this);}get id(){return this._id;}
 set textContent(value){this._text=String(value);this.children=[];}get textContent(){return this._text+this.children.map(c=>c.textContent).join(' ');}
 get innerText(){return this.textContent;}
 appendChild(child){this.children.push(child);child.parent=this;return child;}
 append(...children){children.forEach(c=>this.appendChild(typeof c==='string'?Object.assign(new Element('#text'),{textContent:c}):c));}
 replaceChildren(...children){this._text='';this.children=[];this.append(...children);}
 setAttribute(k,v){this.attributes[k]=String(v);}
 addEventListener(k,f){(this.listeners[k]??=[]).push(f);}
 dispatch(type){for(const f of this.listeners[type]||[])f({target:this,preventDefault(){}});}
 closest(){return null;}
}
for(const [,id] of template.matchAll(/\bid="([^"]+)"/g)){assert(!ids.has(id),'duplicate id '+id);const e=new Element();e.id=id;}
ids.get('player-data').textContent=payload;
const document={getElementById:id=>{assert(ids.has(id),'missing id '+id);return ids.get(id);},createElement:tag=>new Element(tag),createTextNode:text=>Object.assign(new Element('#text'),{textContent:text}),addEventListener(){}};
const plotCalls=[];
const Plotly={react:async(element,traces,layout,config)=>{element.data=traces;element.layout=layout;plotCalls.push({id:element.id,count:traces.length});}};
const win={};const sandbox={window:win,document,Plotly,console,Intl,Map,Math,Number,String,Array,Boolean,JSON,Promise,Error,
 setTimeout:fn=>{const id=++timerId;timers.set(id,fn);return id;},clearTimeout:id=>timers.delete(id)};
vm.createContext(sandbox);
const scripts=[...template.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)];
const code=scripts[scripts.length-1][1];new vm.Script(code).runInContext(sandbox);
const settle=async()=>{for(let k=0;k<30;k++)await Promise.resolve();};
const fire=async(id,event,value)=>{const e=ids.get(id);if(value!==undefined)e.value=value;e.dispatch(event);await settle();};
(async()=>{
 const api=win.__TIDE_PLAYER__;await api.ready;
 assert.equal(api.getState().caseId,'legacy_pickup');assert.equal(api.getState().future,false);
 await fire('time-slider','input','70');assert.equal(api.getState().renderedIndex,70);
 const firstRange=ids.get('combined-plot').layout.yaxis.range.slice();
 for(const trace of ids.get('combined-plot').data){assert(trace.x.length<=71);assert(trace.x.every(x=>x<=70*4048/1e5));assert.equal(trace.connectgaps||false,false);}
 const rows=ids.get('values-body').children;assert.equal(rows.length,7);
 for(const j of [1,2,3,4,5])assert(rows[j].children[1].textContent.includes('kein Eingang'));
 assert(rows[3].children[2].textContent.includes('fehlt'));assert(rows[3].children[4].textContent.includes('fehlt'));
 for(const j of [0,6])assert(!rows[j].children[1].textContent.includes('fehlt'));
 await fire('play-button','click');assert(api.getState().playing);
 const active=[...timers.entries()][0];timers.delete(active[0]);await active[1]();await settle();
 assert.equal(api.getState().index,71);await fire('play-button','click');assert.equal(api.getState().playing,false);
 await fire('forward-button','click');assert.equal(api.getState().index,72);
 await fire('back-button','click');assert.equal(api.getState().index,71);
 await fire('layout-select','change','split');assert.equal(api.getState().renderedLayout,'split');
 for(let j=0;j<7;j++){assert(ids.get('station-plot-'+j).data);assert.equal(JSON.stringify(ids.get('station-plot-'+j).layout.yaxis.range),JSON.stringify(firstRange));}
 ids.get('future-checkbox').checked=true;await fire('future-checkbox','change');assert.equal(api.getState().visibleSampleCount,151);
 assert.equal(ids.get('station-plot-1').data[0].x.length,151);
 await fire('metric-select','change','error');assert.equal(api.getState().renderedMetric,'error');
 assert(ids.get('station-plot-3').data[0].y.every(v=>v===null));
 for(const c of data.cases){
  await fire('case-select','change',c.id);assert.equal(api.getState().index,0);assert.equal(api.getState().sampleCount,c.q_elapsed.length);
  await api.setIndex(c.q_elapsed.length-1);await api.setFuture(false);
  assert.equal(api.getState().qElapsed,c.q_elapsed.at(-1));
  for(let j=0;j<7;j++)for(const trace of ids.get('station-plot-'+j).data)assert(trace.x.length<=c.q_elapsed.length);
 }
 await api.setCase('min_01');await api.setStation(1);assert(ids.get('target-increment').textContent.includes('fehlt'));
 await api.setIndex(3);assert(!ids.get('target-increment').textContent.includes('fehlt'));
 assert.equal(api.getState().error,null);
 const report={status:'passed_controller_and_data_contract',cases:data.cases.length,stations:7,
  checks:['play_pause_clock','step_buttons','slider_event','case_selection','two_layouts','level_and_error','actual_future_truncation','fixed_common_axes','input_target_roles','missing_stoer_not_zero','missing_increment_prefix','explicit_quant_units'],
  test_environment:'Node VM with minimal DOM and recording Plotly adapter; no graphical browser',
  visual_browser_check:'blocked: local browser process cannot create its socket; Cloud Browser file protocol rejected by URL policy',
  browser_render_verified:false,plotly_renderer_executed:false,no_network_access:true,
  scope:'Control wiring and arrays supplied to Plotly, not pixel layout or browser compatibility'};
 fs.writeFileSync(path.join(root,'review/tide_player_controller_review.json'),JSON.stringify(report,null,2));
 console.log(JSON.stringify(report));
})().catch(e=>{console.error(e.stack);process.exit(1);});
