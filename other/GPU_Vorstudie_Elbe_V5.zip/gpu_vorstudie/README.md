# GPU-Vorstudie Elbe S1 Integer V4 → V5-Kern

Ergänzt das Projekt, ändert keine Projektdatei. Alle Befehle aus diesem Ordner, Projektpfad als Argument.

## Inhalt

| Datei | Zweck |
|---|---|
| `quant_integer_direct_solver.py` | V5-Kandidat: direkter Löser + exakte Integer-Residuenkorrektur, **gleiches Zertifikat wie V4** (`|b−Mx|_i ≤ 2^tol·δ_i`) |
| `test_integer_direct_solver.py` | 9 Sollprüfungen inkl. Abgleich gegen V4 auf Zufalls-M-Matrizen |
| `integration_check.py` | unveränderter V4-Fallrunner mit eingesetztem Direktlöser |
| `lab/capture_systems.py` | greift echte eingefrorene Systeme ab, löst sie mit V4 und V5 |
| `lab/analyze_systems.py` | Kopplung, Kontraktion, Kondition, Bitbreiten, Lösungsvarianten |
| `lab/fixedpoint_check.py` | GPU-Format: int64-Koeffizienten, int128-Residuen, Zertifikat am Originalsystem |
| `lab/count_fp32_ops.py` | Tensoroperationen je FP32-Schritt (≈ Kernelstarts) |

## Ausführen

```bash
P=/pfad/zu/Elbe_Blockmodell_Integer_V4
python -I test_integer_direct_solver.py $P
python -I integration_check.py $P min_01 2
python -I lab/capture_systems.py $P min_01 2560 min01.pkl --advance-with v5 --compare-every 32
python -I lab/summarize.py min01.pkl
python -I lab/analyze_systems.py min01.pkl
ELBE_PROJECT=$P python -I lab/fixedpoint_check.py min01.pkl
```

## Einbindung (Vorschlag, eigene Serienidentität)

In `quant_integer_storage.IntegerStorageFlowSolver.step` den Löser über die Config wählen, z. B.
`linear_solver: {"algorithm": "direct", "lattice_exponent": -58, "tolerance_exponent": -50, "max_passes": 4}`.
Die Trajektorie ist **nicht bitgleich zu V4** (beide zertifiziert, Abstand ≤ 2·2^-50 Lq je System); daher neue Referenz V5.
