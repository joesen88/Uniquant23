"""Offline analysis of captured frozen systems: structure, widths, solver variants."""
import pickle
import statistics as st
import sys
import time
from fractions import Fraction
from math import log2
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import v5lab

paths = sys.argv[1:]
recs = []
for p in paths:
    d = pickle.load(open(p, "rb"))
    for r in d["records"]:
        if "system" in r:
            r["case"] = d["meta"]["case"]
            recs.append(r)
print(f"{len(recs)} captured systems from {len(paths)} files")

# 1) structure: coupling ratio, contraction, condition bound, raw rational widths
rho_j, kappa, wc_max, raw_bits, dom_min_rel = [], [], [], [], []
eta_abs, eta_grad, eta_step = [], [], []
for r in recs:
    lo, diag, up, rhs, init = r["system"]
    n = len(diag)
    W = [-x for x in lo]                      # W_i at face i (lo[0]=0)
    Wr = [-x for x in up]                     # W_{i+1}
    C = [diag[i] + lo[i] + up[i] for i in range(n)]   # dominance margin per row
    rj = max(float((W[i] + Wr[i]) / diag[i]) for i in range(n))
    rho_j.append(rj)
    wc_max.append(max(float((W[i] + Wr[i]) / C[i]) for i in range(n)))
    norm = max(float(diag[i] - lo[i] - up[i]) for i in range(n))
    kappa.append(norm / min(float(c) for c in C))
    raw_bits.append(max(max(v.numerator.bit_length(), v.denominator.bit_length())
                        for v in (*lo, *diag, *up, *rhs)))
    x = r["v4_solution"]
    eta_abs.append(max(abs(float(v)) for v in x))
    eta_grad.append(max(abs(float(x[i] - x[i - 1])) for i in range(1, n)))
    eta_step.append(max(abs(float(a - Fraction(b))) for a, b in zip(x, init)))
print("Jacobi contraction rho_J = max (W_i+W_{i+1})/M_ii : max %.6f  (GS ~ rho_J^2 = %.6f)" % (max(rho_j), max(rho_j) ** 2))
print("coupling (W_i+W_{i+1})/C_i: max %.1f   inf-norm condition bound: max %.1f" % (max(wc_max), max(kappa)))
print("raw rational coefficient width (num or den bits): max %d" % max(raw_bits))
h = 2.0 ** -54
print("|eta| max %.3e Lq = %.1f bits in 2^-54 ticks" % (max(eta_abs), log2(max(eta_abs) / h)))
print("|eta_i - eta_{i-1}| max %.3e Lq = %.1f bits" % (max(eta_grad), log2(max(eta_grad) / h)))
print("|eta - guess| per step max %.3e Lq = %.1f bits" % (max(eta_step), log2(max(eta_step) / h)))

# 2) solver variants on the same systems
def run_variant(label, **kw):
    passes, ratios, times, ok = [], [], [], True
    for r in recs:
        lo, diag, up, rhs, init = r["system"]
        t0 = time.perf_counter()
        out = v5lab.solve_v5(lo, diag, up, rhs, initial=init, **kw)
        times.append(time.perf_counter() - t0)
        ok &= out["certified"]
        passes.append(out["passes"])
        ratios.append(float(out["max_ratio"]))
    hist = {p: passes.count(p) for p in sorted(set(passes))}
    print(f"{label:34s} certified={ok}  passes={hist}  max_ratio={max(ratios):.3g}  t={st.mean(times)*1e3:.1f} ms")

for e in (-52, -53, -54, -56, -58):
    run_variant(f"FP64 Thomas, lattice 2^{e}", lattice_exponent=e)
run_variant("FP32 Thomas, lattice 2^-54", lattice_exponent=-54, precision="fp32")
run_variant("FP64 Thomas, cold start, 2^-54", lattice_exponent=-54, cold=True)
run_variant("FP32 Thomas, cold start, 2^-54", lattice_exponent=-54, precision="fp32", cold=True)
