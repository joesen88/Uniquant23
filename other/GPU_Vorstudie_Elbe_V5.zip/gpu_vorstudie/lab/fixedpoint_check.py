"""GPU-format check: fixed-point int64 coefficients, int128 residuals, certificate vs ORIGINAL system.

For every captured real system:
  1. round C_i, W_f to the 2^-90 Lq^2 grid (int64) and b_i to 2^-100 Lq^3 (int64),
     assembling the diagonal consistently from the rounded parts;
  2. solve on the 2^-54 lattice: approximate Thomas (FP32 or FP64) + exact integer residual;
  3. verify every int64/int128 range, and the V4 certificate against the exact rational system.
"""
import pickle
import sys
from fractions import Fraction
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import v5lab
import os
PROJECT = Path(os.environ.get("ELBE_PROJECT", ".")).resolve() / "src"   # project root via ELBE_PROJECT
sys.path.insert(0, str(PROJECT))
import quant_storage_flow as QF
OPS = QF.NumpyOps()

I64, I128 = (1 << 63), (1 << 127)
SM, SB, E, TOL = 90, 100, -54, -50   # matrix scale 2^-90, rhs scale 2^-100, lattice 2^-54, tol 2^-50


def rnd(x, s):
    """nearest-even of x * 2^s, as Python int."""
    v = x * (1 << s)
    q, r = divmod(v.numerator, v.denominator)
    if 2 * r > v.denominator or (2 * r == v.denominator and q % 2):
        q += 1
    return q


def check64(v, what, stats):
    stats[what] = max(stats.get(what, 0), abs(v).bit_length())
    assert -I64 <= v < I64, what


def check128(v, what, stats):
    stats[what] = max(stats.get(what, 0), abs(v).bit_length())
    assert -I128 <= v < I128, what


def solve_fixed(lo, diag, up, rhs, init, precision, stats):
    n = len(diag)
    W = [0] + [rnd(-lo[i], SM) for i in range(1, n)]             # W_i, face i (internal)
    Wn = [rnd(-up[i], SM) for i in range(n - 1)] + [0]            # W_{i+1}
    # Rows share faces: -up[i] == -lo[i+1] exactly, so one rounded W per face.
    assert all(Wn[i] == W[i + 1] for i in range(n - 1))
    D = [rnd(diag[i] + lo[i] + up[i], SM) for i in range(n)]      # C_i (row 0: C_0 + W_0)
    Bv = [rnd(rhs[i], SB) for i in range(n)]
    for v in W + D + Bv:
        check64(v, "coeff_int64_bits", stats)
    diagf = [D[i] + W[i] + Wn[i] for i in range(n)]
    for v in diagf:
        check64(v, "diag_int64_bits", stats)
    # residual in units 2^-(SM - E) = 2^-144 Lq^3:  r = Bv * 2^(144-100) - M*K
    up_s = (SM - E) - SB
    a = [(-float(W[i]) / float(diagf[i])) if i else 0.0 for i in range(n)]   # same two roundings as (double)int64 on GPU
    c = [(-float(Wn[i]) / float(diagf[i])) if i < n - 1 else 0.0 for i in range(n)]
    K = [round(Fraction(v) * (1 << -E)) for v in init]
    for k in K:
        check64(k, "eta_int64_bits", stats)
    passes = 0
    while True:
        res, ok = [], True
        for i in range(n):
            r = (Bv[i] << up_s) - diagf[i] * K[i]
            if i:
                r += W[i] * K[i - 1]
            if i < n - 1:
                r += Wn[i] * K[i + 1]
            check128(r, "residual_int128_bits", stats)
            res.append(r)
            # fixed-system certificate: |r| * 2^-144 <= 2^-50 * C_i * 2^-90  <=>  |r| <= C_i * 2^(144-50-90)
            if abs(r) > D[i] << ((SM - E) + TOL - SM):
                ok = False
        if ok or passes >= 4:
            break
        d = [float(res[i]) / float(diagf[i]) for i in range(n)]    # lattice units, float
        if precision == "fp64":
            delta = v5lab.thomas(a, c, d)
        elif precision == "fp32":
            delta = v5lab.thomas32(a, c, d)
        else:  # project's own FP32 PCR (quant_storage_flow.tridiagonal_pcr), unit diagonal
            sc = 2.0 ** round(np.log2(max(abs(v) for v in d) or 1.0))
            x = QF.tridiagonal_pcr(np.asarray(a, np.float32), np.ones(n, np.float32), np.asarray(c, np.float32),
                                   np.asarray([v / sc for v in d], np.float32), OPS)
            delta = [float(v) * sc for v in x]
        K = [k + round(x) for k, x in zip(K, delta)]
        passes += 1
    return K, passes, ok


def original_certificate(lo, diag, up, rhs, K):
    """Exact V4 criterion on the original rational system; returns max ratio (<=1 passes)."""
    n = len(diag)
    h = Fraction(1, 1 << -E)
    x = [k * h for k in K]
    worst = Fraction(0)
    for i in range(n):
        r = rhs[i] - diag[i] * x[i]
        if i:
            r -= lo[i] * x[i - 1]
        if i < n - 1:
            r -= up[i] * x[i + 1]
        dom = diag[i] + lo[i] + up[i]
        worst = max(worst, abs(r) / (Fraction(1, 1 << -TOL) * dom))
    return worst


recs = []
for p in sys.argv[1:]:
    for r in pickle.load(open(p, "rb"))["records"]:
        if "system" in r:
            recs.append(r)
for precision in ("fp32", "fp64", "pcr32"):
    stats, passes, ratios, diffs, ok_all = {}, [], [], [], True
    for r in recs:
        lo, diag, up, rhs, init = r["system"]
        K, p, ok = solve_fixed(lo, diag, up, rhs, init, precision, stats)
        ok_all &= ok
        passes.append(p)
        ratios.append(float(original_certificate(lo, diag, up, rhs, K)))
        diffs.append(max(abs(float(Fraction(k, 1 << -E) - v)) for k, v in zip(K, r["v4_solution"])))
    print(f"[{precision}] systems={len(recs)} fixed-system certified={ok_all} passes={ {q: passes.count(q) for q in sorted(set(passes))} }")
    print(f"        ORIGINAL rational certificate: max ratio {max(ratios):.3f} (<=1 passes: {max(ratios) <= 1})")
    print(f"        max |eta_fixed - eta_V4| = {max(diffs):.3e} Lq ; widths used: {stats}")
