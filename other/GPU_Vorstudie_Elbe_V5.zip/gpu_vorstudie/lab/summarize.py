import pickle, sys, statistics as st
d = pickle.load(open(sys.argv[1], "rb"))
R = d["records"]
cmp_ = [r for r in R if "v4_seconds" in r]
print("meta:", {k: d["meta"][k] for k in ("case", "steps", "advance", "compare_every")})
print("V5 certified all:", all(r["v5_certified"] for r in R), " passes histogram:",
      {p: sum(1 for r in R if r["v5_passes"] == p) for p in sorted(set(r["v5_passes"] for r in R))})
print("V5 max certificate ratio (<=1 required): %.3g" % max(r["v5_ratio"] for r in R))
print("row bits after scaling: max", max(r["row_bits"] for r in R))
if cmp_:
    print("V4 solve s/step: mean %.3f  | V5 solve s/step: mean %.4f  | speedup %.0fx" % (
        st.mean(r["v4_seconds"] for r in cmp_), st.mean(r["v5_seconds"] for r in cmp_),
        st.mean(r["v4_seconds"] for r in cmp_) / st.mean(r["v5_seconds"] for r in cmp_)))
    print("V4 sweeps mean %.1f, V4 final exp %s, V4 max bits %d" % (
        st.mean(r["v4_sweeps"] for r in cmp_), sorted(set(r["v4_exponent"] for r in cmp_)), max(r["v4_bits"] for r in cmp_)))
    print("max |eta_V4 - eta_V5| = %.3e Lq  (2^-50 = %.3e)" % (max(r["max_abs_diff"] for r in cmp_), 2**-50))
print("step wall s (whole step incl. Fractions): mean %.3f" % st.mean(r["step_seconds"] for r in R))
print("limited faces total:", sum(r["limited"] for r in R), " blocked units total:", sum(r["blocked"] for r in R))
