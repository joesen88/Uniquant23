"""Experimental V5 solver candidate: deterministic FP64 Thomas + exact integer residual refinement.

Same certificate as V4 (every original row: |b - M x| <= 2^tol * dominance_i), but the
iteration is a direct solve plus integer-residual corrections instead of integer
Gauss-Seidel with dyadic refinement. Pure Python floats are IEEE-754 binary64 with
correctly rounded +,-,*,/ and no FMA contraction, so the same operation order on a GPU
(compiled without FMA contraction) yields identical bits.
"""
from __future__ import annotations

from fractions import Fraction
from math import gcd, lcm, log2


def scale_rows(lo, diag, up, rhs):
    """Exactly V4's positive row scaling (denominator clearing, then gcd)."""
    il, idg, iu, ib, dom = [], [], [], [], []
    max_bits = 0
    for i in range(len(diag)):
        row = (lo[i], diag[i], up[i], rhs[i])
        den = lcm(*(v.denominator for v in row))
        ints = [v.numerator * (den // v.denominator) for v in row]
        g = gcd(*ints)
        a, b, c, d = (v // g for v in ints)
        max_bits = max(max_bits, *(abs(v).bit_length() for v in (a, b, c, d)))
        il.append(a); idg.append(b); iu.append(c); ib.append(d); dom.append(a + b + c)
    return il, idg, iu, ib, dom, max_bits


def thomas(a, c, d):
    """Unit-diagonal Thomas sweep in binary64; a[0] and c[-1] are ignored."""
    n = len(d)
    cp = [0.0] * n
    dp = [0.0] * n
    cp[0] = c[0]
    dp[0] = d[0]
    for i in range(1, n):
        m = 1.0 - a[i] * cp[i - 1]
        cp[i] = c[i] / m
        dp[i] = (d[i] - a[i] * dp[i - 1]) / m
    x = [0.0] * n
    x[-1] = dp[-1]
    for i in range(n - 2, -1, -1):
        x[i] = dp[i] - cp[i] * x[i + 1]
    return x


def thomas32(a, c, d):
    """Same sweep in IEEE binary32 (numpy scalars are correctly rounded, no FMA)."""
    import numpy as np
    f = np.float32
    n = len(d)
    a = [f(x) for x in a]; c = [f(x) for x in c]; d = [f(x) for x in d]
    cp = [f(0)] * n; dp = [f(0)] * n
    cp[0] = c[0]; dp[0] = d[0]
    one = f(1)
    for i in range(1, n):
        m = one - a[i] * cp[i - 1]
        cp[i] = c[i] / m
        dp[i] = (d[i] - a[i] * dp[i - 1]) / m
    x = [f(0)] * n
    x[-1] = dp[-1]
    for i in range(n - 2, -1, -1):
        x[i] = dp[i] - cp[i] * x[i + 1]
    return [float(v) for v in x]


def solve_v5(lo, diag, up, rhs, *, initial=None, lattice_exponent=-54,
             tolerance_exponent=-50, max_passes=6, scaled=None, precision="fp64", cold=False):
    """Return dict(solution, main, passes, certified, max_ratio)."""
    il, idg, iu, ib, dom, bits = scaled if scaled is not None else scale_rows(lo, diag, up, rhs)
    n = len(idg)
    e = lattice_exponent
    inv_h = 1 << (-e)                      # h = 2^e, e < 0
    # Unit-diagonal float coefficients (row factor cancels exactly in the ratio).
    a = [float(Fraction(il[i], idg[i])) for i in range(n)]
    c = [float(Fraction(iu[i], idg[i])) for i in range(n)]
    if precision == "fp32":
        # Residuals in lattice units can exceed binary32 range only for absurd
        # inputs; normalize by a power of two that is exact in both formats.
        def thomas(a_, c_, d_):
            s = max(abs(v) for v in d_) or 1.0
            p = 2.0 ** round(log2(s))
            return [v * p for v in thomas32(a_, c_, [v / p for v in d_])]
    else:
        thomas = globals()["thomas"]
    if initial is None or cold:
        K = [0] * n
    else:
        K = [round(Fraction(v) * inv_h) for v in initial]
    shift = tolerance_exponent - e          # certificate: |res_i| <= 2^shift * dom_i
    passes = 0
    while True:
        res = []
        ok = True
        worst = Fraction(0)
        for i in range(n):
            r = ib[i] * inv_h - idg[i] * K[i]
            if i:
                r -= il[i] * K[i - 1]
            if i + 1 < n:
                r -= iu[i] * K[i + 1]
            res.append(r)
            lim = dom[i] << shift if shift >= 0 else dom[i] >> (-shift)
            if abs(r) > lim:
                ok = False
            ratio = Fraction(abs(r), dom[i]) / (Fraction(2) ** shift)
            if ratio > worst:
                worst = ratio
        if ok:
            return {"solution": [Fraction(k, inv_h) for k in K], "main": K, "passes": passes,
                    "certified": True, "max_ratio": worst, "row_bits": bits}
        if passes >= max_passes:
            return {"solution": None, "main": K, "passes": passes, "certified": False,
                    "max_ratio": worst, "row_bits": bits}
        rhs_f = [float(Fraction(res[i], idg[i])) for i in range(n)]
        delta = thomas(a, c, rhs_f)
        K = [k + round(dx) for k, dx in zip(K, delta)]
        passes += 1
