import pickle, sys
import numpy as np
a = pickle.load(open(sys.argv[1], "rb"))["meta"]; b = pickle.load(open(sys.argv[2], "rb"))["meta"]
for k in ("final_volume_units", "final_flow_units", "final_eta_units"):
    x, y = np.array(a[k], dtype=object), np.array(b[k], dtype=object)
    d = np.array([int(u) - int(v) for u, v in zip(x, y)])
    print(f"{k:20s} differing entries {np.count_nonzero(d):4d}/{len(d)}  max |diff| {np.abs(d).max()} ticks  (max value {max(abs(int(v)) for v in x)}, {max(abs(int(v)) for v in x).bit_length()} bits)")
