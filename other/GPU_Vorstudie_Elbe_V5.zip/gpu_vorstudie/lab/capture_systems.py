"""Capture real frozen S1 systems from the V4 integer stepper and compare solvers.

Usage: python -I capture_systems.py PROJECT_ROOT CASE STEPS OUT.pkl [--advance-with v5]
Each captured record holds the exact rational system, the V4 result and timings.
With --advance-with v5 the trajectory is advanced by the V5 candidate (V4 is still
solved on every captured system for comparison, but only every --compare-every steps).
"""
import pickle
import sys
import time
from fractions import Fraction
from pathlib import Path

root = Path(sys.argv[1]).resolve()
case_id, steps, out_path = sys.argv[2], int(sys.argv[3]), sys.argv[4]
advance_v5 = "--advance-with" in sys.argv and sys.argv[sys.argv.index("--advance-with") + 1] == "v5"
compare_every = int(sys.argv[sys.argv.index("--compare-every") + 1]) if "--compare-every" in sys.argv else 1
sys.path.insert(0, str(root / "src"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import os
os.chdir(root)

import run_integer_storage as R
import quant_integer_storage as S
import quant_integer_solver as V4
import v5lab

active, cfg, name, profile, freeze, _ = R.load_integer_config("cpu_parallel_probe")
profile = dict(profile)
profile["sample_intervals"] = -(-steps // cfg["steps_per_sample"])
geo = R.prepare_geometry(cfg, freeze)
prepared = R.prepare_case(case_id, cfg, profile, freeze, geometry_context=geo)
solver = S.IntegerStorageFlowSolver(prepared["geometry"], prepared["parameters"], cfg)
solver.initialize(prepared["eta0"], prepared["inland"])
lin = cfg["linear_solver"]

records = []
state = {"step": 0}
original = V4.solve_tridiagonal_integer


def patched(lo, diag, up, rhs, *, initial=None, **kw):
    k = state["step"]
    do_compare = (k % compare_every == 0)
    rec = {"step": k}
    scaled = v5lab.scale_rows(lo, diag, up, rhs)
    t0 = time.perf_counter()
    v5 = v5lab.solve_v5(lo, diag, up, rhs, initial=initial, lattice_exponent=-54,
                        tolerance_exponent=lin["tolerance_exponent"], scaled=scaled)
    t1 = time.perf_counter()
    rec.update(v5_passes=v5["passes"], v5_certified=v5["certified"], v5_seconds=t1 - t0,
               v5_ratio=float(v5["max_ratio"]), row_bits=scaled[5])
    if do_compare:
        t2 = time.perf_counter()
        ref = original(lo, diag, up, rhs, initial=initial, **kw)
        t3 = time.perf_counter()
        rec.update(v4_seconds=t3 - t2, v4_sweeps=ref["diagnostics"]["sweeps"],
                   v4_exponent=ref["exponent"], v4_bits=ref["diagnostics"]["max_integer_bits"],
                   max_abs_diff=float(max(abs(x - y) for x, y in zip(ref["solution"], v5["solution"]))))
        rec["system"] = (lo, diag, up, rhs, initial)
        rec["v4_solution"] = ref["solution"]
        rec["v5_solution"] = v5["solution"]
    records.append(rec)
    chosen = v5 if advance_v5 else (ref if do_compare else v5)
    if not advance_v5 and not do_compare:
        raise RuntimeError("V4 advance requires compare_every=1")
    return {"solution": chosen["solution"], "main": chosen["main"], "exponent": -54,
            "certified": True, "diagnostics": {"certified": True, "sweeps": 0, "changes": 0,
                                                "skips": 0, "max_integer_bits": 0,
                                                "residual_bound_ratio": "0", "levels": []}}


S.solve_tridiagonal_integer = patched
start = time.perf_counter()
extra = []
for k, sea in enumerate(prepared["sea_steps"][:steps]):
    state["step"] = k
    t0 = time.perf_counter()
    result = solver.step(sea, prepared["inland"])
    extra.append({"step": k, "step_seconds": time.perf_counter() - t0,
                  "limited": result["limited_face_count"],
                  "blocked": int(sum(abs(int(b)) for b in result["blocked_transfer_units"]))})
    if (k + 1) % 256 == 0:
        print(f"{case_id}: {k + 1}/{steps} steps, {time.perf_counter() - start:.1f}s", flush=True)
for r, e in zip(records, extra):
    r.update(e)
meta = {"case": case_id, "steps": steps, "advance": "v5" if advance_v5 else "v4",
        "compare_every": compare_every, "dt": solver.dt, "flow_unit": solver.flow_unit,
        "height_unit": solver.height_unit, "volume_unit": solver.volume_unit,
        "final_flow_units": solver.flow_units.tolist(), "final_volume_units": solver.volume_units.tolist(),
        "final_eta_units": solver.eta_units.tolist()}
with open(out_path, "wb") as fh:
    pickle.dump({"meta": meta, "records": records}, fh)
print("done", case_id, steps, f"{time.perf_counter() - start:.1f}s")
