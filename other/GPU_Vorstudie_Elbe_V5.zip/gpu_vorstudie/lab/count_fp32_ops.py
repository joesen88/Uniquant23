import sys, json, time
from pathlib import Path
root = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root / "src"))
import os; os.chdir(root)
import numpy as np
import run_storage_flow as RS
import quant_storage_flow as QF
COUNT = {"ufunc": 0, "func": 0}
class C(np.ndarray):
    def __array_ufunc__(self, ufunc, method, *inputs, **kw):
        COUNT["ufunc"] += 1
        inputs = [np.asarray(x) if isinstance(x, C) else x for x in inputs]
        out = getattr(ufunc, method)(*inputs, **kw)
        return out.view(C) if isinstance(out, np.ndarray) else out
    def __array_function__(self, func, types, args, kwargs):
        COUNT["func"] += 1
        def conv(a):
            if isinstance(a, C): return np.asarray(a)
            if isinstance(a, (list, tuple)): return type(a)(conv(x) for x in a)
            return a
        out = func(*conv(args), **{k: conv(v) for k, v in kwargs.items()})
        return out.view(C) if isinstance(out, np.ndarray) else out
orig = QF.NumpyOps.asarray
QF.NumpyOps.asarray = lambda self, v, dtype=None: np.asarray(v, dtype=self.float32 if dtype is None else dtype).view(C)
QF.NumpyOps.zeros = lambda self, s, dtype=None: np.zeros(s, dtype=self.float32 if dtype is None else dtype).view(C)
QF.NumpyOps.ones = lambda self, s, dtype=None: np.ones(s, dtype=self.float32 if dtype is None else dtype).view(C)
active, cfg, pname, profile, freeze = RS.load_config("cpu_smoke")
prepared = RS.prepare_case("min_01", cfg, profile, freeze)
solver = RS.cpu_solver(prepared, cfg)
v, f = prepared["volume0"], prepared["flow0"]
COUNT.update(ufunc=0, func=0)
out = solver.step(v, f, np.asarray(prepared["sea_steps"][0], np.float32), np.asarray(prepared["inland_steps"][0], np.float32))
print("array ops per FP32 step (each ~1 CUDA kernel in Torch eager/graph):", COUNT)
COUNT.update(ufunc=0, func=0)
QF.tridiagonal_pcr(np.ones(340).view(C)*-0.1, np.ones(340).view(C), np.ones(340).view(C)*-0.1, np.ones(340).view(C), solver.ops)
print("of which PCR:", COUNT)
QF.NumpyOps.asarray = orig
