"""Certified direct solve of one frozen tridiagonal M-system (V5 candidate).

Drop-in alternative to ``quant_integer_solver.solve_tridiagonal_integer`` with
the SAME acceptance criterion, but a fixed, short, GPU-portable path:

  1. Exact positive row scaling, identical to V4 (denominator clearing, gcd).
  2. One dyadic lattice h = 2**lattice_exponent; warm start
     K = round_half_even(initial / h).
  3. Exact integer residual  r_i = d_i/h - (a_i K_{i-1} + b_i K_i + c_i K_{i+1}).
  4. Certificate: |r_i| <= 2**(tol - e) * delta_i for every row, with
     delta_i = b_i + a_i + c_i > 0.  Row dominance then gives
     ||x - x*||_inf <= max_i |r_i| h / delta_i <= 2**tol  (x* exact solution).
  5. Otherwise ONE binary64 Thomas sweep on the unit-diagonal rows with
     right-hand side r_i / b_i, K <- K + round_half_even(correction); go to 3.

Only step 5 uses floating point, and only to propose an integer correction;
acceptance is decided exclusively by the exact integer residual.  Python
floats are IEEE-754 binary64 with correctly rounded + - * / and no FMA
contraction, so a GPU build with the same operation order and without FMA
contraction proposes identical corrections.

Strict row dominance makes Thomas pivot-free: with unit diagonal,
m_i = 1 - a_i c'_{i-1} >= 1 - |a_i| > |c_i| >= 0, hence |c'_i| < 1.

This module keeps exact rational inputs (CPU reference, phase A).  A GPU
kernel additionally needs the declared fixed-point coefficient contract
(phase B); the certificate and the correction path stay the same.
"""

from __future__ import annotations

from fractions import Fraction
from math import gcd, isfinite, lcm
from numbers import Integral
from typing import Any

from quant_integer_solver import IntegerSolveError


def _integer(value: Any, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise TypeError(f"{name} must be an integer, not {type(value).__name__}")
    return int(value)


def _rational(value: Any, name: str) -> Fraction:
    if isinstance(value, Fraction):
        return value
    if isinstance(value, Integral) and not isinstance(value, bool):
        return Fraction(int(value))
    raise TypeError(f"{name} must be Fraction or integer; floating input is forbidden")


def _thomas_unit_diagonal(a, c, d):
    """Fixed-order binary64 sweep; a[0] and c[-1] are ignored."""
    n = len(d)
    cp = [0.0] * n
    dp = [0.0] * n
    cp[0] = c[0]
    dp[0] = d[0]
    for i in range(1, n):
        m = 1.0 - a[i] * cp[i - 1]
        if not (m > 0.0 and isfinite(m)):
            return None
        cp[i] = c[i] / m
        dp[i] = (d[i] - a[i] * dp[i - 1]) / m
    x = [0.0] * n
    x[-1] = dp[-1]
    for i in range(n - 2, -1, -1):
        x[i] = dp[i] - cp[i] * x[i + 1]
    return x if all(isfinite(v) for v in x) else None


def solve_tridiagonal_direct(lower, diagonal, upper, rhs, *, initial=None,
                             lattice_exponent=-58, tolerance_exponent=-50, max_passes=4):
    e = _integer(lattice_exponent, "lattice_exponent")
    tol = _integer(tolerance_exponent, "tolerance_exponent")
    passes_limit = _integer(max_passes, "max_passes")
    if e >= 0 or tol < e:
        raise ValueError("Require lattice_exponent < 0 and tolerance_exponent >= lattice_exponent")
    if passes_limit < 1:
        raise ValueError("max_passes must be positive")
    lo = [_rational(v, f"lower[{i}]") for i, v in enumerate(lower)]
    dg = [_rational(v, f"diagonal[{i}]") for i, v in enumerate(diagonal)]
    up = [_rational(v, f"upper[{i}]") for i, v in enumerate(upper)]
    b = [_rational(v, f"rhs[{i}]") for i, v in enumerate(rhs)]
    n = len(dg)
    if n < 1 or any(len(v) != n for v in (lo, up, b)):
        raise ValueError("All four arrays must have the same nonzero length")
    if lo[0] != 0 or up[-1] != 0:
        raise ValueError("Unused lower[0] and upper[-1] must be zero")
    for i in range(n):
        if dg[i] <= 0 or lo[i] > 0 or up[i] > 0:
            raise ValueError(f"Row {i} violates positive diagonal/nonpositive off-diagonals")
        if dg[i] + lo[i] + up[i] <= 0:
            raise ValueError(f"Row {i} is not strictly diagonally dominant")

    il, idg, iu, ib, dom = [], [], [], [], []
    max_bits = 0
    for i in range(n):
        row = (lo[i], dg[i], up[i], b[i])
        den = lcm(*(v.denominator for v in row))
        ints = [v.numerator * (den // v.denominator) for v in row]
        g = gcd(*ints)
        p, q, r, s = (v // g for v in ints)
        max_bits = max(max_bits, *(abs(v).bit_length() for v in (p, q, r, s)))
        il.append(p); idg.append(q); iu.append(r); ib.append(s); dom.append(p + q + r)

    inv_h = 1 << (-e)
    shift = tol - e                                   # >= 0
    a = [float(Fraction(il[i], idg[i])) for i in range(n)]
    c = [float(Fraction(iu[i], idg[i])) for i in range(n)]
    if initial is None:
        main = [0] * n
    else:
        start = [_rational(v, f"initial[{i}]") for i, v in enumerate(initial)]
        if len(start) != n:
            raise ValueError(f"initial must have length {n}")
        main = [round(v * inv_h) for v in start]       # Fraction.__round__: ties to even
    passes = changes = skips = 0

    def residuals():
        nonlocal max_bits
        out, ok, worst = [], True, Fraction(0)
        for i in range(n):
            res = ib[i] * inv_h - idg[i] * main[i]
            if i:
                res -= il[i] * main[i - 1]
            if i + 1 < n:
                res -= iu[i] * main[i + 1]
            max_bits = max(max_bits, abs(res).bit_length())
            limit = dom[i] << shift
            if abs(res) > limit:
                ok = False
            ratio = Fraction(abs(res), limit)
            if ratio > worst:
                worst = ratio
            out.append(res)
        return out, ok, worst

    def diagnostics(certified, worst):
        tolerance = Fraction(1, 1 << -tol) if tol < 0 else Fraction(1 << tol)
        return {
            "certified": certified,
            "algorithm": "direct_binary64_thomas_with_exact_integer_residual",
            "arithmetic": "Python_integer_and_Fraction_CPU_reference; binary64_proposals_only",
            "matrix_scope": "strictly_row_dominant_tridiagonal_M_matrix; symmetry_not_required",
            "coefficient_evaluations": 1, "row_count": n,
            "final_exponent": e, "lattice_exponent": e, "tolerance_exponent": tol,
            "tolerance": str(tolerance),
            "absolute_error_bound": str(worst * tolerance),
            "residual_bound_ratio": str(worst),
            "max_integer_bits": max_bits,
            "max_integer_bits_scope": "row_scaling_and_exact_residuals",
            "passes": passes, "sweeps": passes, "changes": changes, "skips": skips,
            "sweeps_scope": "number of direct correction passes, not Gauss-Seidel sweeps",
            "levels": [],
            "certificate": "every_original_row_abs_residual_le_tolerance_times_dominance",
            "state_rest_accumulation": False,
        }

    while True:
        res, ok, worst = residuals()
        if ok:
            solution = [Fraction(k, inv_h) for k in main]
            return {"solution": solution, "main": main.copy(), "exponent": e,
                    "diagnostics": diagnostics(True, worst), "certified": True}
        if passes >= passes_limit:
            raise IntegerSolveError(
                f"Direct solve not certified after {passes} passes; residual bound/tolerance = {worst}",
                diagnostics(False, worst))
        delta = _thomas_unit_diagonal(a, c, [float(Fraction(res[i], idg[i])) for i in range(n)])
        if delta is None:
            raise IntegerSolveError("Non-finite or nonpositive binary64 Thomas pivot",
                                    diagnostics(False, worst))
        for i, x in enumerate(delta):
            k = round(x)                               # float.__round__: ties to even
            if k:
                main[i] += k
                changes += 1
            else:
                skips += 1
        passes += 1


__all__ = ["solve_tridiagonal_direct"]
