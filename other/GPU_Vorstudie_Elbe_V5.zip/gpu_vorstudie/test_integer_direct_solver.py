"""Exact checks for the direct V5-candidate solver (same certificate as V4)."""

from fractions import Fraction as F
import json
from pathlib import Path
import random
import sys
import unittest

HERE = Path(__file__).resolve().parent
PROJECT = Path(sys.argv.pop(1)).resolve() if len(sys.argv) > 1 and not sys.argv[1].startswith("-") else HERE.parent
for path in (PROJECT / "src", HERE):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from quant_integer_solver import IntegerSolveError, solve_tridiagonal_integer
from quant_integer_direct_solver import solve_tridiagonal_direct


def original_ok(result, lower, diagonal, upper, rhs, tolerance):
    x = result["solution"]
    for i in range(len(x)):
        value = diagonal[i] * x[i]
        if i:
            value += lower[i] * x[i - 1]
        if i + 1 < len(x):
            value += upper[i] * x[i + 1]
        if abs(rhs[i] - value) > tolerance * (diagonal[i] - abs(lower[i]) - abs(upper[i])):
            return False
    return True


class DirectSolverTests(unittest.TestCase):
    def check(self, result, system, tol_exp):
        self.assertTrue(result["certified"])
        self.assertTrue(original_ok(result, *system, F(1, 1 << -tol_exp)))
        json.dumps(result["diagnostics"], allow_nan=False)
        self.assertTrue(all(type(v) is int for v in result["main"]))
        self.assertTrue(all(isinstance(v, F) for v in result["solution"]))

    def test_two_by_two_sign_changed_note(self):
        system = ([0, -1], [4, 3], [-1, 0], [1, -2])
        result = solve_tridiagonal_direct(*system, lattice_exponent=-24, tolerance_exponent=-18)
        self.check(result, system, -18)
        self.assertLessEqual(abs(result["solution"][0] - F(1, 11)), F(1, 1 << 18))
        self.assertLessEqual(abs(result["solution"][1] + F(7, 11)), F(1, 1 << 18))

    def test_exact_half(self):
        result = solve_tridiagonal_direct([0], [2], [0], [1], lattice_exponent=-4, tolerance_exponent=-4)
        self.assertEqual(result["solution"], [F(1, 2)])
        self.assertEqual(result["diagnostics"]["passes"], 1)

    def test_row_scaling_invariance_is_bitwise(self):
        base = ([0, -1, -1], [3, 4, 3], [-1, -1, 0], [1, -2, 4])
        factors = [F(1, 7), F(11, 3), F(5, 13)]
        scaled = tuple([[F(v) * f for v, f in zip(row, factors)] for row in base])
        options = dict(lattice_exponent=-25, tolerance_exponent=-19)
        self.assertEqual(solve_tridiagonal_direct(*base, **options)["main"],
                         solve_tridiagonal_direct(*scaled, **options)["main"])

    def test_manufactured_solution_with_far_initial_values(self):
        lower = [F(0), F(-3, 7), F(-2, 5)]
        diagonal = [F(9, 7), F(11, 5), F(8, 3)]
        upper = [F(-2, 7), F(-4, 9), F(0)]
        exact = [F(-11, 13), F(7, 17), F(-5, 19)]
        rhs = [diagonal[i] * exact[i] + (lower[i] * exact[i - 1] if i else 0)
               + (upper[i] * exact[i + 1] if i < 2 else 0) for i in range(3)]
        result = solve_tridiagonal_direct(lower, diagonal, upper, rhs, initial=[F(10), F(-10), F(3)],
                                          lattice_exponent=-30, tolerance_exponent=-23)
        self.check(result, (lower, diagonal, upper, rhs), -23)
        self.assertLessEqual(max(abs(a - b) for a, b in zip(result["solution"], exact)), F(1, 1 << 23))

    def test_exact_initial_certifies_without_pass(self):
        result = solve_tridiagonal_direct([0], [3], [0], [-6], initial=[-2],
                                          lattice_exponent=-8, tolerance_exponent=-8)
        self.assertEqual(result["solution"], [F(-2)])
        self.assertEqual(result["diagnostics"]["passes"], 0)

    def test_unreachable_tolerance_raises(self):
        system = ([0, F(-19, 10)], [2, 2], [F(-19, 10), 0], [1, 0])
        with self.assertRaises(IntegerSolveError) as caught:
            solve_tridiagonal_direct(*system, lattice_exponent=-2, tolerance_exponent=-2, max_passes=3)
        self.assertFalse(caught.exception.diagnostics["certified"])
        json.dumps(caught.exception.diagnostics)

    def test_tiny_rational_coefficients_against_original(self):
        scale = F(1, 10**36 + 7)
        system = ([0], [7 * scale], [0], [2 * scale])
        result = solve_tridiagonal_direct(*system, lattice_exponent=-28, tolerance_exponent=-22)
        self.check(result, system, -22)

    def test_random_m_matrices_agree_with_v4_within_both_certificates(self):
        rng = random.Random(20261116)
        for trial in range(25):
            n = rng.randint(1, 40)
            w = [F(rng.randint(1, 10**6), rng.randint(1, 10**6)) for _ in range(n + 1)]
            cap = [F(rng.randint(1, 10**6), rng.randint(1, 10**6)) for _ in range(n)]
            lower = [F(0)] + [-w[i] for i in range(1, n)]
            upper = [-w[i + 1] for i in range(n - 1)] + [F(0)]
            diagonal = [cap[i] + w[i] + (w[i + 1] if i < n - 1 else 0) for i in range(n)]
            rhs = [F(rng.randint(-10**9, 10**9), rng.randint(1, 10**6)) for _ in range(n)]
            system = (lower, diagonal, upper, rhs)
            direct = solve_tridiagonal_direct(*system, lattice_exponent=-40, tolerance_exponent=-30)
            reference = solve_tridiagonal_integer(*system, coarse_exponent=-10, finest_exponent=-40,
                                                  tolerance_exponent=-30, max_sweeps_per_level=4096)
            with self.subTest(trial=trial, n=n):
                self.check(direct, system, -30)
                gap = max(abs(a - b) for a, b in zip(direct["solution"], reference["solution"]))
                self.assertLessEqual(gap, F(2, 1 << 30))

    def test_invalid_matrices_and_float_rejected(self):
        invalid = [([0], [0], [0], [1]),
                   ([0, -1], [1, 1], [-1, 0], [1, 1]),
                   ([0, 1], [3, 3], [-1, 0], [1, 1]),
                   ([1], [3], [0], [1]),
                   ([], [], [], [])]
        for arguments in invalid:
            with self.subTest(arguments=arguments), self.assertRaises(ValueError):
                solve_tridiagonal_direct(*arguments)
        with self.assertRaises(TypeError):
            solve_tridiagonal_direct([0], [2.0], [0], [1])


if __name__ == "__main__":
    unittest.main(verbosity=2)
