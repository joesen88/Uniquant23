"""Run the unchanged V4 case runner with the direct solver substituted (no project file is modified).

Usage: python -I integration_check.py PROJECT_ROOT [CASE] [INTERVALS]
"""
import json, os, sys
from pathlib import Path
root = Path(sys.argv[1]).resolve()
case_id = sys.argv[2] if len(sys.argv) > 2 else "min_01"
intervals = int(sys.argv[3]) if len(sys.argv) > 3 else 2
sys.path.insert(0, str(root / "src")); sys.path.insert(0, str(Path(__file__).resolve().parent))
os.chdir(root)
import run_integer_storage as R
import quant_integer_storage as S
from quant_integer_direct_solver import solve_tridiagonal_direct

def adapter(lo, diag, up, rhs, *, initial=None, coarse_exponent=None, finest_exponent=-58,
            tolerance_exponent=-50, max_sweeps_per_level=None):
    # V4 config keys -> direct solver: finest allowed lattice, unchanged tolerance.
    return solve_tridiagonal_direct(lo, diag, up, rhs, initial=initial,
                                    lattice_exponent=finest_exponent, tolerance_exponent=tolerance_exponent)

S.solve_tridiagonal_integer = adapter
active, cfg, name, profile, freeze, _ = R.load_integer_config("cpu_parallel_probe")
prepared = R.prepare_case(case_id, cfg, dict(profile, sample_intervals=intervals), freeze,
                          geometry_context=R.prepare_geometry(cfg, freeze))
arrays, runtime, snapshot = R.run_prepared_case(prepared, cfg)
keep = {k: runtime[k] for k in ("status", "steps", "execution_seconds", "volume_conservation_exact",
                                 "volume_balance_error_units", "limited_face_count", "linear_solve")}
print(json.dumps(keep, indent=1))
