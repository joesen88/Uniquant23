# GANZ Kern-Prototyp (Stand 18.11.2026)

Ganzzahliger Kern zum Konzept „Ganzzahlige Lernarchitektur für Sprache und Programme“.
Im Kern gibt es keine Gleitkommazahl: Klassen, Zählungen und Skalenwerte mit Rest am Ort.

## Dateien

| Datei | Inhalt |
|---|---|
| `kern.py` | Log-Tafel LG = floor(2^24 · log2 i) mit Zertifikat (Quadrierfolge ab- und aufgerundet, genauer Pfad mit Python-int), C1/C2-Summentafeln, Dirichlet-Kodelänge mit Schranke, Übertrag mit Rest, Verteilung nach größtem Rest, arithmetischer Kodierer (Witten/Neal/Cleary, 32 Bit, KT-Häufigkeiten 2n+1) |
| `pruefe_kern.py` | Prüfungen: Tafel gegen exakten Potenzvergleich (E = 12) und gegen unabhängige artanh-Reihe (E = 24), Dirichlet-Formel gegen adaptives Produkt (Fraction), Verteilung und Übertrag, Kodierer gegen Formel und Rückweg |
| `stufe0.py` | Stufe 0, Durchgang 0a: Verschmelzen nach Kodelängengewinn mit Entscheidungsregel, Test auf zurückgehaltenen Seiten |
| `cm.py` | Ganzzahliges Context Mixing, Python-Referenz (Ordnungen 0–4 und 6, Wort, Match, Bias; Lernen mit Rest am Ort) |
| `cm.c` | Derselbe Mischer nativ, bitgleich zu `cm.py`; kodieren und dekodieren |
| `kein_float.py` | Prüfung des Zahlvertrags im Quelltext (AST) |
| `ergebnisse/` | JSON-Ausgaben der Läufe und die Streck-/Stauchtafel `tafeln.bin` |

## Aufruf

```
python3 -I pruefe_kern.py <tldr-Ordner> ergebnisse/pruefe_kern.json
python3 -I stufe0.py <tldr-Ordner> ergebnisse/stufe0.json 40000
python3 -I cm.py tafeln ergebnisse/tafeln.bin
gcc -O2 -std=c11 -o cm cm.c
./cm e ergebnisse/tafeln.bin strom.bin strom.cm 3661225      # Lernseiten, dann Testseiten
./cm d ergebnisse/tafeln.bin strom.cm zurueck.bin 4059435
python3 -I cm.py kodiere ergebnisse/tafeln.bin praefix.bin praefix_py.cm   # Referenz, bitgleich zu ./cm
python3 -I kein_float.py kern.py cm.py stufe0.py
```

tldr: `git clone https://github.com/tldr-pages/tldr` (Stand der Messung: Commit 70eef44 vom 17.11.2026).
Aufteilung: Dateien von pages/common und pages/linux sortiert; jede zehnte (Index mod 10 = 7) ist Test.
Der Strom `strom.bin` ist Lernseiten + Testseiten hintereinander; die Grenze liegt bei Byte 3.661.225.

## Gemessen (2 Kerne)

- Log-Tafel 2^23 Einträge: 4,9 s; 0,78 % über den genauen Pfad; 0 Fehler gegen beide unabhängigen Prüfungen.
- Kodierer Ordnung 0 auf 4.059.435 Byte: 20.409.939 bit, Formel 20.409.937 bit (Überhang 2 bit).
- Stufe 0: 2.347 Verschmelzungen, Test 2,929 bit/Byte gegen 5,030 (Byte-Unigramm).
- Mischer: Testseiten 1,381 bit/Byte (xz -9e mit Vorwissen 1,490; bzip2 1,827); Python und C bitgleich.

## Grenzen

Mischer auf Bytes, noch nicht auf Einheiten mit Klassenpfaden. Stufe 0 ohne Durchgang 0b und ohne harte EM.
Tafeln ohne Schutzbits (Schranke einer Summe über n Terme = n Einheiten von 2^-24 bit).
`pruefe_kern.py` und `stufe0.py` sind Prüf- und Messskripte; `pruefe_kern.py` nutzt Fraction und random (erlaubt in Tests).
