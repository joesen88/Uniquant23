"""Gezeitenkern, grob: Mond- und Sonnenort aus mittleren Bahnelementen (genuegt auf ~0,5 Grad),
daraus die Gleichgewichtsflut zeta = Summe GM_b * a^2 / (g d^3) * P2(cos psi) an jedem Ort.
Eine Kueste antwortet nicht mit der Gleichgewichtsflut, sondern verstaerkt und verzoegert sie:
    eta(t) = Summe_k  Z_art(k) * H_k * cos(omega_k t + phi_k)        Z komplex je Station und Tideart
mit den Konstituenten H_k der Gleichgewichtsflut (M2, S2, N2, K2 halbtaegig; K1, O1, P1, Q1 eintaegig).
Fit-Demo: zwei Kunstpegel verschiedener Breite und Tideart; unbekannt sind je Station Z_halb, Z_ein
und gemeinsam die Sonnenstaerke s (Skalierung von GM_Sonne/d^3).  Start s = 0,5; die Iteration
(abwechselnd Z je Station, dann s aus allen Stationen) soll s = 1 und die Z wiederfinden.
Schreibt konstituenten.csv und gezeiten_rand.csv: Kunst-Nordseepegel als Randpegel bei Osteriff fuer rohbett.py --tide.
Seine Form (Spring/Nipp, ungleiche Hochwasser) kommt aus dem Kern; die Groesse ist auf einen mittleren Tidehub skaliert
(--hub, Vorgabe 2,9 m wie in der Unterelbe), weil die Antwort Z der Elbmuendung noch nicht an einem echten Pegel gefittet ist.

    python gezeiten.py [--tage 5] [--hub 2.9]

Echte Pegel statt der Kunstpegel (Zeiten in UTC oder mit Zeitzone; je Pegel mindestens 30 Tage, besser ein Jahr):
    python gezeiten.py --pegel Cuxhaven 53.867 8.717 h825.csv --pegel Galveston 29.31 -94.79 galveston.csv
        liest je Pegel eine Datei (UHSLC-Stundenwerte: Jahr,Monat,Tag,Stunde,mm | Zeitstempel,Wert | PEGELONLINE-JSON),
        bestimmt die Konstituenten und fittet Z_halb, Z_ein je Pegel und die gemeinsame Sonnenstaerke s -> pegel_fit.csv
    python gezeiten.py --rand_aus osteriff.json [--pnp_cm 500]
        schreibt gezeiten_rand.csv aus einer gemessenen Reihe: Stunden ab dem ersten Wert, Pegel in m ueber NHN = (W - PNP) / 100"""
import argparse, csv, json
from datetime import datetime, timezone
from pathlib import Path
import numpy as np

D2R = np.pi / 180
GM_SONNE, GM_MOND = 1.32712440018e20, 4.9028695e12        # m3/s2
A, G, AU = 6.371e6, 9.81, 1.495978707e11
FREQ = {"M2": 28.9841042, "S2": 30.0, "N2": 28.4397295, "K2": 30.0821373,       # Grad je Stunde
        "K1": 15.0410686, "O1": 13.9430356, "P1": 14.9589314, "Q1": 13.3986609}
HALB = ("M2", "S2", "N2", "K2"); EIN = ("K1", "O1", "P1", "Q1")


def sonne(d):                                             # d = Tage seit J2000; ekliptikale Laenge, Breite 0, Abstand m
    g = (357.529 + 0.98560028 * d) * D2R
    lam = (280.459 + 0.98564736 * d) * D2R + (1.915 * np.sin(g) + 0.020 * np.sin(2 * g)) * D2R
    return lam, np.zeros_like(d), (1.00014 - 0.01671 * np.cos(g) - 0.00014 * np.cos(2 * g)) * AU


def mond(d):
    L = (218.316 + 13.176396 * d) * D2R; M = (134.963 + 13.064993 * d) * D2R; F = (93.272 + 13.229350 * d) * D2R
    return L + 6.289 * D2R * np.sin(M), 5.128 * D2R * np.sin(F), (385001 - 20905 * np.cos(M)) * 1e3


def rektadekl(lam, beta, d):                              # Ekliptik -> Rektaszension, Deklination
    eps = (23.439 - 4e-7 * d) * D2R
    x = np.cos(beta) * np.cos(lam)
    y = np.cos(eps) * np.cos(beta) * np.sin(lam) - np.sin(eps) * np.sin(beta)
    z = np.sin(eps) * np.cos(beta) * np.sin(lam) + np.cos(eps) * np.sin(beta)
    return np.arctan2(y, x), np.arcsin(z)


def zeta_eq(d, lat, lon, koerper=("mond", "sonne"), s_sonne=1.0):
    """Gleichgewichtsflut in m am Ort (lat, lon Grad) zu den Zeiten d (Tage seit J2000)."""
    gmst = (280.46061837 + 360.98564736629 * d) * D2R
    phi = lat * D2R; out = np.zeros_like(d)
    for name, gm, f in (("mond", GM_MOND, 1.0), ("sonne", GM_SONNE, s_sonne)):
        if name not in koerper:
            continue
        lam, beta, r = (mond if name == "mond" else sonne)(d)
        ra, dec = rektadekl(lam, beta, d)
        H = gmst + lon * D2R - ra                                     # Stundenwinkel
        cospsi = np.sin(phi) * np.sin(dec) + np.cos(phi) * np.cos(dec) * np.cos(H)
        out += f * gm * A * A / (G * r ** 3) * (1.5 * cospsi ** 2 - 0.5)
    return out


def harmonisch(t_h, y, keys=None):
    """Komplexe Konstituenten H_k aus einer Zeitreihe (t in Stunden, Luecken erlaubt): y ~ Summe Re(H_k exp(i omega_k t)) + const."""
    keys = list(keys or FREQ); cols = [np.ones_like(t_h)]
    for k in keys:
        wt = FREQ[k] * D2R * t_h; cols += [np.cos(wt), np.sin(wt)]
    c, *_ = np.linalg.lstsq(np.stack(cols, axis=1), y, rcond=None)
    return {k: c[1 + 2 * i] - 1j * c[2 + 2 * i] for i, k in enumerate(keys)}    # eta = Re(H e^{i w t})


def fit(stationen, beob, H_mond, H_sonne, s0=0.5, iters=12):
    """Je Station komplexe Antworten Z_halb, Z_ein und gemeinsam die Sonnenstaerke s.
    Modell je Konstituente: H_modell = Z_art * (H_mond_k + s * H_sonne_k).  Es zaehlen die Konstituenten, die beob je Station hat."""
    s = s0; Z = {st: {"halb": 1 + 0j, "ein": 1 + 0j} for st in stationen}
    arten = {st: (("halb", [k for k in HALB if k in beob[st]]), ("ein", [k for k in EIN if k in beob[st]])) for st in stationen}
    for _ in range(iters):
        for st in stationen:                                          # Z bei festem s: lineare LSQ je Tideart
            for art, keys in arten[st]:
                e = np.array([H_mond[st][k] + s * H_sonne[st][k] for k in keys])
                o = np.array([beob[st][k] for k in keys])
                Z[st][art] = np.vdot(e, o) / np.vdot(e, e)
        num = den = 0.0                                               # s bei festem Z: reelle LSQ ueber alles
        for st in stationen:
            for art, keys in arten[st]:
                for k in keys:
                    rest = beob[st][k] / Z[st][art] - H_mond[st][k]
                    num += (rest * np.conj(H_sonne[st][k])).real; den += abs(H_sonne[st][k]) ** 2
        s = num / den
    return Z, s


J2000 = datetime(2000, 1, 1, 12, tzinfo=timezone.utc)


def lies_pegel(datei):
    """Pegelreihe lesen -> (Tage seit J2000 in UTC, Werte, Einheit).  Erkennt UHSLC-Stundenwerte (Jahr,Monat,Tag,Stunde,mm;
    -32767 = fehlt), Zeilen 'Zeitstempel,Wert' (ISO-Zeit, Komma oder Semikolon) und PEGELONLINE-JSON (timestamp, value in cm)."""
    text = Path(datei).read_text(encoding="utf-8-sig").strip(); d, y, einheit = [], [], "cm"

    def tage(ts):
        t = datetime.fromisoformat(ts.strip().replace("Z", "+00:00").replace(" ", "T", 1))
        return ((t if t.tzinfo else t.replace(tzinfo=timezone.utc)) - J2000).total_seconds() / 86400

    if text[:1] in "[{":
        data = json.loads(text); data = data if isinstance(data, list) else data.get("measurements", data.get("data", []))
        for m in data:
            if m.get("value") is not None:
                d.append(tage(m["timestamp"])); y.append(float(m["value"]))
    else:
        for line in text.splitlines():
            c = [x.strip() for x in line.replace(";", ",").split(",")]
            try:
                if len(c) >= 5 and all(x.lstrip("-").isdigit() for x in c[:5]):          # UHSLC
                    if int(c[4]) > -30000:
                        d.append((datetime(int(c[0]), int(c[1]), int(c[2]), int(c[3]), tzinfo=timezone.utc) - J2000).total_seconds() / 86400); y.append(float(c[4]))
                    einheit = "mm"
                elif len(c) >= 2:
                    v = float(c[1].replace(",", ".")); d.append(tage(c[0])); y.append(v)
            except ValueError:
                continue                                                                # Kopfzeilen, Kommentare, Fehlwerte
    assert len(d) > 24, f"{datei}: keine Pegelwerte erkannt"
    o = np.argsort(d); return np.array(d)[o], np.array(y)[o], einheit


def echte_pegel(a):
    """Fit an gemessenen Reihen: Konstituenten je Pegel, Z_halb und Z_ein je Pegel, gemeinsame Sonnenstaerke s."""
    faktor = {"mm": 0.001, "cm": 0.01, "m": 1.0}; H_mond, H_sonne, beob, rows, info = {}, {}, {}, [], {}
    for name, lat, lon, datei in a.pegel:
        d, y, einheit = lies_pegel(datei); y = y * faktor[a.einheit or einheit]; lat, lon = float(lat), float(lon)
        tage = d[-1] - d[0]; assert tage >= 28, f"{name}: {tage:.0f} Tage sind zu kurz, um M2 und S2 zu trennen (mindestens 28)"
        keys = [k for k in FREQ if tage >= 180 or k not in ("K2", "P1")] if tage >= 28 else []      # K2/S2 und P1/K1 trennen sich erst nach einem halben Jahr
        t_h = (d - d[0]) * 24
        H_mond[name] = harmonisch(t_h, zeta_eq(d, lat, lon, ("mond",)), keys); H_sonne[name] = harmonisch(t_h, zeta_eq(d, lat, lon, ("sonne",)), keys)
        beob[name] = harmonisch(t_h, y - y.mean(), keys)
        rest = y - y.mean() - sum((beob[name][k] * np.exp(1j * FREQ[k] * D2R * t_h)).real for k in keys)
        info[name] = (len(d), tage, float(rest.std()))
    Z, s = fit([p[0] for p in a.pegel], beob, H_mond, H_sonne)
    print(f"Fit an {len(a.pegel)} Pegeln: Sonnenstaerke s = {s:.3f} (1 = wie aus Masse und Abstand der Sonne;"
          f" bei echten Pegeln steckt darin auch, dass das Meer auf S2 und M2 verschieden antwortet)")
    for name, lat, lon, datei in a.pegel:
        n, tage, rest = info[name]
        print(f"  {name}: {n} Werte ueber {tage:.0f} Tage | Z_halb = {abs(Z[name]['halb']):.2f} bei {-np.degrees(np.angle(Z[name]['halb'])):.0f} Grad,"
              f" Z_ein = {abs(Z[name]['ein']):.2f} bei {-np.degrees(np.angle(Z[name]['ein'])):.0f} Grad | Rest nach den Konstituenten {rest * 100:.1f} cm")
        for k in beob[name]:
            art = "halb" if k in HALB else "ein"; mod = Z[name][art] * (H_mond[name][k] + s * H_sonne[name][k])
            rows.append({"pegel": name, "konstituente": k, "gemessen_m": round(abs(beob[name][k]), 4), "modell_m": round(abs(mod), 4),
                         "gleichgewicht_m": round(abs(H_mond[name][k] + H_sonne[name][k]), 4), "z_betrag": round(abs(Z[name][art]), 3),
                         "z_verzug_grad": round(-float(np.degrees(np.angle(Z[name][art]))), 1), "sonnenstaerke": round(s, 4)})
    with open("pegel_fit.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print("geschrieben: pegel_fit.csv")


def rand_aus(a):
    """Gemessene Reihe als Randpegel fuer rohbett.py --tide: Stunden ab dem ersten Wert, m ueber NHN = (W - PNP) / 100."""
    d, y, einheit = lies_pegel(a.rand_aus); y = y * {"mm": 0.1, "cm": 1.0, "m": 100.0}[a.einheit or einheit] - a.pnp_cm
    with open("gezeiten_rand.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["zeit_h", "pegel_m"]); w.writerows([round(t, 4), round(v / 100, 4)] for t, v in zip((d - d[0]) * 24, y))
    print(f"geschrieben: gezeiten_rand.csv aus {a.rand_aus}: {len(d)} Werte ueber {(d[-1] - d[0]) * 24:.1f} h, Mittel {y.mean() / 100:+.2f} m,"
          f" hoechstens {y.max() / 100:+.2f}, tiefstens {y.min() / 100:+.2f} m ueber NHN (PNP {a.pnp_cm:g} cm abgezogen)")


def mittlerer_hub(eta):
    """Mittlerer Tidehub einer Pegelreihe: Mittel der Unterschiede aufeinanderfolgender Hoch- und Niedrigwasser."""
    d = np.sign(np.diff(eta)); ext = eta[1:-1][d[1:] != d[:-1]]
    return float(np.abs(np.diff(ext)).mean())


def main(argv=None, seed=1):
    ap = argparse.ArgumentParser(description="Gezeitenkern: Gleichgewichtsflut, Stationsantwort, Fit, Randreihe fuer rohbett")
    ap.add_argument("--tage", type=float, default=5.0, help="Laenge der Randreihe in Tagen")
    ap.add_argument("--hub", type=float, default=2.9, help="mittlerer Tidehub der Randreihe in m; 0 = unskaliert lassen")
    ap.add_argument("--pegel", nargs=4, action="append", default=[], metavar=("NAME", "BREITE", "LAENGE", "DATEI"), help="gemessene Pegelreihe; mehrfach moeglich")
    ap.add_argument("--einheit", choices=["mm", "cm", "m"], default=None, help="Einheit der Pegelwerte, wenn sie nicht erkannt wird (UHSLC mm, sonst cm)")
    ap.add_argument("--rand_aus", default=None, metavar="DATEI", help="gemessene Reihe als gezeiten_rand.csv fuer rohbett.py --tide schreiben")
    ap.add_argument("--pnp_cm", type=float, default=500.0, help="Pegelnullpunkt unter NHN in cm (Kuestenpegel: 500), wird vom Wasserstand abgezogen")
    a = ap.parse_args(argv)
    if a.rand_aus:
        return rand_aus(a)
    if a.pegel:
        return echte_pegel(a)
    rng = np.random.default_rng(seed)
    d0 = 9500.0                                                       # Tage seit J2000, Lage egal
    t_h = np.arange(0, 365 * 24, 1.0)                                 # ein Jahr, stuendlich
    d = d0 + t_h / 24
    print(f"Gleichgewichtsflut am Aequator: Mond {GM_MOND*A*A/(G*3.844e8**3):.3f} m, Sonne {GM_SONNE*A*A/(G*AU**3):.3f} m,"
          f" Verhaeltnis Sonne/Mond {GM_SONNE/GM_MOND*(3.844e8/AU)**3:.4f}")
    # Kunstpegel: Nordsee mit starker halbtaegiger und schwacher eintaegiger Antwort (Groessenordnung Deutsche Bucht), Golfkueste umgekehrt
    stationen = {"Nordsee": (54.0, 8.4, 15.0 * np.exp(-1j * 60 * D2R), 0.5 * np.exp(-1j * 30 * D2R)),
                 "Golfkueste": (29.0, -94.7, 0.5 * np.exp(-1j * 20 * D2R), 3.0 * np.exp(-1j * 45 * D2R))}
    H_mond, H_sonne, beob, wahr = {}, {}, {}, {}
    rows = []
    for st, (lat, lon, zh, ze) in stationen.items():
        H_mond[st] = harmonisch(t_h, zeta_eq(d, lat, lon, ("mond",)))
        H_sonne[st] = harmonisch(t_h, zeta_eq(d, lat, lon, ("sonne",)))
        y = sum((( zh if k in HALB else ze) * (H_mond[st][k] + H_sonne[st][k]) * np.exp(1j * FREQ[k] * D2R * t_h)).real
                for k in FREQ) + rng.normal(0, 0.05, t_h.size)        # Kunstpegel: wahre Sonnenstaerke 1, Rauschen 5 cm
        beob[st] = harmonisch(t_h, y); wahr[st] = (zh, ze)
        for k in FREQ:
            H = H_mond[st][k] + H_sonne[st][k]
            rows.append({"station": st, "konstituente": k, "eq_amp_m": round(abs(H), 4),
                         "eq_phase_grad": round(np.degrees(np.angle(H)), 1),
                         "pegel_amp_m": round(abs(beob[st][k]), 4)})
    with open("konstituenten.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    Z, s = fit(list(stationen), beob, H_mond, H_sonne)
    print(f"\nFit (Start Sonnenstaerke 0,5): s = {s:.4f} (wahr 1) ->"
          f" GM_Sonne = {s*GM_SONNE:.4e} (wahr {GM_SONNE:.4e}), Sonne/Mond-Flut = {s*GM_SONNE/GM_MOND*(3.844e8/AU)**3:.4f}")
    for st in stationen:
        for art, idx in (("halb", 0), ("ein", 1)):
            zf, zw = Z[st][art], wahr[st][idx]
            print(f"  {st:10s} Z_{art:4s} = {abs(zf):.3f} bei {-np.degrees(np.angle(zf)):6.1f} Grad"
                  f"  (wahr {abs(zw):.3f} bei {-np.degrees(np.angle(zw)):6.1f}) | Fehler {abs(zf-zw)/abs(zw)*100:.1f} %")
    assert abs(s - 1) < 0.05, "Sonnenstaerke nicht wiedergefunden"
    lat, lon, zh, ze = stationen["Nordsee"]                           # Randreihe fuer Osteriff, 10-min-Schritt
    t3 = np.arange(0, a.tage * 24 + 0.0001, 1 / 6); d3 = d0 + 365 + t3 / 24
    Hm = H_mond["Nordsee"]; Hs = H_sonne["Nordsee"]
    eta = sum(((zh if k in HALB else ze) * (Hm[k] + Hs[k]) * np.exp(1j * FREQ[k] * D2R * (t3 + 365 * 24))).real for k in FREQ)
    roh = mittlerer_hub(eta)
    if a.hub > 0:
        eta = (eta - eta.mean()) * a.hub / roh                        # auf den gewuenschten mittleren Hub, Mittel null
    with open("gezeiten_rand.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["zeit_h", "pegel_m"]); w.writerows([round(t, 4), round(v, 4)] for t, v in zip(t3, eta))
    print(f"\ngeschrieben: konstituenten.csv, gezeiten_rand.csv ({a.tage * 24:g} h, mittlerer Hub {mittlerer_hub(eta):.2f} m"
          f" (aus dem Kern {roh:.2f} m), hoechstens {eta.max():+.2f}, tiefstens {eta.min():+.2f} m)")
    print(f"Planeten zum Vergleich (Anteil an der Mondflut): Venus {3.249e14/4.1e10**3/(GM_MOND/3.844e8**3):.1e},"
          f" Jupiter {1.267e17/6.3e11**3/(GM_MOND/3.844e8**3):.1e} -> vernachlaessigbar")
    return t3, eta, d3, (lat, lon)


if __name__ == "__main__":
    main()
