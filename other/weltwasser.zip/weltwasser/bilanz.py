"""Weltwasser-Bilanz, grob: Bestaende (km3) und Fluesse (km3/Jahr) nach den Standardwerken
Shiklomanov 1993 (Bestaende, wie vom USGS verbreitet) und Baumgartner & Reichel 1975 (Fluesse).
Rundung grob, Unsicherheit der Fluesse etwa +-10 %.  Schreibt bilanz_bestaende.csv und bilanz_fluesse.csv."""
import csv

KM3_JAHR_M3S = 1e9 / (365.25 * 86400)          # km3/Jahr -> m3/s

BESTAENDE = [  # Name, km3, Anteil Suesswasser daran in km3 (None = unbekannt/egal)
    ("Ozeane",                1_338_000_000, 0),
    ("Eis und Gletscher",        24_064_000, 24_064_000),
    ("Grundwasser",              23_400_000, 10_530_000),
    ("Permafrost-Eis",              300_000, 300_000),
    ("Seen",                        176_400, 91_000),
    ("Bodenfeuchte",                 16_500, 16_500),
    ("Atmosphaere",                  12_900, 12_900),
    ("Suempfe/Moore",                11_470, 11_470),
    ("Fluesse (Gerinne)",             2_120, 2_120),
    ("Lebewesen",                     1_120, 1_120),
]
STAUSEEN = 8_000        # km3, in "Seen" nicht enthalten (grobe Spanne 7000-8300, Stand der Literatur)

FLUESSE = [  # km3/Jahr
    ("Verdunstung Ozean",  425_000),
    ("Niederschlag Ozean", 385_000),
    ("Niederschlag Land",  111_000),
    ("Verdunstung Land",    71_000),
    ("Abfluss ins Meer",    40_000),
]

GROSSE_FLUESSE = [  # Name, mittlerer Abfluss an der Muendung m3/s (grob, Literaturmittel)
    ("Amazonas", 209_000), ("Kongo", 41_000), ("Ganges+Brahmaputra", 38_000), ("Orinoco", 33_000),
    ("Jangtse", 30_000), ("Jenissei", 19_600), ("Parana", 17_300), ("Lena", 17_100),
    ("Mississippi", 16_800), ("Mekong", 16_000), ("Elbe", 860),
]


def main():
    total = sum(v for _, v, _ in BESTAENDE)
    print(f"Bestaende, zusammen {total/1e9:.3f} Mrd km3 (Stauseen {STAUSEEN} km3 zusaetzlich):")
    rows = []
    for name, v, fresh in BESTAENDE:
        rows.append({"bestand": name, "km3": v, "anteil_prozent": round(100 * v / total, 4),
                     "suesswasser_km3": fresh})
        print(f"  {name:20s} {v:>13,} km3  {100*v/total:7.3f} %")
    with open("bilanz_bestaende.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

    eo, po, pl, el, r = (v for _, v in FLUESSE)
    assert eo - po == r == pl - el, "Kreislauf schliesst nicht"
    print("\nFluesse (km3/Jahr | m3/s):")
    rows = []
    for name, v in FLUESSE:
        rows.append({"fluss": name, "km3_jahr": v, "m3_s": round(v * KM3_JAHR_M3S)})
        print(f"  {name:20s} {v:>8,} | {v*KM3_JAHR_M3S:>12,.0f} m3/s")
    print(f"  Kontrolle: Ozean verliert {eo-po:,} = Land gewinnt {pl-el:,} = Abfluss {r:,} km3/Jahr")
    verweil = [("Atmosphaere", 12_900 / (eo + el) * 365.25, "Tage"), ("Fluesse", 2_120 / r * 365.25, "Tage"),
               ("Ozean", 1_338_000_000 / eo, "Jahre"), ("Seen", (176_400 + STAUSEEN) / r, "Jahre (bez. auf Abfluss)")]
    print("\nVerweilzeiten (Bestand/Fluss):")
    for name, t, unit in verweil:
        print(f"  {name:12s} {t:8.1f} {unit}")
    with open("bilanz_fluesse.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

    summe = sum(q for _, q in GROSSE_FLUESSE[:-1])
    welt = r * KM3_JAHR_M3S
    print(f"\nGrosse Fluesse (m3/s), Welt-Abfluss {welt:,.0f} m3/s:")
    for name, q in GROSSE_FLUESSE:
        print(f"  {name:20s} {q:>8,}  {100*q/welt:6.2f} %")
    print(f"  Top 10 zusammen {summe:,} m3/s = {100*summe/welt:.0f} % | Elbe {100*860/welt:.3f} %")


if __name__ == "__main__":
    main()
