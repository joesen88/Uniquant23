"""Ganzzahliges Context Mixing (Python-Referenz).  Bitgleich mit cm.c.

Eingaben je Bit: Ordnung 0 (Teilbyte), Ordnungen 1, 2, 3, 4, 6 (gestreut), Wortkontext, Match-Modell, Bias.
Match-Modell: letzte Fundstelle der 6 vorigen Bytes; Vorhersage = Bit des dort folgenden Bytes, Zaehler je Laenge.
Zaehler je Platz: n0, n1 (je 8 Bit, gepackt), KT-Schaetzung p1 = (2 n1 + 1) 2^12 / (2 (n0 + n1) + 2), Halbieren ab 61.
Mischer: Gewichte Q16 je Bitposition, Streckwerte 2^8 log2(p/(1-p)) aus der Log-Tafel, Lernen mit Rest am Ort.
Kodierer: binaer, 32 Bit, Bytes ausgeben (Bauart lpaq).

Aufruf: python3 -I cm.py tafeln <tafeln.bin>          Streck- und Stauchtafel schreiben
        python3 -I cm.py kodiere <tafeln.bin> <eingabe> <ausgabe> [bytes]
"""
import hashlib
import sys
from array import array
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

BITS_TAB = 22
MASKE = (1 << BITS_TAB) - 1
ORDNUNGEN = (1, 2, 3, 4, 6)
GRENZE = 60
LERN_SCHIEBEN = 10
START_GEWICHT = 19660
U32 = 0xFFFFFFFF
M_LAENGE = 6
M_BITS = 20


def baue_tafeln(pfad):
    import kern as K
    lg, _ = K.lg_tafel(4096)
    st = [0] * 4096
    for p in range(1, 4096):
        st[p] = (int(lg[p]) - int(lg[4096 - p])) >> 16
    sq = []
    for d in range(-3072, 3072):
        z = 1 + sum(1 for p in range(1, 4096) if st[p] < d)
        sq.append(min(max(z, 1), 4095))
    a = array("i", st + sq)
    Path(pfad).write_bytes(a.tobytes())


def lies_tafeln(pfad):
    a = array("i")
    a.frombytes(Path(pfad).read_bytes())
    return list(a[:4096]), list(a[4096:])


def kodiere(tafeln, daten, grenze_bytes=None):
    st, sq = lies_tafeln(tafeln)
    tabs = [array("H", bytes(2 * (1 << BITS_TAB))) for _ in range(len(ORDNUNGEN) + 1)]
    t0 = array("H", bytes(2 * 256))
    nin = len(ORDNUNGEN) + 4
    mtab = array("i", bytes(4 * (1 << M_BITS)))
    mz = array("H", bytes(2 * 64))
    buf = bytearray()
    mptr, mlen = 0, 0
    w = [[START_GEWICHT] * nin for _ in range(8)]
    rest = [[0] * nin for _ in range(8)]
    x1, x2 = 0, U32
    aus = bytearray()
    hist = bytearray()
    hw = 0
    marke = None
    for pos_byte, byte in enumerate(daten):
        if grenze_bytes is not None and pos_byte == grenze_bytes:
            marke = len(aus)
        hs = []
        for k in ORDNUNGEN:
            h = 2166136261 ^ k
            for b in hist[-k:]:
                h = ((h ^ b) * 16777619) & U32
            hs.append(h)
        hs.append(hw ^ 0x5bd1e995)
        eb = buf[mptr] if mlen > 0 else -1
        c0 = 1
        for bit in range(8):
            y = (byte >> (7 - bit)) & 1
            idx = [c0]
            for h in hs:
                idx.append(((((h + c0 * 0x9E3779B1) & U32) * 0x85EBCA6B) & U32) >> (32 - BITS_TAB))
            werte = [t0[c0]] + [tabs[j][idx[j + 1]] for j in range(len(hs))]
            sts = []
            for v in werte:
                n0, n1 = v & 255, v >> 8
                sts.append(st[((2 * n1 + 1) << 12) // (2 * (n0 + n1) + 2)])
            if mlen > 0 and ((eb + 256) >> (8 - bit)) == c0:
                mctx = (min(mlen, 31) << 1) | ((eb >> (7 - bit)) & 1)
                v = mz[mctx]
                n0, n1 = v & 255, v >> 8
                sts.append(st[((2 * n1 + 1) << 12) // (2 * (n0 + n1) + 2)])
            else:
                mctx = -1
                sts.append(0)
            sts.append(256)
            ww = w[bit]
            dot = 0
            for i in range(nin):
                dot += ww[i] * sts[i]
            d = dot >> 16
            d = -3071 if d < -3071 else (3071 if d > 3071 else d)
            p = sq[d + 3072]
            xm = x1 + ((x2 - x1) >> 12) * p
            if y:
                x2 = xm
            else:
                x1 = xm + 1
            while ((x1 ^ x2) & 0xFF000000) == 0:
                aus.append(x2 >> 24)
                x1 = (x1 << 8) & U32
                x2 = ((x2 << 8) & U32) | 255
            err = (y << 12) - p
            rr = rest[bit]
            for i in range(nin):
                t = rr[i] + sts[i] * err
                q = t >> LERN_SCHIEBEN
                rr[i] = t - (q << LERN_SCHIEBEN)
                ww[i] += q
            for j, v in enumerate(werte):
                n0, n1 = v & 255, v >> 8
                if y:
                    n1 += 1
                else:
                    n0 += 1
                if n0 + n1 > GRENZE:
                    n0, n1 = (n0 + 1) >> 1, (n1 + 1) >> 1
                nv = n0 | (n1 << 8)
                if j == 0:
                    t0[c0] = nv
                else:
                    tabs[j - 1][idx[j]] = nv
            if mctx >= 0:
                v = mz[mctx]
                n0, n1 = v & 255, v >> 8
                if y:
                    n1 += 1
                else:
                    n0 += 1
                if n0 + n1 > GRENZE:
                    n0, n1 = (n0 + 1) >> 1, (n1 + 1) >> 1
                mz[mctx] = n0 | (n1 << 8)
            c0 = (c0 << 1) | y
        buf.append(byte)
        if mlen > 0:
            if eb == byte:
                mlen = min(mlen + 1, 65535)
                mptr += 1
            else:
                mlen = 0
        if len(buf) >= M_LAENGE:
            h = 0
            for b in buf[-M_LAENGE:]:
                h = (h * 773 + b + 1) & U32
            h = ((h * 0x9E3779B1) & U32) >> (32 - M_BITS)
            if mlen == 0 and mtab[h] > 0:
                mptr, mlen = mtab[h], 1
            mtab[h] = len(buf)
        hist.append(byte)
        if len(hist) > 16:
            del hist[0]
        is_buch = (65 <= byte <= 90) or (97 <= byte <= 122) or byte >= 128
        hw = ((hw ^ byte) * 16777619) & U32 if is_buch else 0
    for _ in range(4):
        aus.append(x1 >> 24)
        x1 = (x1 << 8) & U32
    return bytes(aus), marke


def main():
    if sys.argv[1] == "tafeln":
        baue_tafeln(sys.argv[2])
        return
    tafeln, ein, aus = sys.argv[2], sys.argv[3], sys.argv[4]
    daten = Path(ein).read_bytes()
    if len(sys.argv) > 5:
        daten = daten[: int(sys.argv[5])]
    k, _ = kodiere(tafeln, daten)
    Path(aus).write_bytes(k)
    print(len(daten), "Byte ->", len(k), "Byte | sha256", hashlib.sha256(k).hexdigest()[:16])


if __name__ == "__main__":
    main()
