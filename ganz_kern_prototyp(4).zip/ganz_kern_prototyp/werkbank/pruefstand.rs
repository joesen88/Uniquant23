// pruefstand.rs: exakter Pruefer fuer stufen.rs.  Liest Pruefvektoren (aus vektoren.py) und vergleicht bitgleich.
//
// Aufruf:  rustc -C overflow-checks=on -o pruefstand pruefstand.rs   und   ./pruefstand vektoren.txt
// Zeile der Vektordatei:  <funktion> <eingaben ...> | <erwartete ausgaben ...>      (alles ganze Zahlen)
// Ausgabe je Funktion:    F <funktion> <faelle> <falsch> <panik> <erste_fehlerzeile> <panikklasse> <maske>
//                         maske: Bit i gesetzt, wenn Ausgabestelle i je abwich (Bit 7: andere Laenge)
// Die Rueckgabetypen sind hier festgeschrieben, damit auch eine Abweichung nur im Typ auffaellt.
// Letzte Zeile:           ERGEBNIS <0 bestanden | 1 nicht bestanden>
mod stufen;

use std::io::BufRead;
use std::sync::Mutex;

static LETZTE_PANIK: Mutex<String> = Mutex::new(String::new());

fn s3(v: &[i64]) -> stufen::Stufe {
    (v[0] as i32, v[1] as u64, v[2] as u64)
}

fn aus3(r: stufen::Stufe) -> Vec<i64> {
    vec![r.0 as i64, r.1 as i64, r.2 as i64]
}

fn rechne(name: &str, v: &[i64]) -> Vec<i64> {
    match name {
        "klasse_fein" => {
            let r: (u64, u64) = stufen::klasse_fein(v[0] as u64);
            vec![r.0 as i64, r.1 as i64]
        }
        "reste" => {
            let r: (u64, u64) = stufen::reste(v[0] as u64);
            vec![r.0 as i64, r.1 as i64]
        }
        "aus_resten" => {
            let r: u64 = stufen::aus_resten(v[0] as u64, v[1] as u64);
            vec![r as i64]
        }
        "klasse_per_quersumme" => {
            let r: u64 = stufen::klasse_per_quersumme(v[0] as u64);
            vec![r as i64]
        }
        "zwei_skalen" => {
            let r: (u64, u64) = stufen::zwei_skalen(v[0] as u64);
            vec![r.0 as i64, r.1 as i64]
        }
        "zurueck" => {
            let r: u64 = stufen::zurueck(v[0] as u64, v[1] as u64);
            vec![r as i64]
        }
        "seiten_diagonal" => {
            let mut out: Vec<i64> = Vec::new();
            let paare: Vec<(u64, u64)> = stufen::seiten_diagonal(v[0] as usize);
            for (s, d) in paare {
                out.push(s as i64);
                out.push(d as i64);
            }
            out
        }
        "unter_22_5" => {
            let r: (bool, u32) = stufen::unter_22_5(v[0] as u64, v[1] as u64);
            vec![r.0 as i64, r.1 as i64]
        }
        "vergleiche" => {
            let r: (i32, u8) = stufen::vergleiche(s3(&v[0..3]), s3(&v[3..6]));
            vec![r.0 as i64, r.1 as i64]
        }
        "entscheide" => {
            let r: (i32, u8) = stufen::entscheide(s3(&v[0..3]), s3(&v[3..6]), s3(&v[6..9]), s3(&v[9..12]));
            vec![r.0 as i64, r.1 as i64]
        }
        "bruch" => aus3(stufen::bruch(v[0] as u64, v[1] as u64, v[2] != 0)),
        "mal" => aus3(stufen::mal(s3(&v[0..3]), s3(&v[3..6]), v[6] != 0)),
        "plus" => aus3(stufen::plus(s3(&v[0..3]), s3(&v[3..6]), v[6] != 0)),
        _ => vec![i64::MIN],
    }
}

fn panikklasse(text: &str) -> &'static str {
    if text.contains("overflow") {
        "ueberlauf"
    } else if text.contains("divide by zero") || text.contains("remainder with a divisor of zero") {
        "teilung_durch_null"
    } else if text.contains("out of bounds") || text.contains("out of range") {
        "grenze"
    } else {
        "andere"
    }
}

fn main() {
    let pfad = std::env::args().nth(1).expect("Vektordatei fehlt");
    let datei = std::fs::File::open(&pfad).expect("Vektordatei nicht lesbar");
    std::panic::set_hook(Box::new(|info| {
        *LETZTE_PANIK.lock().unwrap() = info.to_string();
    }));
    // je Funktion: Name, Faelle, falsch, Panik, erste Fehlerzeile, Panikklasse, Maske der abweichenden Stellen
    let mut tafel: Vec<(String, u32, u32, u32, usize, &'static str, u32)> = Vec::new();
    for (nr, zeile) in std::io::BufReader::new(datei).lines().enumerate() {
        let zeile = zeile.expect("Lesefehler");
        let zeile = zeile.trim();
        if zeile.is_empty() || zeile.starts_with('#') {
            continue;
        }
        let (links, rechts) = zeile.split_once('|').expect("Trenner | fehlt");
        let mut teile = links.split_whitespace();
        let name = teile.next().expect("Funktionsname fehlt").to_string();
        let v: Vec<i64> = teile.map(|t| t.parse().expect("Zahl erwartet")).collect();
        let soll: Vec<i64> = rechts.split_whitespace().map(|t| t.parse().expect("Zahl erwartet")).collect();
        if tafel.last().map(|e| e.0 != name).unwrap_or(true) {
            tafel.push((name.clone(), 0, 0, 0, 0, "-", 0));
        }
        let ergebnis = std::panic::catch_unwind(|| rechne(&name, &v));
        let e = tafel.last_mut().unwrap();
        e.1 += 1;
        match ergebnis {
            Ok(ist) => {
                if ist != soll {
                    e.2 += 1;
                    if e.4 == 0 {
                        e.4 = nr + 1;
                    }
                    if ist.len() != soll.len() {
                        e.6 |= 1 << 7;
                    } else {
                        for i in 0..ist.len() {
                            if ist[i] != soll[i] {
                                e.6 |= 1 << i.min(6);
                            }
                        }
                    }
                }
            }
            Err(_) => {
                e.3 += 1;
                if e.4 == 0 {
                    e.4 = nr + 1;
                }
                if e.5 == "-" {
                    e.5 = panikklasse(&LETZTE_PANIK.lock().unwrap());
                }
            }
        }
    }
    let mut schlecht = 0;
    for e in &tafel {
        println!("F {} {} {} {} {} {} {}", e.0, e.1, e.2, e.3, e.4, e.5, e.6);
        schlecht += e.2 + e.3;
    }
    println!("ERGEBNIS {}", if schlecht == 0 { 0 } else { 1 });
    std::process::exit(if schlecht == 0 { 0 } else { 1 });
}
