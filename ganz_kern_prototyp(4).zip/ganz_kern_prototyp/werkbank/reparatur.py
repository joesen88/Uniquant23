"""Reparaturschleife: Programme mit Abweichungen anhand der Rueckmeldung reparieren und aus bestandenen Faellen lernen.

Episode   Start = richtiges stufen.rs mit 1 oder 2 zufaelligen Abweichungen (nur solche, die der Pruefer einzeln
          entdeckt).  Die Schleife kennt weder Zahl noch Ort der Abweichungen und nie das richtige Programm.
Kette     bewerten  Rueckmeldung lesen: Klasse und Ort
          planen    Aenderungen (eine Luecke, ein anderes Zeichen) an den Luecken des gemeldeten Orts reihen
          handeln   die naechste Aenderung einsetzen
          pruefen   Fortschritt?  Dann vorlaeufig behalten und von dort weiter; fuehrt der Weg nicht zum Ziel, wird der
                    Schritt zurueckgenommen und die naechste Aenderung versucht (Ruecksprung).
          Fortschritt (strenge Regel): Uebersetzungsfehler werden weniger oder verschwinden; bei Lauffehlern zaehlt nur,
          dass die gemeldete Funktion ganz besteht.  Die erste Fassung liess auch "weniger fehlschlagende Faelle" gelten
          und lief damit in Scheinfortschritt: 27 von 48 Episoden geloest (regel = "locker", Ergebnis reparatur_locker.json).
Ort       Uebersetzungsfehler: Luecken unter der Hauptstelle (Stufe 0), in ihrer Zeile (1), in Zeilen der Nebenstellen (2),
          in der betroffenen Funktion (3).  Lauffehler: Luecken der ersten fehlschlagenden Funktion.
Varianten ort        Reihenfolge nach Ortsstufe, dann nach Stelle im Text
          ort_tafel  Reihenfolge nach gelerntem Rang, alles ganzzahlig:
                       A[Fehlerbild][Art der Luecke]   wie oft lag der Fehler bei diesem Bild in einer Luecke dieser Art
                       L[Fehlerklasse][Ortsstufe]      wie oft lag er auf dieser Ortsstufe
                       G[Art][Zeichen]                 Grundverteilung der Zeichen in geprueftem Code
                     Rang = (A + 1) * (L + 1) * (Summe G - G[jetziges Zeichen] + 1) * (G[neues Zeichen] + 1)
                     Der dritte Faktor macht ein seltenes Zeichen verdaechtig, der vierte ein haeufiges wahrscheinlich.
Lernen    nur aus Episoden, die bestanden enden.  Fuer eine Luecke in Funktion f zaehlen nur Erfahrungen aus den
          anderen Funktionen: Die Schleife kann sich das richtige Programm nicht merken.

Aufruf: python3 -I reparatur.py <stufen.rs> <vektoren.txt> <mutationsanalyse.json> <ausgabe.json> [episoden]
"""
import json
import re
import sys
from math import comb
from multiprocessing import Pool
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import werkbank as W  # noqa: E402

M64 = (1 << 64) - 1
BUDGET = 160
TIEFE = 6
AUFRUF = re.compile(r"stufen::(\w+)")
VARIANTEN = ("ort", "ort_tafel")


def misch(x):
    x = (x + 0x9E3779B97F4A7C15) & M64
    x = ((x ^ (x >> 30)) * 0xBF58476D1CE4E5B9) & M64
    x = ((x ^ (x >> 27)) * 0x94D049BB133111EB) & M64
    return x ^ (x >> 31)


def schluessel(r):
    """Kurzcode der Rueckmeldung fuer die Tafeln."""
    return r.get("bild") or r["klasse"]


def ortsluecken(quelle, stand_zeilen, wahl, r):
    """[(Ortsstufe, Lueckennummer)] nach der Rueckmeldung; kleinere Stufe ist naeher."""
    alle = range(len(quelle.luecken))
    if r["art"] in ("falsch", "panik") and r["funktionen"]:
        f = r["funktionen"][0]["name"]
        return [(0, nr) for nr in alle if quelle.luecken[nr]["funktion"] == f] or [(4, nr) for nr in alle]
    if r["art"] == "uebersetzung" and r["fehler"]:
        lage = quelle.lage(wahl)
        erste = r["fehler"][0]
        haupt = [s for s in erste["haupt"] if s["datei"] == "stufen.rs"]
        neben = [s for s in erste["neben"] if s["datei"] == "stufen.rs"]
        neben += [t for g in erste["vorschlaege"] for t in g if t["datei"] == "stufen.rs"]
        funktionen = {quelle.funktion_der_zeile(s["zeile"]) for s in haupt + neben} - {None}
        for s in erste["haupt"] + erste["neben"]:                    # Meldung im Pruefstand: aufgerufene Funktion lesen
            if s["datei"] == "pruefstand.rs":
                for z in range(max(1, s["zeile"] - 2), s["zeile"] + 1):
                    m = AUFRUF.search(stand_zeilen[z - 1])
                    if m:
                        funktionen.add(m.group(1))
        aus = []
        for nr in alle:
            z, von, bis = lage[nr]
            if any(s["zeile"] == z == s["zeile_bis"] and s["von"] < bis and von < s["bis"] for s in haupt):
                aus.append((0, nr))
            elif any(s["zeile"] <= z <= s["zeile_bis"] for s in haupt):
                aus.append((1, nr))
            elif any(s["zeile"] <= z <= s["zeile_bis"] for s in neben):
                aus.append((2, nr))
            elif quelle.luecken[nr]["funktion"] in funktionen:
                aus.append((3, nr))
        return sorted(aus) or [(4, nr) for nr in alle]
    return [(4, nr) for nr in alle]


class Tafeln:
    """Zaehlungen je Funktion, gelesen stets ohne die Funktion der fraglichen Luecke."""

    def __init__(self):
        self.a, self.l, self.g = {}, {}, {}

    @staticmethod
    def _plus(tafel, funktion, key):
        t = tafel.setdefault(key, {})
        t[funktion] = t.get(funktion, 0) + 1
        t[None] = t.get(None, 0) + 1

    @staticmethod
    def _ohne(tafel, funktion, key):
        t = tafel.get(key)
        return t[None] - t.get(funktion, 0) if t else 0

    def lerne(self, quelle, schritte, wahl):
        for s in schritte:
            self._plus(self.a, s["funktion"], (s["bild"], s["art"]))
            self._plus(self.l, s["funktion"], (s["klasse"], s["stufe"]))
        if not self.g:                                # gepruefter Code: Zeichen aller Luecken des bestandenen Programms
            for luecke in quelle.luecken:
                self._plus(self.g, luecke["funktion"], (luecke["art"], wahl.get(luecke["nr"], luecke["original"])))
                self._plus(self.g, luecke["funktion"], (luecke["art"], None))

    def rang(self, luecke, bild, klasse, stufe, jetzt, neu):
        f, art = luecke["funktion"], luecke["art"]
        a = self._ohne(self.a, f, (bild, art))
        ll = self._ohne(self.l, f, (klasse, stufe))
        summe = self._ohne(self.g, f, (art, None))
        return (a + 1) * (ll + 1) * (summe - self._ohne(self.g, f, (art, jetzt)) + 1) * (self._ohne(self.g, f, (art, neu)) + 1)


def repariere(quelle, pruefer, stand_zeilen, start, tafeln):
    """Tiefensuche mit Ruecksprung.  Rueckgabe: (bestanden, Pruefer-Laeufe, Schritte des Loesungswegs, Zeichenwahl am Ende)."""
    gesehen = set()
    schritte = []

    def pruefe(w):
        text = quelle.baue(w)
        gesehen.add(text)
        return pruefer.pruefe(text)

    def suche(wahl, r, tiefe):
        if r["art"] == "bestanden":
            return wahl
        if tiefe >= TIEFE:
            return None
        bild, klasse = schluessel(r), r["klasse"]
        plan = []
        for platz, (stufe, nr) in enumerate(ortsluecken(quelle, stand_zeilen, wahl, r)):
            luecke = quelle.luecken[nr]
            jetzt = wahl.get(nr, luecke["original"])
            for i, zeichen in enumerate(W.OPTIONEN[luecke["art"]]):
                if zeichen != jetzt:
                    wert = tafeln.rang(luecke, bild, klasse, stufe, jetzt, zeichen) if tafeln else 0
                    plan.append((-wert, platz, i, stufe, nr, jetzt, zeichen))
        plan.sort()
        for stelle_im_plan, (_, _, _, stufe, nr, jetzt, zeichen) in enumerate(plan):
            if len(gesehen) >= BUDGET:
                return None
            neu = dict(wahl)
            if zeichen == quelle.luecken[nr]["original"]:
                neu.pop(nr, None)
            else:
                neu[nr] = zeichen
            r2 = pruefe(neu)
            if W.rang_streng(r2) > W.rang_streng(r):
                luecke = quelle.luecken[nr]
                schritte.append(dict(funktion=luecke["funktion"], art=luecke["art"], ausgang=r["art"], bild=bild,
                                     klasse=klasse, stufe=stufe, alt=jetzt, neu=zeichen, platz=stelle_im_plan + 1,
                                     plan=len(plan)))
                ende = suche(neu, r2, tiefe + 1)
                if ende is not None:
                    return ende
                schritte.pop()                                   # Ruecksprung: dieser Schritt fuehrte nicht zum Ziel
        return None

    start = dict(start)
    ende = suche(start, pruefe(start), 0)
    return ende is not None, len(gesehen), schritte, ende if ende is not None else start


def episoden(quelle, einzeln, zahl, samen=20261118):
    """Je Episode 1 oder 2 Abweichungen an verschiedenen Luecken, gezogen aus den einzeln entdeckten."""
    entdeckt = [(e["luecke"], e["ersatz"]) for e in einzeln if e["ausgang"] in ("uebersetzung", "falsch", "panik")]
    aus, zust = [], samen
    for i in range(zahl):
        m = 1 + i % 2
        wahl = {}
        while len(wahl) < m:
            zust = misch(zust)
            nr, zeichen = entdeckt[zust % len(entdeckt)]
            if nr not in wahl:
                wahl[nr] = zeichen
        aus.append(wahl)
    return aus


def laufe(auftrag):
    variante, pfad, vektoren, liste = auftrag
    quelle = W.Quelle(pfad)
    pruefer = W.Pruefer(vektoren)
    stand_zeilen = W.HIER.joinpath("pruefstand.rs").read_text(encoding="utf-8").split("\n")
    tafeln = Tafeln() if variante == "ort_tafel" else None
    aus = []
    for nr, start in enumerate(liste):
        ok, laeufe, schritte, ende = repariere(quelle, pruefer, stand_zeilen, start, tafeln)
        if ok and tafeln is not None:
            tafeln.lerne(quelle, schritte, ende)
        print(variante, nr, "bestanden" if ok else "offen", laeufe, file=sys.stderr, flush=True)
        aus.append(dict(abweichungen=[dict(funktion=quelle.luecken[nr]["funktion"], art=quelle.luecken[nr]["art"],
                                           original=quelle.luecken[nr]["original"], ersatz=z) for nr, z in sorted(start.items())],
                        bestanden=ok, laeufe=laeufe, schritte=schritte))
    pruefer.schliesse()
    return variante, aus


def zehntel(summe, n):
    return (20 * summe + n) // (2 * n) if n else 0


def vorzeichen(x, y):
    besser = sum(1 for p, q in zip(x, y) if p < q)
    schlechter = sum(1 for p, q in zip(x, y) if p > q)
    n, k = besser + schlechter, max(besser, schlechter)
    zaehler = min(1 << n, 2 * sum(comb(n, i) for i in range(k, n + 1)))
    return dict(besser=besser, schlechter=schlechter, gleich=len(x) - n, p_unter_1_promille=1000 * zaehler < (1 << n),
                p_unter_5_prozent=20 * zaehler < (1 << n))


def main():
    pfad, vektoren, analyse, ziel = sys.argv[1:5]
    zahl = int(sys.argv[5]) if len(sys.argv) > 5 else 48
    quelle = W.Quelle(pfad)
    einzeln = json.load(open(analyse, encoding="utf-8"))["einzeln"]
    liste = episoden(quelle, einzeln, zahl)
    with Pool(2) as pool:
        ergebnisse = dict(pool.map(laufe, [(v, pfad, vektoren, liste) for v in VARIANTEN], chunksize=1))
    drittel = zahl // 3
    erg = dict(episoden=zahl, budget=BUDGET, luecken=len(quelle.luecken),
               einzelaenderungen=sum(len(quelle.andere(l)) for l in quelle.luecken), varianten={})
    for v, eps in ergebnisse.items():
        schritte = [s for e in eps for s in e["schritte"]]
        je_art = {}
        for art in ("uebersetzung", "lauf"):
            teil = [s for s in schritte if (s["ausgang"] == "uebersetzung") == (art == "uebersetzung")]
            je_art[art] = dict(schritte=len(teil), platz_im_mittel_zehntel=zehntel(sum(s["platz"] for s in teil), len(teil)),
                               planlaenge_im_mittel_zehntel=zehntel(sum(s["plan"] for s in teil), len(teil)))
        erg["varianten"][v] = dict(
            bestanden=sum(1 for e in eps if e["bestanden"]),
            laeufe_je_episode_zehntel=zehntel(sum(e["laeufe"] for e in eps), len(eps)),
            laeufe_bei_1_abweichung_zehntel=zehntel(sum(e["laeufe"] for e in eps[0::2]), len(eps[0::2])),
            laeufe_bei_2_abweichungen_zehntel=zehntel(sum(e["laeufe"] for e in eps[1::2]), len(eps[1::2])),
            laeufe_erstes_drittel_zehntel=zehntel(sum(e["laeufe"] for e in eps[:drittel]), drittel),
            laeufe_letztes_drittel_zehntel=zehntel(sum(e["laeufe"] for e in eps[-drittel:]), drittel),
            platz_der_richtigen_aenderung=je_art, episoden=eps)
    erg["vorzeichentest_laeufe_ort_tafel_gegen_ort"] = vorzeichen([e["laeufe"] for e in ergebnisse["ort_tafel"]],
                                                                  [e["laeufe"] for e in ergebnisse["ort"]])
    with open(ziel, "w", encoding="utf-8") as f:
        json.dump(erg, f, indent=1, ensure_ascii=False)
    for v, e in erg["varianten"].items():
        print(v, {k: x for k, x in e.items() if k != "episoden"})
    print("gepaart", erg["vorzeichentest_laeufe_ort_tafel_gegen_ort"])


if __name__ == "__main__":
    main()
