"""Was meldet der Pruefer bei genau einer Abweichung?  Alle Ein-Zeichen-Abweichungen vom richtigen stufen.rs.

Je Luecke und je anderem Zeichen ihrer Art wird das Programm gebaut und geprueft.  Gezaehlt wird
    Ausgang      Uebersetzungsfehler | Panik (Ueberlauf, Teilung durch null) | falsches Ergebnis | Zeitueberschreitung |
                 unentdeckt (alle Vektoren bestehen)
    Ort          Trifft die Hauptstelle der ersten Compiler-Meldung das geaenderte Zeichen, seine Zeile, eine
                 Nebenstelle seine Zeile, seine Funktion, oder liegt sie daneben?  Bei Lauffehlern: Ist die erste
                 fehlschlagende Funktion die geaenderte?
    Vorschlag    Bietet der Compiler eine Ersetzung an?  Stellt sie das Original her?  Besteht das Programm danach?
Unentdeckte Abweichungen sind entweder gleichwertig (anderes Zeichen, gleiche Wirkung) oder Luecken der Vektoren.

Aufruf: python3 -I mutationsanalyse.py <stufen.rs> <vektoren.txt> <ausgabe.json> [prozesse]
"""
import json
import sys
from multiprocessing import Pool
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import werkbank as W  # noqa: E402


def ortsstufe(quelle, luecke, lage, meldung):
    """Wie nah liegt die Meldung am geaenderten Zeichen?  genau > zeile > nebenstelle > funktion > daneben"""
    zeile, von, bis = lage
    a, b = quelle.bereich[luecke["funktion"]]
    haupt = [s for s in meldung["haupt"] if s["datei"] == "stufen.rs"]
    neben = [s for s in meldung["neben"] if s["datei"] == "stufen.rs"]
    neben += [t for gruppe in meldung["vorschlaege"] for t in gruppe if t["datei"] == "stufen.rs"]
    if any(s["zeile"] <= zeile <= s["zeile_bis"] and (s["zeile"] != s["zeile_bis"] or (s["von"] < bis and von < s["bis"]))
           for s in haupt):
        return "genau"
    if any(s["zeile"] <= zeile <= s["zeile_bis"] for s in haupt):
        return "zeile"
    if any(s["zeile"] <= zeile <= s["zeile_bis"] for s in neben):
        return "nebenstelle"
    if any(a <= s["zeile"] <= b for s in haupt + neben):
        return "funktion"
    return "daneben"


def wende_an(text, gruppe):
    """Ersetzungen einer Vorschlagsgruppe anwenden (nur einzeilige Stellen in stufen.rs); sonst None."""
    if any(t["datei"] != "stufen.rs" or t["zeile"] != t["zeile_bis"] for t in gruppe):
        return None
    zeilen = text.split("\n")
    for t in sorted(gruppe, key=lambda t: (-t["zeile"], -t["von"])):
        z = zeilen[t["zeile"] - 1]
        zeilen[t["zeile"] - 1] = z[:t["von"]] + t["ersatz"] + z[t["bis"]:]
    return "\n".join(zeilen)


def arbeite(auftrag):
    pfad, vektoren, nummern = auftrag
    quelle = W.Quelle(pfad)
    referenz = "\n".join(quelle.zeilen)
    pruefer = W.Pruefer(vektoren)
    aus = []
    for nr in nummern:
        luecke = quelle.luecken[nr]
        for zeichen in quelle.andere(luecke):
            wahl = {nr: zeichen}
            text = quelle.baue(wahl)
            r = pruefer.pruefe(text)
            e = dict(luecke=nr, art_der_luecke=luecke["art"], funktion=luecke["funktion"], zeile=luecke["zeile"],
                     original=luecke["original"], ersatz=zeichen, ausgang=r["art"], klasse=r["klasse"],
                     warnungen=r.get("warnungen", []))
            if r["art"] == "uebersetzung":
                erste = r["fehler"][0]
                lage = quelle.lage(wahl)[nr]
                e["fehlerzahl"] = len(r["fehler"])
                e["ort"] = ortsstufe(quelle, luecke, lage, erste)
                e["text"] = erste["text"]
                gruppen = [g for f in r["fehler"] for g in f["vorschlaege"]]
                e["vorschlag"] = "keiner"
                for g in gruppen:
                    neu = wende_an(text, g)
                    if neu is None:
                        continue
                    if neu == referenz:
                        e["vorschlag"] = "original"
                        break
                    if pruefer.pruefe(neu)["art"] == "bestanden":
                        e["vorschlag"] = "besteht"
                    elif e["vorschlag"] == "keiner":
                        e["vorschlag"] = "hilft_nicht"
            elif r["art"] in ("falsch", "panik"):
                namen = [f["name"] for f in r["funktionen"]]
                pruefname = luecke["funktion"]
                e["erste_funktion"] = namen[0] if namen else None
                e["erste_ist_ursache"] = bool(namen) and namen[0] == pruefname
                e["ursache_dabei"] = pruefname in namen
                e["funktionen"] = len(namen)
            aus.append(e)
    pruefer.schliesse()
    return aus


def anteil(z, n):
    return (2000 * z + n) // (2 * n) if n else 0


def main():
    pfad, vektoren, ziel = sys.argv[1], sys.argv[2], sys.argv[3]
    prozesse = int(sys.argv[4]) if len(sys.argv) > 4 else 2
    quelle = W.Quelle(pfad)
    n = len(quelle.luecken)
    teile = [(pfad, vektoren, list(range(i, n, prozesse * 4))) for i in range(prozesse * 4)]
    with Pool(prozesse) as pool:
        alle = sorted((e for teil in pool.map(arbeite, teile, chunksize=1) for e in teil), key=lambda e: (e["luecke"], e["ersatz"]))

    def zaehle(liste, schluessel):
        z = {}
        for e in liste:
            k = schluessel(e)
            z[k] = z.get(k, 0) + 1
        return dict(sorted(z.items(), key=lambda kv: (-kv[1], str(kv[0]))))

    ueb = [e for e in alle if e["ausgang"] == "uebersetzung"]
    lauf = [e for e in alle if e["ausgang"] in ("falsch", "panik")]
    arten = sorted({e["art_der_luecke"] for e in alle})
    erg = dict(
        luecken=n, luecken_je_art=zaehle(quelle.luecken, lambda l: l["art"]), abweichungen=len(alle),
        ausgang=zaehle(alle, lambda e: e["ausgang"]),
        ausgang_promille={k: anteil(v, len(alle)) for k, v in zaehle(alle, lambda e: e["ausgang"]).items()},
        ausgang_je_art={a: zaehle([e for e in alle if e["art_der_luecke"] == a], lambda e: e["ausgang"]) for a in arten},
        klassen=zaehle(alle, lambda e: e["klasse"]),
        uebersetzung=dict(zahl=len(ueb), ort=zaehle(ueb, lambda e: e["ort"]),
                          ort_promille={k: anteil(v, len(ueb)) for k, v in zaehle(ueb, lambda e: e["ort"]).items()},
                          vorschlag=zaehle(ueb, lambda e: e["vorschlag"]),
                          vorschlag_je_klasse={k: zaehle([e for e in ueb if e["klasse"] == k], lambda e: e["vorschlag"])
                                               for k in zaehle(ueb, lambda e: e["klasse"])}),
        lauf=dict(zahl=len(lauf), erste_ist_ursache=sum(1 for e in lauf if e["erste_ist_ursache"]),
                  ursache_dabei=sum(1 for e in lauf if e["ursache_dabei"]),
                  funktionen_im_mittel_zehntel=(20 * sum(e["funktionen"] for e in lauf) + len(lauf)) // (2 * len(lauf)) if lauf else 0),
        warnungen_bei_unentdeckten=zaehle([e for e in alle if e["ausgang"] == "bestanden"], lambda e: ",".join(e["warnungen"]) or "-"),
        unentdeckt=[dict(funktion=e["funktion"], zeile=e["zeile"], art=e["art_der_luecke"], original=e["original"],
                         ersatz=e["ersatz"], warnungen=e["warnungen"]) for e in alle if e["ausgang"] == "bestanden"],
        zeit=[dict(funktion=e["funktion"], zeile=e["zeile"], original=e["original"], ersatz=e["ersatz"]) for e in alle if e["ausgang"] == "zeit"],
        einzeln=alle)
    with open(ziel, "w", encoding="utf-8") as f:
        json.dump(erg, f, indent=1, ensure_ascii=False)
    for k in ("luecken", "luecken_je_art", "abweichungen", "ausgang", "ausgang_promille", "klassen"):
        print(k, erg[k])
    for a in arten:
        print("  ", a, erg["ausgang_je_art"][a])
    print("uebersetzung", {k: v for k, v in erg["uebersetzung"].items() if k != "vorschlag_je_klasse"})
    for k, v in erg["uebersetzung"]["vorschlag_je_klasse"].items():
        print("   ", k, v)
    print("lauf", erg["lauf"])
    print("unentdeckt", len(erg["unentdeckt"]), "zeit", len(erg["zeit"]))
    for e in erg["unentdeckt"]:
        print("   ", e)


if __name__ == "__main__":
    main()
