"""Gipfelaufgaben: geschriebene Funktionen zu groesseren Programmen zusammensetzen.  Nur ganze Zahlen.

Bausteine  bruch, mal, vergleiche, entscheide in der Fassung, die synthese.py geschrieben hat; plus von Hand (stufen.py).
Aufgaben   in Folge, jede bildet Brueche (z_i, n_i) mit 1 <= z_i <= n_i < 2^16 auf ein Urteil (Vorzeichen, Ebene) ab:
           vorstufe  z1/n1 gegen z2/n2
           gipfel_1  z1/n1 * z2/n2 gegen z3/n3
           gipfel_2  z1/n1 * z2/n2 + z3/n3 * z4/n4 gegen z5/n5
Typen      U Zahl, F Rundung (ab, auf), S Stufenzahl, E Urteil.
           bruch(U, U, F) -> S   mal(S, S, F) -> S   plus(S, S, F) -> S   vergleiche(S, S) -> E   entscheide(S, S, S, S) -> E
Fasern     Eine Faser ist eine logische Datenkette ueber einem Fusspunkt (der Eingabe): Glied fuer Glied wird ein Wert
           aus dem vorigen gerechnet (bruch -> mal -> plus).  Jede Faser laeuft in zwei Fassungen, abgerundet und
           aufgerundet; das Paar ist die Klammer um den wahren Wert (zwei Erklaerungen).  Ein Urteil vereinigt die
           Enden zweier Faserpaare.
Suche      blind   alle typrichtigen Aufrufbaeume, kleine zuerst.  Ungueltige (bruch mit z > n auf einem Beispiel) und
                   wertgleiche Stufenausdruecke fallen weg.  Ausgefuehrt nur bis GRENZE_BLIND Kandidaten, sonst gezaehlt.
           Maske   Aus der blind gefundenen Loesung der Vorstufe wird die Maske gelesen: Argumente, die bis auf die
                   Rundung gleich sind, teilen sich einen Platz.  In den Gipfelaufgaben werden die Plaetze mit
                   Stufenausdruecken einheitlicher Rundung gefuellt, Ebene fuer Ebene.
Eindeutig  Erklaeren mehrere Kandidaten alle Beispiele, entscheidet eine Rueckfrage an den Lehrer (Eingabe, auf der
           zwei Kandidaten verschieden antworten).  Danach prueft der Lehrer den Kandidaten auf breiten Eingaben.
Pruefung   Die gefundenen Programme werden als Rust an den geschriebenen Kern gehaengt, uebersetzt und auf frischen
           Vektoren geprueft.

Aufruf: python3 -I gipfel.py <stufen.rs> <vektoren.txt> <ausgabe.json> <stufen_gipfel.rs>
"""
import json
import subprocess
import sys
import tempfile
import time
from math import gcd
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bereich as BR  # noqa: E402
import synthese as SY  # noqa: E402

S = BR.S
GRENZE_BLIND = 300000
PROBEN = 3000
BREIT = 5000
START = 40
VEKTOREN = 3000


# ---------------------------------------------------------------- Bereiche und Lehrer
def paar(z):
    n = 1 + BR.bis(z, 65535)
    return (1 + z.unter(n), n)


def nachbarn(z):
    """Zwei Brueche a/b < c/d mit c*b - a*d = 1 und Nennern ueber BASIS: Abstand 1/(b*d), unter einer Einheit der Leiter."""
    while True:
        b = BR.B + 1 + z.unter(65535 - BR.B)
        d = BR.B + 1 + z.unter(65535 - BR.B)
        if b != d and gcd(b, d) == 1:
            a = (b - pow(d, -1, b)) % b
            c = (1 + a * d) // b
            if 1 <= a and 1 <= c <= d:
                return (a, b, c, d)


def e_vorstufe(z):
    art = z.unter(6)
    if art == 0:                                           # gleicher Wert, verschieden erweitert
        n = 1 + z.unter(250)
        zz = 1 + z.unter(n)
        f, g = 1 + z.unter(65535 // n), 1 + z.unter(65535 // n)
        return (zz * f, n * f, zz * g, n * g)
    if art == 1:
        a, b, c, d = nachbarn(z)
        return (a, b, c, d) if z.unter(2) else (c, d, a, b)
    if art == 2:                                           # gleicher Nenner, Zaehler um hoechstens 1 verschieden
        zz, n = paar(z)
        return (zz, n, max(1, min(n, zz + z.unter(3) - 1)), n)
    return paar(z) + paar(z)


def e_gipfel_1(z):
    art = z.unter(5)
    if art <= 1:                                           # kleine Nenner: das Produkt ist als Bruch darstellbar
        n1, n2 = 1 + z.unter(255), 1 + z.unter(255)
        z1, z2 = 1 + z.unter(n1), 1 + z.unter(n2)
        z3, n3 = z1 * z2, n1 * n2
        if art == 1:
            z3 = max(1, min(n3, z3 + z.unter(3) - 1))
        return (z1, n1, z2, n2, z3, n3)
    if art == 2:                                           # grosse Nenner, dritter Bruch dicht am Produkt
        (z1, n1), (z2, n2) = paar(z), paar(z)
        n3 = 1 + BR.bis(z, 65535)
        z3 = max(1, min(n3, z1 * z2 * n3 // (n1 * n2) + z.unter(3) - 1))
        return (z1, n1, z2, n2, z3, n3)
    return paar(z) + paar(z) + paar(z)


def e_gipfel_2(z):
    art = z.unter(5)
    if art <= 1:                                           # kleine Nenner: die Summe ist als Bruch darstellbar
        n = [1 + z.unter(15) for _ in range(4)]
        zz = [1 + z.unter(x) for x in n]
        n5 = n[0] * n[1] * n[2] * n[3]
        z5 = zz[0] * zz[1] * n[2] * n[3] + zz[2] * zz[3] * n[0] * n[1]
        if art == 1:
            z5 += z.unter(3) - 1
        return (zz[0], n[0], zz[1], n[1], zz[2], n[2], zz[3], n[3], max(1, min(n5, z5)), n5)
    if art == 2:                                           # grosse Nenner, fuenfter Bruch dicht an der Summe
        b = [paar(z) for _ in range(4)]
        n5 = 1 + BR.bis(z, 65535)
        nenner = b[0][1] * b[1][1] * b[2][1] * b[3][1]
        summe = b[0][0] * b[1][0] * b[2][1] * b[3][1] + b[2][0] * b[3][0] * b[0][1] * b[1][1]
        z5 = max(1, min(n5, summe * n5 // nenner + z.unter(3) - 1))
        return b[0] + b[1] + b[2] + b[3] + (z5, n5)
    return paar(z) + paar(z) + paar(z) + paar(z) + paar(z)


def klammer(z, n):
    return S.bruch(z, n), S.bruch(z, n, True)


def urteil(r):
    return (r[0], BR.EBENE[r[1]])


def l_vorstufe(e):
    a, b = klammer(e[0], e[1]), klammer(e[2], e[3])
    return urteil(S.entscheide(a[0], a[1], b[0], b[1]))


def l_gipfel_1(e):
    a, b, c = klammer(e[0], e[1]), klammer(e[2], e[3]), klammer(e[4], e[5])
    return urteil(S.entscheide(S.mal(a[0], b[0]), S.mal(a[1], b[1], True), c[0], c[1]))


def l_gipfel_2(e):
    a, b, c, d, f = (klammer(e[2 * i], e[2 * i + 1]) for i in range(5))
    unten = S.plus(S.mal(a[0], b[0]), S.mal(c[0], d[0]))
    oben = S.plus(S.mal(a[1], b[1], True), S.mal(c[1], d[1], True), True)
    return urteil(S.entscheide(unten, oben, f[0], f[1]))


AUFGABEN = [
    dict(name="vorstufe", eingaben=4, eingabe=e_vorstufe, lehrer=l_vorstufe, text="z1/n1 gegen z2/n2"),
    dict(name="gipfel_1", eingaben=6, eingabe=e_gipfel_1, lehrer=l_gipfel_1, text="z1/n1 * z2/n2 gegen z3/n3"),
    dict(name="gipfel_2", eingaben=10, eingabe=e_gipfel_2, lehrer=l_gipfel_2,
         text="z1/n1 * z2/n2 + z3/n3 * z4/n4 gegen z5/n5"),
]


# ---------------------------------------------------------------- Bausteine als Rechner
class Faul:
    """Merkmale von entscheide (Ergebnisse der zwoelf Aufrufe von vergleiche), erst bei Bedarf gerechnet."""
    def __init__(self, ein, vergleiche):
        self.ein, self.vergleiche, self.merk = ein, vergleiche, {}

    def __getitem__(self, i):
        q = i // 2
        if q not in self.merk:
            a, b = SY.PAARE[q]
            self.merk[q] = self.vergleiche(self.ein[3 * a:3 * a + 3] + self.ein[3 * b:3 * b + 3])
        return self.merk[q][i % 2]


def bausteine(koennen):
    baum, preds, terme = koennen["entscheide_teile"]
    vergleiche = koennen["vergleiche"]
    return {
        "bruch": lambda z, n, f: koennen["bruch"]((z, n, f)) if 1 <= z <= n < 65536 else None,
        "mal": lambda a, b, f: koennen["mal"](a + b + (f,)),
        "plus": lambda a, b, f: tuple(S.plus(a, b, bool(f))),
        "vergleiche": lambda a, b: vergleiche(a + b),
        "entscheide": lambda a, ao, b, bo: SY.baum_wert(baum, Faul(a + ao + b + bo, vergleiche), preds, terme),
    }


# ---------------------------------------------------------------- Ausdruecke: ("u", i), ("f", 0|1), ("phi",), (Name, Argumente ...)
def wert(x, ein, phi, K):
    if x[0] == "u":
        return ein[x[1]]
    if x[0] == "f":
        return x[1]
    if x[0] == "phi":
        return phi
    args = [wert(a, ein, phi, K) for a in x[1:]]
    return None if any(a is None for a in args) else K[x[0]](*args)


def setze_phi(x, f):
    if x[0] == "phi":
        return ("f", f)
    return x if x[0] in ("u", "f") else (x[0],) + tuple(setze_phi(a, f) for a in x[1:])


def text_rs(x, namen):
    if x[0] == "u":
        return namen[x[1]]
    if x[0] == "f":
        return "true" if x[1] else "false"
    return x[0] + "(" + ", ".join(text_rs(a, namen) for a in x[1:]) + ")"


def aufrufe(x):
    return 0 if x[0] in ("u", "f", "phi") else 1 + sum(aufrufe(a) for a in x[1:])


def ebenen(x):
    return 0 if x[0] in ("u", "f", "phi") else 1 + max(ebenen(a) for a in x[1:])


def geruest(x):
    """Ausdruck mit Rundungsvariable statt fester Rundung; dazu die Menge der vorgefundenen Rundungen."""
    if x[0] == "f":
        return ("phi",), {x[1]}
    if x[0] in ("u", "phi"):
        return x, set()
    teile = [geruest(a) for a in x[1:]]
    return (x[0],) + tuple(t[0] for t in teile), set().union(*[t[1] for t in teile])


def maske_aus(x):
    """Maske einer Loesung: Kopf und je Argument (Platz, Rundung).  Argumente mit gleichem Geruest teilen einen Platz."""
    plaetze, maske = [], []
    for a in x[1:]:
        g, rundung = geruest(a)
        if len(rundung) != 1:
            return None
        if g not in plaetze:
            plaetze.append(g)
        maske.append((plaetze.index(g), next(iter(rundung))))
    return (x[0], tuple(maske))


# ---------------------------------------------------------------- Vorraete von Stufenausdruecken
def vorrat_frei(beispiele, n_ein, K):
    """Ebene 1 mit freier Rundung: gueltige bruch(u_i, u_j, f).  Eintrag: (Ausdruck, Werte je Beispiel).
    beispiele: Liste der Eingaben."""
    gesehen, aus = set(), []
    for i in range(n_ein):
        for j in range(n_ein):
            for f in (0, 1):
                if i != j:
                    v = tuple(K["bruch"](b[i], b[j], f) for b in beispiele)
                    if None not in v and v not in gesehen:
                        gesehen.add(v)
                        aus.append((("bruch", ("u", i), ("u", j), ("f", f)), v))
    return aus


def vorrat_einheitlich(beispiele, n_ein, K, bis_ebene):
    """Fasern: Stufenausdruecke mit einheitlicher Rundung phi, Ebene fuer Ebene.  Jede Faser ist eine Datenkette
    bruch -> mal/plus -> ... und laeuft in zwei Fassungen (ab, auf).  Eintrag: (Ausdruck, (Werte ab, Werte auf)).
    beispiele: Liste der Eingaben."""
    gesehen, erste = set(), []
    for i in range(n_ein):
        for j in range(n_ein):
            if i != j:
                v0 = tuple(K["bruch"](b[i], b[j], 0) for b in beispiele)
                if None in v0:
                    continue
                v = (v0, tuple(K["bruch"](b[i], b[j], 1) for b in beispiele))
                if v not in gesehen:
                    gesehen.add(v)
                    erste.append((("bruch", ("u", i), ("u", j), ("phi",)), v))
    alle = [erste]
    for _ in range(2, bis_ebene + 1):
        alt = [e for eb in alle for e in eb]
        ab = len(alt) - len(alle[-1])                       # ab hier liegt die letzte Ebene
        neu = []
        for p, a in enumerate(alt):
            for q in range(max(p, 0), len(alt)):
                if p < ab and q < ab:
                    continue
                b = alt[q]
                for name in ("mal", "plus"):
                    v = tuple(tuple(K[name](x, y, f) for x, y in zip(a[1][f], b[1][f])) for f in (0, 1))
                    if v not in gesehen:
                        gesehen.add(v)
                        neu.append(((name, a[0], b[0], ("phi",)), v))
        alle.append(neu)
    return alle


def blind_gezaehlt(gueltig, bis_ebene):
    """Zahl der typrichtigen Kandidaten ohne Maske, gezaehlt ohne Wertgleiche zu entfernen.
    gueltig = Zahl der gueltigen Paare (z, n) auf Ebene 1."""
    vorrat = letzte = 2 * gueltig
    for _ in range(2, bis_ebene + 1):
        paare = vorrat * (vorrat + 1) // 2 - (vorrat - letzte) * (vorrat - letzte + 1) // 2
        letzte = paare * 2 * 2
        vorrat += letzte
    return vorrat ** 4 + vorrat ** 2


# ---------------------------------------------------------------- Suche
def suche_blind(beispiele, n_ein, K, z):
    """Alle Urteile ueber Stufenausdruecke der Ebene 1 mit freier Rundung.  Rueckgabe: stimmige Ausdruecke."""
    vor = vorrat_frei([ein for ein, _ in beispiele], n_ein, K)
    soll = [aus for _, aus in beispiele]
    treffer = []
    idx = range(len(vor))
    for a in idx:
        for b in idx:
            z["blind_geprueft"] += 1
            if all(K["vergleiche"](vor[a][1][e], vor[b][1][e]) == soll[e] for e in range(len(soll))):
                treffer.append(("vergleiche", vor[a][0], vor[b][0]))
    for a in idx:
        for b in idx:
            for c in idx:
                for d in idx:
                    z["blind_geprueft"] += 1
                    if all(K["entscheide"](vor[a][1][e], vor[b][1][e], vor[c][1][e], vor[d][1][e]) == soll[e]
                           for e in range(len(soll))):
                        treffer.append(("entscheide", vor[a][0], vor[b][0], vor[c][0], vor[d][0]))
    return treffer


def suche_maske(beispiele, n_ein, K, maske, z, hoechste_ebene=3):
    """Plaetze der Maske mit Stufenausdruecken einheitlicher Rundung fuellen; erst Ebene 1, dann 2, dann 3."""
    kopf, stellen = maske
    soll = [aus for _, aus in beispiele]
    n = len(soll)
    assert max(p for p, _ in stellen) == 1                 # zwei Plaetze
    for ebene in range(1, hoechste_ebene + 1):
        alle = vorrat_einheitlich([ein for ein, _ in beispiele], n_ein, K, ebene)
        vor = [e for eb in alle for e in eb]
        z["vorrat_je_ebene"] = [len(eb) for eb in alle]
        treffer = []
        neu_ab = len(vor) - len(alle[-1])
        f = K[kopf]
        for p, x in enumerate(vor):
            for q, y in enumerate(vor):
                if p < neu_ab and q < neu_ab:                # schon auf der Ebene davor geprueft
                    continue
                z["fuellungen"] += 1
                platz = (x[1], y[1])
                for e in range(n):
                    if f(*[platz[pl][fl][e] for pl, fl in stellen]) != soll[e]:
                        break
                else:
                    wahl = (x[0], y[0])
                    treffer.append((kopf,) + tuple(setze_phi(wahl[pl], fl) for pl, fl in stellen))
        if treffer:
            z["ebene"] = ebene
            return treffer
    return []


def loese(aufgabe, K, maske, zufall):
    """Rueckgabe: (Ausdruck oder None, Zaehler)."""
    n_ein, eingabe, lehrer = aufgabe["eingaben"], aufgabe["eingabe"], aufgabe["lehrer"]
    beispiele = []
    while len(beispiele) < START:
        ein = eingabe(zufall)
        beispiele.append((ein, lehrer(ein)))
    z = dict(blind_geprueft=0, fuellungen=0, rueckfragen=0, lehrer_gegenbeispiele=0, runden=0, weg="Maske" if maske else "blind")
    for _ in range(8):
        z["runden"] += 1
        kandidaten = suche_maske(beispiele, n_ein, K, maske, z) if maske else suche_blind(beispiele, n_ein, K, z)
        z["stimmige_kandidaten_nach_beispielen"] = len(kandidaten)
        if not kandidaten:
            return None, z
        while len(kandidaten) > 1:                          # zwei Erklaerungen: Rueckfrage
            frage = None
            for _ in range(PROBEN):
                ein = eingabe(zufall)
                w = wert(kandidaten[0], ein, None, K)
                if any(wert(k, ein, None, K) != w for k in kandidaten[1:]):
                    frage = ein
                    break
            if frage is None:
                break
            z["rueckfragen"] += 1
            antwort = lehrer(frage)
            beispiele.append((frage, antwort))
            kandidaten = [k for k in kandidaten if wert(k, frage, None, K) == antwort]
            if not kandidaten:
                break
        if not kandidaten:
            continue
        gegen = None
        for _ in range(PROBEN):                             # Lehrerprobe
            ein = eingabe(zufall)
            if wert(kandidaten[0], ein, None, K) != lehrer(ein):
                gegen = ein
                break
        if gegen is None:
            z["beispiele"] = len(beispiele)
            z["gleichwertige_kandidaten"] = len(kandidaten)
            return kandidaten[0], z
        z["lehrer_gegenbeispiele"] += 1
        beispiele.append((gegen, lehrer(gegen)))
    return None, z


# ---------------------------------------------------------------- Rust
STAND = '''mod stufen;
use std::io::BufRead;

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let datei = std::fs::File::open(&args[1]).unwrap();
    let mut faelle: u64 = 0;
    let mut falsch: u64 = 0;
    for zeile in std::io::BufReader::new(datei).lines() {
        let zeile = zeile.unwrap();
        if zeile.starts_with('#') || zeile.trim().is_empty() {
            continue;
        }
        let teile: Vec<&str> = zeile.split('|').collect();
        let links: Vec<&str> = teile[0].split_whitespace().collect();
        let e: Vec<u64> = links[1..].iter().map(|x| x.parse().unwrap()).collect();
        let soll: Vec<i64> = teile[1].split_whitespace().map(|x| x.parse().unwrap()).collect();
        let ist: (i32, u8) = match links[0] {
ARME
            _ => panic!("unbekannte Funktion"),
        };
        faelle += 1;
        if (ist.0 as i64, ist.1 as i64) != (soll[0], soll[1]) {
            falsch += 1;
        }
    }
    println!("FAELLE {} FALSCH {}", faelle, falsch);
}
'''


def pruefe_rust(kern, loesungen, ziel_rs):
    """Programme an den Kern haengen, uebersetzen, auf frischen Vektoren pruefen."""
    zusatz, arme, zeilen = [], [], []
    zufall = BR.Zufall(31337)
    for aufgabe, ausdruck in loesungen:
        n = aufgabe["eingaben"]
        namen = [("z%d" if i % 2 == 0 else "n%d") % (i // 2 + 1) for i in range(n)]
        zusatz += ["", "pub fn %s(%s) -> (i32, u8) {" % (aufgabe["name"], ", ".join(x + ": u64" for x in namen)),
                   "    " + text_rs(ausdruck, namen), "}"]
        arme.append('            "%s" => stufen::%s(%s),' % (aufgabe["name"], aufgabe["name"],
                                                             ", ".join("e[%d]" % i for i in range(n))))
        for _ in range(VEKTOREN):
            ein = aufgabe["eingabe"](zufall)
            zeilen.append("%s %s | %s" % (aufgabe["name"], " ".join(str(x) for x in ein),
                                          " ".join(str(x) for x in aufgabe["lehrer"](ein))))
    quelltext = kern.rstrip("\n") + "\n" + "\n".join(zusatz) + "\n"
    Path(ziel_rs).write_text(quelltext, encoding="utf-8")
    ordner = Path(tempfile.mkdtemp(prefix="gipfel_"))
    ordner.joinpath("stufen.rs").write_text(quelltext, encoding="utf-8")
    ordner.joinpath("gipfelstand.rs").write_text(STAND.replace("ARME", "\n".join(arme)), encoding="utf-8")
    ordner.joinpath("vektoren.txt").write_text("\n".join(zeilen) + "\n", encoding="utf-8")
    bau = subprocess.run(["rustc", "--edition", "2021", "-C", "overflow-checks=on", "-o", "gipfelstand", "gipfelstand.rs"],
                         cwd=ordner, capture_output=True, text=True, timeout=600)
    if bau.returncode != 0:
        return dict(ausgang="uebersetzung", meldung=bau.stderr[-800:])
    lauf = subprocess.run([str(ordner.joinpath("gipfelstand")), "vektoren.txt"], cwd=ordner, capture_output=True, text=True,
                          timeout=600)
    if lauf.returncode != 0:
        return dict(ausgang="panik", meldung=lauf.stderr[-800:])
    t = lauf.stdout.split()
    return dict(ausgang="bestanden" if t[3] == "0" else "falsch", faelle=int(t[1]), falsch=int(t[3]))


def ms():
    return time.monotonic_ns() // 1000000


def main():
    pfad_rs, pfad_vek, ziel, ziel_rs = sys.argv[1:5]
    vek = SY.lies_vektoren(pfad_vek)
    koennen = {}
    _, ruempfe = SY.loese_alles(vek, "lehrer", koennen=koennen)
    K = bausteine(koennen)
    kern = SY.setze_ein(pfad_rs, ruempfe)
    zufall = BR.Zufall(20261118)
    erg, loesungen, maske = {}, [], None
    for aufgabe in AUFGABEN:
        t0 = ms()
        ausdruck, z = loese(aufgabe, K, maske, zufall)
        e = dict(aufgabe=aufgabe["text"], geloest=ausdruck is not None, aufwand=z, millisekunden=ms() - t0)
        if ausdruck is not None:
            namen = [("z%d" if i % 2 == 0 else "n%d") % (i // 2 + 1) for i in range(aufgabe["eingaben"])]
            e["programm"] = text_rs(ausdruck, namen)
            e["aufrufe"] = aufrufe(ausdruck)
            e["ebenen"] = ebenen(ausdruck)
            probe, falsch = BR.Zufall(99), 0
            for _ in range(BREIT):
                ein = aufgabe["eingabe"](probe)
                falsch += wert(ausdruck, ein, None, K) != aufgabe["lehrer"](ein)
            e["abweichungen_breitprobe"] = falsch
            gueltig = aufgabe["eingaben"] // 2
            e["blind_gezaehlt"] = blind_gezaehlt(gueltig, ebenen(ausdruck) - 1)
            loesungen.append((aufgabe, ausdruck))
            if maske is None:
                maske = maske_aus(ausdruck)
                e["maske"] = dict(kopf=maske[0], stellen=[list(s) for s in maske[1]]) if maske else None
        erg[aufgabe["name"]] = e
        print(aufgabe["name"], {k: v for k, v in e.items()}, flush=True)
    erg["pruefung"] = pruefe_rust(kern, loesungen, ziel_rs)
    print("Pruefung", erg["pruefung"], flush=True)
    with open(ziel, "w", encoding="utf-8") as f:
        json.dump(erg, f, indent=1, ensure_ascii=False)


if __name__ == "__main__":
    main()
