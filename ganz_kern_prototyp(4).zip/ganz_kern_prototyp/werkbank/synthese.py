"""Synthese: Kernfunktionen aus Beispielen schreiben und vom Compiler pruefen lassen.  Nur ganze Zahlen.

Gegeben   je Funktion die Schnittstelle (Kopfzeile aus stufen.rs), die benannten Konstanten, Beispiele aus vektoren.txt
          und der Bereich der Eingaben (bereich.py).  Der Rumpf wird gesucht.
Sprossen  Ausdruck     kleinsten Ausdruck finden, der alle Beispiele trifft.  Aufgezaehlt wird nach Groesse; Ausdruecke
                       mit gleichen Werten auf allen Beispielen gelten als einer (Beobachtungsgleichheit).  Gerechnet wird
                       wie in Rust mit Ueberlaufpruefung: Ueberlauf, negatives Ergebnis oder Teilung durch null macht
                       einen Ausdruck ungueltig.
          Rueckwaerts  Ziel zerlegen: Ziel = e + X  ->  X = Ziel - e;  Ziel = e * X  ->  X = Ziel / e, wenn es aufgeht;
                       Ziel = X - e  ->  X = Ziel + e;  Ziel = e - X  ->  X = e - Ziel.  Hoechstens zwei Schritte.
          Schablone    Geloeste Ausdruecke kommen mit Platzhaltern statt Blaettern in die Bibliothek und werden bei
                       neuen Aufgaben mit allen Belegungen versucht.
          Folge        Die Ausgabe ist eine Folge: Schrittfunktion aus aufeinanderfolgenden Gliedern suchen; das
                       Schleifenschema ist fest.
          Liste        Fallunterscheidung als kuerzeste Entscheidungsliste: Frage, Antwort, sonst naechste Frage.
                       Gesucht wird die Liste mit den wenigsten Fragen (Tiefe 1, 2, 3 ...); jede Antwort ist je
                       Ausgabestelle ein Term, der alle Beispiele ihres Falls trifft.
          Baum         Ersatz, wenn keine kurze Liste existiert: den groessten gemeinsamen Treffer waehlen, mit der
                       besten Bedingung abtrennen, wiederholen.  Guete einer Bedingung = Reinheit der beiden Teile,
                       ganzzahlig ueber Kreuzprodukte.  Aus mehreren Wurzeln wird der kleinste Baum genommen.
          Aufruf       Geloeste Funktionen stehen spaeteren als Bausteine bereit (entscheide ruft vergleiche).
          Faelle mit Rechnung  Typregel: Ein Wert vom Typ Stufe (k, m, r) wird als (k, D) mit D = m * BASIS + r
                       gefuehrt (zwei Skalen), bei Eingaben wie bei der Ausgabe.  Erst Terme fuer D schuerfen: wenige
                       Ausdruecke, die zusammen alle Beispiele treffen (auch Term + 1).  Dann sind die Zwischenwerte
                       der Terme und die Reste ihrer Teilungen die Merkmale fuer Liste oder Baum (bruch, mal).
Zwei Erklaerungen  Zu jeder Aufgabe werden mehrere Programme gehalten, die alle Beispiele erklaeren.  Solange zwei davon
          auf einer Eingabe des Bereichs verschieden rechnen, ist die Aufgabe nicht eindeutig bestimmt: Die Eingabe geht
          als Rueckfrage an den Lehrer (Python-Referenz), seine Antwort wird ein neues Beispiel.  Danach prueft der Lehrer
          die erste Erklaerung auf breiten Zufallseingaben und liefert Gegenbeispiele.
          Fassung "naiv": nur die Beispiele, ohne Rueckfragen und ohne Lehrerprobe.
Pruefung  Die gefundenen Ruempfe werden in stufen.rs eingesetzt, mit rustc uebersetzt und vom Pruefstand auf drei
          Vektorsaetzen geprueft: vektoren.txt, ein zweiter Satz mit anderem Samen, ein Breitsatz aus bereich.py.
Gegenproben  nur Aufzaehlen gegen Rueckwaertsrechnen (aus_resten, zurueck); Fallunterscheidung Frage fuer Frage gegen
          kuerzeste Liste (vergleiche, entscheide); bruch mit weiterem Bereich (Nenner bis 120000).
Von Hand bleiben plus und unter_22_5.

Aufruf: python3 -I synthese.py <stufen.rs> <vektoren.txt> <ausgabe.json> <stufen_synthese.rs>
"""
import functools
import itertools
import json
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import bereich as BR  # noqa: E402
import vektoren as V  # noqa: E402
import werkbank as W  # noqa: E402

W64 = (1 << 64) - 1
KONST = [("1", 1), ("2", 2), ("KLASSEN", 13), ("FEIN", 4096), ("BASIS", 53248), ("PROBE", 53247), ("QUADRAT", 53248 * 53248)]
MAX_GROESSE = 7
GRENZE = 3000000
ALT = 6                 # gemerkte Erklaerungen je Wertetupel
HALTEN = 3              # Erklaerungen, die je Ausgabestelle behalten werden
PROBEN = 3000           # breite Zufallseingaben je Runde
BREIT = 20000           # Schlussprobe je Funktion
WURZELN = 4             # Baumvarianten mit erzwungener Wurzel
ZWEITER_SAMEN = 777001


# ---------------------------------------------------------------- Rechnen auf Wertetupeln (ein Wert je Beispiel)
def v_plus(a, b):
    r = tuple([x + y for x, y in zip(a, b)])
    return r if max(r) <= W64 else None


def v_minus(a, b):
    r = tuple([x - y for x, y in zip(a, b)])
    return r if min(r) >= 0 else None


def v_mal(a, b):
    r = tuple([x * y for x, y in zip(a, b)])
    return r if max(r) <= W64 else None


def v_durch(a, b):
    return None if 0 in b else tuple([x // y for x, y in zip(a, b)])


def v_rest(a, b):
    return None if 0 in b else tuple([x % y for x, y in zip(a, b)])


OPS = (("+", v_plus, True), ("-", v_minus, False), ("*", v_mal, True), ("/", v_durch, False), ("%", v_rest, False))
OP = {s: f for s, f, _ in OPS}
RANG = {"+": 1, "-": 1, "*": 2, "/": 2, "%": 2}


def rechne(b, ein):
    """Ein Baum auf einer Eingabe; None, wenn Rust hier abbraeche."""
    if b[0] == "v":
        return ein[b[1]]
    if b[0] == "c":
        return b[2]
    links, rechts = rechne(b[2], ein), rechne(b[3], ein)
    if links is None or rechts is None:
        return None
    if b[1] == "+":
        return links + rechts if links + rechts <= W64 else None
    if b[1] == "-":
        return links - rechts if links >= rechts else None
    if b[1] == "*":
        return links * rechts if links * rechts <= W64 else None
    if rechts == 0:
        return None
    return links // rechts if b[1] == "/" else links % rechts


def text(b):
    if b[0] == "v":
        return b[2]
    if b[0] == "c":
        return b[1]
    if b[0] == "p":
        return "p%d" % b[1]
    links, rechts = text(b[2]), text(b[3])
    if b[2][0] == "o" and RANG[b[2][1]] < RANG[b[1]]:
        links = "(" + links + ")"
    if b[3][0] == "o" and RANG[b[3][1]] <= RANG[b[1]]:
        rechts = "(" + rechts + ")"
    return links + " " + b[1] + " " + rechts


def groesse(b):
    return 1 if b[0] != "o" else 1 + groesse(b[2]) + groesse(b[3])


# ---------------------------------------------------------------- Vorrat: alle verschiedenen Ausdruecke bis zu einer Groesse
class Vorrat:
    def __init__(self, blaetter):
        self.wert = {}                        # Wertetupel -> kleinster Baum (Groessen unter der obersten)
        self.anders = {}                      # Streuwert des Wertetupels -> bis zu ALT Baeume mit diesen Werten
        self.nach_groesse = {1: []}
        self.erzeugt = 0
        self.groesse = 1
        for baum, w in blaetter:
            self.anders.setdefault(hash(w), []).append(baum)
            if w not in self.wert:
                self.wert[w] = baum
                self.nach_groesse[1].append((baum, w))
        self.je_groesse = {1: dict(erzeugt=len(blaetter), verschieden_bis_hier=len(self.anders))}

    def verschieden(self):
        return len(self.anders)

    def erklaerungen(self, ziel, beispiele):
        """Alle gemerkten Baeume, die auf den Beispielen genau das Ziel ergeben."""
        return [t for t in self.anders.get(hash(ziel), []) if tuple(rechne(t, e) for e in beispiele) == ziel]

    def wachse(self, oberste):
        """Naechste Groesse bauen.  oberste=True: Werte nicht mehr aufheben (spart Speicher)."""
        g = self.groesse + 2
        neu = []
        for gl in range(1, g - 1, 2):
            gr = g - 1 - gl
            links, rechts = self.nach_groesse[gl], self.nach_groesse[gr]
            for i, (bl, wl) in enumerate(links):
                for j, (br, wr) in enumerate(rechts):
                    for sym, f, komm in OPS:
                        if komm and (gl > gr or (gl == gr and j < i)):
                            continue
                        self.erzeugt += 1
                        w = f(wl, wr)
                        if w is None:
                            continue
                        liste = self.anders.setdefault(hash(w), [])
                        if len(liste) < ALT:
                            liste.append(("o", sym, bl, br))
                        if len(liste) == 1 and not oberste and w not in self.wert:
                            self.wert[w] = liste[0]
                            neu.append((liste[0], w))
        self.nach_groesse[g] = neu
        self.groesse = g
        self.je_groesse[g] = dict(erzeugt=self.erzeugt - sum(e["erzeugt"] for k, e in self.je_groesse.items() if k > 1),
                                  verschieden_bis_hier=len(self.anders))


# ---------------------------------------------------------------- Schablonen (Bibliothek)
def schablonen_aus(baum):
    """Teilbaeume mit mindestens zwei Rechenzeichen; gleiche Blaetter werden derselbe Platzhalter."""
    aus = []

    def besuche(b):
        if b[0] != "o":
            return 0
        n = 1 + besuche(b[2]) + besuche(b[3])
        if n >= 2:
            platz = {}

            def ersetze(t):
                if t[0] == "o":
                    return ("o", t[1], ersetze(t[2]), ersetze(t[3]))
                if t[:3] not in platz:
                    platz[t[:3]] = len(platz)
                return ("p", platz[t[:3]])
            aus.append((ersetze(b), len(platz)))
        return n
    besuche(baum)
    return aus


def belege(form, werte):
    """Schablone mit Wertetupeln je Platzhalter ausrechnen; None, wenn ungueltig."""
    if form[0] == "p":
        return werte[form[1]]
    links = belege(form[2], werte)
    if links is None:
        return None
    rechts = belege(form[3], werte)
    return None if rechts is None else OP[form[1]](links, rechts)


def setze(form, baeume):
    return baeume[form[1]] if form[0] == "p" else ("o", form[1], setze(form[2], baeume), setze(form[3], baeume))


def versuche_schablonen(ziel, blaetter, bibliothek, zaehler):
    """Alle Belegungen aller Schablonen; Rueckgabe: bis zu HALTEN Baeume, die das Ziel treffen."""
    aus = []
    for form, k in bibliothek:
        for wahl in itertools.product(range(len(blaetter)), repeat=k):
            zaehler["schablonen"] += 1
            if belege(form, [blaetter[i][1] for i in wahl]) == ziel:
                aus.append(setze(form, [blaetter[i][0] for i in wahl]))
                if len(aus) >= HALTEN:
                    return aus
    return aus


# ---------------------------------------------------------------- Rueckwaertsrechnen
def rueckwaerts(ziel, vorrat, beispiele, tiefe, klein, blatt, zaehler):
    """Liste von Baeumen fuer das Ziel; leer, wenn keiner gefunden wird."""
    t = vorrat.erklaerungen(ziel, beispiele)
    if t or tiefe == 0:
        return t
    for baum, w in (klein if tiefe >= 2 else blatt):
        h = v_minus(ziel, w)                                        # Ziel = w + X
        if h is not None and h != ziel:
            zaehler["teilziele"] += 1
            x = rueckwaerts(h, vorrat, beispiele, tiefe - 1, klein, blatt, zaehler)
            if x:
                return [("o", "+", baum, t) for t in x]
        if 0 not in w and all(z % y == 0 for z, y in zip(ziel, w)):  # Ziel = w * X
            h = tuple([z // y for z, y in zip(ziel, w)])
            if h != ziel:
                zaehler["teilziele"] += 1
                x = rueckwaerts(h, vorrat, beispiele, tiefe - 1, klein, blatt, zaehler)
                if x:
                    return [("o", "*", baum, t) for t in x]
        h = v_plus(ziel, w)                                         # Ziel = X - w
        if h is not None and h != ziel:
            zaehler["teilziele"] += 1
            x = rueckwaerts(h, vorrat, beispiele, tiefe - 1, klein, blatt, zaehler)
            if x:
                return [("o", "-", t, baum) for t in x]
        h = v_minus(w, ziel)                                        # Ziel = w - X
        if h is not None:
            zaehler["teilziele"] += 1
            x = rueckwaerts(h, vorrat, beispiele, tiefe - 1, klein, blatt, zaehler)
            if x:
                return [("o", "-", baum, t) for t in x]
    return []


# ---------------------------------------------------------------- Suche nach Ausdruecken
def suche(ziele, blaetter, beispiele, bibliothek, mit_schablonen=True, mit_rueckwaerts=True):
    """Je Ziel (Liste von Erklaerungen, Weg) oder None; dazu der Aufwand.
    Reihenfolge: kleine Ausdruecke, Schablonen der Bibliothek, alle Ausdruecke bis MAX_GROESSE, Rueckwaertsrechnen."""
    zaehler = dict(schablonen=0, teilziele=0)
    fund = [None] * len(ziele)
    vorrat = Vorrat(blaetter)

    def schaue(weg):
        for i, z in enumerate(ziele):
            if fund[i] is None:
                t = vorrat.erklaerungen(z, beispiele)
                if t:
                    fund[i] = (t, weg)

    for i, z in enumerate(ziele):
        if len(set(z)) == 1 and not vorrat.erklaerungen(z, beispiele):
            fund[i] = ([("c", str(z[0]), z[0])], "Konstante")
    schaue("Ausdruck")
    if any(f is None for f in fund):
        vorrat.wachse(oberste=False)
        schaue("Ausdruck")
    if mit_schablonen:
        for i, z in enumerate(ziele):
            if fund[i] is None:
                t = versuche_schablonen(z, blaetter, bibliothek, zaehler)
                if t:
                    fund[i] = (t, "Schablone")
    while any(f is None for f in fund) and vorrat.groesse < MAX_GROESSE and vorrat.erzeugt < GRENZE:
        vorrat.wachse(oberste=vorrat.groesse + 2 >= MAX_GROESSE)
        schaue("Ausdruck")
    if mit_rueckwaerts:
        klein = [e for g in (1, 3) for e in vorrat.nach_groesse.get(g, [])]
        for i, z in enumerate(ziele):
            if fund[i] is None:
                t = rueckwaerts(z, vorrat, beispiele, 2, klein, vorrat.nach_groesse[1], zaehler)
                if t:
                    fund[i] = (t, "Rueckwaerts")
    zaehler.update(erzeugt=vorrat.erzeugt, verschieden=vorrat.verschieden(), bis_groesse=vorrat.groesse,
                   je_groesse=vorrat.je_groesse)
    return fund, zaehler


def loese_ausdruck(start, namen, bibliothek, eingabe=None, lehrer=None, zufall=None, **schalter):
    """start: [(Eingaben, Ausgaben)].  Mit eingabe/lehrer: Rueckfragen und Lehrerprobe, sonst nur die Beispiele.
    Rueckgabe: (Erklaerungen je Ausgabestelle oder None, Wege, Aufwand)."""
    beispiele = list(start)
    n_aus = len(start[0][1])
    n = len(beispiele)
    auswahl = sorted(set(list(range(min(10, n))) + list(range(0, n, max(1, n // 14)))))
    g = dict(schablonen=0, teilziele=0, erzeugt=0, verschieden=0, bis_groesse=1, runden=0, gegenbeispiele=0, rueckfragen=0,
             lehrer_gegenbeispiele=0)
    for _ in range(60):
        b = [beispiele[i][0] for i in auswahl]
        blaetter = [(("v", j, name), tuple(e[j] for e in b)) for j, name in enumerate(namen)]
        blaetter += [(("c", name, w), (w,) * len(b)) for name, w in KONST]
        ziele = [tuple(beispiele[i][1][k] for i in auswahl) for k in range(n_aus)]
        fund, z = suche(ziele, blaetter, b, bibliothek, **schalter)
        g["runden"] += 1
        for k in ("schablonen", "teilziele", "erzeugt"):
            g[k] += z[k]
        g["verschieden"] = max(g["verschieden"], z["verschieden"])
        g["bis_groesse"] = max(g["bis_groesse"], z["bis_groesse"])
        g["je_groesse"] = z["je_groesse"]
        g["beispiele"] = len(auswahl)
        if any(f is None for f in fund):
            return None, None, g
        neu, erkl = set(), []
        for k, (baeume, _) in enumerate(fund):                      # jede Erklaerung gegen alle bekannten Beispiele
            gut = []
            for t in baeume:
                gegen = next((i for i, (ein, aus) in enumerate(beispiele) if rechne(t, ein) != aus[k]), None)
                if gegen is None:
                    gut.append(t)
                else:
                    neu.add(gegen)
            erkl.append(gut[:HALTEN])
        if any(not e for e in erkl):
            g["gegenbeispiele"] += len(neu)
            auswahl = sorted(set(auswahl) | neu)
            continue
        wege = [f[1] for f in fund]
        if eingabe is None:
            return erkl, wege, g
        frage = None
        for _ in range(PROBEN):                                     # zwei Erklaerungen, verschiedene Antwort?
            ein = eingabe(zufall)
            if any(any(rechne(t, ein) != rechne(e[0], ein) for t in e[1:]) for e in erkl):
                frage = ein
                g["rueckfragen"] += 1
                break
        if frage is None:
            for _ in range(PROBEN):                                 # Lehrerprobe der ersten Erklaerung
                ein = eingabe(zufall)
                soll = lehrer(ein)
                if any(rechne(erkl[k][0], ein) != soll[k] for k in range(n_aus)):
                    frage = ein
                    g["lehrer_gegenbeispiele"] += 1
                    break
        if frage is None:
            return erkl, wege, g
        beispiele.append((frage, lehrer(frage)))
        auswahl.append(len(beispiele) - 1)
    return None, None, g


# ---------------------------------------------------------------- Baum: Fallunterscheidung ueber Merkmale
def m_wert(x, m):
    return m[x[1]] if x[0] == "m" else x[1]


def m_text(x, namen):
    return namen[x[1]] if x[0] == "m" else {53248: "BASIS", 53248 * 53248: "QUADRAT"}.get(x[1], str(x[1]))


def bedingungen(typen, konst):
    """Alle Vergleiche typgleicher Merkmale untereinander und mit den Konstanten ihres Typs."""
    aus = []
    for i, ti in enumerate(typen):
        if ti == "-":                                         # nur als Antwort brauchbar, nicht als Frage
            continue
        for j in range(i + 1, len(typen)):
            if typen[j] == ti:
                aus += [("<", ("m", i), ("m", j)), ("<", ("m", j), ("m", i)), ("==", ("m", i), ("m", j))]
        for c in konst.get(ti, []):
            aus += [("<", ("m", i), ("k", c)), ("<", ("k", c), ("m", i)), ("==", ("m", i), ("k", c))]
    return aus


def gilt(p, m):
    a, b = m_wert(p[1], m), m_wert(p[2], m)
    return a < b if p[0] == "<" else a == b


def guete(w, idx, gedeckt, n, n1):
    """Reinheit der Teilung von idx durch die Bedingung w als Bruch (Zaehler, Nenner); None, wenn sie nichts teilt."""
    a = (w & idx).bit_count()
    if a == 0 or a == n:
        return None
    a1 = (w & gedeckt).bit_count()
    a0, b, b1 = a - a1, n - a, n1 - a1
    b0 = b - b1
    return ((a1 * a1 + a0 * a0) * b + (b1 * b1 + b0 * b0) * a, a * b)


def baue_baum(idx, treffer, wahrheit, tiefe, zaehler, wurzel=None):
    """Exakter Entscheidungsbaum auf den Beispielen der Bitmaske idx.  Blatt: je Ausgabestelle ein Term."""
    blatt = []
    for liste in treffer:
        t = next((ti for ti, m in enumerate(liste) if m & idx == idx), None)
        if t is None:
            break
        blatt.append(t)
    if len(blatt) == len(treffer):
        return ("blatt", blatt)
    if tiefe == 0:
        return None
    gedeckt = idx                                                # groesster gemeinsamer Treffer, Stelle fuer Stelle
    for liste in treffer:
        best, zahl = 0, -1
        for ti, m in enumerate(liste):
            c = (m & gedeckt).bit_count()
            if c > zahl:
                best, zahl = ti, c
        gedeckt &= liste[best]
    n, n1 = idx.bit_count(), gedeckt.bit_count()
    wahl = wurzel
    if wahl is None:
        wz, wn = 0, 1
        for q, w in enumerate(wahrheit):
            gq = guete(w, idx, gedeckt, n, n1)
            if gq is None:
                continue
            zaehler["bedingungen"] += 1
            if wahl is None or gq[0] * wn > wz * gq[1]:
                wahl, wz, wn = q, gq[0], gq[1]
    if wahl is None or guete(wahrheit[wahl], idx, gedeckt, n, n1) is None:
        return None
    w = wahrheit[wahl]
    ja = baue_baum(idx & w, treffer, wahrheit, tiefe - 1, zaehler)
    if ja is None:
        return None
    nein = baue_baum(idx & ~w, treffer, wahrheit, tiefe - 1, zaehler)
    return None if nein is None else ("wenn", wahl, ja, nein)


def blatt_fuer(seite, treffer):
    """Je Ausgabestelle die Terme, die alle Beispiele der Seite treffen; None, wenn eine Stelle keinen hat."""
    aus = []
    for liste in treffer:
        t = [ti for ti, m in enumerate(liste) if m & seite == seite]
        if not t:
            return None
        aus.append(t)
    return aus


def kuerzeste_liste(alle, treffer, wahrheit, hoechstens, zaehler, merkmalzahl=None):
    """Entscheidungsliste mit den wenigsten Fragen.  Rueckgabe: Liste von Erklaerungen (Baeumen), die erste ist die
    Hauptfassung; die weiteren tauschen an einer Stelle eine Frage oder Antwort gegen eine auf den Beispielen gleiche."""
    merk = {}

    def optionen(idx):
        aus = {}                                              # abgetrennte Seite -> [(Bedingung, Seite ist der Ja-Fall)]
        for q, w in enumerate(wahrheit):
            for ja, seite in ((True, idx & w), (False, idx & ~w)):
                if seite == 0 or seite == idx:
                    continue
                if seite in aus:
                    aus[seite].append((q, ja))
                elif blatt_fuer(seite, treffer) is not None:
                    aus[seite] = [(q, ja)]
        zaehler["bedingungen"] += len(wahrheit)
        if merkmalzahl is not None:                           # unter gleichwertigen Fragen die sparsamste zuerst
            for liste in aus.values():
                liste.sort(key=lambda e: merkmalzahl[e[0]])
        return aus

    def suche(idx, tiefe):
        """Kette [(Seite, Fragen, Blattterme)] + Schlussblatt, oder None."""
        b = blatt_fuer(idx, treffer)
        if b is not None:
            return [(None, None, b)]
        if tiefe == 0:
            return None
        if (idx, tiefe) in merk:
            return merk[(idx, tiefe)]
        opt = optionen(idx)
        fund = None
        for seite in sorted(opt, key=lambda x: -x.bit_count()):
            rest = suche(idx & ~seite, tiefe - 1)
            if rest is not None:
                fund = [(seite, opt[seite], blatt_fuer(seite, treffer))] + rest
                break
        merk[(idx, tiefe)] = fund
        return fund

    kette = None
    for tiefe in range(hoechstens + 1):
        kette = suche(alle, tiefe)
        if kette is not None:
            break
    if kette is None:
        return []

    def baue(wahl_frage, wahl_blatt):
        """wahl_frage[i], wahl_blatt[i][k]: welche der gleichwertigen Fragen und Terme an Stelle i genommen werden."""
        baum = ("blatt", [t[wahl_blatt[-1][k]] for k, t in enumerate(kette[-1][2])])
        for i in range(len(kette) - 2, -1, -1):
            _, fragen, b = kette[i]
            q, ja = fragen[wahl_frage[i]]
            blatt = ("blatt", [t[wahl_blatt[i][k]] for k, t in enumerate(b)])
            baum = ("wenn", q, blatt, baum) if ja else ("wenn", q, baum, blatt)
        return baum

    null_f = [0] * (len(kette) - 1)
    null_b = [[0] * len(treffer) for _ in kette]
    aus = [baue(null_f, null_b)]
    for i, (_, fragen, b) in enumerate(kette):                 # Varianten: je Stelle eine andere, auf den Beispielen gleiche Wahl
        if fragen is not None:
            for j in range(1, min(len(fragen), 4)):
                aus.append(baue(null_f[:i] + [j] + null_f[i + 1:], null_b))
        for k, t in enumerate(b):
            for j in range(1, min(len(t), 3)):
                wb = [list(x) for x in null_b]
                wb[i][k] = j
                aus.append(baue(null_f, wb))
    return aus


def beste_wurzeln(idx, treffer, wahrheit, zahl):
    """Die besten Bedingungen an der Wurzel, nach Reinheit geordnet."""
    gedeckt = idx
    for liste in treffer:
        gedeckt &= max(liste, key=lambda m: (m & gedeckt).bit_count())
    n, n1 = idx.bit_count(), gedeckt.bit_count()
    liste = [(guete(w, idx, gedeckt, n, n1), q) for q, w in enumerate(wahrheit)]
    liste = [e for e in liste if e[0] is not None]
    liste.sort(key=functools.cmp_to_key(lambda x, y: y[0][0] * x[0][1] - x[0][0] * y[0][1]))
    return [q for _, q in liste[:zahl]]


def baum_wert(b, m, preds, terme):
    while b[0] == "wenn":
        b = b[2] if gilt(preds[b[1]], m) else b[3]
    return tuple(m_wert(terme[k][t], m) for k, t in enumerate(b[1]))


def baum_blaetter(b):
    return 1 if b[0] == "blatt" else baum_blaetter(b[2]) + baum_blaetter(b[3])


def baum_merkmale(b, preds, terme, aus):
    if b[0] == "blatt":
        aus.update(terme[k][t][1] for k, t in enumerate(b[1]) if terme[k][t][0] == "m")
    else:
        aus.update(x[1] for x in preds[b[1]][1:] if x[0] == "m")
        baum_merkmale(b[2], preds, terme, aus)
        baum_merkmale(b[3], preds, terme, aus)
    return aus


SCHOEN = {"0 < (oben as u64)": "oben", "(oben as u64) == 0": "!oben", "(oben as u64) < 1": "!oben"}


def baum_text(b, namen, preds, terme, einzug, blatt=None):
    """blatt: Funktion (Texte der Terme) -> Zeilen des Blatts; sonst ein Tupel der Terme."""
    if b[0] == "blatt":
        texte = [m_text(terme[k][t], namen) for k, t in enumerate(b[1])]
        zeilen = blatt(texte) if blatt else ["(" + ", ".join(texte) + ")"]
        return "\n".join(einzug + z for z in zeilen)
    p = preds[b[1]]
    frage = m_text(p[1], namen) + " " + p[0] + " " + m_text(p[2], namen)
    kopf = einzug + "if " + SCHOEN.get(frage, frage) + " {\n"
    return (kopf + baum_text(b[2], namen, preds, terme, einzug + "    ", blatt) + "\n" + einzug + "} else {\n" +
            baum_text(b[3], namen, preds, terme, einzug + "    ", blatt) + "\n" + einzug + "}")


def loese_baum(start, merkmal, typen, konst, terme, eingabe=None, lehrer=None, zufall=None, protokoll=None,
               nur_baum=False):
    """Kleinster Baum aus mehreren Wurzeln.  Mit eingabe/lehrer: Rueckfragen, solange zwei Baeume verschieden antworten.
    Rueckgabe: (Baum, Bedingungen, Zaehler)."""
    preds = bedingungen(typen, konst)
    wahrheit = [0] * len(preds)
    treffer = [[0] * len(liste) for liste in terme]
    zahl = 0

    def nimm(ein, aus):
        nonlocal zahl
        m = merkmal(ein)
        bit = 1 << zahl
        for q, p in enumerate(preds):
            if gilt(p, m):
                wahrheit[q] |= bit
        for k, liste in enumerate(terme):
            for ti, t in enumerate(liste):
                if m_wert(t, m) == aus[k]:
                    treffer[k][ti] |= bit
        zahl += 1

    for ein, aus in start:
        nimm(ein, aus)
    z = dict(bedingungen=0, runden=0, rueckfragen=0, lehrer_gegenbeispiele=0, moegliche_bedingungen=len(preds))
    for _ in range(400):
        z["runden"] += 1
        alle = (1 << zahl) - 1
        varianten = [] if nur_baum else kuerzeste_liste(alle, treffer, wahrheit, 8 if len(preds) <= 100 else 3, z,
                                                        [sum(1 for x in p[1:] if x[0] == "m") for p in preds])
        z["form"] = "Liste"
        if not varianten:                                        # keine kurze Liste: Baum mit mehreren Wurzeln
            z["form"] = "Baum"
            t = baue_baum(alle, treffer, wahrheit, 16, z)
            if t is not None:
                varianten.append(t)
            for q in beste_wurzeln(alle, treffer, wahrheit, WURZELN):
                t = baue_baum(alle, treffer, wahrheit, 16, z, wurzel=q)
                if t is not None and t not in varianten:
                    varianten.append(t)
            varianten.sort(key=baum_blaetter)
        if not varianten:
            return None, preds, z
        z["beispiele"] = zahl
        z["varianten"] = len(varianten)
        if eingabe is None:
            return varianten[0], preds, z
        frage = None
        for _ in range(PROBEN):
            ein = eingabe(zufall)
            m = merkmal(ein)
            w0 = baum_wert(varianten[0], m, preds, terme)
            if any(baum_wert(t, m, preds, terme) != w0 for t in varianten[1:]):
                frage = ein
                z["rueckfragen"] += 1
                break
        if frage is None:
            for _ in range(PROBEN):
                ein = eingabe(zufall)
                if baum_wert(varianten[0], merkmal(ein), preds, terme) != tuple(lehrer(ein)):
                    frage = ein
                    z["lehrer_gegenbeispiele"] += 1
                    break
        if frage is None:
            return varianten[0], preds, z
        nimm(frage, lehrer(frage))
        if protokoll is not None:
            protokoll.append((frage, lehrer(frage)))
    return None, preds, z


# ---------------------------------------------------------------- Faelle mit Rechnung
def teilausdruecke(b, aus):
    if b[0] == "o":
        teilausdruecke(b[2], aus)
        teilausdruecke(b[3], aus)
        if b not in aus:
            aus.append(b)
    return aus


def schuerfe(vorrat, ziel, hoechstens=8):
    """Terme, die das Ziel auf moeglichst vielen noch unerklaerten Beispielen treffen; erlaubt ist auch Term + 1.
    Bei gleicher Trefferzahl gewinnt der kleinere Term.  Rueckgabe: (Terme, Zahl der unerklaerten Beispiele)."""
    masken = []
    for g in sorted(vorrat.nach_groesse):
        for baum, w in vorrat.nach_groesse[g]:
            m0 = m1 = 0
            for i, soll in enumerate(ziel):
                d = soll - w[i]
                if d == 0:
                    m0 |= 1 << i
                elif d == 1:
                    m1 |= 1 << i
            if m0:
                masken.append((m0, baum))
            if m1:
                masken.append((m1, ("o", "+", baum, ("c", "1", 1))))
    offen = (1 << len(ziel)) - 1
    terme = []
    while offen and masken and len(terme) < hoechstens:
        best = max(masken, key=lambda e: (e[0] & offen).bit_count())
        if best[0] & offen == 0:
            break
        terme.append(best[1])
        offen &= ~best[0]
    return terme, offen.bit_count()


def loese_faelle(start, aufgabe, eingabe=None, lehrer=None, zufall=None):
    """Faelle mit Rechnung.  Die Ausgabe ist eine Stufenzahl (k, m, r); m und r werden nach der Zwei-Skalen-Regel zu
    D = m * BASIS + r zusammengelegt.  aufgabe: zahlen(ein) -> Blattwerte der Suche, namen, k_terme(ein) -> [(Text, Wert)],
    flagge(ein).  Ablauf: Terme fuer D schuerfen, Zwischenwerte der Terme als Merkmale, dann Liste oder Baum.
    Rueckgabe: (Baum, Bedingungen, Terme, Merkmalsnamen, Merkmalsfunktion, Zaehler)."""
    basis = 53248
    zahlen, namen, k_terme, flagge = aufgabe["zahlen"], aufgabe["namen"], aufgabe["k_terme"], aufgabe["flagge"]
    beispiele = [(ein, (aus[0], aus[1] * basis + aus[2])) for ein, aus in start]
    lehrer2 = (lambda ein: (lehrer(ein)[0], lehrer(ein)[1] * basis + lehrer(ein)[2])) if lehrer else None
    n = len(beispiele)
    auswahl = sorted(set(list(range(min(40, n))) + list(range(0, n, max(1, n // 40)))))
    z = dict(schuerfrunden=0, nachgereichte_beispiele=0)
    for _ in range(8):
        z["schuerfrunden"] += 1
        b = [zahlen(beispiele[i][0]) for i in auswahl]
        blaetter = [(("v", j, name), tuple(e[j] for e in b)) for j, name in enumerate(namen)]
        blaetter += [(("c", name, w), (w,) * len(b)) for name, w in KONST]
        vorrat = Vorrat(blaetter)
        while vorrat.groesse < MAX_GROESSE:
            vorrat.wachse(oberste=False)
        d_terme, rest = schuerfe(vorrat, tuple(beispiele[i][1][1] for i in auswahl))
        z.update(erzeugt=vorrat.erzeugt, verschieden=vorrat.verschieden(), geschuerfte_terme=[text(t) for t in d_terme],
                 beispiele_beim_schuerfen=len(auswahl))
        offen = [i for i, (ein, aus) in enumerate(beispiele) if not any(rechne(t, zahlen(ein)) == aus[1] for t in d_terme)]
        if offen:                                              # ein Fall fehlt noch: Beispiele nachreichen, neu schuerfen
            z["nachgereichte_beispiele"] += min(len(offen), 40)
            auswahl = sorted(set(auswahl) | set(offen[:40]))
            continue
        # Merkmale: Blattwerte, Zwischenwerte der Terme, zu jeder Teilung der Rest (zwei Skalen), die Terme, die Flagge
        ausdruecke = [("v", j, name) for j, name in enumerate(namen)]
        for t in d_terme:
            teilausdruecke(t, ausdruecke)
            if t not in ausdruecke:
                ausdruecke.append(t)
        for t in list(ausdruecke):
            if t[0] == "o" and t[1] == "/" and ("o", "%", t[2], t[3]) not in ausdruecke:
                ausdruecke.append(("o", "%", t[2], t[3]))
        k_namen = [name for name, _ in k_terme(beispiele[0][0])]
        m_namen = [text(t) for t in ausdruecke] + ["(oben as u64)"] + k_namen
        typen = "u" * len(ausdruecke) + "f" + "-" * len(k_namen)

        def merkmal(ein, ausdruecke=ausdruecke):
            zl = zahlen(ein)
            werte = [rechne(t, zl) for t in ausdruecke]
            return [-1 if w is None else w for w in werte] + [flagge(ein)] + [w for _, w in k_terme(ein)]

        terme = [[("m", len(ausdruecke) + 1 + q) for q in range(len(k_namen))], [("m", ausdruecke.index(t)) for t in d_terme]]
        protokoll = []
        baum, preds, zz = loese_baum(beispiele, merkmal, typen, {"u": [0, 1, basis, basis * basis], "f": [0]}, terme,
                                     eingabe=eingabe, lehrer=lehrer2, zufall=zufall, protokoll=protokoll)
        for k in ("rueckfragen", "lehrer_gegenbeispiele", "bedingungen", "runden"):
            z[k] = z.get(k, 0) + zz[k]
        z.update({k: v for k, v in zz.items() if k in ("form", "beispiele", "varianten", "moegliche_bedingungen")})
        z["merkmale"] = len(m_namen)
        if baum is not None:
            return baum, preds, terme, m_namen, merkmal, z
        if not protokoll:
            break
        for ein, aus in protokoll:                             # der Lehrer hat einen Fall gezeigt, den kein Term trifft
            beispiele.append((ein, aus))
            auswahl.append(len(beispiele) - 1)
    return None, None, None, None, None, z


# ---------------------------------------------------------------- Aufgaben
def lies_vektoren(pfad):
    aus = {}
    with open(pfad, encoding="utf-8") as f:
        for zeile in f:
            if zeile.startswith("#") or not zeile.strip():
                continue
            links, rechts = zeile.split("|")
            t = links.split()
            aus.setdefault(t[0], []).append((tuple(int(x) for x in t[1:]), tuple(int(x) for x in rechts.split())))
    return aus


AUSDRUCK = [                      # (Funktion, Namen der Eingaben)
    ("klasse_fein", ["m"]), ("reste", ["m"]), ("zwei_skalen", ["x"]), ("klasse_per_quersumme", ["x"]),
    ("aus_resten", ["a", "f"]), ("zurueck", ["a", "b"]),
]
STUFEN_NAMEN = ["a_unten", "a_oben", "b_unten", "b_oben"]
PAARE = [(i, j) for i in range(4) for j in range(4) if i != j]


def rumpf_ausdruck(erkl):
    teile = [text(e[0]) for e in erkl]
    return ["    " + (teile[0] if len(teile) == 1 else "(" + ", ".join(teile) + ")")]


def ersetze_rumpf(zeilen, name, rumpf):
    """Rumpf der Funktion name in den Quellzeilen ersetzen; die Kopfzeile bleibt."""
    start = next(i for i, z in enumerate(zeilen) if z.startswith("pub fn " + name + "("))
    ende = next(i for i in range(start + 1, len(zeilen)) if zeilen[i] == "}")
    return zeilen[:start + 1] + rumpf + zeilen[ende:]


def ms():
    return time.monotonic_ns() // 1000000


def breitprobe(name, rechner, samen=99):
    """Abweichungen vom Lehrer auf BREIT Zufallseingaben des Bereichs."""
    z = BR.Zufall(samen)
    falsch = 0
    for _ in range(BREIT):
        ein = BR.EINGABE[name](z)
        if rechner(ein) != tuple(BR.LEHRER[name](ein)):
            falsch += 1
    return falsch


def folge_rechner(erkl, start):
    def f(ein):
        aus, g = [], start
        for _ in range(ein[0]):
            aus += list(g)
            g = (rechne(erkl[0][0], g), rechne(erkl[1][0], g))
            if None in g:
                return None
        return tuple(aus)
    return f


def rumpf_folge(erkl, start):
    return ["    let mut s: u64 = %d;" % start[0], "    let mut d: u64 = %d;" % start[1],
            "    let mut out: Vec<(u64, u64)> = Vec::new();", "    for _ in 0..stufen {", "        out.push((s, d));",
            "        let s_neu: u64 = %s;" % text(erkl[0][0]), "        let d_neu: u64 = %s;" % text(erkl[1][0]),
            "        s = s_neu;", "        d = d_neu;", "    }", "    out"]


def loese_alles(vek, fassung, nur_baum=False, koennen=None):
    """fassung 'naiv': nur Beispiele.  fassung 'lehrer': zwei Erklaerungen, Rueckfragen, Lehrerprobe.
    nur_baum: Fallunterscheidungen Frage fuer Frage bauen (Gegenprobe zur kuerzesten Liste).
    koennen: Woerterbuch, in das die geschriebenen Funktionen als Rechner gelegt werden (fuer gipfel.py)."""
    mit = fassung == "lehrer"
    zufall = BR.Zufall(20261118)
    bibliothek, erg, ruempfe = [], {}, {}

    def hilfe(name):
        return dict(eingabe=BR.EINGABE[name], lehrer=BR.LEHRER[name], zufall=zufall) if mit else {}

    for name, namen in AUSDRUCK:
        t0 = ms()
        erkl, wege, aufwand = loese_ausdruck(vek[name], namen, bibliothek, **hilfe(name))
        e = dict(sprosse="Ausdruck", geloest=erkl is not None, aufwand=aufwand, millisekunden=ms() - t0)
        if erkl is not None:
            e["rumpf"] = rumpf_ausdruck(erkl)[0].strip()
            e["weitere_erklaerungen"] = [[text(t) for t in liste[1:]] for liste in erkl]
            e["weg"] = wege
            e["groesse"] = sum(groesse(liste[0]) for liste in erkl)
            e["abweichungen_breitprobe"] = breitprobe(name, lambda ein, erkl=erkl: tuple(rechne(liste[0], ein) for liste in erkl))
            ruempfe[name] = rumpf_ausdruck(erkl)
            for liste in erkl:
                for t in liste:
                    for s in schablonen_aus(t):
                        if s not in bibliothek:
                            bibliothek.append(s)
        erg[name] = e
        print(fassung, name, e.get("rumpf"), e.get("weg"), e.get("weitere_erklaerungen"), aufwand,
              "Breitprobe", e.get("abweichungen_breitprobe"), e["millisekunden"], "ms", flush=True)
    erg["bibliothek"] = [dict(form=text(f), platzhalter=k) for f, k in bibliothek]

    # Folge: seiten_diagonal.  Schrittfunktion aus aufeinanderfolgenden Gliedern; der Lehrer liefert laengere Folgen.
    t0 = ms()
    name = "seiten_diagonal"
    laengste = max(vek[name], key=lambda e: len(e[1]))[1]
    e = dict(sprosse="Folge", geloest=False, lehrer_gegenbeispiele=0)
    for _ in range(4):
        glieder = [(laengste[i], laengste[i + 1]) for i in range(0, len(laengste), 2)]
        schritte = [(glieder[i], glieder[i + 1]) for i in range(len(glieder) - 1)]
        erkl, wege, aufwand = loese_ausdruck(schritte, ["s", "d"], bibliothek)
        if erkl is None:
            break
        f = folge_rechner(erkl, glieder[0])
        gegen = next((ein for ein, aus in vek[name] if f(ein) != aus), None)
        if gegen is None and mit:
            gegen = next(((n,) for n in range(31) if f((n,)) != tuple(BR.LEHRER[name]((n,)))), None)
        if gegen is None:
            e.update(geloest=True, aufwand=aufwand, weg=wege, groesse=sum(groesse(liste[0]) for liste in erkl),
                     rumpf="Start (%d, %d); Schritt s' = %s, d' = %s" % (glieder[0] + (text(erkl[0][0]), text(erkl[1][0]))),
                     abweichungen_breitprobe=breitprobe(name, f))
            ruempfe[name] = rumpf_folge(erkl, glieder[0])
            break
        e["lehrer_gegenbeispiele"] += 1
        laengste = tuple(BR.LEHRER[name]((30,)))
    e["millisekunden"] = ms() - t0
    erg[name] = e
    print(fassung, name, e, flush=True)

    # Baum: vergleiche
    t0 = ms()
    name = "vergleiche"
    namen_v = ["a.0", "a.1", "a.2", "b.0", "b.1", "b.2"]
    terme_v = [[("k", 1), ("k", -1), ("k", 0)], [("k", c) for c in range(5)]]
    baum_v, preds_v, z = loese_baum(vek[name], lambda ein: ein, "iuuiuu", {"i": [0], "u": [0]}, terme_v,
                                    nur_baum=nur_baum, **hilfe(name))
    e = dict(sprosse="Baum", geloest=baum_v is not None, aufwand=z, millisekunden=ms() - t0)

    def vergleiche(ein):
        return baum_wert(baum_v, ein, preds_v, terme_v)

    if baum_v is not None:
        if koennen is not None:
            koennen["vergleiche"] = vergleiche
        e["blaetter"] = baum_blaetter(baum_v)
        e["rumpf"] = baum_text(baum_v, namen_v, preds_v, terme_v, "    ")
        e["abweichungen_breitprobe"] = breitprobe(name, vergleiche)
        ruempfe[name] = e["rumpf"].split("\n")
    erg[name] = e
    print(fassung, name, {k: v for k, v in e.items() if k != "rumpf"}, flush=True)

    # Aufruf: entscheide mit vergleiche als Baustein (Merkmale = Ergebnisse aller zwoelf Aufrufe)
    if baum_v is not None:
        t0 = ms()
        name = "entscheide"
        namen_e = [n for q in range(len(PAARE)) for n in ("v%d.0" % q, "v%d.1" % q)]
        typen = "iw" * len(PAARE)

        def merkmal(ein):
            m = []
            for i, j in PAARE:
                m += list(vergleiche(ein[3 * i:3 * i + 3] + ein[3 * j:3 * j + 3]))
            return m

        terme_e = [[("k", 1), ("k", -1), ("k", 0)] + [("m", q) for q in range(0, len(typen), 2)],
                   [("k", c) for c in range(5)] + [("m", q) for q in range(1, len(typen), 2)]]
        baum_e, preds_e, z = loese_baum(vek[name], merkmal, typen, {"i": [0], "w": [0, 1, 2, 3, 4]}, terme_e,
                                        nur_baum=nur_baum, **hilfe(name))
        e = dict(sprosse="Aufruf", geloest=baum_e is not None, aufwand=z, millisekunden=ms() - t0)
        if baum_e is not None:
            if koennen is not None:
                koennen["entscheide_teile"] = (baum_e, preds_e, terme_e)
            benutzt = sorted({q // 2 for q in baum_merkmale(baum_e, preds_e, terme_e, set())})
            kopf = ["    let v%d = vergleiche(%s, %s);" % (q, STUFEN_NAMEN[PAARE[q][0]], STUFEN_NAMEN[PAARE[q][1]]) for q in benutzt]
            e["blaetter"] = baum_blaetter(baum_e)
            e["aufrufe"] = len(benutzt)
            e["rumpf"] = "\n".join(kopf) + "\n" + baum_text(baum_e, namen_e, preds_e, terme_e, "    ")
            e["abweichungen_breitprobe"] = breitprobe(name, lambda ein: baum_wert(baum_e, merkmal(ein), preds_e, terme_e))
            ruempfe[name] = e["rumpf"].split("\n")
        erg[name] = e
        print(fassung, name, {k: v for k, v in e.items() if k != "rumpf"}, flush=True)
    # Faelle mit Rechnung: bruch.  Ausgabe ueber zwei Skalen zusammengelegt, Terme geschuerft, Baum ueber Zwischenwerte.
    t0 = ms()
    name = "bruch"
    for name in ("bruch", "mal"):
        t0 = ms()
        e = loese_stufe(name, vek[name], hilfe(name))
        e["millisekunden"] = ms() - t0
        if e["geloest"]:
            rechner = e.pop("rechner")
            if koennen is not None:
                koennen[name] = rechner
            e["abweichungen_breitprobe"] = breitprobe(name, rechner)
            ruempfe[name] = e["rumpf"].split("\n")
        erg[name] = e
        print(fassung, name, {k: v for k, v in e.items() if k != "rumpf"}, flush=True)
    return erg, ruempfe


STUFENAUFGABE = {
    # Typregel: Ein Wert vom Typ Stufe (k, m, r) wird als (k, m * BASIS + r) gefuehrt, bei Eingaben wie bei der Ausgabe.
    "bruch": dict(zahlen=lambda ein: ein[:2], namen=["z", "n"], flagge=lambda ein: ein[2], kopf=[],
                  k_terme=lambda ein: [("0", 0), ("1", 1), ("-1", -1)]),
    "mal": dict(zahlen=lambda ein: (ein[1] * 53248 + ein[2], ein[4] * 53248 + ein[5]), namen=["x", "y"],
                flagge=lambda ein: ein[6],
                kopf=["    let x: u64 = a.1 * BASIS + a.2;", "    let y: u64 = b.1 * BASIS + b.2;"],
                k_terme=lambda ein: [("a.0 + b.0", ein[0] + ein[3]), ("a.0 + b.0 + 1", ein[0] + ein[3] + 1),
                                     ("a.0 + b.0 - 1", ein[0] + ein[3] - 1)]),
}


def loese_stufe(name, beispiele, hilfe):
    aufgabe = STUFENAUFGABE[name]
    baum, preds, terme, namen, merkmal, z = loese_faelle(beispiele, aufgabe, **hilfe)
    e = dict(sprosse="Faelle mit Rechnung", geloest=baum is not None, aufwand=z)
    if baum is not None:
        def blatt(texte):
            return ["let d: u64 = %s;" % texte[1], "(%s, d / BASIS, d %% BASIS)" % texte[0]]

        def rechner(ein):
            k, d = baum_wert(baum, merkmal(ein), preds, terme)
            return (k, d // 53248, d % 53248)
        e["blaetter"] = baum_blaetter(baum)
        e["rumpf"] = "\n".join(aufgabe["kopf"] + [baum_text(baum, namen, preds, terme, "    ", blatt)])
        e["rechner"] = rechner
    return e


def setze_ein(pfad_rs, ruempfe):
    """Quelltext des Kerns mit den geschriebenen Ruempfen."""
    zeilen = Path(pfad_rs).read_text(encoding="utf-8").split("\n")
    for name, rumpf in ruempfe.items():
        zeilen = ersetze_rumpf(zeilen, name, rumpf)
    return "\n".join(zeilen)


def pruefe_quelle(pfad_rs, ruempfe, saetze):
    quelltext = setze_ein(pfad_rs, ruempfe)
    aus = {}
    for marke, datei in saetze:
        pr = W.Pruefer(datei)
        r = pr.pruefe(quelltext)
        aus[marke] = dict(ausgang=r["art"], faelle=sum(1 for z in open(datei, encoding="utf-8") if z.strip() and not z.startswith("#")),
                          meldungen=[f["text"] for f in r.get("fehler", [])][:3],
                          fehlschlagende_funktionen=[f["name"] for f in r.get("funktionen", [])])
        pr.schliesse()
    return quelltext, aus


def main():
    pfad_rs, pfad_vek, ziel, ziel_rs = sys.argv[1:5]
    vek = lies_vektoren(pfad_vek)
    ordner = Path(tempfile.mkdtemp(prefix="synthese_"))
    zweiter, breit = ordner.joinpath("vektoren2.txt"), ordner.joinpath("breitsatz.txt")
    zweiter.write_text("\n".join(V.erzeuge(ZWEITER_SAMEN)) + "\n", encoding="utf-8")
    breit.write_text("\n".join(BR.breitsatz(1500, 424242)) + "\n", encoding="utf-8")
    saetze = [("vektoren", pfad_vek), ("zweiter_satz", str(zweiter)), ("breitsatz", str(breit))]
    gesamt = {}
    for fassung in ("naiv", "lehrer"):
        erg, ruempfe = loese_alles(vek, fassung)
        quelltext, pruefung = pruefe_quelle(pfad_rs, ruempfe, saetze)
        erg["pruefung"] = pruefung
        erg["geschrieben"] = sorted(ruempfe)
        erg["von_hand"] = sorted(set(vek) - set(ruempfe))
        gesamt[fassung] = erg
        print(fassung, "geschrieben", erg["geschrieben"], "von Hand", erg["von_hand"])
        print(fassung, "Pruefung", pruefung, flush=True)
        if fassung == "lehrer":
            Path(ziel_rs).write_text(quelltext, encoding="utf-8")

    # Gegenproben: was leisten Rueckwaertsrechnen und Bibliothek bei den beiden grossen Ausdruecken?
    proben = {}
    for name, namen in (("aus_resten", ["a", "f"]), ("zurueck", ["a", "b"])):
        for marke, schalter in (("nur_aufzaehlen", dict(mit_schablonen=False, mit_rueckwaerts=False)),
                                ("mit_rueckwaerts", dict(mit_schablonen=False, mit_rueckwaerts=True))):
            t0 = ms()
            erkl, wege, aufwand = loese_ausdruck(vek[name], namen, [], **schalter)
            proben[name + ":" + marke] = dict(geloest=erkl is not None, aufwand=aufwand, millisekunden=ms() - t0)
            print("Gegenprobe", name, marke, proben[name + ":" + marke], flush=True)
    gesamt["gegenproben"] = proben

    # Gegenprobe: Fallunterscheidung Frage fuer Frage (jeweils die beste naechste Frage) statt als ganze Kette
    erg, ruempfe = loese_alles(vek, "lehrer", nur_baum=True)
    _, pruefung = pruefe_quelle(pfad_rs, ruempfe, saetze)
    gesamt["frage_fuer_frage"] = {n: erg[n] for n in ("vergleiche", "entscheide")}
    gesamt["frage_fuer_frage"]["pruefung"] = pruefung
    print("Frage fuer Frage, Pruefung", pruefung, flush=True)

    # Gegenprobe: bruch mit weiterem Bereich (Nenner bis 120000).  Der Bereich legt das Programm fest.
    e = loese_stufe("bruch", vek["bruch"], dict(eingabe=BR.e_bruch_weit, lehrer=BR.LEHRER["bruch"], zufall=BR.Zufall(5)))
    if e["geloest"]:
        rechner = e.pop("rechner")
        zz, falsch = BR.Zufall(99), 0
        for _ in range(BREIT):
            ein = BR.e_bruch_weit(zz)
            falsch += rechner(ein) != tuple(BR.LEHRER["bruch"](ein))
        e["abweichungen_breitprobe_weit"] = falsch
    gesamt["bruch_weiter_bereich"] = e
    print("bruch weit", {k: v for k, v in e.items() if k != "rumpf"}, flush=True)
    with open(ziel, "w", encoding="utf-8") as f:
        json.dump(gesamt, f, indent=1, ensure_ascii=False)


if __name__ == "__main__":
    main()
