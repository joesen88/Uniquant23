"""Suchraum je Schritt: wie viele verschiedene Ausdruecke gibt es mit 0, 1, 2, 3, 4 Rechenzeichen?  Nur ganze Zahlen.

Gezaehlt wird an der Aufgabe zurueck (zwei Eingaben, sieben Konstanten, 24 Beispiele).  Zwei Ausdruecke gelten als
gleich, wenn sie auf allen Beispielen dieselben Werte haben.  Die oberste Groesse wird nur gezaehlt, nicht gemerkt.

Aufruf: python3 -I suchraum.py <vektoren.txt> <ausgabe.json>
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import synthese as SY  # noqa: E402


def main():
    vek = SY.lies_vektoren(sys.argv[1])
    bsp = vek["zurueck"]
    n = len(bsp)
    auswahl = sorted(set(list(range(min(10, n))) + list(range(0, n, max(1, n // 14)))))
    b = [bsp[i][0] for i in auswahl]
    blaetter = [(("v", j, name), tuple(e[j] for e in b)) for j, name in enumerate(["a", "b"])]
    blaetter += [(("c", name, w), (w,) * len(b)) for name, w in SY.KONST]
    vorrat = SY.Vorrat(blaetter)
    while vorrat.groesse < 7:
        vorrat.wachse(oberste=False)
    zeilen = []
    vorher = 0
    for g in (1, 3, 5, 7):
        e = vorrat.je_groesse[g]
        zeilen.append(dict(rechenzeichen=g // 2, erzeugt=e["erzeugt"], verschieden_bis_hier=e["verschieden_bis_hier"],
                           neu=e["verschieden_bis_hier"] - vorher))
        vorher = e["verschieden_bis_hier"]
    # Groesse 9: nur zaehlen
    gesehen = set(vorrat.anders)
    erzeugt = 0
    for gl in (1, 3, 5, 7):
        gr = 8 - gl
        links, rechts = vorrat.nach_groesse[gl], vorrat.nach_groesse[gr]
        for i, (_, wl) in enumerate(links):
            for j, (_, wr) in enumerate(rechts):
                for sym, f, komm in SY.OPS:
                    if komm and (gl > gr or (gl == gr and j < i)):
                        continue
                    erzeugt += 1
                    w = f(wl, wr)
                    if w is not None:
                        gesehen.add(hash(w))
    zeilen.append(dict(rechenzeichen=4, erzeugt=erzeugt, verschieden_bis_hier=len(gesehen), neu=len(gesehen) - vorher))
    for i in range(1, len(zeilen)):                     # Wachstum je Schritt als ganzzahliges Verhaeltnis in Zehnteln
        zeilen[i]["wachstum_zehntel"] = 10 * zeilen[i]["verschieden_bis_hier"] // zeilen[i - 1]["verschieden_bis_hier"]
    for z in zeilen:
        print(z)
    with open(sys.argv[2], "w", encoding="utf-8") as f:
        json.dump(dict(aufgabe="zurueck", blaetter=len(blaetter), beispiele=len(b), je_schritt=zeilen), f, indent=1)


if __name__ == "__main__":
    main()
