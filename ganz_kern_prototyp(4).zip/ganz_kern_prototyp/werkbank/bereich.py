"""Definitionsbereiche und Lehrer fuer die Kernfunktionen.  Nur ganze Zahlen.

Bereich   Je Funktion ein Erzeuger breiter Zufallseingaben.  Anders als vektoren.py erzwingt er Zusammentreffen:
          Teile einer Stufenzahl werden mit halber Wahrscheinlichkeit von einer anderen uebernommen, Klammern
          (unten, oben) haben jede Breite.  So kommen alle Lagen kleiner, gleich, groesser in jeder Stelle vor.
Lehrer    Die Python-Referenz stufen.py beantwortet Rueckfragen: richtige Ausgabe zu einer Eingabe.
Breitsatz Vektordatei im Format von vektoren.txt aus diesen Eingaben, fuer den Pruefstand.

Aufruf: python3 -I bereich.py <breitsatz.txt> [faelle_je_funktion] [samen]
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import stufen as S  # noqa: E402

M64 = (1 << 64) - 1
B = S.BASIS
EBENE = {"stufe": 0, "teile": 1, "rest": 2, "gleich": 3, "offen": 4}


class Zufall:                                   # splitmix64, ganzzahlig
    def __init__(self, samen):
        self.s = samen & M64

    def zahl(self):
        self.s = (self.s + 0x9E3779B97F4A7C15) & M64
        z = self.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        return z ^ (z >> 31)

    def unter(self, n):
        return self.zahl() % n


def bis(z, grenze):
    """Zahl in [0, grenze); jede vierte nahe am Rand."""
    if z.unter(4) == 0:
        rand = [0, 1, 2, 12, 13, 14, 4095, 4096, 4097, grenze - 2, grenze - 1]
        return rand[z.unter(len(rand))] % grenze
    return z.unter(grenze)


def stufe(z):
    return (z.unter(6) - 2, 1 + bis(z, B - 1), bis(z, B))


def nah(z, a):
    """Stufenzahl, die a in jeder Stelle mit halber Wahrscheinlichkeit gleicht."""
    b = stufe(z)
    return tuple(a[i] if z.unter(2) else b[i] for i in range(3))


def klammer(z, anker=None):
    """(unten, oben) mit unten <= oben; Breite von null bis mehrere Stufen."""
    u = stufe(z) if anker is None else nah(z, anker)
    art = z.unter(4)
    if art == 0:
        o = u
    elif art == 1:
        o = (u[0], u[1], min(B - 1, u[2] + 1 + z.unter(3)))
    else:
        o = nah(z, u)
    return (u, o) if S.vergleiche(u, o)[0] <= 0 else (o, u)


def e_vergleiche(z):
    a = stufe(z)
    return a + nah(z, a)


def e_entscheide(z):
    au, ao = klammer(z)
    bu, bo = klammer(z, (au, ao)[z.unter(2)])
    return au + ao + bu + bo


def e_bruch(z):
    """1 <= z <= n < 2^16.  Erzwungen: z = n; Bruch unter 1/BASIS (eine Stufe tiefer); Nenner teilt BASIS^2 (Rest null)."""
    art = z.unter(8)
    oben = z.unter(2)
    if art == 0:
        n = 1 + bis(z, 65535)
        return (n, n, oben)
    if art == 1:
        return (1, B - 2 + z.unter(65538 - B), oben)
    if art == 2:
        n = (1 << z.unter(16)) * (1, 13, 169)[z.unter(3)]
        while n > 65535:
            n >>= 1
        return (1 + z.unter(n), n, oben)
    n = 1 + bis(z, 65535)
    return (1 + z.unter(n), n, oben)


def e_bruch_weit(z):
    """Wie e_bruch, aber Nenner bis 120000.  Dann liegen auch Brueche mit z = 2 unter 1/BASIS (Gegenprobe:
    Der Bereich legt das Programm fest)."""
    grenze = 120000
    art = z.unter(8)
    oben = z.unter(2)
    if art == 0:
        n = 1 + bis(z, grenze)
        return (n, n, oben)
    if art in (1, 2):
        zz = 1 + z.unter(2)
        return (zz, zz * B - 2 + z.unter(grenze + 3 - zz * B), oben)
    if art == 3:
        n = (1 << z.unter(17)) * (1, 13, 169)[z.unter(3)]
        while n > grenze:
            n >>= 1
        return (1 + z.unter(n), n, oben)
    n = 1 + bis(z, grenze)
    return (1 + z.unter(n), n, oben)


def e_stufenpaar(z):
    a = (z.unter(5) - 1, 1 + bis(z, B - 1), bis(z, B))
    b = nah(z, a)
    return a + (max(-1, min(3, b[0])), b[1], b[2]) + (z.unter(2),)


def e_mal(z):
    """Stufenpaar fuer mal.  Erzwungen: glatte Produkte (kein Rest) und Produkte um BASIS^3 herum; dort wechselt die
    Stufe, und knapp darunter kippt das Aufrunden in die naechste Stufe."""
    art = z.unter(8)
    oben = z.unter(2)
    if art == 0:
        return (z.unter(3), 4096 * (1 + z.unter(12)), 0) + (z.unter(3), 13 * (1 + z.unter(4095)), 0) + (oben,)
    if art in (1, 2):
        x = B + 1 + z.unter(64)
        y = (B * B * B - 1 - z.unter(3 * B)) // x if art == 1 else (B * B * B + z.unter(3 * B)) // x
        return (z.unter(3), x // B, x % B) + (z.unter(3), y // B, y % B) + (oben,)
    return e_stufenpaar(z)


def e_winkel(z):
    x = bis(z, 1 << 15)
    return ((x * 408 // 985 + z.unter(5)) % (x + 1) if z.unter(2) else z.unter(x + 1), x)


EINGABE = {
    "klasse_fein": lambda z: (bis(z, B),),
    "reste": lambda z: (bis(z, B),),
    "aus_resten": lambda z: (z.unter(13), bis(z, 4096)),
    "klasse_per_quersumme": lambda z: (bis(z, 1 << 48),),
    "zwei_skalen": lambda z: (bis(z, B * (B - 1)),),
    "zurueck": lambda z: (bis(z, B), bis(z, B - 1)),
    "seiten_diagonal": lambda z: (z.unter(31),),
    "unter_22_5": e_winkel,
    "vergleiche": e_vergleiche,
    "entscheide": e_entscheide,
    "bruch": e_bruch,
    "mal": e_mal,
    "plus": e_stufenpaar,
}


def _vgl(r):
    return (r[0], EBENE[r[1]])


LEHRER = {
    "klasse_fein": lambda e: tuple(S.klasse_fein(e[0])),
    "reste": lambda e: tuple(S.reste(e[0])),
    "aus_resten": lambda e: (S.aus_resten(e[0], e[1]),),
    "klasse_per_quersumme": lambda e: (S.klasse_per_quersumme(e[0]),),
    "zwei_skalen": lambda e: tuple(S.zwei_skalen(e[0])),
    "zurueck": lambda e: (S.zurueck(e[0], e[1]),),
    "seiten_diagonal": lambda e: tuple(v for paar in S.seiten_diagonal(e[0]) for v in paar),
    "unter_22_5": lambda e: tuple(int(v) for v in S.unter_22_5(e[0], e[1])),
    "vergleiche": lambda e: _vgl(S.vergleiche(e[0:3], e[3:6])),
    "entscheide": lambda e: _vgl(S.entscheide(e[0:3], e[3:6], e[6:9], e[9:12])),
    "bruch": lambda e: tuple(S.bruch(e[0], e[1], bool(e[2]))),
    "mal": lambda e: tuple(S.mal(e[0:3], e[3:6], bool(e[6]))),
    "plus": lambda e: tuple(S.plus(e[0:3], e[3:6], bool(e[6]))),
}
REIHENFOLGE = ["klasse_fein", "reste", "aus_resten", "klasse_per_quersumme", "zwei_skalen", "zurueck", "seiten_diagonal",
               "unter_22_5", "vergleiche", "entscheide", "bruch", "mal", "plus"]


def breitsatz(faelle, samen):
    z = Zufall(samen)
    zeilen = []
    for name in REIHENFOLGE:
        for _ in range(faelle if name != "seiten_diagonal" else 31):
            ein = EINGABE[name](z)
            zeilen.append("%s %s | %s" % (name, " ".join(str(x) for x in ein), " ".join(str(x) for x in LEHRER[name](ein))))
    return zeilen


def main():
    ziel = sys.argv[1]
    faelle = int(sys.argv[2]) if len(sys.argv) > 2 else 2000
    samen = int(sys.argv[3]) if len(sys.argv) > 3 else 424242
    zeilen = breitsatz(faelle, samen)
    with open(ziel, "w", encoding="utf-8") as f:
        f.write("# Breitsatz aus stufen.py, Samen %d\n" % samen)
        f.write("\n".join(zeilen) + "\n")
    print(len(zeilen), "Faelle")


if __name__ == "__main__":
    main()
