# Werkbank: Compiler-Schleife ohne Netz (Arbeitspaket 1), Synthese und Gipfelaufgaben

Erster Baustein der Feldforschung: Kandidat bauen, mit rustc übersetzen, gegen exakte Prüfvektoren laufen lassen,
Rückmeldung als kurze Codes (Klasse, Ort, Vorschlag) lesen. Kein Netz, kein fremder Code: Geprüft werden nur
Abwandlungen des eigenen Kerns. Schritte 1 bis 3 reparieren ein fast richtiges Programm, Schritt 4 schreibt
Kernfunktionen aus Beispielen selbst, Schritt 6 setzt die geschriebenen Funktionen zu größeren Programmen zusammen.

Braucht Rust (rustc ab 1.80, über rustup) und Python 3. Getestet mit rustc 1.97.0 und Python 3.13.

## Dateien

| Datei | Zweck |
| --- | --- |
| `stufen.rs` | Rust-Kern der Leiter-Arithmetik (13 · 4096), übertragen aus `../stufen.py`, 13 Funktionen |
| `pruefstand.rs` | exakter Prüfer: liest Vektoren, vergleicht bitgleich, fängt Panik je Fall, meldet je Funktion |
| `vektoren.py` | erzeugt die Prüfvektoren aus `../stufen.py` (8590 Fälle, Zufall mit festem Samen und gezielte Randfälle) |
| `werkbank.py` | Lücken finden, Kandidat bauen, rustc-Meldungen (JSON) in Klasse, Ort und Vorschlag zerlegen |
| `mutationsanalyse.py` | prüft den Prüfer: alle 787 Abweichungen um ein Zeichen |
| `reparatur.py` | Reparaturschleife mit und ohne gelernte Tafeln |
| `bereich.py` | Definitionsbereich je Funktion (breite Zufallseingaben mit erzwungenem Zusammentreffen) und Lehrer (`../stufen.py`) |
| `synthese.py` | schreibt Kernfunktionen aus Beispielen: Ausdruck, Rückwärtsrechnen, Schablone, Folge, Fragenkette, Aufruf, Fälle mit Rechnung |
| `suchraum.py` | zählt die verschiedenen Ausdrücke je Zahl der Rechenzeichen |
| `gipfel.py` | Gipfelaufgaben: setzt die geschriebenen Funktionen zusammen, lernt an der leichten Aufgabe eine Maske und füllt sie in den schweren |

## Schritt 1: Bitgleichheit

```
python3 -I vektoren.py vektoren.txt
rustc --edition 2021 -C overflow-checks=on -o pruefstand pruefstand.rs
./pruefstand vektoren.txt            # letzte Zeile muss "ERGEBNIS 0" sein
```

`vektoren.txt` liegt bei; neu erzeugt muss sie Byte für Byte gleich sein.

## Schritt 2: Den Prüfer prüfen

```
python3 -I mutationsanalyse.py stufen.rs vektoren.txt mutationsanalyse.json 2      # etwa 2,5 Minuten auf 2 Kernen
```

Soll (in `../ergebnisse/mutationsanalyse.json`): 236 Lücken, 787 Abweichungen. Ausgang: falsches Ergebnis 431,
Übersetzungsfehler 246, Panik 73 (Überlauf 48, Teilung durch null 25), Zeitüberschreitung 5, unentdeckt 32.

Die 32 unentdeckten sind im Definitionsbereich gleichwertig, einzeln begründet:

- `!= 0` gegen `> 0` bei vorzeichenlosen Zahlen (5 Stellen)
- Vergleiche, bei denen der Gleichheitsfall ausgeschlossen ist oder nichts ändert (`vergleiche`, `plus`, `mal`,
  `unter_22_5`, 10 Stellen)
- `bruch` (15 Stellen): `z == n` gegen `z >= n` bei z ≤ n (1); der Rest im unteren Zweig ist im Bereich n < 2^16
  nie null (9); der Zweig `d == QUADRAT` wird im Bereich nie erreicht (5)
- `zurueck`: `a % PROBE` gegen `a + PROBE` (gleicher Rest); `unter_22_5`: `d - s` gegen `d % s` auf der festen Tafel (2 Stellen)

Die erste Fassung des Prüfers ließ 48 durch. 16 davon waren echte Lücken und sind geschlossen: Die exakte letzte
Stufe von `unter_22_5` erreichte kein Vektor, `entscheide` sah nie genau gleiche Klammern, und zwei Rückgabetypen
waren im Prüfstand nicht festgeschrieben.

## Schritt 3: Reparaturschleife

```
python3 -I reparatur.py stufen.rs vektoren.txt mutationsanalyse.json reparatur.json 48
```

Etwa 13 Minuten auf 2 Kernen. Soll (in `../ergebnisse/reparatur.json`), 48 Episoden mit 1 oder 2 Abweichungen,
höchstens 160 Prüferläufe je Episode:

| Messgröße | Reihenfolge nach Ort | dazu gelernte Tafeln |
| --- | --- | --- |
| gelöste Episoden | 41 | 43 |
| Prüferläufe je Episode | 64,7 | 47,5 |
| bei 1 Abweichung | 35,1 | 25,9 |
| bei 2 Abweichungen | 94,2 | 69,1 |
| Platz der richtigen Änderung nach Übersetzungsfehler | 12,6 | 4,4 |
| Platz der richtigen Änderung nach Lauffehler | 41,7 | 33,1 |

Gepaart: mit Tafeln in 35 Episoden weniger Läufe, in 8 mehr, in 5 gleich.

Die erste Fassung der Schleife nahm jede Änderung an, die weniger Fälle scheitern ließ, und löste nur 27 von 48
(`../ergebnisse/reparatur_locker.json`). Die jetzige Regel: Fortschritt ist, wenn die gemeldete Funktion ganz
besteht; ein Schritt wird zurückgenommen, wenn sein Weg nicht zum Ziel führt.

## Schritt 4: Funktionen selbst schreiben

```
python3 -I synthese.py stufen.rs vektoren.txt synthese.json stufen_synthese.rs      # etwa 75 Sekunden
```

Gegeben sind je Funktion die Kopfzeile, die benannten Konstanten und die Beispiele aus `vektoren.txt`. Die Rümpfe
werden gesucht, in `stufen.rs` eingesetzt, übersetzt und auf drei Vektorsätzen geprüft: `vektoren.txt` (8590 Fälle),
ein zweiter Satz mit anderem Samen (8590), ein Breitsatz aus `bereich.py` (18031). Zwei Fassungen laufen
nacheinander: `naiv` (nur die Beispiele) und `lehrer` (zwei Erklärungen, Rückfragen an `../stufen.py`, Lehrerprobe).

Soll (in `../ergebnisse/synthese.json`, geschriebener Kern in `../ergebnisse/stufen_synthese.rs`), Fassung `lehrer`:
11 von 13 Funktionen geschrieben, alle drei Sätze bestanden. Von Hand bleiben `plus` und `unter_22_5`.

| Funktion | Weg | gefundener Rumpf | Aufwand |
| --- | --- | --- | --- |
| `klasse_fein` | Ausdruck | `(m / FEIN, m % FEIN)` | 264 Kandidaten |
| `reste` | Ausdruck | `(m % KLASSEN, m % FEIN)` | 264 |
| `zwei_skalen` | Ausdruck | `(x % BASIS, x % PROBE)` | 264 |
| `klasse_per_quersumme` | Ausdruck | `x % KLASSEN` (geschlossene Form statt Ziffernschleife) | 264 |
| `aus_resten` | Rückwärts | `f + FEIN * ((a + f * PROBE) % KLASSEN)` | 180527 Kandidaten, 37 Teilziele |
| `zurueck` | Schablone | `a + BASIS * ((b + (PROBE - a)) % PROBE)` | 250776 Belegungen |
| `seiten_diagonal` | Folge | Start (1, 1); `s' = s + d`, `d' = d + s * 2` | 333 Kandidaten, 1491 Belegungen |
| `vergleiche` | Fragenkette | 6 Fragen, 7 Antworten | 0 Rückfragen |
| `entscheide` | Aufruf | 2 Aufrufe von `vergleiche`, 2 Fragen, 3 Antworten | 12 Rückfragen |
| `bruch` | Fälle mit Rechnung | 5 Terme, 7 Antworten | 0 Rückfragen |
| `mal` | Fälle mit Rechnung | 4 Terme, 6 Antworten; Aufrunden als `(x * y - 1) / QUADRAT + 1` | 1 Rückfrage, 3 Gegenbeispiele des Lehrers |

Fassung `naiv`: dieselben 11 Funktionen, `vektoren.txt` und der zweite Satz bestanden, der Breitsatz nicht. Auf
20000 breiten Eingaben weicht `entscheide` in 6456 Fällen ab, `mal` in 1637. Beide Programme erklären alle
17180 Beispiele und sind trotzdem falsch.

Gegenproben in derselben Datei:

- Nur Aufzählen bis 3 Rechenzeichen löst `aus_resten` und `zurueck` nicht; mit Rückwärtsrechnen gelöst (37 und 11 Teilziele).
- Fallunterscheidung Frage für Frage statt als kürzeste Kette: `vergleiche` 8 statt 7 Antworten und 6 statt 0
  Rückfragen; `entscheide` 7 statt 3 Antworten, 7 statt 2 Aufrufe, 13 Rückfragen und 22 Gegenbeispiele statt 12
  Rückfragen, 262639 statt 19584 geprüfte Bedingungen. Am Ende sind beide Fassungen richtig.
- `bruch` mit weiterem Bereich (Nenner bis 120000): Im Bereich n < 2^16 genügt `BASIS * QUADRAT / n`, weil der
  untere Zweig nur bei z = 1 erreicht wird. Im weiteren Bereich meldet der Lehrer Gegenbeispiele (2 Rückfragen,
  3 Gegenbeispiele), und der Term wird `z * (BASIS * QUADRAT) / n`. Der Bereich legt das Programm fest.

## Schritt 5: Suchraum je Schritt

```
python3 -I suchraum.py vektoren.txt suchraum.json      # etwa 10 Sekunden
```

Verschiedene Ausdrücke (gleich heißt: gleiche Werte auf allen 24 Beispielen) aus 2 Eingaben und 7 Konstanten:

| Rechenzeichen | erzeugt | verschieden bis hier | Faktor zum Schritt davor |
| --- | --- | --- | --- |
| 0 | 9 | 9 | |
| 1 | 333 | 120 | 13,3 |
| 2 | 7992 | 2140 | 17,8 |
| 3 | 194835 | 48926 | 22,8 |
| 4 | 5162352 | 1265879 | 25,8 |

## Schritt 6: Gipfelaufgaben

```
python3 -I gipfel.py stufen.rs vektoren.txt gipfel.json stufen_gipfel.rs      # etwa 35 Sekunden
```

Drei Aufgaben in Folge. Jede bildet Brüche (z, n) mit 1 ≤ z ≤ n < 2^16 auf ein Urteil (Vorzeichen, Ebene) ab.
Bausteine sind `bruch`, `mal`, `vergleiche`, `entscheide` in der Fassung aus Schritt 4 und `plus` von Hand.

Begriffe: Eine Faser ist eine logische Datenkette über einem Fußpunkt (der Eingabe): Glied für Glied wird ein Wert
aus dem vorigen gerechnet (`bruch` → `mal` → `plus`). Jede Faser läuft in zwei Fassungen, abgerundet und
aufgerundet; das Paar ist die Klammer um den wahren Wert. Ein Urteil vereinigt die Enden zweier Faserpaare.

Die Vorstufe wird blind gelöst. Aus ihrer Lösung wird die Maske gelesen: Argumente, die bis auf die Rundung gleich
sind, teilen sich einen Platz. Die Maske lautet `entscheide(A ab, A auf, B ab, B auf)`; A und B sind freie Plätze
für Fasern. In den Gipfelaufgaben werden die Plätze Ebene für Ebene gefüllt.

Soll (in `../ergebnisse/gipfel.json`, Programme in `../ergebnisse/stufen_gipfel.rs`):

| Aufgabe | Weg | geprüfte Kandidaten | ohne Maske (gezählt) | Programm |
| --- | --- | --- | --- | --- |
| `vorstufe`: z1/n1 gegen z2/n2 | blind | 272 | 272 | 5 Aufrufe auf 2 Ebenen |
| `gipfel_1`: z1/n1 · z2/n2 gegen z3/n3 | Maske | 225 | 65618100 | 9 Aufrufe auf 3 Ebenen |
| `gipfel_2`: z1/n1 · z2/n2 + z3/n3 · z4/n4 gegen z5/n5 | Maske | 1600225 | 127538916268599722900 | 17 Aufrufe auf 4 Ebenen |

Alle drei: 0 Abweichungen vom Lehrer auf 5000 breiten Eingaben; als Rust an den geschriebenen Kern gehängt,
übersetzt, 9000 frische Vektoren bestanden. Die Spalte „ohne Maske" zählt alle typrichtigen Aufrufbäume bis zur
Ebene der Lösung, ohne wertgleiche zu entfernen; ausgeführt wurde diese Suche nur für die Vorstufe.

## Hinweise

- Meldungen des Compilers können sich zwischen rustc-Versionen ändern. Ausgang und Klasse sollten gleich bleiben,
  die Ortsstufe einzelner Meldungen kann abweichen.
- Sobald Code aus fremden Quellen geprüft wird (ab Arbeitspaket 4), läuft der Prüfstand im Sandkasten ohne Netz,
  zum Beispiel `docker run --network none` oder `unshare -n`.
