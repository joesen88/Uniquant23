"""Pruefvektoren fuer stufen.rs, erzeugt aus stufen.py (der Wahrheit).  Nur ganze Zahlen.

Je Funktion Zufallsfaelle (splitmix64, fester Samen) und gezielte Randfaelle: Gleichheit, Stufenwechsel, exakte
Teilungen (Rest 0), Uebertrag beim Aufrunden, Grenze der 22,5-Grad-Pruefung.  Reihenfolge von unten nach oben
in der Aufrufkette, damit die erste fehlschlagende Funktion die Ursache ist.

Zeile:  <funktion> <eingaben ...> | <erwartete ausgaben ...>
Ebene eines Vergleichs: 0 Stufe, 1 Teile, 2 Rest, 3 gleich, 4 offen.

Aufruf: python3 -I vektoren.py <vektoren.txt> [samen]
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import stufen as S  # noqa: E402

M64 = (1 << 64) - 1
EBENE = {"stufe": 0, "teile": 1, "rest": 2, "gleich": 3, "offen": 4}
B = S.BASIS


class Zufall:                                   # splitmix64, ganzzahlig
    def __init__(self, samen):
        self.s = samen & M64

    def zahl(self):
        self.s = (self.s + 0x9E3779B97F4A7C15) & M64
        z = self.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        return z ^ (z >> 31)

    def unter(self, n):
        return self.zahl() % n


def ziffer(z, unten):
    """Ziffer in [unten, B); jede vierte ist ein Randwert."""
    if z.unter(4) == 0:
        rand = [unten, unten + 1, 12, 13, 4095, 4096, 4097, B - 2, B - 1]
        return rand[z.unter(len(rand))]
    return unten + z.unter(B - unten)


def stufe(z, k=None):
    return (z.unter(5) - 1 if k is None else k, ziffer(z, 1), ziffer(z, 0))


def zeile(name, ein, aus):
    return f"{name} {' '.join(str(int(x)) for x in ein)} | {' '.join(str(int(x)) for x in aus)}"


def vgl(r):
    return (r[0], EBENE[r[1]])


def erzeuge(samen):
    z = Zufall(samen)
    out = []

    for m in [0, 1, 12, 13, 4095, 4096, 4097, B - 1] + [z.unter(B) for _ in range(200)]:
        out.append(zeile("klasse_fein", [m], S.klasse_fein(m)))
    for m in [0, 1, 12, 13, 4095, 4096, 4097, B - 1] + [z.unter(B) for _ in range(200)]:
        out.append(zeile("reste", [m], S.reste(m)))
    paare = [(a, f) for a in range(13) for f in (0, 1, 12, 13, 14, 4095)] + [(z.unter(13), z.unter(4096)) for _ in range(300)]
    for a, f in paare:
        out.append(zeile("aus_resten", [a, f], [S.aus_resten(a, f)]))
    for x in [0, 1, 12, 13, 4095, 4096, 4097, B, B * B, (1 << 48) - 1] + [z.unter(1 << 48) for _ in range(300)]:
        out.append(zeile("klasse_per_quersumme", [x], [S.klasse_per_quersumme(x)]))
    grenze = B * (B - 1)
    xs = [0, 1, B - 2, B - 1, B, B + 1, grenze - 1] + [z.unter(grenze) for _ in range(300)]
    for x in xs:
        out.append(zeile("zwei_skalen", [x], S.zwei_skalen(x)))
    for x in xs:
        a, b = S.zwei_skalen(x)
        out.append(zeile("zurueck", [a, b], [S.zurueck(a, b)]))
    for a, b in [(B - 1, 0), (0, 0), (0, B - 2), (B - 1, B - 2), (5, 3), (3, 5)] + [(z.unter(B), z.unter(B - 1)) for _ in range(200)]:
        out.append(zeile("zurueck", [a, b], [S.zurueck(a, b)]))
    for n in range(10):
        out.append(zeile("seiten_diagonal", [n], [v for paar in S.seiten_diagonal(n) for v in paar]))

    punkte = [(0, 0), (0, 1), (1, 1), (1, 2), (2, 5), (5, 12), (12, 29), (29, 70), (408, 985), (407, 985), (409, 985)]
    for _ in range(400):
        x = z.unter(1 << 15)
        punkte.append((z.unter(x + 1), x))
    for _ in range(400):                         # nahe der Grenze y/x = sqrt2 - 1 (408/985 ist der letzte Naeherungsbruch)
        x = 1 + z.unter((1 << 15) - 1)
        y = x * 408 // 985 + z.unter(5) - 2
        punkte.append((min(max(y, 0), x), x))
    letzte = []                                  # Punkte, die erst die exakte Quadratprobe entscheidet (Stufe 9)
    for x in range(1, 1 << 15):
        for y in range(max(0, x * 408 // 985 - 1), min(x, x * 408 // 985 + 2) + 1):
            if S.unter_22_5(y, x)[1] == len(S.PELL):
                letzte.append((y, x))
    punkte += letzte
    for y, x in punkte:
        out.append(zeile("unter_22_5", [y, x], S.unter_22_5(y, x)))

    paare = []
    for _ in range(100):
        paare.append((stufe(z), stufe(z)))
    for _ in range(100):
        a = stufe(z)
        paare.append((a, (a[0], ziffer(z, 1), ziffer(z, 0))))
    for _ in range(100):
        a = stufe(z)
        paare.append((a, (a[0], a[1], ziffer(z, 0))))
    for _ in range(30):
        a = stufe(z)
        paare.append((a, a))
    for a, b in paare:
        out.append(zeile("vergleiche", a + b, vgl(S.vergleiche(a, b))))

    def klammer():
        n = 2 + z.unter(65534)
        zz = 1 + z.unter(n)
        return S.bruch(zz, n), S.bruch(zz, n, True), zz, n
    vier = []
    for _ in range(150):
        au, ao, _, _ = klammer()
        bu, bo, _, _ = klammer()
        vier.append((au, ao, bu, bo))
    for _ in range(100):                         # derselbe Bruch, gekuerzt und erweitert: muss offen bleiben
        au, ao, zz, n = klammer()
        f = 1 + z.unter(max(1, 65535 // n))
        vier.append((au, ao, S.bruch(zz * f, n * f), S.bruch(zz * f, n * f, True)))
    for _ in range(100):                         # Nachbarbrueche: Entscheidung auf Teilen oder Rest
        n = 3 + z.unter(65000)
        zz = 1 + z.unter(n - 1)
        vier.append((S.bruch(zz, n), S.bruch(zz, n, True), S.bruch(zz + 1, n), S.bruch(zz + 1, n, True)))
        vier.append((S.bruch(zz + 1, n), S.bruch(zz + 1, n, True), S.bruch(zz, n), S.bruch(zz, n, True)))
    for zz, n, f in [(1, 2, 2), (1, 13, 2), (3, 4, 2), (5, 4096, 2), (1, 1, 7), (7, 8, 3), (1, 26, 5), (3, 16, 1), (12, 13, 4)]:
        a, b = S.bruch(zz, n), S.bruch(zz * f, n * f)        # exakt darstellbar: unten = oben, beide Seiten gleich
        vier.append((a, S.bruch(zz, n, True), b, S.bruch(zz * f, n * f, True)))
    for _ in range(40):                          # eine Seite exakt, die andere ein Nachbar
        n = (2, 4, 8, 13, 16, 26, 52, 4096)[z.unter(8)]
        zz = 1 + z.unter(n)
        m = 2 + z.unter(65000)
        y = 1 + z.unter(m)
        vier.append((S.bruch(zz, n), S.bruch(zz, n, True), S.bruch(y, m), S.bruch(y, m, True)))
        vier.append((S.bruch(y, m), S.bruch(y, m, True), S.bruch(zz, n), S.bruch(zz, n, True)))
    for au, ao, bu, bo in vier:
        out.append(zeile("entscheide", au + ao + bu + bo, vgl(S.entscheide(au, ao, bu, bo))))

    brueche = [(1, 1), (7, 7), (65535, 65535), (1, 2), (1, 13), (1, 4096), (3, 4), (1, B), (1, B + 1), (1, 60000), (1, 65535),
               (2, 65535), (65534, 65535), (1, 3), (2, 3), (4095, 4096), (12, 13)]
    for _ in range(500):
        n = 1 + z.unter(65535)
        brueche.append((1 + z.unter(n), n))
    for _ in range(60):                          # kleine Brueche: eine Stufe tiefer
        brueche.append((1, B + 1 + z.unter(65535 - B)))
    for zz, n in brueche:
        for oben in (0, 1):
            out.append(zeile("bruch", [zz, n, oben], S.bruch(zz, n, bool(oben))))

    paare = [(S.EINS, S.EINS), ((0, 1, 2), (0, B - 2, 3)), ((0, 4096, 0), (0, 13, 0)), ((0, 1, 0), (0, B - 1, B - 1)),
             ((0, 1, 0), (0, 1, 0)), ((0, B - 1, B - 1), (0, B - 1, B - 1)), ((1, 1, 1), (2, 1, 1)), ((0, 2, 0), (0, B // 2, 0))]
    for _ in range(40):
        a = stufe(z)
        paare.append((S.EINS, a))
        paare.append((a, S.EINS))
    for _ in range(500):
        paare.append((stufe(z), stufe(z)))
    for _ in range(60):                          # glatte Ziffern: Produkt ohne Rest
        paare.append(((z.unter(3), 4096 * (1 + z.unter(12)), 0), (z.unter(3), 13 * (1 + z.unter(4095)), 0)))
    for a, b in paare:
        for oben in (0, 1):
            out.append(zeile("mal", a + b + (oben,), S.mal(a, b, bool(oben))))

    paare = [((0, B - 1, B - 1), (0, B - 1, B - 1)), ((0, B - 1, B - 1), (1, B - 1, B - 1)), ((0, 1, 0), (0, 1, 0)),
             ((0, B - 1, B - 1), (1, 1, 0)), ((0, B - 1, B - 1), (1, 1, 1)), ((2, 5, 5), (0, 5, 5)), ((0, B // 2, 0), (0, B // 2, 0))]
    for _ in range(150):
        k = z.unter(4) - 1
        paare.append((stufe(z, k), stufe(z, k)))
    for _ in range(200):
        k = z.unter(4) - 1
        a, b = stufe(z, k), stufe(z, k + 1)
        paare.append((a, b) if z.unter(2) else (b, a))
    for _ in range(60):                          # hohe Ziffern: Uebertrag in die naechste Stufe
        k = z.unter(4) - 1
        paare.append(((k, B - 1 - z.unter(3), ziffer(z, 0)), (k + z.unter(2), B - 1 - z.unter(3), ziffer(z, 0))))
    for _ in range(150):
        paare.append((stufe(z), stufe(z)))
    for _ in range(40):
        a = stufe(z)
        paare.append((a, a))
    for a, b in paare:
        for oben in (0, 1):
            out.append(zeile("plus", a + b + (oben,), S.plus(a, b, bool(oben))))
    return out


def main():
    ziel = sys.argv[1]
    samen = int(sys.argv[2]) if len(sys.argv) > 2 else 20261118
    zeilen = erzeuge(samen)
    with open(ziel, "w", encoding="utf-8") as f:
        f.write("# Pruefvektoren aus stufen.py, Samen %d\n" % samen)
        f.write("\n".join(zeilen) + "\n")
    print(len(zeilen), "Faelle")


if __name__ == "__main__":
    main()
