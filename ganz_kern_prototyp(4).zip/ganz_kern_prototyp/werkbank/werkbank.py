"""Werkbank der Compiler-Schleife: Kandidat bauen, uebersetzen, pruefen, Rueckmeldung als kurze Codes.

Kette je Versuch (ohne Netz):  Kandidat -> rustc (Meldungen als JSON) -> Pruefstand mit Vektoren -> Rueckmeldung
Rueckmeldung  art       bestanden | uebersetzung | falsch | panik | zeit
              klasse    Fehlercode des Compilers (E0308, Name einer Lint-Regel), "falsch", "panik:<art>", "zeit"
              bild      Fehlerbild eines Lauffehlers: Klasse, Anteil der fehlschlagenden Faelle (alle, viele, wenige)
                        und Maske der abweichenden Ausgabestellen, z. B. "falsch:wenige:6"
              ort       Stellen im Quelltext (Datei, Zeile, Spalten) oder die erste fehlschlagende Funktion
              vorschlag Ersetzungen, die der Compiler selbst anbietet, mit seiner Angabe zur Anwendbarkeit
Luecken       Stellen im Bereich zwischen "// LUECKEN AN" und "// LUECKEN AUS", an denen ein Zeichen einer Art steht:
              Vergleich, Rechenzeichen, Zuweisung, Verknuepfung, Zahltyp, Feldnummer, kleine Konstante, Wahrheitswert.
              Sie werden nach festen Mustern gefunden, nicht von Hand gewaehlt.

Die Werkbank ist Werkzeug, kein Kern: Sie startet Prozesse und misst nichts mit Gleitkomma.
"""
import json
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

HIER = Path(__file__).resolve().parent
RUSTC = ["rustc", "--edition", "2021", "-C", "opt-level=0", "-C", "debuginfo=0", "-C", "overflow-checks=on",
         "--error-format=json", "-o", "pruefstand", "pruefstand.rs"]
ZEIT_BAU = 120
ZEIT_LAUF = 3
OPTIONEN = {
    "vgl": ["<", "<=", ">", ">=", "==", "!="],
    "rech": ["+", "-", "*", "/", "%"],
    "zuw": ["+=", "-="],
    "logik": ["&&", "||"],
    "typ": ["u16", "u32", "u64", "i32", "i64"],
    "feld": ["0", "1", "2"],
    "konst": ["0", "1", "2"],
    "wahr": ["true", "false"],
}
MUSTER = [
    ("vgl", re.compile(r"(?<= )(<=|>=|==|!=|<|>)(?= )")),
    ("rech", re.compile(r"(?<= )(\+|-|\*|/|%)(?= )")),
    ("zuw", re.compile(r"(?<= )(\+=|-=)(?= )")),
    ("logik", re.compile(r"(?<= )(&&|\|\|)(?= )")),
    ("typ", re.compile(r"\b(u8|u16|u32|u64|i32|i64|usize)\b")),
    ("feld", re.compile(r"(?<=[\w)]\.)([012])\b")),
    ("konst", re.compile(r"(?<![\w.])([012])(?![\w.])")),
    ("wahr", re.compile(r"\b(true|false)\b")),
]
FN = re.compile(r"^\s*pub fn (\w+)")


class Quelle:
    """Referenztext mit seinen Luecken.  Luecke = dict(nr, zeile, von, bis, art, original, funktion); Zeile ab 1, Spalte ab 0."""

    def __init__(self, pfad):
        self.zeilen = Path(pfad).read_text(encoding="utf-8").split("\n")
        self.luecken = []
        self.bereich = {}                         # Funktion -> (erste Zeile, letzte Zeile)
        aktiv, funktion = False, None
        for nr, text in enumerate(self.zeilen, 1):
            if "// LUECKEN AN" in text:
                aktiv = True
                continue
            if "// LUECKEN AUS" in text:
                aktiv = False
                continue
            if not aktiv:
                continue
            m = FN.match(text)
            if m:
                funktion = m.group(1)
                self.bereich[funktion] = [nr, nr]
            if funktion:
                self.bereich[funktion][1] = nr
            code = text.split("//")[0]
            gefunden = []
            for art, muster in MUSTER:
                for t in muster.finditer(code):
                    gefunden.append((t.start(1), t.end(1), art, t.group(1)))
            for von, bis, art, original in sorted(gefunden):
                self.luecken.append(dict(nr=len(self.luecken), zeile=nr, von=von, bis=bis, art=art, original=original,
                                         funktion=funktion))

    def andere(self, luecke):
        return [o for o in OPTIONEN[luecke["art"]] if o != luecke["original"]]

    def baue(self, wahl):
        """wahl: {Lueckennummer: Zeichen}.  Rueckgabe: Quelltext mit diesen Ersetzungen."""
        zeilen = list(self.zeilen)
        je_zeile = {}
        for nr, zeichen in wahl.items():
            je_zeile.setdefault(self.luecken[nr]["zeile"], []).append((self.luecken[nr], zeichen))
        for z, liste in je_zeile.items():
            text = zeilen[z - 1]
            for luecke, zeichen in sorted(liste, key=lambda e: -e[0]["von"]):
                text = text[:luecke["von"]] + zeichen + text[luecke["bis"]:]
            zeilen[z - 1] = text
        return "\n".join(zeilen)

    def lage(self, wahl):
        """Spaltenbereiche aller Luecken im gebauten Text: {nr: (zeile, von, bis)} (Spalten verschieben sich)."""
        aus, je_zeile = {}, {}
        for luecke in self.luecken:
            je_zeile.setdefault(luecke["zeile"], []).append(luecke)
        for z, liste in je_zeile.items():
            schub = 0
            for luecke in sorted(liste, key=lambda e: e["von"]):
                zeichen = wahl.get(luecke["nr"], luecke["original"])
                aus[luecke["nr"]] = (z, luecke["von"] + schub, luecke["von"] + schub + len(zeichen))
                schub += len(zeichen) - (luecke["bis"] - luecke["von"])
        return aus

    def funktion_der_zeile(self, zeile):
        for name, (a, b) in self.bereich.items():
            if a <= zeile <= b:
                return name
        return None


def stelle(span):
    return dict(datei=span["file_name"], zeile=span["line_start"], zeile_bis=span["line_end"],
                von=span["column_start"] - 1, bis=span["column_end"] - 1, haupt=bool(span.get("is_primary")),
                ersatz=span.get("suggested_replacement"), anwendbar=span.get("suggestion_applicability"))


def lies_meldung(m):
    """Eine Compiler-Meldung als kurze Codes."""
    eigene = [stelle(s) for s in m.get("spans", [])]
    neben, vorschlaege = [], []
    for kind in m.get("children", []):
        teile = [stelle(s) for s in kind.get("spans", [])]
        ersatz = [t for t in teile if t["ersatz"] is not None]
        if ersatz:
            vorschlaege.append(ersatz)
        neben += [t for t in teile if t["ersatz"] is None]
    direkt = [t for t in eigene if t["ersatz"] is not None]
    if direkt:
        vorschlaege.insert(0, direkt)
    code = (m.get("code") or {}).get("code") or "ohne_code"
    return dict(klasse=code, stufe=m.get("level"), text=m.get("message", "")[:100],
                haupt=[t for t in eigene if t["haupt"]], neben=[t for t in eigene if not t["haupt"]] + neben,
                vorschlaege=vorschlaege)


class Pruefer:
    """Uebersetzt und prueft Kandidaten in einem eigenen Arbeitsordner; zaehlt die Laeufe."""

    def __init__(self, vektoren, pruefstand=None):
        self.ordner = Path(tempfile.mkdtemp(prefix="werkbank_"))
        shutil.copy(pruefstand or HIER.joinpath("pruefstand.rs"), self.ordner.joinpath("pruefstand.rs"))
        self.vektoren = str(Path(vektoren).resolve())
        self.laeufe = 0
        self.speicher = {}

    def schliesse(self):
        shutil.rmtree(self.ordner, ignore_errors=True)

    def pruefe(self, text):
        if text in self.speicher:
            return self.speicher[text]
        self.laeufe += 1
        self.ordner.joinpath("stufen.rs").write_text(text, encoding="utf-8")
        bau = subprocess.run(RUSTC, cwd=self.ordner, capture_output=True, text=True, timeout=ZEIT_BAU)
        meldungen = []
        for z in bau.stderr.splitlines():
            if z.startswith("{"):
                m = json.loads(z)
                if m.get("spans"):
                    meldungen.append(lies_meldung(m))
        fehler = [m for m in meldungen if m["stufe"] == "error"]
        warnungen = sorted({m["klasse"] for m in meldungen if m["stufe"] == "warning"})
        if bau.returncode != 0:
            r = dict(art="uebersetzung", klasse=fehler[0]["klasse"] if fehler else "ohne_meldung", fehler=fehler,
                     warnungen=warnungen)
        else:
            try:
                lauf = subprocess.run([str(self.ordner.joinpath("pruefstand")), self.vektoren], capture_output=True,
                                      text=True, timeout=ZEIT_LAUF)
                funktionen = []
                for z in lauf.stdout.splitlines():
                    t = z.split()
                    if t and t[0] == "F":
                        funktionen.append(dict(name=t[1], faelle=int(t[2]), falsch=int(t[3]), panik=int(t[4]),
                                               erste=int(t[5]), panikklasse=t[6], maske=int(t[7]) if len(t) > 7 else 0))
                schlecht = [f for f in funktionen if f["falsch"] or f["panik"]]
                if lauf.returncode == 0 and funktionen and not schlecht:
                    r = dict(art="bestanden", klasse="bestanden", warnungen=warnungen)
                elif not schlecht:
                    r = dict(art="panik", klasse="panik:abbruch", funktionen=[], warnungen=warnungen)
                else:
                    erste = schlecht[0]
                    art = "panik" if erste["panik"] else "falsch"
                    klasse = "panik:" + erste["panikklasse"] if erste["panik"] else "falsch"
                    zehntel = 10 * (erste["falsch"] + erste["panik"]) // erste["faelle"]
                    anteil = "alle" if zehntel >= 9 else ("viele" if zehntel >= 1 else "wenige")
                    r = dict(art=art, klasse=klasse, bild=f"{klasse}:{anteil}:{erste['maske']}", funktionen=schlecht,
                             stelle=funktionen.index(erste), warnungen=warnungen)
            except subprocess.TimeoutExpired:
                r = dict(art="zeit", klasse="zeit", warnungen=warnungen)
        self.speicher[text] = r
        return r


def rang_streng(r):
    """Strenger Fortschritt: Bei Lauffehlern zaehlt nur, dass die erste fehlschlagende Funktion ganz besteht.

    Weniger fehlschlagende Faelle gelten nicht als Fortschritt: Das waere Scheinfortschritt (siehe rang).
    """
    if r["art"] == "bestanden":
        return (3, 0)
    if r["art"] in ("falsch", "panik"):
        return (2, r.get("stelle", 0))
    if r["art"] == "uebersetzung":
        return (1, -len(r["fehler"]))
    return (0, 0)


def rang(r):
    """Lockerer Fortschritt (erste Fassung, fuehrt zu Scheinfortschritt): groesser ist besser."""
    if r["art"] == "bestanden":
        return (3, 0, 0)
    if r["art"] in ("falsch", "panik"):
        return (2, -len(r["funktionen"]), -sum(f["falsch"] + f["panik"] for f in r["funktionen"]))
    if r["art"] == "uebersetzung":
        return (1, -len(r["fehler"]), 0)
    return (0, 0, 0)
