// stufen.rs: Leiter-Arithmetik des Kerns mit B = 13 * 4096 Teilen je Stufe.
// Uebertragung von stufen.py; bitgleich geprueft mit pruefstand.rs gegen Vektoren aus vektoren.py.
// Nur ganze Zahlen.  Zu uebersetzen mit Ueberlaufpruefung (-C overflow-checks=on).
//
// Wert einer Stufenzahl (k, m, r): (m * B + r) * B^-2 * B^-k, mit 1 <= m < B und 0 <= r < B.
// Ebene eines Vergleichs: 0 Stufe, 1 Teile, 2 Rest, 3 gleich, 4 offen.

pub const KLASSEN: u64 = 13;
pub const FEIN: u64 = 4096;
pub const BASIS: u64 = KLASSEN * FEIN;
pub const QUADRAT: u64 = BASIS * BASIS;
pub const PROBE: u64 = BASIS - 1;
pub type Stufe = (i32, u64, u64);
pub const EINS: Stufe = (-1, 1, 0);
pub const PELL: [(u64, u64); 9] = [(1, 1), (2, 3), (5, 7), (12, 17), (29, 41), (70, 99), (169, 239), (408, 577), (985, 1393)];

// LUECKEN AN
pub fn klasse_fein(m: u64) -> (u64, u64) {
    (m / FEIN, m % FEIN)
}

pub fn reste(m: u64) -> (u64, u64) {
    (m % KLASSEN, m % FEIN)
}

pub fn aus_resten(a: u64, f: u64) -> u64 {
    f + FEIN * ((a + KLASSEN - f % KLASSEN) % KLASSEN)
}

pub fn klasse_per_quersumme(x: u64) -> u64 {
    let mut s: u64 = 0;
    let mut rest: u64 = x;
    while rest != 0 {
        s += rest & (FEIN - 1);
        rest >>= 12;
    }
    s % KLASSEN
}

pub fn zwei_skalen(x: u64) -> (u64, u64) {
    (x % BASIS, x % PROBE)
}

pub fn zurueck(a: u64, b: u64) -> u64 {
    a + BASIS * ((b + PROBE - a % PROBE) % PROBE)
}

pub fn seiten_diagonal(stufen: usize) -> Vec<(u64, u64)> {
    let mut s: u64 = 1;
    let mut d: u64 = 1;
    let mut out: Vec<(u64, u64)> = Vec::new();
    for _ in 0..stufen {
        out.push((s, d));
        let neu: u64 = s + d;
        d = 2 * s + d;
        s = neu;
    }
    out
}

pub fn unter_22_5(y: u64, x: u64) -> (bool, u32) {
    let mut i: u32 = 0;
    for (s, d) in PELL {
        let g: u64 = d - s;
        if d * d < 2 * s * s {
            if y * s < g * x {
                return (true, i);
            }
        } else if y * s >= g * x {
            return (false, i);
        }
        i += 1;
    }
    ((x + y) * (x + y) < 2 * x * x, 9)
}

pub fn vergleiche(a: Stufe, b: Stufe) -> (i32, u8) {
    if a.0 != b.0 {
        return (if a.0 < b.0 { 1 } else { -1 }, 0);
    }
    if a.1 != b.1 {
        return (if a.1 > b.1 { 1 } else { -1 }, 1);
    }
    if a.2 != b.2 {
        return (if a.2 > b.2 { 1 } else { -1 }, 2);
    }
    (0, 3)
}

pub fn entscheide(a_unten: Stufe, a_oben: Stufe, b_unten: Stufe, b_oben: Stufe) -> (i32, u8) {
    let (s, wo) = vergleiche(a_unten, b_oben);
    if s > 0 {
        return (1, wo);
    }
    let (s, wo) = vergleiche(a_oben, b_unten);
    if s < 0 {
        return (-1, wo);
    }
    (0, 4)
}

pub fn bruch(z: u64, n: u64, oben: bool) -> Stufe {
    if z == n {
        return EINS;
    }
    let mut k: i32 = 0;
    let mut d: u64 = z * QUADRAT / n;
    let mut rest: u64 = z * QUADRAT % n;
    if d < BASIS {
        k = 1;
        d = z * QUADRAT * BASIS / n;
        rest = z * QUADRAT * BASIS % n;
    }
    if oben && rest != 0 {
        d += 1;
        if d == QUADRAT {
            k -= 1;
            d = BASIS;
        }
    }
    (k, d / BASIS, d % BASIS)
}

pub fn mal(a: Stufe, b: Stufe, oben: bool) -> Stufe {
    let p: u64 = (a.1 * BASIS + a.2) * (b.1 * BASIS + b.2);
    let mut k: i32 = a.0 + b.0;
    let mut d: u64 = p / QUADRAT;
    let mut weg: u64 = p % QUADRAT;
    if d < BASIS {
        k += 1;
        d = p / BASIS;
        weg = p % BASIS;
    }
    if oben && weg != 0 {
        d += 1;
        if d == QUADRAT {
            k -= 1;
            d = BASIS;
        }
    }
    (k, d / BASIS, d % BASIS)
}

pub fn plus(a: Stufe, b: Stufe, oben: bool) -> Stufe {
    let (a, b) = if vergleiche(a, b).0 < 0 { (b, a) } else { (a, b) };
    let x: u64 = a.1 * BASIS + a.2;
    let y: u64 = b.1 * BASIS + b.2;
    let dk: i32 = b.0 - a.0;
    let mut s: u64 = x;
    let mut weg: u64 = y;
    if dk == 0 {
        s = x + y;
        weg = 0;
    } else if dk == 1 {
        s = x + y / BASIS;
        weg = y % BASIS;
    }
    if oben && weg != 0 {
        s += 1;
    }
    let mut k: i32 = a.0;
    if s >= QUADRAT {
        let weg2: u64 = s % BASIS;
        s = s / BASIS;
        k -= 1;
        if oben && weg2 != 0 {
            s += 1;
        }
    }
    (k, s / BASIS, s % BASIS)
}
// LUECKEN AUS
