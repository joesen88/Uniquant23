"""Urwerte: 12 Fasern je Wert, 13 Klassen, Drift zur leicht positiven Mitte.  Nur ganze Zahlen (Zahlvertrag).

Faser     Ein Urwert ist ein Wort aus 12 Fasern (Bits).  Klasse a = Zahl der positiven Fasern, 0..12 (13 Klassen,
          neutral 6).  Startwort und Drift sind reine Funktionen aus Samen und Kontextcode: keine Tafel noetig.
Tick      eine freie Faser waehlen, mit theta/frei positiv setzen, sonst negativ.  Bei 12 freien Fasern:
          E[a'] = (11 a + theta) / 12, Fixpunkt a = theta, Abweichungen schrumpfen je Tick um 11/12.
          Ruheverteilung: Binomial(12, theta/12), exakt C(12,a) theta^a (12-theta)^(12-a) / 12^12.
Anker     Bauart "anker": 6 Fasern sind fest positiv, 6 sind frei (je 1/6 positiv).  Klasse 6..12, nie unter neutral,
          Mittel 7, Abweichungen schrumpfen je Tick um 5/6.
Vorschuss Die 12 Fasern zaehlen wie 12 gedachte Beobachtungen.  Schaetzung mit s Erfolgen aus n echten Versuchen:
          (2 (s + a) + 1) / (2 (n + 12) + 2).  Ohne Erfahrung: (2 a + 1) / 26, neutral 13/26, leicht + 15/26.

Teil A    prueft Ruheverteilung, Rueckkehr zum Fixpunkt und die gestreuten Start- und Driftwerte exakt.
Teil B    Vorschuss-Versuch unter selektiver Beobachtung: 8 Optionen, man sieht nur das Ergebnis der gewaehlten.
          Trefferquoten je Option zufaellig aus 2..14 Sechzehnteln.  Gieriger Waehler (groesste Schaetzung),
          Zaehler halbieren sich bei 64 je Lerner.  Welt "ruhend": Quoten fest.  Welt "wandel": zur Halbzeit neue
          Quoten.  Einzeln: ein Lerner.  Gruppe: 3 Lerner waehlen gleichzeitig und addieren ihre Zaehlungen in eine
          gemeinsame Tafel; jeder hat eigene Urwerte.  Alle Varianten sehen dieselben Welten und Zufallsergebnisse.

Aufruf: python3 -I urwerte.py <ausgabe.json> [laeufe] [schritte]
"""
import json
import sys
from math import comb
from multiprocessing import Pool

M64 = (1 << 64) - 1
FASERN = 12
FEST = 6
FREI = 6
K = 8
KAPPE = 64
DRIFT_ALLE = 8
FRUEH = 50

VARIANTEN = {
    "ohne":          ("kt", 0, False),       # KT-Schaetzung (2s+1)/(2n+2), kein Urwert
    "fest_6":        ("fest", 6, False),     # alle Optionen neutral, starr
    "fest_7":        ("fest", 7, False),     # alle Optionen leicht +, starr
    "fest_8":        ("fest", 8, False),
    "fest_9":        ("fest", 9, False),
    "streu_7":       ("faser", 7, False),    # 12 freie Fasern: Start zufaellig um 7, keine Drift
    "streu_6_drift": ("faser", 6, True),
    "streu_7_drift": ("faser", 7, True),     # zufaellig, im Mittel leicht +, driftet immer wieder dorthin
    "streu_8_drift": ("faser", 8, True),
    "anker_7":       ("anker", 1, False),    # 6 feste + 6 freie Fasern: Klasse 6..12, Mittel 7
    "anker_7_drift": ("anker", 1, True),
    "anker_8_drift": ("anker", 2, True),
}
BEZUG = "fest_7"


def misch(x):                                   # splitmix64, ganzzahlige Streufunktion
    x = (x + 0x9E3779B97F4A7C15) & M64
    x = ((x ^ (x >> 30)) * 0xBF58476D1CE4E5B9) & M64
    x = ((x ^ (x >> 27)) * 0x94D049BB133111EB) & M64
    return x ^ (x >> 31)


def streu(*teile):
    h = 0x243F6A8885A308D3
    for t in teile:
        h = misch(h ^ (t & M64))
    return h


def startwort(samen, kontext, theta, frei=FASERN):
    """Startwort eines Kontexts: jede freie Faser mit theta/frei positiv."""
    w = 0
    for i in range(frei):
        if streu(samen, kontext, i, 0) % frei < theta:
            w |= 1 << i
    return w


def tick(w, samen, kontext, nummer, theta, frei=FASERN):
    """Ein Driftschritt des Kontexts: freie Faser waehlen, mit theta/frei positiv setzen."""
    i = streu(samen, kontext, nummer, 1) % frei
    if streu(samen, kontext, nummer, 2) % frei < theta:
        return w | (1 << i)
    return w & ~(1 << i)


def klasse(w):
    return bin(w).count("1")


# ---------------------------------------------------------------- Teil A: exakte Eigenschaften
def ruhe(theta, frei=FASERN):
    return [comb(frei, a) * theta ** a * (frei - theta) ** (frei - a) for a in range(frei + 1)]


def schritt_exakt(v, theta, frei=FASERN):
    """Verteilung nach einem Tick; alle Eintraege tragen danach den Faktor frei^2 mehr."""
    neu = [0] * (frei + 1)
    for a, m in enumerate(v):
        if not m:
            continue
        auf = (frei - a) * theta
        ab = a * (frei - theta)
        neu[a] += m * (frei * frei - auf - ab)
        if a < frei:
            neu[a + 1] += m * auf
        if a > 0:
            neu[a - 1] += m * ab
    return neu


def kennzahlen(theta, frei, sockel):
    pi = ruhe(theta, frei)
    summe = frei ** frei
    assert sum(pi) == summe
    assert schritt_exakt(pi, theta, frei) == [frei * frei * p for p in pi]      # Ruheverteilung bleibt exakt stehen
    voll = [0] * sockel + pi + [0] * (FASERN - frei - sockel)                   # auf die 13 Klassen gelegt
    return dict(mittel_tausendstel=1000 * sum(a * p for a, p in enumerate(voll)) // summe,
                ueber_neutral_promille=1000 * sum(voll[7:]) // summe, neutral_promille=1000 * voll[6] // summe,
                unter_neutral_promille=1000 * sum(voll[:6]) // summe,
                verteilung_promille=[(2000 * p + summe) // (2 * summe) for p in voll])


def rueckkehr(theta, frei, sockel, starts):
    """Exakte Erwartung nach t Ticks gegen die geschlossene Form theta + (a0 - theta) ((frei-1)/frei)^t."""
    aus = {}
    for a0 in starts:
        v = [0] * (frei + 1)
        v[a0] = 1
        zeile = {}
        for t in range(1, 97):
            v = schritt_exakt(v, theta, frei)
            links = sum(a * m for a, m in enumerate(v)) * frei ** t
            rechts = (theta * frei ** t + (a0 - theta) * (frei - 1) ** t) * (frei * frei) ** t
            assert links == rechts
            if t in (6, 12, 24, 48, 96):
                zeile[str(t)] = 1000 * sockel + 1000 * sum(a * m for a, m in enumerate(v)) // (frei * frei) ** t
        aus[f"start_{a0 + sockel}"] = zeile
    return aus


def stichprobe(theta, frei, sockel):
    pi, summe, n = ruhe(theta, frei), frei ** frei, 100000
    zahl = [0] * (frei + 1)
    for c in range(n):
        zahl[klasse(startwort(20261118, c, theta, frei))] += 1
    abw_start = max(abs(1000 * z * summe - 1000 * p * n) // (n * summe) for z, p in zip(zahl, pi))
    mittel_start = 1000 * sockel + 1000 * sum(a * z for a, z in enumerate(zahl)) // n
    w, zahl, erster, ticks = 0, [0] * (frei + 1), None, 120000
    for t in range(ticks):
        w = tick(w, 20261118, 0, t, theta, frei)
        zahl[klasse(w)] += 1
        if erster is None and klasse(w) >= theta:
            erster = t + 1
    abw_drift = max(abs(1000 * z * summe - 1000 * p * ticks) // (ticks * summe) for z, p in zip(zahl, pi))
    return dict(kontexte=n, start_mittel_tausendstel=mittel_start, start_groesste_abweichung_promille=abw_start,
                ticks=ticks, drift_mittel_tausendstel=1000 * sockel + 1000 * sum(a * z for a, z in enumerate(zahl)) // ticks,
                drift_groesste_abweichung_promille=abw_drift, ticks_bis_fixpunkt_aus_tiefster_lage=erster)


def teil_a():
    aus = {f"streu_theta_{th}": kennzahlen(th, FASERN, 0) for th in (5, 6, 7, 9)}
    aus["anker_frei_1"] = kennzahlen(1, FREI, FEST)
    aus["anker_frei_2"] = kennzahlen(2, FREI, FEST)
    aus["rueckkehr_streu_7"] = rueckkehr(7, FASERN, 0, (0, 6, 12))
    aus["rueckkehr_anker_7"] = rueckkehr(1, FREI, FEST, (0, 6))
    aus["stichprobe_streu_7"] = stichprobe(7, FASERN, 0)
    aus["stichprobe_anker_7"] = stichprobe(1, FREI, FEST)
    return aus


# ---------------------------------------------------------------- Teil B: Vorschuss-Versuch
def welt(lauf, phase):
    return [2 + streu(lauf, phase, 200 + i) % 13 for i in range(K)]            # Trefferquoten in Sechzehnteln


def lauf_agent(lauf, var, schritte, wandel, gruppe):
    art, theta, drift = var
    frei = FASERN if art == "faser" else FREI
    sockel = 0 if art == "faser" else FEST
    kappe = KAPPE * gruppe
    s, n = [0] * K, [0] * K
    sa = [streu(lauf, 400, g) for g in range(gruppe)]
    if art in ("faser", "anker"):
        w = [[startwort(sa[g], i, theta, frei) for i in range(K)] for g in range(gruppe)]
        a = [[sockel + klasse(x) for x in zeile] for zeile in w]
    elif art == "fest":
        a = [[theta] * K for _ in range(gruppe)]
    quoten = welt(lauf, 0)
    spitze = max(quoten)
    halb = schritte // 2
    spaet_ab = halb - halb // 4
    treffer = bestwahl = frueh = spaet1 = spaet2 = 0
    for t in range(schritte):
        if wandel and t == halb:
            quoten = welt(lauf, 1)
            spitze = max(quoten)
        if drift and t and t % DRIFT_ALLE == 0:
            nr = t // DRIFT_ALLE
            for g in range(gruppe):
                wg, ag, sg = w[g], a[g], sa[g]
                for i in range(K):
                    wg[i] = tick(wg[i], sg, i, nr, theta, frei)
                    ag[i] = sockel + klasse(wg[i])
        wahl = []
        for g in range(gruppe):
            if art == "kt":
                bi, bz, bn = 0, 2 * s[0] + 1, 2 * n[0] + 2
                for i in range(1, K):
                    z, d = 2 * s[i] + 1, 2 * n[i] + 2
                    if z * bn > bz * d:
                        bi, bz, bn = i, z, d
            else:
                ag = a[g]
                bi, bz, bn = 0, 2 * (s[0] + ag[0]) + 1, 2 * n[0] + 26
                for i in range(1, K):
                    z, d = 2 * (s[i] + ag[i]) + 1, 2 * n[i] + 26
                    if z * bn > bz * d:
                        bi, bz, bn = i, z, d
            wahl.append(bi)
        for g, bi in enumerate(wahl):
            ok = 1 if streu(lauf, g, bi, t, 300) % 16 < quoten[bi] else 0
            s[bi] += ok
            n[bi] += 1
            if n[bi] >= kappe:
                s[bi] >>= 1
                n[bi] >>= 1
            treffer += ok
            if t < FRUEH:
                frueh += ok
            if quoten[bi] == spitze:
                bestwahl += 1
                if spaet_ab <= t < halb:
                    spaet1 += 1
                if t >= halb + spaet_ab:
                    spaet2 += 1
    return treffer, bestwahl, frueh, spaet1, spaet2


def vorzeichen(x, y):
    besser = sum(1 for p, q in zip(x, y) if p > q)
    schlechter = sum(1 for p, q in zip(x, y) if p < q)
    n = besser + schlechter
    k = max(besser, schlechter)
    zaehler = min(1 << n, 2 * sum(comb(n, i) for i in range(k, n + 1)))
    return dict(besser=besser, schlechter=schlechter, gleich=len(x) - n,
                p_unter_1_promille=1000 * zaehler < (1 << n), p_unter_5_prozent=20 * zaehler < (1 << n))


def rechne(auftrag):
    name_welt, wandel, gruppe, laeufe, schritte = auftrag
    viertel = (schritte // 2) // 4
    zuege = laeufe * schritte * gruppe
    je_var, roh = {}, {}
    for name, var in VARIANTEN.items():
        tr = bw = fr = s1 = s2 = 0
        liste = []
        for lauf in range(laeufe):
            t, b, f, x1, x2 = lauf_agent(lauf, var, schritte, wandel, gruppe)
            tr += t
            bw += b
            fr += f
            s1 += x1
            s2 += x2
            liste.append(t)
        roh[name] = liste
        je_var[name] = dict(treffer_promille=1000 * tr // zuege, bestwahl_promille=1000 * bw // zuege,
                            treffer_erste_50_promille=1000 * fr // (laeufe * FRUEH * gruppe),
                            bestwahl_ende_haelfte_1_promille=1000 * s1 // (laeufe * viertel * gruppe),
                            bestwahl_ende_haelfte_2_promille=1000 * s2 // (laeufe * viertel * gruppe))
    kundig = blind = 0
    for lauf in range(laeufe):
        q0 = welt(lauf, 0)
        q1 = welt(lauf, 1) if wandel else q0
        kundig += max(q0) + max(q1)
        blind += sum(q0) + sum(q1)
    je_var["kundig"] = dict(treffer_promille=1000 * kundig // (laeufe * 2 * 16))
    je_var["blind"] = dict(treffer_promille=1000 * blind // (laeufe * 2 * K * 16))
    tests = {f"{name}_gegen_{BEZUG}": vorzeichen(roh[name], roh[BEZUG]) for name in VARIANTEN if name != BEZUG}
    return name_welt, gruppe, dict(varianten=je_var, vorzeichentest_treffer_je_lauf=tests)


def main():
    ziel = sys.argv[1]
    laeufe = int(sys.argv[2]) if len(sys.argv) > 2 else 2000
    schritte = int(sys.argv[3]) if len(sys.argv) > 3 else 400
    auftraege = [(w, wd, g, laeufe, schritte) for g in (1, 3) for w, wd in (("ruhend", False), ("wandel", True))]
    with Pool(2) as pool:
        teile = pool.map(rechne, auftraege, chunksize=1)
    teil_b = {"einzeln": {}, "gruppe_3": {}}
    for name_welt, gruppe, erg in teile:
        teil_b["einzeln" if gruppe == 1 else "gruppe_3"][name_welt] = erg
    erg = dict(fasern=FASERN, feste_fasern_anker=FEST, optionen=K, kappe_je_lerner=KAPPE, drift_alle=DRIFT_ALLE,
               laeufe=laeufe, schritte=schritte, teil_a=teil_a(), teil_b=teil_b)
    with open(ziel, "w", encoding="utf-8") as f:
        json.dump(erg, f, indent=1, ensure_ascii=False)
    for art in ("einzeln", "gruppe_3"):
        for w in ("ruhend", "wandel"):
            print(art, w)
            for name, v in teil_b[art][w]["varianten"].items():
                print(f"  {name:14s}", " ".join(f"{k.replace('_promille', '')}={x}" for k, x in v.items()))


if __name__ == "__main__":
    main()
