/* Ganzzahliges Context Mixing, nativer Kern.  Bitgleich mit cm.py (gleiche Tafeln, Streuung, Rundung, Reste).
   Bau:     gcc -O2 -std=c11 -fno-strict-aliasing -o cm cm.c
   Aufruf:  ./cm e <tafeln.bin> <eingabe> <ausgabe> [grenze_byte]   kodieren (Groesse an der Grenze wird gemeldet)
            ./cm d <tafeln.bin> <eingabe> <ausgabe> <anzahl>         dekodieren
   Keine Gleitkommazahl im ganzen Programm. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BITS_TAB 22
#define NORD 5
#define NIN (NORD + 4)
#define M_LAENGE 6
#define M_BITS 20
#define GRENZE 60
#define SCHIEBEN 10
#define START_W 19660

static const int ORD[NORD] = {1, 2, 3, 4, 6};
static int32_t ST[4096], SQ[6144];

typedef struct {
    uint16_t *tabs[NORD + 1];
    uint16_t t0[256];
    int64_t w[8][NIN], r[8][NIN];
    uint8_t hist[16];
    int nhist;
    uint32_t hw, hs[NORD + 1];
    int c0, bit;
    uint32_t idx[NORD + 2];
    uint16_t werte[NORD + 2];
    int64_t sts[NIN];
    uint8_t *buf;
    long nbuf;
    int32_t *mtab;
    uint16_t mz[64];
    long mptr, mlen;
    int eb, mctx;
} Modell;

static void modell_init(Modell *m, long n) {
    memset(m, 0, sizeof *m);
    m->buf = malloc(n + 1);
    m->mtab = calloc((size_t)1 << M_BITS, sizeof(int32_t));
    for (int j = 0; j < NORD + 1; j++) m->tabs[j] = calloc((size_t)1 << BITS_TAB, sizeof(uint16_t));
    for (int b = 0; b < 8; b++)
        for (int i = 0; i < NIN; i++) m->w[b][i] = START_W;
}

static void byte_anfang(Modell *m) {
    for (int j = 0; j < NORD; j++) {
        int k = ORD[j];
        uint32_t h = 2166136261u ^ (uint32_t)k;
        int start = m->nhist > k ? m->nhist - k : 0;
        for (int i = start; i < m->nhist; i++) h = (h ^ m->hist[i]) * 16777619u;
        m->hs[j] = h;
    }
    m->hs[NORD] = m->hw ^ 0x5bd1e995u;
    m->eb = m->mlen > 0 ? m->buf[m->mptr] : -1;
    m->c0 = 1;
    m->bit = 0;
}

static int vorhersage(Modell *m) {
    m->idx[0] = (uint32_t)m->c0;
    m->werte[0] = m->t0[m->c0];
    for (int j = 0; j < NORD + 1; j++) {
        uint32_t a = m->hs[j] + (uint32_t)m->c0 * 0x9E3779B1u;
        uint32_t b = a * 0x85EBCA6Bu;
        m->idx[j + 1] = b >> (32 - BITS_TAB);
        m->werte[j + 1] = m->tabs[j][m->idx[j + 1]];
    }
    for (int j = 0; j < NORD + 2; j++) {
        int64_t n0 = m->werte[j] & 255, n1 = m->werte[j] >> 8;
        m->sts[j] = ST[((2 * n1 + 1) << 12) / (2 * (n0 + n1) + 2)];
    }
    if (m->mlen > 0 && ((m->eb + 256) >> (8 - m->bit)) == m->c0) {
        long l = m->mlen < 31 ? m->mlen : 31;
        m->mctx = (int)((l << 1) | ((m->eb >> (7 - m->bit)) & 1));
        int64_t n0 = m->mz[m->mctx] & 255, n1 = m->mz[m->mctx] >> 8;
        m->sts[NIN - 2] = ST[((2 * n1 + 1) << 12) / (2 * (n0 + n1) + 2)];
    } else {
        m->mctx = -1;
        m->sts[NIN - 2] = 0;
    }
    m->sts[NIN - 1] = 256;
    int64_t dot = 0;
    for (int i = 0; i < NIN; i++) dot += m->w[m->bit][i] * m->sts[i];
    int64_t d = dot >> 16;
    if (d < -3071) d = -3071;
    if (d > 3071) d = 3071;
    return SQ[d + 3072];
}

static void lerne(Modell *m, int y, int p) {
    int64_t err = ((int64_t)y << 12) - p;
    for (int i = 0; i < NIN; i++) {
        int64_t t = m->r[m->bit][i] + m->sts[i] * err;
        int64_t q = t >> SCHIEBEN;
        m->r[m->bit][i] = t - (q << SCHIEBEN);
        m->w[m->bit][i] += q;
    }
    for (int j = 0; j < NORD + 2; j++) {
        int n0 = m->werte[j] & 255, n1 = m->werte[j] >> 8;
        if (y) n1++; else n0++;
        if (n0 + n1 > GRENZE) { n0 = (n0 + 1) >> 1; n1 = (n1 + 1) >> 1; }
        uint16_t nv = (uint16_t)(n0 | (n1 << 8));
        if (j == 0) m->t0[m->c0] = nv; else m->tabs[j - 1][m->idx[j]] = nv;
    }
    if (m->mctx >= 0) {
        int n0 = m->mz[m->mctx] & 255, n1 = m->mz[m->mctx] >> 8;
        if (y) n1++; else n0++;
        if (n0 + n1 > GRENZE) { n0 = (n0 + 1) >> 1; n1 = (n1 + 1) >> 1; }
        m->mz[m->mctx] = (uint16_t)(n0 | (n1 << 8));
    }
    m->c0 = (m->c0 << 1) | y;
    m->bit++;
}

static void byte_ende(Modell *m, int byte) {
    m->buf[m->nbuf++] = (uint8_t)byte;
    if (m->mlen > 0) {
        if (m->eb == byte) { m->mlen = m->mlen + 1 < 65535 ? m->mlen + 1 : 65535; m->mptr++; }
        else m->mlen = 0;
    }
    if (m->nbuf >= M_LAENGE) {
        uint32_t h = 0;
        for (long i = m->nbuf - M_LAENGE; i < m->nbuf; i++) h = h * 773u + m->buf[i] + 1u;
        h = (h * 0x9E3779B1u) >> (32 - M_BITS);
        if (m->mlen == 0 && m->mtab[h] > 0) { m->mptr = m->mtab[h]; m->mlen = 1; }
        m->mtab[h] = (int32_t)m->nbuf;
    }
    if (m->nhist == 16) { memmove(m->hist, m->hist + 1, 15); m->nhist = 15; }
    m->hist[m->nhist++] = (uint8_t)byte;
    int buch = (byte >= 65 && byte <= 90) || (byte >= 97 && byte <= 122) || byte >= 128;
    m->hw = buch ? (m->hw ^ (uint32_t)byte) * 16777619u : 0;
}

static uint8_t *lies(const char *pfad, long *n) {
    FILE *f = fopen(pfad, "rb");
    if (!f) { perror(pfad); exit(1); }
    fseek(f, 0, SEEK_END); *n = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *b = malloc(*n + 1);
    if (fread(b, 1, *n, f) != (size_t)*n) { perror("fread"); exit(1); }
    fclose(f);
    return b;
}

int main(int argc, char **argv) {
    if (argc < 5) { fprintf(stderr, "Aufruf siehe Kopf\n"); return 1; }
    long nt; uint8_t *t = lies(argv[2], &nt);
    memcpy(ST, t, sizeof ST); memcpy(SQ, t + sizeof ST, sizeof SQ);
    long n; uint8_t *ein = lies(argv[3], &n);
    FILE *aus = fopen(argv[4], "wb");
    Modell *m = malloc(sizeof *m); modell_init(m, argv[1][0] == 'e' ? n : atol(argv[5]));
    uint32_t x1 = 0, x2 = 0xFFFFFFFFu;
    if (argv[1][0] == 'e') {
        long grenze = argc > 5 ? atol(argv[5]) : -1, bei_grenze = -1, raus = 0;
        for (long i = 0; i < n; i++) {
            if (i == grenze) bei_grenze = raus;
            int byte = ein[i];
            byte_anfang(m);
            for (int k = 7; k >= 0; k--) {
                int y = (byte >> k) & 1, p = vorhersage(m);
                uint32_t xm = x1 + ((x2 - x1) >> 12) * (uint32_t)p;
                if (y) x2 = xm; else x1 = xm + 1;
                while (((x1 ^ x2) & 0xFF000000u) == 0) { fputc(x2 >> 24, aus); raus++; x1 <<= 8; x2 = (x2 << 8) | 255; }
                lerne(m, y, p);
            }
            byte_ende(m, byte);
        }
        for (int k = 0; k < 4; k++) { fputc(x1 >> 24, aus); raus++; x1 <<= 8; }
        printf("{\"bytes\": %ld, \"kodiert\": %ld, \"kodiert_bis_grenze\": %ld}\n", n, raus, bei_grenze);
    } else {
        long anzahl = atol(argv[5]), pos = 0;
        uint32_t x = 0;
        for (int k = 0; k < 4; k++) x = (x << 8) | (pos < n ? ein[pos++] : 0);
        for (long i = 0; i < anzahl; i++) {
            byte_anfang(m);
            int byte = 0;
            for (int k = 0; k < 8; k++) {
                int p = vorhersage(m);
                uint32_t xm = x1 + ((x2 - x1) >> 12) * (uint32_t)p;
                int y = x <= xm;
                if (y) x2 = xm; else x1 = xm + 1;
                while (((x1 ^ x2) & 0xFF000000u) == 0) {
                    x1 <<= 8; x2 = (x2 << 8) | 255; x = (x << 8) | (pos < n ? ein[pos++] : 0);
                }
                lerne(m, y, p);
                byte = (byte << 1) | y;
            }
            fputc(byte, aus);
            byte_ende(m, byte);
        }
    }
    fclose(aus);
    return 0;
}
