"""Stufe 0 Prototyp: Einheiten durch Verschmelzen nach Kodelaengengewinn (Durchgang 0a, innerhalb von Woertern).

Kodelaenge: Einheiten-Unigramm mit Dirichlet(1/2) plus Lexikon (2 Nummern je Regel).  Nur ganze Zahlen.
Aufruf: python3 -I stufe0.py <tldr-Ordner> <ausgabe.json> [max_verschmelzungen]
"""
import heapq
import json
import sys
import time
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import kern as K  # noqa: E402

M_KANDIDATEN = 64


def lade(tldr):
    dateien = sorted(tldr.glob("pages/common/*.md")) + sorted(tldr.glob("pages/linux/*.md"))
    lern = [f for i, f in enumerate(dateien) if i % 10 != 7]
    test = [f for i, f in enumerate(dateien) if i % 10 == 7]
    return lern, test


def woerter(dateien):
    """Woerter = Bytefolgen zwischen Leerzeichen/Zeilenumbruechen; die Trenner sind eigene Einheiten."""
    zaehl = defaultdict(int)
    trenner = defaultdict(int)
    for f in dateien:
        b = f.read_bytes()
        start = 0
        for i, x in enumerate(b):
            if x in (32, 10):
                if i > start:
                    zaehl[b[start:i]] += 1
                trenner[x] += 1
                start = i + 1
        if len(b) > start:
            zaehl[b[start:]] += 1
    return zaehl, trenner


def main():
    tldr, aus = Path(sys.argv[1]), Path(sys.argv[2])
    max_v = int(sys.argv[3]) if len(sys.argv) > 3 else 40000
    T = K.Tafeln(1 << 23)
    lern, test = lade(tldr)
    wz, tz = woerter(lern)
    typen = list(wz.keys())
    freq = [wz[w] for w in typen]
    folgen = [list(w) for w in typen]
    n = defaultdict(int)                         # Einheitenzaehlung im ganzen Lernkorpus
    for w, f in zip(folgen, freq):
        for s in w:
            n[s] += f
    for x, f in tz.items():
        n[x] += f
    kk = 256                                     # Alphabetgroesse (alle Bytes kodierbar)
    for s in range(256):
        n[s] += 0
    N = sum(n.values())
    bytes_lern = N

    paar = defaultdict(int)
    wo = defaultdict(set)
    for i, (w, f) in enumerate(zip(folgen, freq)):
        for a, b in zip(w, w[1:]):
            paar[(a, b)] += f
            wo[(a, b)].add(i)
    heap = [(-c, p) for p, c in paar.items()]
    heapq.heapify(heap)

    def S(c, b, m):
        return T.S(c, b, m)

    def delta(a, b, c):
        """genaue Aenderung der Kodelaenge (Einheiten 2^-24 bit) und Zahl der Terme (Schranke)."""
        if a != b:
            neu = (S(kk + 1, 2, N - c) - S(1, 2, n[a] - c) - S(1, 2, n[b] - c) - S(1, 2, c))
            alt = (S(kk, 2, N) - S(1, 2, n[a]) - S(1, 2, n[b]))
            terme = (N - c) + n[a] + n[b] + N + n[a] + n[b]
        else:
            neu = S(kk + 1, 2, N - c) - S(1, 2, n[a] - 2 * c) - S(1, 2, c)
            alt = S(kk, 2, N) - S(1, 2, n[a])
            terme = (N - c) + 2 * n[a] + N
        lex = 2 * T.lg(kk)
        return neu - alt + lex, terme

    def echte_zahl(a, b):
        if a != b:
            return paar[(a, b)]
        c = 0
        for i in wo[(a, a)]:
            w, j, k = folgen[i], 0, 0
            while j < len(w) - 1:
                if w[j] == a and w[j + 1] == a:
                    k += 1
                    j += 2
                else:
                    j += 1
            c += k * freq[i]
        return c

    regeln = []
    log = []
    LOG2E = (1 << (200 + K.E)) // __import__("pruefe_kern").LN2      # floor(2^24 log2 e)
    t0 = time.perf_counter_ns()
    stopp = "maximum"
    while len(regeln) < max_v:
        kand = []
        gesehen = set()
        while heap and len(kand) < M_KANDIDATEN:
            c, p = heapq.heappop(heap)
            if p in gesehen or paar.get(p, 0) != -c or -c <= 0:
                continue
            gesehen.add(p)
            kand.append(p)
        if not kand:
            stopp = "keine Paare"
            break
        bestes = None
        for p in kand:
            c = echte_zahl(*p)
            if c == 0:
                continue
            d, terme = delta(p[0], p[1], c)
            if d + terme <= 0 and (bestes is None or d < bestes[1]):
                bestes = (p, d, c, terme)
        for p in kand:
            if bestes is None or p != bestes[0]:
                heapq.heappush(heap, (-paar[p], p))
        if bestes is None:
            stopp = "kein sicherer Gewinn"
            break
        (a, b), d, c, terme = bestes
        z = kk
        kk += 1
        if len(log) < 60:
            naeh = -c * (T.lg(c) + T.lg(N) - T.lg(n[a]) - T.lg(n[b]) - LOG2E) + 2 * T.lg(kk - 1)
            xl = lambda x: x * T.lg(x) if x > 0 else 0
            if a != b:
                emp = (xl(N - c) - xl(N)) - (xl(n[a] - c) - xl(n[a]) + xl(n[b] - c) - xl(n[b]) + xl(c)) + 2 * T.lg(kk - 1)
            else:
                emp = (xl(N - c) - xl(N)) - (xl(n[a] - 2 * c) - xl(n[a]) + xl(c)) + 2 * T.lg(kk - 1)
            log.append({"regel": len(regeln), "c": c, "n_a": n[a], "n_b": n[b], "genau_mbit": d * 1000 >> K.E,
                        "naeherung_klein_c_mbit": naeh * 1000 >> K.E, "empirisch_mbit": emp * 1000 >> K.E})
        regeln.append((a, b))
        # Verschmelzen in allen betroffenen Woertern
        geaendert = set()
        for i in list(wo[(a, b)]):
            w, f = folgen[i], freq[i]
            for x, y in zip(w, w[1:]):
                paar[(x, y)] -= f
                geaendert.add((x, y))
                if paar[(x, y)] == 0:
                    del paar[(x, y)]
            neu, j = [], 0
            while j < len(w):
                if j < len(w) - 1 and w[j] == a and w[j + 1] == b:
                    neu.append(z)
                    j += 2
                else:
                    neu.append(w[j])
                    j += 1
            for x, y in zip(w, w[1:]):
                wo[(x, y)].discard(i)
            folgen[i] = neu
            for x, y in zip(neu, neu[1:]):
                paar[(x, y)] += f
                wo[(x, y)].add(i)
                geaendert.add((x, y))
        for q in geaendert:
            if paar.get(q, 0) > 0:
                heapq.heappush(heap, (-paar[q], q))
        n[a] -= c
        n[b] -= c
        n[z] = c
        N -= c
    ms = (time.perf_counter_ns() - t0) // 10 ** 6

    # Test: Regeln in Rangfolge anwenden (BPE-Kodierung), statische KT-Kosten mit Lernzaehlungen
    rang = {p: r for r, p in enumerate(regeln)}
    tw, tt = woerter(test)

    def zerlege(w):
        w = list(w)
        while len(w) > 1:
            r, j = min(((rang.get((w[k], w[k + 1]), 1 << 60), k) for k in range(len(w) - 1)))
            if r == 1 << 60:
                break
            a, b = regeln[r]
            neu, k = [], 0
            while k < len(w):
                if k < len(w) - 1 and w[k] == a and w[k + 1] == b:
                    neu.append(256 + r)
                    k += 2
                else:
                    neu.append(w[k])
                    k += 1
            w = neu
        return w

    gesamt_u = 2 * N + kk
    bits_u = 0
    tok_u = 0
    bytes_test = 0
    for w, f in tw.items():
        z = zerlege(w)
        bytes_test += len(w) * f
        tok_u += len(z) * f
        for s in z:
            bits_u += f * (T.lg(gesamt_u) - T.lg(2 * n[s] + 1))
    for x, f in tt.items():
        bytes_test += f
        tok_u += f
        bits_u += f * (T.lg(gesamt_u) - T.lg(2 * n[x] + 1))
    # Byte-Unigramm als Vergleich
    nb = [0] * 256
    for f in lern:
        for x in f.read_bytes():
            nb[x] += 1
    Nb = sum(nb)
    bits_b = 0
    for f in test:
        for x in f.read_bytes():
            bits_b += T.lg(2 * Nb + 256) - T.lg(2 * nb[x] + 1)
    lange = sorted((len(bytes(_entfalte(z, regeln))) for z in range(256, kk)), reverse=True)
    erg = {"seiten_lern": len(lern), "seiten_test": len(test), "bytes_lern": bytes_lern, "bytes_test": bytes_test,
           "regeln": len(regeln), "stopp": stopp, "lern_ms": ms, "einheiten_lern_token": N,
           "test_token": tok_u, "test_bytes_je_token_milli": bytes_test * 1000 // tok_u,
           "test_milli_bit_je_byte_einheiten": (bits_u * 1000 // bytes_test) >> K.E,
           "test_milli_bit_je_byte_bytes": (bits_b * 1000 // bytes_test) >> K.E,
           "laengste_einheiten_bytes": lange[:5], "naeherung_gegen_genau": log[:8] + log[-4:],
           "beispiele": [bytes(_entfalte(256 + r, regeln)).decode("utf-8", "replace") for r in range(0, len(regeln), max(1, len(regeln) // 40))][:40]}
    print(json.dumps({k: v for k, v in erg.items() if k not in ("naeherung_gegen_genau",)}, ensure_ascii=False))
    aus.write_text(json.dumps(erg, indent=1, ensure_ascii=False))


def _entfalte(z, regeln):
    if z < 256:
        return [z]
    a, b = regeln[z - 256]
    return _entfalte(a, regeln) + _entfalte(b, regeln)


if __name__ == "__main__":
    main()
