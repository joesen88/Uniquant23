"""Zwei Strukturen aus der Hieroglyphen-Arbeit an deutschem Text geprueft.  Nur ganze Zahlen (Zahlvertrag).

Herkunft  Stilometrie am aegyptischen Korpus: Der Abstand zweier Haeufigkeitsprofile (150 haeufigste Zeichen, L1 auf
          rohen Anteilen, ohne Standardabweichung) erkennt die Textgruppe.  Zeichenpaare wie G43 / Z7 schliessen
          sich ueber Texte fast aus und stehen sonst an denselben Stellen: eine Einheit plus ein Schalter je Text.

Teil 1    Profilkontext.  Je Kategorie ein Profil: Anteile der N haeufigsten Woerter in 65536 Teilen.  Ein Artikel
          bekommt die Klasse des naechsten Profils (L1, Kreuzprodukte statt Division).  Gemessen: Trefferquote und
          Kodelaenge eines Wortmodells mit dieser Klasse als Kontext:
              p(w | Klasse) = (n_Klasse(w) + k * p_gesamt(w)) / (N_Klasse + k)        (Rueckfall auf die Grundverteilung)
          k wird auf zurueckgehaltenen Lernartikeln gewaehlt.  Die Klasse wird je Artikel mitkodiert (lg 9 bit).
          Gegenprobe mit erfundenen Klassen: dieselben Klassengroessen, aber den Lernartikeln zufaellig zugeteilt
          (wie die erfundenen Bearbeiter der Hieroglyphen-Auftrennung).  Ihr Gewinn ist der Boden, den jede
          echte Klasse uebertreffen muss.
Teil 2    Schalterpaare.  Gesucht: haeufige Zeichenfolgen x, y, die selten im selben Artikel stehen (hoechstens ein
          Viertel der erwarteten gemeinsamen Artikel) und aehnliche linke und rechte Nachbarn haben.  Fuer die
          besten Paare: Kodelaenge der Wahl x oder y mit festem Anteil gegen Zaehlung je Artikel (KT), das ist der
          Gewinn eines Schalters je Dokument.

Aufruf: python3 -I profil.py <train.csv> <test.csv> <ausgabe.json>
"""
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import kern as K  # noqa: E402

EB = 16
LG, _ = K.lg_tafel(1 << 16, e_bits=EB)
LG = [int(v) for v in LG]
TEILE = 1 << 16
ZEICHEN = re.compile(r"[^\W\d_]+|\d+|[^\w\s]")
PROFIL_N = (50, 150, 500, 2000)
K_WAHL = (1 << 8, 1 << 12, 1 << 14, 1 << 16, 1 << 18, 1 << 20, 1 << 22)
M64 = (1 << 64) - 1


def lg(x):
    """log2 x in Einheiten 2^-16 bit (Tafel nach Rechtsschieben auf 16 Stellen)."""
    sh = max(0, x.bit_length() - 16)
    return LG[x >> sh] + (sh << EB)


def lies(pfad):
    artikel = []
    with open(pfad, encoding="utf-8") as f:
        for zeile in f:
            kat, _, text = zeile.rstrip("\n").partition(";")
            if text[:1] == "'" and text[-1:] == "'":
                text = text[1:-1].replace("''", "'")
            artikel.append((kat, ZEICHEN.findall(text)))
    return artikel


def woerter(zeichen):
    return [t.lower() for t in zeichen if t[0].isalpha()]


def zaehle(folge):
    z = {}
    for w in folge:
        z[w] = z.get(w, 0) + 1
    return z


def promille(z, n):
    return (2000 * z + n) // (2 * n)


# ---------------------------------------------------------------- Teil 1: Profilkontext
def profile(lern, klassen, merkmale):
    """Je Klasse: Anteile der Merkmale in 65536 Teilen und deren Summe."""
    zahl = {k: {} for k in klassen}
    gesamt = {k: 0 for k in klassen}
    menge = set(merkmale)
    for kat, ws in lern:
        gesamt[kat] += len(ws)
        z = zahl[kat]
        for w in ws:
            if w in menge:
                z[w] = z.get(w, 0) + 1
    prof = {k: {w: zahl[k].get(w, 0) * TEILE // gesamt[k] for w in merkmale} for k in klassen}
    return prof, {k: sum(prof[k].values()) for k in klassen}


def naechstes_profil(ws, prof, summe, klassen, menge):
    laenge = len(ws)
    z = zaehle(w for w in ws if w in menge)
    best, bd = None, None
    for k in klassen:
        p = prof[k]
        d = laenge * summe[k]
        for w, c in z.items():
            d += abs(c * TEILE - p[w] * laenge) - p[w] * laenge
        if bd is None or d < bd:
            best, bd = k, d
    return best


def teil_1(lern_alle, test):
    klassen = sorted({k for k, _ in lern_alle})
    lern_alle = [(k, woerter(z)) for k, z in lern_alle]
    test = [(k, woerter(z)) for k, z in test]
    schnitt = len(lern_alle) * 9 // 10
    lern, halt = lern_alle[:schnitt], lern_alle[schnitt:]
    ges = zaehle(w for _, ws in lern for w in ws)
    rang = [w for w, _ in sorted(ges.items(), key=lambda kv: (-kv[1], kv[0]))]
    aus = dict(klassen=klassen, artikel_lernen=len(lern), artikel_zurueckgehalten=len(halt), artikel_test=len(test))
    groesste = max(sum(1 for k, _ in test if k == c) for c in klassen)
    aus["groesste_klasse_promille"] = promille(groesste, len(test))

    # Profilklassen fuer mehrere Merkmalszahlen
    klasse_je_n = {}
    aus["profil_treffer_promille"] = {}
    for n in PROFIL_N:
        merkmale = rang[:n]
        prof, summe = profile(lern, klassen, merkmale)
        menge = set(merkmale)
        vorher = [naechstes_profil(ws, prof, summe, klassen, menge) for _, ws in test]
        klasse_je_n[n] = vorher
        aus["profil_treffer_promille"][str(n)] = promille(sum(1 for (k, _), v in zip(test, vorher) if k == v), len(test))
    aus["profil_beispielmerkmale_150"] = rang[:12]

    # Wortmodell: Grundverteilung und Klassentafeln mit Rueckfall
    vokabular = {w for w, c in ges.items() if c >= 2}
    v = len(vokabular) + 1
    def idx(w):
        return w if w in vokabular else ""
    n_g = zaehle(idx(w) for _, ws in lern for w in ws)
    gross_g = sum(n_g.values())
    d_g = 2 * gross_g + v
    def klassentafeln(artikel):
        tafel = {k: {} for k in klassen}
        gross = {k: 0 for k in klassen}
        for kat, ws in artikel:
            z = tafel[kat]
            gross[kat] += len(ws)
            for w in ws:
                w = idx(w)
                z[w] = z.get(w, 0) + 1
        return tafel, gross

    n_k, gross_k = klassentafeln(lern)
    lg_dg = lg(d_g)
    lg9 = lg(len(klassen))

    def bits_gesamt(z):
        return sum(c * (lg_dg - lg(2 * n_g.get(w, 0) + 1)) for w, c in z.items())

    def bits_klasse(z, k, kk):
        nenner = lg((gross_k[k] + kk) * d_g)
        tafel = n_k[k]
        return sum(c * (nenner - lg(tafel.get(w, 0) * d_g + kk * (2 * n_g.get(w, 0) + 1))) for w, c in z.items())

    # k auf den zurueckgehaltenen Lernartikeln waehlen (wahre Klasse)
    halt_z = [(k, zaehle(idx(w) for w in ws)) for k, ws in halt]
    wahl = {}
    for kk in K_WAHL:
        wahl[kk] = sum(bits_klasse(z, k, kk) for k, z in halt_z)
    k_best = min(K_WAHL, key=lambda kk: (wahl[kk], kk))
    worte_halt = sum(len(ws) for _, ws in halt)
    aus["k_wahl_bit_je_wort_tausendstel"] = {str(kk): 1000 * b // (worte_halt << EB) for kk, b in wahl.items()}
    aus["k"] = k_best

    # Test
    worte = sum(len(ws) for _, ws in test)
    sum_g = sum_wahr = sum_mdl = 0
    sum_prof = {n: 0 for n in PROFIL_N}
    mdl_treffer = 0
    for i, (kat, ws) in enumerate(test):
        z = zaehle(idx(w) for w in ws)
        sum_g += bits_gesamt(z)
        je = {k: bits_klasse(z, k, k_best) for k in klassen}
        sum_wahr += je[kat] + lg9
        kb = min(klassen, key=lambda k: (je[k], k))
        sum_mdl += je[kb] + lg9
        mdl_treffer += 1 if kb == kat else 0
        for n in PROFIL_N:
            sum_prof[n] += je[klasse_je_n[n][i]] + lg9
    def bw(b):
        return 1000 * b // (worte << EB)
    aus["woerter_test"] = worte
    aus["vokabular"] = v
    aus["bit_je_wort_tausendstel"] = dict(
        grundverteilung=bw(sum_g), wahre_klasse=bw(sum_wahr), kuerzeste_klasse=bw(sum_mdl),
        **{f"profilklasse_{n}": bw(sum_prof[n]) for n in PROFIL_N})
    aus["kuerzeste_klasse_treffer_promille"] = promille(mdl_treffer, len(test))

    # Gegenprobe: erfundene Klassen gleicher Groesse (Fisher-Yates mit splitmix64), 5 Wiederholungen
    def misch(x):
        x = (x + 0x9E3779B97F4A7C15) & M64
        x = ((x ^ (x >> 30)) * 0xBF58476D1CE4E5B9) & M64
        x = ((x ^ (x >> 27)) * 0x94D049BB133111EB) & M64
        return x ^ (x >> 31)
    echte = (n_k, gross_k)
    erfunden = []
    for wdh in range(5):
        marken = [k for k, _ in lern]
        zust = 20261118 + wdh
        for i in range(len(marken) - 1, 0, -1):
            zust = misch(zust)
            j = zust % (i + 1)
            marken[i], marken[j] = marken[j], marken[i]
        n_k, gross_k = klassentafeln([(m, ws) for m, (_, ws) in zip(marken, lern)])
        s_zufall = s_mdl = 0
        for i, (kat, ws) in enumerate(test):
            z = zaehle(idx(w) for w in ws)
            je = {k: bits_klasse(z, k, k_best) for k in klassen}
            zust = misch(zust)
            s_zufall += je[klassen[zust % len(klassen)]] + lg9
            s_mdl += min(je.values()) + lg9
        erfunden.append(dict(zugeteilte_klasse=bw(s_zufall), kuerzeste_klasse=bw(s_mdl)))
    n_k, gross_k = echte
    aus["gegenprobe_erfundene_klassen_bit_je_wort_tausendstel"] = erfunden
    aus["tafeleintraege"] = dict(grundverteilung=len(n_g), klassentafeln=sum(len(t) for t in n_k.values()))
    return aus


# ---------------------------------------------------------------- Teil 2: Schalterpaare
def bitzahl(x):
    return bin(x).count("1")


def teil_2(lern, min_df=150, merkmal_n=256, zeige=30):
    n_dok = len(lern)
    df, je_dok, haeuf = {}, {}, {}
    for d, (_, zs) in enumerate(lern):
        z = zaehle(zs)
        for t, c in z.items():
            df[t] = df.get(t, 0) | (1 << d)
            haeuf[t] = haeuf.get(t, 0) + c
    kandidaten = sorted(t for t, b in df.items() if bitzahl(b) >= min_df)
    kmenge = set(kandidaten)
    dfz = {t: bitzahl(df[t]) for t in kandidaten}
    merkmale = [t for t, _ in sorted(haeuf.items(), key=lambda kv: (-kv[1], kv[0]))[:merkmal_n]]
    mmenge = set(merkmale)
    links = {t: {} for t in kandidaten}
    rechts = {t: {} for t in kandidaten}
    for d, (_, zs) in enumerate(lern):
        for i, t in enumerate(zs):
            if t in kmenge:
                jd = je_dok.setdefault(t, {})
                jd[d] = jd.get(d, 0) + 1
                if i:
                    v = zs[i - 1]
                    if v in mmenge:
                        links[t][v] = links[t].get(v, 0) + 1
                if i + 1 < len(zs):
                    v = zs[i + 1]
                    if v in mmenge:
                        rechts[t][v] = rechts[t].get(v, 0) + 1

    def abstand(px, tx, py, ty):
        """L1-Abstand zweier Nachbarprofile in 4096 Teilen (0 gleich, 8192 getrennt); Rest zaehlt als eigene Klasse."""
        s = 0
        for f in set(px) | set(py):
            s += abs(px.get(f, 0) * ty - py.get(f, 0) * tx)
        rx, ry = tx - sum(px.values()), ty - sum(py.values())
        s += abs(rx * ty - ry * tx)
        return s * 4096 // (tx * ty)

    paare = []
    for i, x in enumerate(kandidaten):
        bx, dx = df[x], dfz[x]
        for y in kandidaten[i + 1:]:
            dy = dfz[y]
            if dx * dy < 30 * n_dok:
                continue
            n11 = bitzahl(bx & df[y])
            if 4 * n11 * n_dok <= dx * dy:
                a = abstand(links[x], haeuf[x], links[y], haeuf[y]) + abstand(rechts[x], haeuf[x], rechts[y], haeuf[y])
                paare.append((a, x, y, dx, dy, n11))
    paare.sort()
    liste = []
    for a, x, y, dx, dy, n11 in paare[:zeige]:
        # Gewinn eines Schalters je Dokument: fester Anteil gegen KT-Zaehlung je Artikel
        gx, gy = haeuf[x], haeuf[y]
        fest = gx * (lg(gx + gy) - lg(gx)) + gy * (lg(gx + gy) - lg(gy))
        kt = 0
        for d in set(je_dok[x]) | set(je_dok[y]):
            p, q = je_dok[x].get(d, 0), je_dok[y].get(d, 0)
            kt += sum(lg(2 * m + 2) for m in range(p + q)) - sum(lg(2 * m + 1) for m in range(p)) - sum(lg(2 * m + 1) for m in range(q))
        liste.append(dict(x=x, y=y, artikel_x=dx, artikel_y=dy, gemeinsam=n11, erwartet=dx * dy // n_dok,
                          nachbar_abstand_von_16384=a, vorkommen=gx + gy,
                          bit_je_wahl_fest_tausendstel=1000 * fest // ((gx + gy) << EB),
                          bit_je_wahl_je_artikel_tausendstel=1000 * kt // ((gx + gy) << EB)))
    return dict(artikel=n_dok, kandidaten=len(kandidaten), komplementaere_paare=len(paare), beste=liste)


def main():
    lern, test, ziel = lies(sys.argv[1]), lies(sys.argv[2]), sys.argv[3]
    erg = dict(teil_1=teil_1(lern, test), teil_2=teil_2(lern))
    with open(ziel, "w", encoding="utf-8") as f:
        json.dump(erg, f, indent=1, ensure_ascii=False)
    t1 = erg["teil_1"]
    print("Profil-Treffer", t1["profil_treffer_promille"], "groesste Klasse", t1["groesste_klasse_promille"])
    print("k", t1["k"], t1["k_wahl_bit_je_wort_tausendstel"])
    print("bit je Wort", t1["bit_je_wort_tausendstel"], "kuerzeste Klasse trifft", t1["kuerzeste_klasse_treffer_promille"])
    print("Tafeln", t1["tafeleintraege"], "Woerter", t1["woerter_test"])
    print("erfundene Klassen", t1["gegenprobe_erfundene_klassen_bit_je_wort_tausendstel"])
    t2 = erg["teil_2"]
    print("Kandidaten", t2["kandidaten"], "komplementaer", t2["komplementaere_paare"])
    for p in t2["beste"]:
        print(f"  {p['x']!r:14} {p['y']!r:14} Artikel {p['artikel_x']:5d} {p['artikel_y']:5d} gemeinsam {p['gemeinsam']:4d} "
              f"erwartet {p['erwartet']:4d} Abstand {p['nachbar_abstand_von_16384']:5d} "
              f"bit fest {p['bit_je_wahl_fest_tausendstel']:4d} je Artikel {p['bit_je_wahl_je_artikel_tausendstel']:4d}")


if __name__ == "__main__":
    main()
