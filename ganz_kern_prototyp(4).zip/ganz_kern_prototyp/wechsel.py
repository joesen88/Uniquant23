"""Fassungswechsel statt Dauerdrift: Vergessen nur, wenn ein Wechsel erkannt ist.  Nur ganze Zahlen (Zahlvertrag).

Herkunft  Abschreib-Uhr der Hieroglyphen-Arbeit: Die Abweichungen zwischen Abschriften passen ebenso gut zu
          "lange stabil, dann ein Wechsel der Fassung" wie zu einem gleichmaessigen Verlust je Jahrhundert.
          Als Modellstruktur heisst das: Erfahrung nicht laufend verduennen (Zaehler halbieren), sondern ganz
          behalten, bis die juengsten Beobachtungen nicht mehr zur alten Tafel passen, und dann neu beginnen.
Pruefung  Je Option die letzten 16 Ergebnisse (Fenster).  Zwei Beschreibungen derselben Ergebnisfolge:
              ein Block:    KT(a, b)                  a Erfolge, b Fehlschlaege insgesamt
              zwei Bloecke: KT(a_alt, b_alt) * KT(a_neu, b_neu)
          mit KT(a, b) = [1*3*...*(2a-1)] [1*3*...*(2b-1)] / [2*4*...*2(a+b)].  Wechsel, wenn die zwei Bloecke
          mindestens SCHWELLE-mal wahrscheinlicher sind.  Verglichen wird exakt ueber Kreuzprodukte grosser
          ganzer Zahlen, ohne Logarithmus.
Folge     global: alle Optionen zurueck auf den Urwert, die ausloesende behaelt ihr Fenster.
          lokal:  nur die ausloesende Option beginnt neu.
Welt      wie urwerte.py (8 Optionen, Quoten 2..14 Sechzehntel, ein gieriger Lerner, Urwert fest 7).
          ruhend: keine Aenderung.  wandel: neue Quoten zur Halbzeit.  oft: neue Quoten alle 100 Schritte.
          Alle Varianten sehen dieselben Welten und Zufallsergebnisse.

Aufruf: python3 -I wechsel.py <ausgabe.json> [laeufe] [schritte]
"""
import json
import sys
from multiprocessing import Pool
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import urwerte as U  # noqa: E402

K = U.K
FENSTER = 16
URWERT = 7
KAPPE = 64
NACH = 50
MAXN = 1024
ODD, EVEN = [1], [1]
for _i in range(MAXN):
    ODD.append(ODD[-1] * (2 * _i + 1))
    EVEN.append(EVEN[-1] * (2 * _i + 2))
BITS = [bin(x).count("1") for x in range(1 << FENSTER)]

VARIANTEN = {                          # (halbieren, pruefen, global, schwelle)
    "halbieren":           (True, False, False, 0),
    "starr":               (False, False, False, 0),
    "wechsel_16":          (False, True, True, 16),
    "wechsel_64":          (False, True, True, 64),
    "wechsel_256":         (False, True, True, 256),
    "wechsel_64_lokal":    (False, True, False, 64),
    "wechsel_64_halbieren": (True, True, True, 64),
}
WELTEN = {"ruhend": 0, "wandel": 200, "oft": 100}
BEZUG = "halbieren"


def wechsel_erkannt(s, n, sr, schwelle):
    """Sind 'alt | Fenster' als zwei KT-Bloecke mindestens schwelle-mal wahrscheinlicher als ein Block?"""
    a, b = s, n - s
    ar, br = sr, FENSTER - sr
    ao, bo = a - ar, b - br
    if ao < 0 or bo < 0 or n - FENSTER < 8 or n >= MAXN:
        return False
    zwei = ODD[ao] * ODD[bo] * ODD[ar] * ODD[br] * EVEN[n]
    eins = ODD[a] * ODD[b] * EVEN[n - FENSTER] * EVEN[FENSTER]
    return zwei >= schwelle * eins


def lauf_agent(lauf, var, schritte, periode):
    halbieren, pruefen, glob, schwelle = var
    s, n = [0] * K, [0] * K
    reg, voll = [0] * K, [0] * K
    quoten = U.welt(lauf, 0)
    spitze = max(quoten)
    treffer = bestwahl = meldungen = nach = nach_zuege = 0
    letzter_wechsel = None
    for t in range(schritte):
        if periode and t and t % periode == 0:
            quoten = U.welt(lauf, t // periode)
            spitze = max(quoten)
            letzter_wechsel = t
        bi, bz, bn = 0, 2 * (s[0] + URWERT) + 1, 2 * n[0] + 26
        for i in range(1, K):
            z, d = 2 * (s[i] + URWERT) + 1, 2 * n[i] + 26
            if z * bn > bz * d:
                bi, bz, bn = i, z, d
        ok = 1 if U.streu(lauf, 0, bi, t, 300) % 16 < quoten[bi] else 0
        s[bi] += ok
        n[bi] += 1
        reg[bi] = ((reg[bi] << 1) | ok) & 0xFFFF
        if voll[bi] < FENSTER:
            voll[bi] += 1
        if halbieren and n[bi] >= KAPPE:
            s[bi] >>= 1
            n[bi] >>= 1
        if pruefen and voll[bi] == FENSTER and wechsel_erkannt(s[bi], n[bi], BITS[reg[bi]], schwelle):
            meldungen += 1
            sr = BITS[reg[bi]]
            if glob:
                s, n = [0] * K, [0] * K
                r_alt = reg[bi]
                reg, voll = [0] * K, [0] * K
                reg[bi], voll[bi] = r_alt, 0
            s[bi], n[bi] = sr, FENSTER
            voll[bi] = 0                                    # neues Fenster erst wieder fuellen
        treffer += ok
        if quoten[bi] == spitze:
            bestwahl += 1
        if letzter_wechsel is not None and t - letzter_wechsel < NACH:
            nach += ok
            nach_zuege += 1
    return treffer, bestwahl, meldungen, nach, nach_zuege


def rechne(auftrag):
    name_welt, periode, laeufe, schritte = auftrag
    je_var, roh = {}, {}
    for name, var in VARIANTEN.items():
        tr = bw = me = na = nz = 0
        liste = []
        for lauf in range(laeufe):
            t, b, m, x, y = lauf_agent(lauf, var, schritte, periode)
            tr += t
            bw += b
            me += m
            na += x
            nz += y
            liste.append(t)
        roh[name] = liste
        je_var[name] = dict(treffer_promille=1000 * tr // (laeufe * schritte), bestwahl_promille=1000 * bw // (laeufe * schritte),
                            meldungen_je_100_laeufe=100 * me // laeufe,
                            treffer_50_zuege_nach_wechsel_promille=1000 * na // nz if nz else None)
    tests = {f"{name}_gegen_{BEZUG}": U.vorzeichen(roh[name], roh[BEZUG]) for name in VARIANTEN if name != BEZUG}
    return name_welt, dict(varianten=je_var, vorzeichentest_treffer_je_lauf=tests)


def main():
    ziel = sys.argv[1]
    laeufe = int(sys.argv[2]) if len(sys.argv) > 2 else 2000
    schritte = int(sys.argv[3]) if len(sys.argv) > 3 else 400
    with Pool(2) as pool:
        teile = pool.map(rechne, [(w, p, laeufe, schritte) for w, p in WELTEN.items()], chunksize=1)
    erg = dict(optionen=K, fenster=FENSTER, urwert=URWERT, kappe=KAPPE, laeufe=laeufe, schritte=schritte,
               welten={w: e for w, e in teile})
    with open(ziel, "w", encoding="utf-8") as f:
        json.dump(erg, f, indent=1, ensure_ascii=False)
    for w, e in teile:
        print(w)
        for name, v in e["varianten"].items():
            print(f"  {name:21s}", " ".join(f"{k.replace('_promille', '')}={x}" for k, x in v.items()))
        for name, x in e["vorzeichentest_treffer_je_lauf"].items():
            print(f"     {name:34s} {x['besser']:5d} {x['schlechter']:5d} {x['gleich']:4d}",
                  "p<1/1000" if x["p_unter_1_promille"] else ("p<5%" if x["p_unter_5_prozent"] else "n.s."))


if __name__ == "__main__":
    main()
