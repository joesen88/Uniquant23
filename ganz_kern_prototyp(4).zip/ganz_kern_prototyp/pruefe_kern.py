"""Pruefungen und Messungen des Kern-Prototyps.  Fraction nur hier, nicht im Kern.

Aufruf: python3 -I pruefe_kern.py <tldr-Ordner> <ausgabe.json>
"""
import json
import random
import sys
import time
from fractions import Fraction
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import kern as K  # noqa: E402

P = 200


def atanh_fix(num, den, p):
    z = (num << p) // den
    z2 = (z * z) >> p
    term, s, k = z, z, 1
    while term:
        term = (term * z2) >> p
        s += term // (2 * k + 1)
        k += 1
    return s


LN2 = 2 * atanh_fix(1, 3, P)


def log2_fix(x, p=P):
    """2^p * log2 x, unabhaengiges Reihenverfahren (artanh), Fehler weit unter 2^-150."""
    ex = x.bit_length() - 1
    zwei = 1 << ex
    lnm = 2 * atanh_fix(x - zwei, x + zwei, p)
    return (ex << p) + (lnm << p) // LN2


def main():
    tldr, aus = Path(sys.argv[1]), Path(sys.argv[2])
    rnd = random.Random(20261118)
    erg = {}

    # 1 Tafel bauen
    nmax = 1 << 23
    t0 = time.perf_counter_ns()
    T = K.Tafeln(nmax)
    erg["tafel"] = {"nmax": nmax, "bau_ms": (time.perf_counter_ns() - t0) // 10 ** 6, "genauer_pfad": T.genau,
                    "anteil_genau_ppm": T.genau * 10 ** 6 // nmax, "bytes_LG_C1_C2": 3 * T.LG.nbytes}
    print("Tafel", erg["tafel"])

    # 2 Verfahren bei E = 12 gegen den exakten Potenzvergleich: floor(2^12 log2 i) = bitlen(i^4096) - 1
    lg12, gen12 = K.lg_tafel(1 << 14, e_bits=12)
    stich = list(range(1, (1 << 14) + 1))
    falsch12 = sum(1 for i in stich if int(lg12[i]) != (i ** 4096).bit_length() - 1)
    gross = [rnd.randrange(1 << 14, nmax) for _ in range(300)]
    falsch12g = sum(1 for i in gross if K._lg_genau(i, 12) != (i ** 4096).bit_length() - 1)
    erg["pruefung_E12"] = {"alle_bis_2^14": len(stich), "falsch": falsch12, "stichprobe_bis_2^22": len(gross),
                           "falsch_stichprobe": falsch12g, "genauer_pfad": gen12}
    print("E12", erg["pruefung_E12"])

    # 3 E = 24 gegen das Reihenverfahren
    probe = [1, 2, 3, 5, 7, 10, 1000, 65537, nmax - 1, nmax] + [rnd.randrange(2, nmax + 1) for _ in range(3000)]
    falsch24 = 0
    for i in probe:
        v = log2_fix(i)
        if i & (i - 1) == 0:                       # Zweierpotenz: Reihe liefert den Wert exakt
            lo = hi = v >> (P - K.E)
        else:
            lo, hi = (v - 10 ** 6) >> (P - K.E), (v + 10 ** 6) >> (P - K.E)
        assert lo == hi, i
        falsch24 += int(T.LG[i]) != lo
    erg["pruefung_E24"] = {"stichprobe": len(probe), "falsch": falsch24}
    print("E24", erg["pruefung_E24"])

    # 4 Dirichlet-Kodelaenge: geschlossene Form = Produkt der adaptiven Wahrscheinlichkeiten; Schranke haelt
    faelle, ausserhalb = 0, 0
    for _ in range(400):
        k = rnd.randrange(2, 9)
        zaehl = [rnd.randrange(0, 40) for _ in range(k)]
        if sum(zaehl) == 0:
            continue
        a, b = rnd.choice([(1, 1), (1, 2)])
        folge = [s for s, z in enumerate(zaehl) for _ in range(z)]
        rnd.shuffle(folge)
        stand, pr = [0] * k, Fraction(1)
        for t, s in enumerate(folge):
            pr *= Fraction(stand[s] * b + a, t * b + k * a)
            stand[s] += 1
        zu = 1
        for z in zaehl:
            for j in range(z):
                zu *= a + j * b
        ab = 1
        for j in range(sum(zaehl)):
            ab *= k * a + j * b
        assert pr == Fraction(zu, ab)
        wert, schranke = T.dm(zaehl, a, b)
        genau = log2_fix(pr.denominator) - log2_fix(pr.numerator)
        if not ((wert - schranke) << (P - K.E) < genau < (wert + schranke) << (P - K.E)):
            ausserhalb += 1
        faelle += 1
    erg["dirichlet"] = {"faelle": faelle, "geschlossen_gleich_adaptiv": True, "ausserhalb_schranke": ausserhalb}
    print("DM", erg["dirichlet"])

    # 5 Verteilung nach groesstem Rest und Uebertrag
    for _ in range(2000):
        g = [rnd.randrange(0, 10 ** 6) for _ in range(rnd.randrange(1, 40))]
        if sum(g) == 0:
            continue
        h = K.verteile(g, 1 << 16)
        assert sum(h) == 1 << 16
        w = sum(g)
        assert all((x * w <= gi * (1 << 16) + w) and (x * w >= gi * (1 << 16) - w) for x, gi in zip(h, g))
        a, bb, r = rnd.randrange(10 ** 9), rnd.randrange(1, 10 ** 6), rnd.randrange(10 ** 6)
        r %= bb
        q, rn = K.uebertrag(a, bb, 16, r)
        assert (a << 16) + r == q * bb + rn and 0 <= rn < bb
    erg["verteilung_uebertrag"] = {"faelle": 2000, "summe_exakt": True, "identitaet": True}

    # 6 Kodierer auf tldr (Englisch, common + linux), Bytes
    dateien = sorted(tldr.glob("pages/common/*.md")) + sorted(tldr.glob("pages/linux/*.md"))
    daten = b"".join(f.read_bytes() for f in dateien)
    sym = list(daten)
    t0 = time.perf_counter_ns()
    bits = K.kodiere_kt(sym, 256)
    ms = (time.perf_counter_ns() - t0) // 10 ** 6
    zaehl = [0] * 256
    for s in sym:
        zaehl[s] += 1
    wert, schranke = T.dm(zaehl, 1, 2)
    teil = 300_000
    bits_teil = K.kodiere_kt(sym[:teil], 256)
    zurueck = K.dekodiere_kt(bits_teil, 256, teil)
    ueber = len(bits) - (wert >> K.E)
    erg["kodierer"] = {"dateien": len(dateien), "bytes": len(sym), "kodierer_bits": len(bits),
                       "dirichlet_bits_ganz": wert >> K.E, "schranke_bits_ganz": (schranke >> K.E) + 1,
                       "ueberhang_bits": ueber, "bit_je_byte_milli": len(bits) * 1000 // len(sym),
                       "kodier_ms": ms, "rundreise_bytes": teil, "rundreise_gleich": zurueck == sym[:teil]}
    print("Kodierer", erg["kodierer"])
    aus.write_text(json.dumps(erg, indent=1, ensure_ascii=False))


if __name__ == "__main__":
    main()
