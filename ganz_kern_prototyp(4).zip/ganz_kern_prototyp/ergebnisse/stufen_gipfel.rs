// stufen.rs: Leiter-Arithmetik des Kerns mit B = 13 * 4096 Teilen je Stufe.
// Uebertragung von stufen.py; bitgleich geprueft mit pruefstand.rs gegen Vektoren aus vektoren.py.
// Nur ganze Zahlen.  Zu uebersetzen mit Ueberlaufpruefung (-C overflow-checks=on).
//
// Wert einer Stufenzahl (k, m, r): (m * B + r) * B^-2 * B^-k, mit 1 <= m < B und 0 <= r < B.
// Ebene eines Vergleichs: 0 Stufe, 1 Teile, 2 Rest, 3 gleich, 4 offen.

pub const KLASSEN: u64 = 13;
pub const FEIN: u64 = 4096;
pub const BASIS: u64 = KLASSEN * FEIN;
pub const QUADRAT: u64 = BASIS * BASIS;
pub const PROBE: u64 = BASIS - 1;
pub type Stufe = (i32, u64, u64);
pub const EINS: Stufe = (-1, 1, 0);
pub const PELL: [(u64, u64); 9] = [(1, 1), (2, 3), (5, 7), (12, 17), (29, 41), (70, 99), (169, 239), (408, 577), (985, 1393)];

// LUECKEN AN
pub fn klasse_fein(m: u64) -> (u64, u64) {
    (m / FEIN, m % FEIN)
}

pub fn reste(m: u64) -> (u64, u64) {
    (m % KLASSEN, m % FEIN)
}

pub fn aus_resten(a: u64, f: u64) -> u64 {
    f + FEIN * ((a + f * PROBE) % KLASSEN)
}

pub fn klasse_per_quersumme(x: u64) -> u64 {
    x % KLASSEN
}

pub fn zwei_skalen(x: u64) -> (u64, u64) {
    (x % BASIS, x % PROBE)
}

pub fn zurueck(a: u64, b: u64) -> u64 {
    a + BASIS * ((b + (PROBE - a)) % PROBE)
}

pub fn seiten_diagonal(stufen: usize) -> Vec<(u64, u64)> {
    let mut s: u64 = 1;
    let mut d: u64 = 1;
    let mut out: Vec<(u64, u64)> = Vec::new();
    for _ in 0..stufen {
        out.push((s, d));
        let s_neu: u64 = s + d;
        let d_neu: u64 = d + s * 2;
        s = s_neu;
        d = d_neu;
    }
    out
}

pub fn unter_22_5(y: u64, x: u64) -> (bool, u32) {
    let mut i: u32 = 0;
    for (s, d) in PELL {
        let g: u64 = d - s;
        if d * d < 2 * s * s {
            if y * s < g * x {
                return (true, i);
            }
        } else if y * s >= g * x {
            return (false, i);
        }
        i += 1;
    }
    ((x + y) * (x + y) < 2 * x * x, 9)
}

pub fn vergleiche(a: Stufe, b: Stufe) -> (i32, u8) {
    if b.0 < a.0 {
        (-1, 0)
    } else {
        if a.0 < b.0 {
            (1, 0)
        } else {
            if a.1 < b.1 {
                (-1, 1)
            } else {
                if b.1 < a.1 {
                    (1, 1)
                } else {
                    if b.2 < a.2 {
                        (1, 2)
                    } else {
                        if a.2 < b.2 {
                            (-1, 2)
                        } else {
                            (0, 3)
                        }
                    }
                }
            }
        }
    }
}

pub fn entscheide(a_unten: Stufe, a_oben: Stufe, b_unten: Stufe, b_oben: Stufe) -> (i32, u8) {
    let v2 = vergleiche(a_unten, b_oben);
    let v4 = vergleiche(a_oben, b_unten);
    if 0 < v2.0 {
        (1, v2.1)
    } else {
        if v4.0 < 0 {
            (-1, v4.1)
        } else {
            (0, 4)
        }
    }
}

pub fn bruch(z: u64, n: u64, oben: bool) -> Stufe {
    if z * QUADRAT / n < n {
        if oben {
            let d: u64 = BASIS * QUADRAT / n + 1;
            (1, d / BASIS, d % BASIS)
        } else {
            let d: u64 = BASIS * QUADRAT / n;
            (1, d / BASIS, d % BASIS)
        }
    } else {
        if oben {
            if 0 < z * QUADRAT % n {
                let d: u64 = z * QUADRAT / n + 1;
                (0, d / BASIS, d % BASIS)
            } else {
                if z < n {
                    let d: u64 = z * QUADRAT / n;
                    (0, d / BASIS, d % BASIS)
                } else {
                    let d: u64 = BASIS;
                    (-1, d / BASIS, d % BASIS)
                }
            }
        } else {
            if z < n {
                let d: u64 = z * QUADRAT / n;
                (0, d / BASIS, d % BASIS)
            } else {
                let d: u64 = BASIS;
                (-1, d / BASIS, d % BASIS)
            }
        }
    }
}

pub fn mal(a: Stufe, b: Stufe, oben: bool) -> Stufe {
    let x: u64 = a.1 * BASIS + a.2;
    let y: u64 = b.1 * BASIS + b.2;
    if oben {
        if x * y / BASIS < QUADRAT {
            if 0 < x * y % BASIS {
                if x * y / BASIS + 1 < QUADRAT {
                    let d: u64 = x * y / BASIS + 1;
                    (a.0 + b.0 + 1, d / BASIS, d % BASIS)
                } else {
                    let d: u64 = (x * y - 1) / QUADRAT + 1;
                    (a.0 + b.0, d / BASIS, d % BASIS)
                }
            } else {
                let d: u64 = x * y / BASIS;
                (a.0 + b.0 + 1, d / BASIS, d % BASIS)
            }
        } else {
            let d: u64 = (x * y - 1) / QUADRAT + 1;
            (a.0 + b.0, d / BASIS, d % BASIS)
        }
    } else {
        if x * y / BASIS < QUADRAT {
            let d: u64 = x * y / BASIS;
            (a.0 + b.0 + 1, d / BASIS, d % BASIS)
        } else {
            let d: u64 = x * y / QUADRAT;
            (a.0 + b.0, d / BASIS, d % BASIS)
        }
    }
}

pub fn plus(a: Stufe, b: Stufe, oben: bool) -> Stufe {
    let (a, b) = if vergleiche(a, b).0 < 0 { (b, a) } else { (a, b) };
    let x: u64 = a.1 * BASIS + a.2;
    let y: u64 = b.1 * BASIS + b.2;
    let dk: i32 = b.0 - a.0;
    let mut s: u64 = x;
    let mut weg: u64 = y;
    if dk == 0 {
        s = x + y;
        weg = 0;
    } else if dk == 1 {
        s = x + y / BASIS;
        weg = y % BASIS;
    }
    if oben && weg != 0 {
        s += 1;
    }
    let mut k: i32 = a.0;
    if s >= QUADRAT {
        let weg2: u64 = s % BASIS;
        s = s / BASIS;
        k -= 1;
        if oben && weg2 != 0 {
            s += 1;
        }
    }
    (k, s / BASIS, s % BASIS)
}
// LUECKEN AUS

pub fn vorstufe(z1: u64, n1: u64, z2: u64, n2: u64) -> (i32, u8) {
    entscheide(bruch(z1, n1, false), bruch(z1, n1, true), bruch(z2, n2, false), bruch(z2, n2, true))
}

pub fn gipfel_1(z1: u64, n1: u64, z2: u64, n2: u64, z3: u64, n3: u64) -> (i32, u8) {
    entscheide(mal(bruch(z1, n1, false), bruch(z2, n2, false), false), mal(bruch(z1, n1, true), bruch(z2, n2, true), true), bruch(z3, n3, false), bruch(z3, n3, true))
}

pub fn gipfel_2(z1: u64, n1: u64, z2: u64, n2: u64, z3: u64, n3: u64, z4: u64, n4: u64, z5: u64, n5: u64) -> (i32, u8) {
    entscheide(plus(mal(bruch(z1, n1, false), bruch(z2, n2, false), false), mal(bruch(z3, n3, false), bruch(z4, n4, false), false), false), plus(mal(bruch(z1, n1, true), bruch(z2, n2, true), true), mal(bruch(z3, n3, true), bruch(z4, n4, true), true), true), bruch(z5, n5, false), bruch(z5, n5, true))
}
