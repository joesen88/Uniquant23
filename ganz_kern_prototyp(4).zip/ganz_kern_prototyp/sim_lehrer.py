"""Spielwelt-Simulation: Lehrer und Schueler mit Gipfelpruefung.  Nur ganze Zahlen (Zahlvertrag).

Welt      Zustand: Anordnung von 8 Symbolen (Permutation).  Fuenf Primitive: tausche 0/1, drehe links, drehe rechts,
          kehre die ersten vier um, tausche 2/6.  Sie erzeugen die ganze Gruppe S8 (40320 Zustaende).
          Sechs verborgene Konzepte: Woerter aus 3 oder 4 Primitiven, die sich nicht kuerzer schreiben lassen.
          Aufgabe der Stufe k: Start s (zufaellig), Ziel t = s nach k zufaelligen Konzepten.  Pruefer: Programm
          ausfuehren, Ergebnis == t.  Mindestabstand (kuerzestes Primitivprogramm, exakt per Breitensuche ueber S8):
          Stufe 2 >= 5, Stufe 3 (Gipfel) >= 8.
Schueler  Dijkstra ueber Zustaende, Kanten = Bibliothekseintraege, Kantenkosten = KT-Kodelaenge aus Zaehlungen
          (Log-Tafel, Einheit 2^-12 bit), Budget 1500 Expansionen.  Schlaf alle 10 Episoden: die Teilfolge (Laenge
          2 bis 4) gemerkter Programme, die die Dirichlet-Kodelaenge aller gemerkten Programme samt Definition am
          staerksten senkt, wird Eintrag; Aufnahme nur bei echter Ersparnis (bis zu zwei je Schlaf).
Lehrer    siehe BEDINGUNGEN.  lp = Lernfortschritt |Erfolge letzte 4 - Erfolge 4 davor| je Stufe, nur Stufen mit
          Quote < 3/4, jede 8. Wahl zufaellig.  zerlegen = nach gescheiterter Gipfelpruefung die drei Einzelschritte
          vom Ziel rueckwaerts, dann die letzten zwei Schritte, dann die ganze Aufgabe.  zeigen = nach gescheiterter
          Uebung legt der Lehrer seine Loesung in den Speicher (Destillation).
Messung   alle 50 Episoden 16 zurueckgehaltene Gipfelaufgaben ohne Lernen: geloest, Expansionen, Kodelaenge.

Aufruf: python3 -I sim_lehrer.py <ausgabe.json> <bedingung> [samen] [episoden]
"""
import heapq
import json
import sys
from operator import itemgetter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import kern as K  # noqa: E402

E = 12
LG, _ = K.lg_tafel(1 << 16, e_bits=E)
LG = [int(v) for v in LG]
DM = K.Tafeln(1 << 17)
M64 = (1 << 64) - 1
N = 8
ID = tuple(range(N))
GEN = [(1, 0, 2, 3, 4, 5, 6, 7), (1, 2, 3, 4, 5, 6, 7, 0), (7, 0, 1, 2, 3, 4, 5, 6),
       (3, 2, 1, 0, 4, 5, 6, 7), (0, 1, 6, 3, 4, 5, 2, 7)]
BUDGET = 1500
SCHLAF = 10
MESS = 50
MESS_ZAHL = 16
MIN_ABSTAND = {1: 3, 2: 5, 3: 8}
KANDIDATEN = 8

BEDINGUNGEN = {
    "nur_gipfel":            dict(plan="gipfel", pruef=0,  zerlegen=False, zeigen=False, schlaf=True),
    "gipfel_zerlegt":        dict(plan="gipfel", pruef=1,  zerlegen=True,  zeigen=False, schlaf=True),
    "zufall":                dict(plan="zufall", pruef=8,  zerlegen=False, zeigen=False, schlaf=True),
    "lehrer_ohne_gipfel":    dict(plan="lp",     pruef=0,  zerlegen=False, zeigen=False, schlaf=True),
    "lehrer_k4":             dict(plan="lp",     pruef=4,  zerlegen=True,  zeigen=False, schlaf=True),
    "lehrer_k8":             dict(plan="lp",     pruef=8,  zerlegen=True,  zeigen=False, schlaf=True),
    "lehrer_k16":            dict(plan="lp",     pruef=16, zerlegen=True,  zeigen=False, schlaf=True),
    "lehrer_k8_zeigen":      dict(plan="lp",     pruef=8,  zerlegen=True,  zeigen=True,  schlaf=True),
    "lehrer_k8_ohne_schlaf": dict(plan="lp",     pruef=8,  zerlegen=True,  zeigen=False, schlaf=False),
    # Entzifferungslogik: Allographen zusammenlegen, Kartusche, vertauschte Anker, Nicht-Schrift-Kontrolle
    "lehrer_k8_allo":        dict(plan="lp",     pruef=8,  zerlegen=True,  zeigen=False, schlaf=True, allo=True),
    "gipfel_zerlegt_allo":   dict(plan="gipfel", pruef=1,  zerlegen=True,  zeigen=False, schlaf=True, allo=True),
    "zufall_allo":           dict(plan="zufall", pruef=8,  zerlegen=False, zeigen=False, schlaf=True, allo=True),
    "lehrer_k8_kartusche":   dict(plan="lp",     pruef=8,  zerlegen=True,  zeigen=False, schlaf=True, kartusche=True),
    "lehrer_k8_allo_kartusche": dict(plan="lp",  pruef=8,  zerlegen=True,  zeigen=False, schlaf=True, allo=True,
                                     kartusche=True),
    "lehrer_k8_zeigen_vertauscht": dict(plan="lp", pruef=8, zerlegen=True, zeigen="vertauscht", schlaf=True),
    "nichtschrift_lehrer_k8": dict(plan="lp",    pruef=8,  zerlegen=True,  zeigen=False, schlaf=True, welt="ohne"),
    "nichtschrift_lehrer_k8_zeigen": dict(plan="lp", pruef=8, zerlegen=True, zeigen=True, schlaf=True, welt="ohne"),
    # Grundverteilung: Suchkosten aus Mischung (1 - 2^-g) * KT + 2^-g * gleichverteilt; kein Eintrag verhungert
    "lehrer_k8_grund":       dict(plan="lp",     pruef=8,  zerlegen=True,  zeigen=False, schlaf=True, grund=3),
    "gipfel_zerlegt_grund":  dict(plan="gipfel", pruef=1,  zerlegen=True,  zeigen=False, schlaf=True, grund=3),
    "zufall_grund":          dict(plan="zufall", pruef=8,  zerlegen=False, zeigen=False, schlaf=True, grund=3),
    "lehrer_ohne_gipfel_grund": dict(plan="lp",  pruef=0,  zerlegen=False, zeigen=False, schlaf=True, grund=3),
    "lehrer_k8_grund_kartusche": dict(plan="lp", pruef=8,  zerlegen=True,  zeigen=False, schlaf=True, grund=3,
                                      kartusche=True),
    "nichtschrift_lehrer_k8_grund": dict(plan="lp", pruef=8, zerlegen=True, zeigen=False, schlaf=True, grund=3,
                                         welt="ohne"),
}


class Zufall:                                   # splitmix64, ganzzahlig
    def __init__(self, samen):
        self.s = samen & M64

    def zahl(self):
        self.s = (self.s + 0x9E3779B97F4A7C15) & M64
        z = self.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        return z ^ (z >> 31)

    def unter(self, n):
        return self.zahl() % n


def lg_gross(x):
    """log2 x in Einheiten 2^-E fuer beliebig grosse x >= 1 (Tafel nach Rechtsschieben, Fehler < 2^-15 relativ)."""
    sh = max(0, x.bit_length() - 16)
    return LG[x >> sh] + (sh << E)


def wirke(x, p):                                # neu[i] = x[p[i]]
    return tuple(x[i] for i in p)


def kompiliere(wort):
    r = ID
    for g in wort:
        r = wirke(r, GEN[g])
    return r


def _abstaende():
    d = {ID: 0}
    front = [ID]
    while front:
        neu = []
        for x in front:
            for g in GEN:
                y = wirke(x, g)
                if y not in d:
                    d[y] = d[x] + 1
                    neu.append(y)
        front = neu
    return d


ABST = _abstaende()
assert len(ABST) == 40320


def abstand(s, t):
    inv = [0] * N
    for i, v in enumerate(s):
        inv[v] = i
    return ABST[tuple(inv[v] for v in t)]


def mische(z):
    a = list(range(N))
    for i in range(N - 1, 0, -1):
        j = z.unter(i + 1)
        a[i], a[j] = a[j], a[i]
    return tuple(a)


def neues_wort(z):
    while True:
        L = 3 + z.unter(2)
        w = tuple(z.unter(5) for _ in range(L))
        if ABST[kompiliere(w)] == L:
            return w


class Welt:
    def __init__(self, z, ohne=False):
        self.ohne = ohne
        self.makros, perms = [], set()
        while len(self.makros) < 6:
            L = 3 + z.unter(2)
            w = tuple(z.unter(5) for _ in range(L))
            p = kompiliere(w)
            if ABST[p] == L and p not in perms:
                self.makros.append(w)
                perms.add(p)
        self.perm = [kompiliere(w) for w in self.makros]

    def aufgabe(self, z, k):
        while True:
            s = mische(z)
            if self.ohne:                        # Nicht-Schrift-Kontrolle: jedes "Konzept" ist ein frisches Wort
                woerter = [neues_wort(z) for _ in range(k)]
            else:
                woerter = [self.makros[z.unter(6)] for _ in range(k)]
            zw, x = [s], s
            for w in woerter:
                x = wirke(x, kompiliere(w))
                zw.append(x)
            if abstand(s, x) >= MIN_ABSTAND[k]:
                return {"s": s, "t": x, "k": k, "zw": zw, "woerter": woerter,
                        "prog": tuple(op for w in woerter for op in w)}

    def teil(self, a, i, j):                     # Teilaufgabe von Zwischenzustand i bis j
        woerter = a["woerter"][i:j]
        return {"s": a["zw"][i], "t": a["zw"][j], "k": j - i, "zw": a["zw"][i:j + 1], "woerter": woerter,
                "prog": tuple(op for w in woerter for op in w)}


class Schueler:
    def __init__(self, schlaf=True, allo=False, grund=0):
        self.allo = allo
        self.grund = grund
        self.wirk = {GEN[g]: g for g in range(5)}   # Wirkung -> Eintrag (nur im Allographen-Modus genutzt)
        self.segs = {}                            # Programm -> je Position [(Laenge, Wirkung)]
        self.bib = [(g,) for g in range(5)]
        self.index = {w: i for i, w in enumerate(self.bib)}
        self.greif = [itemgetter(*GEN[g]) for g in range(5)]
        self.nutz = [0] * 5
        self.progs = {}                          # Primitivwort -> Anzahl
        self.neu = False
        self.schlaf_an = schlaf

    def kosten(self):
        n, kk = sum(self.nutz), len(self.bib)
        if not self.grund:
            return [LG[2 * n + kk] - LG[2 * u + 1] for u in self.nutz]
        # p_i = ((2^g - 1)(2u_i + 1) K + (2n + K)) / (2^g K (2n + K)): Rueckfall auf die Grundverteilung
        g = self.grund
        nenner = lg_gross((1 << g) * kk * (2 * n + kk))
        return [nenner - lg_gross(((1 << g) - 1) * (2 * u + 1) * kk + (2 * n + kk)) for u in self.nutz]

    def loese(self, s, t, budget=BUDGET):
        """(Weg als Eintragsnummern oder None, Expansionen, Kodelaenge des Wegs)."""
        ko = self.kosten()
        best = {s: 0}
        heap = [(0, 0, s, ())]
        n = lfd = 0
        kanten = list(zip(self.greif, ko, range(len(ko))))
        while heap and n < budget:
            c, _, x, weg = heapq.heappop(heap)
            if c != best[x]:
                continue
            if x == t:
                return weg, n, c
            n += 1
            for g, k, i in kanten:
                y = g(x)
                cy = c + k
                if cy < best.get(y, cy + 1):
                    best[y] = cy
                    lfd += 1
                    heapq.heappush(heap, (cy, lfd, y, weg + (i,)))
        return None, n, 0

    def _merke_wort(self, prog):
        self.progs[prog] = self.progs.get(prog, 0) + 1
        self.neu = True

    def merke(self, weg):
        for i in weg:
            self.nutz[i] += 1
        self._merke_wort(tuple(op for i in weg for op in self.bib[i]))

    def wirkungen(self):
        return set(self.wirk) if self.allo else {kompiliere(w) for w in self.bib}

    def _segmente(self, prog):
        s = self.segs.get(prog)
        if s is None:
            s = []
            for j in range(len(prog)):
                lst, r = [], ID
                for L in range(1, min(4, len(prog) - j) + 1):
                    r = wirke(r, GEN[prog[j + L - 1]])
                    lst.append((L, r))
                s.append(lst)
            self.segs[prog] = s
        return s

    def _parse_allo(self, wirk, prog):
        inf = 1 << 30
        n = len(prog)
        d = [inf] * (n + 1)
        zur = [None] * (n + 1)
        d[0] = 0
        for j, lst in enumerate(self._segmente(prog)):
            if d[j] == inf:
                continue
            for L, eff in lst:
                i = wirk.get(eff)
                if i is not None and d[j] + 1 < d[j + L]:
                    d[j + L] = d[j] + 1
                    zur[j + L] = (j, i)
        out, j = [], n
        while j > 0:
            j, i = zur[j]
            out.append(i)
        return out

    def merke_fremd(self, prog):                 # Destillation: Lehrerloesung in Primitiven
        for i in (self._parse_allo(self.wirk, prog) if self.allo else self._parse(self.index, prog)):
            self.nutz[i] += 1
        self._merke_wort(prog)

    @staticmethod
    def _parse(index, prog):
        """Zerlegung in moeglichst wenige Eintraege (Laenge <= 4), Rueckgabe: Eintragsnummern."""
        inf = 1 << 30
        n = len(prog)
        d = [inf] * (n + 1)
        zur = [None] * (n + 1)
        d[0] = 0
        for j in range(n):
            if d[j] == inf:
                continue
            for L in range(1, min(4, n - j) + 1):
                i = index.get(prog[j:j + L])
                if i is not None and d[j] + 1 < d[j + L]:
                    d[j + L] = d[j] + 1
                    zur[j + L] = (j, i)
        out, j = [], n
        while j > 0:
            j, i = zur[j]
            out.append(i)
        return out

    def _gesamt(self, bib, index):
        zaehl = [0] * len(bib)
        for p, m in self.progs.items():
            for i in (self._parse_allo(index, p) if self.allo else self._parse(index, p)):
                zaehl[i] += m
        wert, _ = DM.dm(zaehl, 1, 2)
        definition = sum(len(w) * DM.lg(5) + DM.lg(3) for w in bib[5:])
        return wert + definition, zaehl

    def schlaf(self):
        if not self.schlaf_an or not self.neu:
            return 0
        self.neu = False
        if self.allo:
            return self._schlaf_allo()
        basis, zaehl = self._gesamt(self.bib, self.index)
        aufgenommen = 0
        for _ in range(2):
            teil = {}
            for p, m in self.progs.items():
                for L in (2, 3, 4):
                    for j in range(len(p) - L + 1):
                        w = p[j:j + L]
                        if w not in self.index:
                            teil[w] = teil.get(w, 0) + m
            kand = sorted(((c * (len(w) - 1), w) for w, c in teil.items()), reverse=True)[:KANDIDATEN]
            bestes = None
            for _, w in kand:
                idx2 = dict(self.index)
                idx2[w] = len(self.bib)
                wert, z = self._gesamt(self.bib + [w], idx2)
                if wert < basis and (bestes is None or wert < bestes[0]):
                    bestes = (wert, w, z)
            if bestes is None:
                break
            basis, w, zaehl = bestes
            self.index[w] = len(self.bib)
            self.bib.append(w)
            self.greif.append(itemgetter(*kompiliere(w)))
            aufgenommen += 1
        self.nutz = zaehl
        return aufgenommen


def _schlaf_allo(self):
    """Wie schlaf(), aber Kandidaten sind Wirkungen: alle Schreibungen derselben Wirkung zaehlen zusammen
    (Allographen zusammenlegen, Voranstellung/Vertauschung unabhaengiger Schritte eingeschlossen)."""
    basis, zaehl = self._gesamt(self.bib, self.wirk)
    aufgenommen = 0
    for _ in range(2):
        teil = {}
        for p, m in self.progs.items():
            for j, lst in enumerate(self._segmente(p)):
                for L, eff in lst:
                    if L < 2 or eff in self.wirk or eff == ID:
                        continue
                    t = teil.get(eff)
                    w = p[j:j + L]
                    if t is None:
                        teil[eff] = [m * (L - 1), w]
                    else:
                        t[0] += m * (L - 1)
                        if len(w) < len(t[1]):
                            t[1] = w
        kand = sorted(((g, w, eff) for eff, (g, w) in teil.items()), reverse=True)[:KANDIDATEN]
        bestes = None
        for _, w, eff in kand:
            lk = dict(self.wirk)
            lk[eff] = len(self.bib)
            wert, z = self._gesamt(self.bib + [w], lk)
            if wert < basis and (bestes is None or wert < bestes[0]):
                bestes = (wert, w, eff, z)
        if bestes is None:
            break
        basis, w, eff, zaehl = bestes
        self.wirk[eff] = len(self.bib)
        self.index[w] = len(self.bib)
        self.bib.append(w)
        self.greif.append(itemgetter(*eff))
        aufgenommen += 1
    self.nutz = zaehl
    return aufgenommen


Schueler._schlaf_allo = _schlaf_allo


def waehle_stufe(fenster, z):
    if z.unter(8) == 0:
        return 1 + z.unter(3)
    lp = {}
    for k, f in fenster.items():
        lp[k] = abs(sum(f[-4:]) - sum(f[-8:-4])) if len(f) >= 8 else 5
    offen = [k for k in (1, 2, 3) if len(fenster[k]) < 8 or 4 * sum(fenster[k][-8:]) < 3 * 8]
    pool = offen or [3]
    return max(pool, key=lambda k: (lp[k], -k))


def lauf(name, samen, episoden):
    cfg = BEDINGUNGEN[name]
    welt = Welt(Zufall(1000 + samen), ohne=(cfg.get("welt") == "ohne"))
    zv = Zufall(7000 + samen)                     # eigener Strom fuer vertauschte Anker
    zl = Zufall(2000 + samen)
    zm = Zufall(9000 + samen)
    mess = [welt.aufgabe(zm, 3) for _ in range(MESS_ZAHL)]
    sch = Schueler(schlaf=cfg["schlaf"], allo=cfg.get("allo", False), grund=cfg.get("grund", 0))
    fenster = {1: [], 2: [], 3: []}
    schlange = []
    kurve = []
    zaehl = {"pruefungen": 0, "pruef_geloest": 0, "uebung": 0, "uebung_geloest": 0, "hilfe_symbole": 0,
             "zerlegungen": 0}
    for ep in range(1, episoden + 1):
        pruef = cfg["pruef"] > 0 and ep % cfg["pruef"] == 0 and not (cfg["plan"] == "gipfel" and schlange)
        if pruef:
            a = welt.aufgabe(zl, 3)
        elif schlange:
            a = schlange.pop(0)
        elif cfg["plan"] == "gipfel":
            a = welt.aufgabe(zl, 3)
        elif cfg["plan"] == "zufall":
            a = welt.aufgabe(zl, 1 + zl.unter(3))
        else:
            a = welt.aufgabe(zl, waehle_stufe(fenster, zl))
        weg, _, _ = sch.loese(a["s"], a["t"])
        ok = weg is not None
        if ok:
            sch.merke(weg)
        if pruef:
            zaehl["pruefungen"] += 1
            zaehl["pruef_geloest"] += ok
            if not ok and cfg["zerlegen"]:
                schlange = [welt.teil(a, 2, 3), welt.teil(a, 1, 2), welt.teil(a, 0, 1), welt.teil(a, 1, 3), dict(a)]
                zaehl["zerlegungen"] += 1
            if not ok and cfg.get("kartusche"):    # nur das erste fehlende Konzept, vom Ziel rueckwaerts
                bekannt = sch.wirkungen()
                for w in reversed(a["woerter"]):
                    if kompiliere(w) not in bekannt:
                        sch.merke_fremd(w)
                        zaehl["hilfe_symbole"] += len(w)
                        break
        else:
            zaehl["uebung"] += 1
            zaehl["uebung_geloest"] += ok
            fenster[a["k"]].append(1 if ok else 0)
            if not ok and cfg["zeigen"] == "vertauscht":     # Loesung einer anderen Aufgabe derselben Stufe
                b = welt.aufgabe(zv, a["k"])
                sch.merke_fremd(b["prog"])
                zaehl["hilfe_symbole"] += len(b["prog"])
            elif not ok and cfg["zeigen"]:
                sch.merke_fremd(a["prog"])
                zaehl["hilfe_symbole"] += len(a["prog"])
        if ep % SCHLAF == 0:
            sch.schlaf()
        if ep % MESS == 0:
            geloest = aufwand = bits = 0
            for m in mess:
                w, n, c = sch.loese(m["s"], m["t"])
                aufwand += n
                if w is not None:
                    geloest += 1
                    bits += c
            bekannt = sch.wirkungen()
            kurve.append({"episode": ep, "geloest": geloest, "expansionen": aufwand // MESS_ZAHL,
                          "bits_milli": (bits * 1000 >> E) // max(geloest, 1), "bibliothek": len(sch.bib),
                          "konzepte": 0 if welt.ohne else sum(1 for p in welt.perm if p in bekannt)})
    return {"kurve": kurve, "zaehl": zaehl, "makros": [list(w) for w in welt.makros],
            "bibliothek": [list(w) for w in sch.bib[5:]]}


def main():
    aus = Path(sys.argv[1])
    name = sys.argv[2]
    samen_zahl = int(sys.argv[3]) if len(sys.argv) > 3 else 5
    episoden = int(sys.argv[4]) if len(sys.argv) > 4 else 600
    global KANDIDATEN
    KANDIDATEN = int(sys.argv[5]) if len(sys.argv) > 5 else KANDIDATEN
    erg = [lauf(name, s, episoden) for s in range(samen_zahl)]
    aus.write_text(json.dumps({"bedingung": name, "kandidaten": KANDIDATEN, "laeufe": erg}))
    ende = [r["kurve"][-1] for r in erg]
    print(name, "Gipfel am Ende:", [x["geloest"] for x in ende], "Bib:", [x["bibliothek"] for x in ende],
          "Bits:", [x["bits_milli"] for x in ende], flush=True)


if __name__ == "__main__":
    main()
