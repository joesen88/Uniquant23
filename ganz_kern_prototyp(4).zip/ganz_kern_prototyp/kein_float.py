"""Pruefung des Zahlvertrags: findet Gleitkomma im Quelltext der Kernmodule.

Verboten: Gleitkomma-Literale, Operator / (auch /=), float(), complex(), math.* ausser isqrt/gcd/comb,
          Module random, decimal, statistics, cmath; numpy-Gleitkommatypen; ** mit negativem Exponenten.
Aufruf: python3 -I kein_float.py <datei.py> ...      Rueckgabe 1 bei Verstoss.
"""
import ast
import sys

ERLAUBT_MATH = {"isqrt", "gcd", "comb"}
VERBOTEN_MOD = {"random", "decimal", "statistics", "cmath"}
NP_FLOAT = {"float16", "float32", "float64", "float128", "longdouble", "half", "single", "double", "float_",
            "complex64", "complex128", "floating", "inexact"}


def pruefe(pfad):
    baum = ast.parse(open(pfad, encoding="utf-8").read(), pfad)
    fehler = []
    for k in ast.walk(baum):
        z = getattr(k, "lineno", 0)
        if isinstance(k, ast.Constant) and isinstance(k.value, (float, complex)):
            fehler.append((z, f"Gleitkomma-Literal {k.value!r}"))
        elif isinstance(k, (ast.BinOp, ast.AugAssign)) and isinstance(k.op, ast.Div):
            fehler.append((z, "Operator /"))
        elif isinstance(k, ast.BinOp) and isinstance(k.op, ast.Pow) and isinstance(k.right, ast.UnaryOp) \
                and isinstance(k.right.op, ast.USub):
            fehler.append((z, "** mit negativem Exponenten"))
        elif isinstance(k, ast.Call) and isinstance(k.func, ast.Name) and k.func.id in ("float", "complex"):
            fehler.append((z, f"{k.func.id}()"))
        elif isinstance(k, ast.Attribute) and isinstance(k.value, ast.Name):
            if k.value.id == "math" and k.attr not in ERLAUBT_MATH:
                fehler.append((z, f"math.{k.attr}"))
            if k.value.id in ("np", "numpy") and k.attr in NP_FLOAT:
                fehler.append((z, f"numpy.{k.attr}"))
        elif isinstance(k, (ast.Import, ast.ImportFrom)):
            namen = [a.name.split(".")[0] for a in k.names] if isinstance(k, ast.Import) else [(k.module or "").split(".")[0]]
            for n in namen:
                if n in VERBOTEN_MOD:
                    fehler.append((z, f"import {n}"))
    return fehler


def main():
    gesamt = 0
    for p in sys.argv[1:]:
        f = pruefe(p)
        gesamt += len(f)
        print(f"{p}: {len(f)} Verstoesse" + "".join(f"\n   Zeile {z}: {t}" for z, t in f[:10]))
    sys.exit(1 if gesamt else 0)


if __name__ == "__main__":
    main()
