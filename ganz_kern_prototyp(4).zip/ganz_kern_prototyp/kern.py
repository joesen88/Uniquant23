"""GANZ Kern-Prototyp: nur ganze Zahlen (Zahlvertrag Abschnitt 2 des Konzepts).

Tafeln     LG[i] = floor(2^E * log2 i) fuer 1 <= i <= nmax, E = 24, zertifiziert:
           Quadrierfolge einmal abgerundet und einmal aufgerundet; wo beide Laeufe ein Bit
           verschieden entscheiden, rechnet der genaue Pfad (Python-int, 128 Bit und mehr).
           C1[m] = sum_{i<=m} LG[i]        (log2 m!,  je Term abgerundet)
           C2[m] = LG[m] + C2[m-2]         (log2 m!!, je Term abgerundet)
Kodelaenge Dirichlet-Multinomial mit alpha = a/b (b = 1 oder 2):
           L = sum_{j<N} log2(K a + j b) - sum_i sum_{j<n_i} log2(a + j b)   (b^N kuerzt sich)
           Schranke: jeder Term ist um weniger als 1 Einheit abgerundet.
Uebertrag  divmod mit Rest am Ort; Verteilung nach groesstem Rest (Hamilton).
Kodierer   arithmetischer Kodierer (Witten, Neal, Cleary 1987), 32 Bit, adaptiv mit KT-Haeufigkeiten 2n+1.
"""
import numpy as np

E = 24
EINS = 1 << E


# ---------------------------------------------------------------- Log-Tafel
def _lg_genau(i, e_bits=E, p=128):
    """floor(2^e_bits * log2 i) mit Python-int; verdoppelt p, bis Unter- und Oberlauf uebereinstimmen."""
    ex = i.bit_length() - 1
    lo = i << (p - ex)
    hi = lo
    frac = 0
    for _ in range(e_bits):
        lo = (lo * lo) >> p
        hi = -((-(hi * hi)) >> p)
        blo, bhi = lo >> (p + 1), hi >> (p + 1)
        if blo != bhi:
            return _lg_genau(i, e_bits, 2 * p)
        if blo:
            lo >>= 1
            hi = (hi + 1) >> 1
        frac = (frac << 1) | blo
    return (ex << e_bits) | frac


def lg_tafel(nmax, e_bits=E, q=31):
    """Feld LG[0..nmax] (int64), LG[0] = 0.  Rueckgabe (LG, Zahl der Eintraege im genauen Pfad)."""
    n = np.arange(1, nmax + 1, dtype=np.uint64)
    ex = np.zeros(nmax, dtype=np.uint64)
    x = n.copy()
    for s in (32, 16, 8, 4, 2, 1):
        m = x >= np.uint64(1 << s)
        ex[m] += np.uint64(s)
        x[m] >>= np.uint64(s)
    lo = n << (np.uint64(q) - ex)
    hi = lo.copy()
    frac = np.zeros(nmax, dtype=np.uint64)
    unsicher = np.zeros(nmax, dtype=bool)
    zwei = np.uint64(1 << (q + 1))
    rund = np.uint64((1 << q) - 1)
    for _ in range(e_bits):
        lo = (lo * lo) >> np.uint64(q)
        hi = (hi * hi + rund) >> np.uint64(q)
        blo = lo >= zwei
        bhi = hi >= zwei
        unsicher |= blo != bhi
        lo[blo] >>= np.uint64(1)
        hi[bhi] = (hi[bhi] + np.uint64(1)) >> np.uint64(1)
        oben = hi >= zwei
        unsicher |= oben
        hi[oben] = zwei - np.uint64(1)
        frac = (frac << np.uint64(1)) | blo.astype(np.uint64)
    lg = (ex.astype(np.int64) << np.int64(e_bits)) | frac.astype(np.int64)
    idx = np.flatnonzero(unsicher)
    for k in idx.tolist():
        lg[k] = _lg_genau(k + 1, e_bits)
    return np.concatenate([np.zeros(1, dtype=np.int64), lg]), len(idx)


class Tafeln:
    def __init__(self, nmax):
        self.nmax = nmax
        self.LG, self.genau = lg_tafel(nmax)
        self.C1 = np.cumsum(self.LG)
        c2 = np.zeros_like(self.LG)
        c2[0::2] = np.cumsum(self.LG[0::2])
        c2[1::2] = np.cumsum(self.LG[1::2])
        self.C2 = c2

    def lg(self, i):
        return int(self.LG[i])

    def S(self, c, b, n):
        """sum_{j<n} log2(c + j b) in Einheiten 2^-24 bit, je Term abgerundet (n Terme)."""
        if n == 0:
            return 0
        tab = self.C1 if b == 1 else self.C2
        unten = c - b
        return int(tab[c + (n - 1) * b]) - (int(tab[unten]) if unten > 0 else 0)

    def dm(self, zaehl, a=1, b=2):
        """Kodelaenge einer Zaehltafel unter Dirichlet(a/b): (Wert, Schranke) in Einheiten.
        Wahrer Wert liegt in (Wert - Schranke, Wert + Schranke)."""
        k = len(zaehl)
        n = sum(zaehl)
        wert = self.S(k * a, b, n) - sum(self.S(a, b, z) for z in zaehl)
        return wert, n


# ---------------------------------------------------------------- Uebertrag und Verteilung
def uebertrag(a, b, e_bits, rest_alt=0):
    """a/b auf die Skala 2^-e_bits; Rest bleibt am Ort.  Identitaet: a*2^e + rest_alt = q*b + rest_neu."""
    return divmod((a << e_bits) + rest_alt, b)


def verteile(gewichte, teile):
    """Verteilung nach groesstem Rest: Summe exakt `teile`, Gleichstand an die kleinere Nummer."""
    w = sum(gewichte)
    h, r = zip(*(divmod(g * teile, w) for g in gewichte))
    h = list(h)
    fehlt = teile - sum(h)
    for i in sorted(range(len(gewichte)), key=lambda i: (-r[i], i))[:fehlt]:
        h[i] += 1
    return h


# ---------------------------------------------------------------- arithmetischer Kodierer
class Fenwick:
    def __init__(self, k):
        self.k = k
        self.t = [0] * (k + 1)

    def add(self, i, d):
        i += 1
        while i <= self.k:
            self.t[i] += d
            i += i & -i

    def summe(self, i):          # Summe der Eintraege 0..i-1
        s = 0
        while i > 0:
            s += self.t[i]
            i -= i & -i
        return s


B = 32
VOLL = (1 << B) - 1
HALB = 1 << (B - 1)
VIERTEL = 1 << (B - 2)


def kodiere_kt(symbole, k):
    """Adaptiv, Haeufigkeit je Zeichen 2n+1, Summe 2t+k (= KT-Schaetzer).  Rueckgabe: Bitfolge als Liste."""
    low, high, offen = 0, VOLL, 0
    bits = []
    fw = Fenwick(k)
    zaehl = [0] * k
    for t, s in enumerate(symbole):
        gesamt = 2 * t + k
        cum_lo = 2 * fw.summe(s) + s
        cum_hi = cum_lo + 2 * zaehl[s] + 1
        spanne = high - low + 1
        high = low + spanne * cum_hi // gesamt - 1
        low = low + spanne * cum_lo // gesamt
        while True:
            if high < HALB:
                bits.append(0)
                bits.extend([1] * offen)
                offen = 0
            elif low >= HALB:
                bits.append(1)
                bits.extend([0] * offen)
                offen = 0
                low -= HALB
                high -= HALB
            elif low >= VIERTEL and high < 3 * VIERTEL:
                offen += 1
                low -= VIERTEL
                high -= VIERTEL
            else:
                break
            low <<= 1
            high = (high << 1) | 1
        zaehl[s] += 1
        fw.add(s, 1)
    offen += 1
    if low < VIERTEL:
        bits.append(0)
        bits.extend([1] * offen)
    else:
        bits.append(1)
        bits.extend([0] * offen)
    return bits


def dekodiere_kt(bits, k, anzahl):
    low, high, wert, pos = 0, VOLL, 0, 0
    for _ in range(B):
        wert = (wert << 1) | (bits[pos] if pos < len(bits) else 0)
        pos += 1
    fw = Fenwick(k)
    zaehl = [0] * k
    aus = []
    for t in range(anzahl):
        gesamt = 2 * t + k
        spanne = high - low + 1
        ziel = ((wert - low + 1) * gesamt - 1) // spanne
        # Zeichen s mit cum_lo(s) <= ziel < cum_hi(s); binaere Suche ueber s
        lo_s, hi_s = 0, k - 1
        while lo_s < hi_s:
            mid = (lo_s + hi_s + 1) >> 1
            if 2 * fw.summe(mid) + mid <= ziel:
                lo_s = mid
            else:
                hi_s = mid - 1
        s = lo_s
        cum_lo = 2 * fw.summe(s) + s
        cum_hi = cum_lo + 2 * zaehl[s] + 1
        high = low + spanne * cum_hi // gesamt - 1
        low = low + spanne * cum_lo // gesamt
        while True:
            if high < HALB:
                pass
            elif low >= HALB:
                low -= HALB
                high -= HALB
                wert -= HALB
            elif low >= VIERTEL and high < 3 * VIERTEL:
                low -= VIERTEL
                high -= VIERTEL
                wert -= VIERTEL
            else:
                break
            low <<= 1
            high = (high << 1) | 1
            wert = (wert << 1) | (bits[pos] if pos < len(bits) else 0)
            pos += 1
        aus.append(s)
        zaehl[s] += 1
        fw.add(s, 1)
    return aus
