"""Haeufung und Oberthema: Was traegt der ganze Text, was kurze Bloecke nicht tragen?  Nur ganze Zahlen (Zahlvertrag).

Frage     Lernt ein Modell Woerter in kurzen, zusammenhanglosen Bloecken, fehlen ihm zwei Dinge: die Haeufung der
          Woerter innerhalb eines Textes und das Oberthema, das fuer alles im Text gilt.  Wie viel ist das in bit?
Modell    Grundverteilung p0(w) = z0(w) / D aus den Lernartikeln (wie profil.py).  Dazu der Text selbst als Kontext:
              p(w) = (n_Text(w) * D + k * z0(w)) / ((N_Text + k) * D)
          n_Text zaehlt nur die Woerter vor der Stelle (keine Vorausschau).  k wird je Lage auf zurueckgehaltenen
          Lernartikeln gewaehlt.  Mit Oberthema tritt an die Stelle von p0 die Verteilung der Kategorie (Rueckfall
          auf p0 mit k = 65536 wie in profil.py); die Kategorie wird je Artikel mitkodiert (lg 9 bit).
Lagen     ganz      jeder Artikel als Ganzes
          bloecke   derselbe Text in Bloecken von BLOCK Woertern; der Zaehler beginnt in jedem Block neu
          gemischt  die Bloecke aller Artikel gemischt und zu Texten der alten Laengen gereiht (Zusammenhang zerstoert)
Dazu      Gewinn nach Stelle im Text.  Wiederkehr: Unter den Artikeln, in denen ein Inhaltswort steht, der Anteil, in
          dem es mindestens zweimal steht; Gegenprobe mit denselben Woertern, einzeln ueber alle Artikel gemischt.

Aufruf: python3 -I haeufung.py <train.csv> <test.csv> <ausgabe.json>
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import profil as P  # noqa: E402

BLOCK = 12
K_WAHL = (4, 16, 64, 256, 1024, 4096)
K_THEMA = 1 << 16
STELLEN = (25, 50, 100, 200, 400)
M64 = (1 << 64) - 1


class Zufall:                                   # splitmix64
    def __init__(self, samen):
        self.s = samen & M64

    def unter(self, n):
        self.s = (self.s + 0x9E3779B97F4A7C15) & M64
        z = self.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        return (z ^ (z >> 31)) % n


def mische(liste, samen):
    z = Zufall(samen)
    for i in range(len(liste) - 1, 0, -1):
        j = z.unter(i + 1)
        liste[i], liste[j] = liste[j], liste[i]
    return liste


def millibit(bits, n):
    return (bits * 1000) // (n << 16)


def main():
    pfad_lern, pfad_test, ziel = sys.argv[1:4]
    lern_alle = [(k, P.woerter(z)) for k, z in P.lies(pfad_lern)]
    test = [(k, P.woerter(z)) for k, z in P.lies(pfad_test)]
    schnitt = len(lern_alle) * 9 // 10
    lern, halt = lern_alle[:schnitt], lern_alle[schnitt:]
    klassen = sorted({k for k, _ in lern})
    ges = P.zaehle(w for _, ws in lern for w in ws)
    vokabular = {w for w, c in ges.items() if c >= 2}

    def idx(w):
        return w if w in vokabular else ""

    n_g = P.zaehle(idx(w) for _, ws in lern for w in ws)
    d_g = 2 * sum(n_g.values()) + len(vokabular) + 1
    n_k = {k: {} for k in klassen}
    gross_k = {k: 0 for k in klassen}
    for kat, ws in lern:
        gross_k[kat] += len(ws)
        z = n_k[kat]
        for w in ws:
            w = idx(w)
            z[w] = z.get(w, 0) + 1
    lg = P.lg

    def grund(kat):
        """(Zaehler je Wort, Nenner) der Grundverteilung; mit kat die Verteilung der Kategorie."""
        if kat is None:
            return (lambda w: 2 * n_g.get(w, 0) + 1), d_g
        tafel = n_k[kat]
        return (lambda w: tafel.get(w, 0) * d_g + K_THEMA * (2 * n_g.get(w, 0) + 1)), (gross_k[kat] + K_THEMA) * d_g

    def bits(texte, k, thema, stellen=None):
        """Kodelaenge aller Texte in 2^-16 bit.  texte: [(Kategorie, Woerter)].  k = None: nur Grundverteilung."""
        summe = 0
        for kat, ws in texte:
            z0, d = grund(kat if thema else None)
            lg_d = lg(d)
            zahl = {}
            for i, w in enumerate(ws):
                w = idx(w)
                if k is None:
                    b = lg_d - lg(z0(w))
                else:
                    b = lg((i + k) * d) - lg(zahl.get(w, 0) * d + k * z0(w))
                    zahl[w] = zahl.get(w, 0) + 1
                summe += b
                if stellen is not None:
                    s = sum(1 for g in STELLEN if i >= g)
                    stellen[s][0] += b
                    stellen[s][1] += 1
        return summe

    def in_bloecken(texte):
        return [(kat, ws[i:i + BLOCK]) for kat, ws in texte for i in range(0, len(ws), BLOCK)]

    def gemischt(texte, samen):
        bl = mische([ws[i:i + BLOCK] for _, ws in texte for i in range(0, len(ws), BLOCK)], samen)
        aus, p = [], 0
        for kat, ws in texte:
            n = (len(ws) + BLOCK - 1) // BLOCK
            aus.append((kat, [w for b in bl[p:p + n] for w in b]))
            p += n
        return aus

    lagen = {"ganz": lambda t: t, "bloecke": in_bloecken, "gemischt": lambda t: gemischt(t, 7)}
    n_test = sum(len(ws) for _, ws in test)
    lg9 = lg(len(klassen))
    aus = dict(artikel_lernen=len(lern), artikel_zurueckgehalten=len(halt), artikel_test=len(test), woerter_test=n_test,
               woerter_je_artikel_test=n_test // len(test), block=BLOCK)
    aus["grund_millibit"] = millibit(bits(test, None, False), n_test)
    aus["thema_millibit"] = millibit(bits(test, None, True) + lg9 * len(test), n_test)
    for thema in (False, True):
        for name, bau in lagen.items():
            halt_l, test_l = bau(halt), bau(test)
            k = min(K_WAHL, key=lambda kk: bits(halt_l, kk, thema))
            marke = ("thema_" if thema else "") + name
            aus[marke + "_k"] = k
            aus[marke + "_millibit"] = millibit(bits(test_l, k, thema) + (lg9 * len(test) if thema else 0), n_test)
            print(marke, "k", k, aus[marke + "_millibit"], flush=True)

    # Gewinn nach Stelle im Text (ganzer Artikel, ohne Thema)
    ohne = [[0, 0] for _ in range(len(STELLEN) + 1)]
    mit = [[0, 0] for _ in range(len(STELLEN) + 1)]
    bits(test, None, False, ohne)
    bits(test, aus["ganz_k"], False, mit)
    grenzen = (0,) + STELLEN
    aus["gewinn_nach_stelle"] = [dict(ab_wort=grenzen[s], woerter=ohne[s][1],
                                      grund_millibit=millibit(ohne[s][0], ohne[s][1]),
                                      mit_text_millibit=millibit(mit[s][0], mit[s][1])) for s in range(len(grenzen))]

    # Wiederkehr: Inhaltswoerter (nicht unter den 150 haeufigsten, in mindestens 50 Lernartikeln)
    rang = [w for w, _ in sorted(ges.items(), key=lambda kv: (-kv[1], kv[0]))]
    haeufig = set(rang[:150])

    def wiederkehr(texte, menge):
        einmal, zweimal = {}, {}
        for ws in texte:
            for w, c in P.zaehle(ws).items():
                if menge is None or w in menge:
                    einmal[w] = einmal.get(w, 0) + 1
                    if c >= 2:
                        zweimal[w] = zweimal.get(w, 0) + 1
        return einmal, zweimal

    echte = [ws for _, ws in lern]
    einmal, zweimal = wiederkehr(echte, None)
    inhalt = {w for w, c in einmal.items() if c >= 50 and w not in haeufig}
    alle = mische([w for ws in echte for w in ws], 11)
    lose, p = [], 0
    for ws in echte:
        lose.append(alle[p:p + len(ws)])
        p += len(ws)
    e2, z2 = wiederkehr(lose, inhalt)
    aus["wiederkehr"] = dict(
        inhaltswoerter=len(inhalt),
        echt_promille=P.promille(sum(zweimal.get(w, 0) for w in inhalt), sum(einmal[w] for w in inhalt)),
        einzeln_gemischt_promille=P.promille(sum(z2.get(w, 0) for w in inhalt), sum(e2.get(w, 0) for w in inhalt)))
    print(json.dumps(aus, ensure_ascii=False))
    with open(ziel, "w", encoding="utf-8") as f:
        json.dump(aus, f, indent=1, ensure_ascii=False)


if __name__ == "__main__":
    main()
