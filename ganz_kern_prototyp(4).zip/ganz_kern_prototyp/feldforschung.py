"""Feldforschung im Spielmodell: unzuverlaessige Quellen, exakter Pruefer, Ausschlusslernen.  Nur ganze Zahlen.

Aufgabe   6 Teile, je Teil 16 Optionen in 4 Klassen (Klasse = Option // 4).  Die Wahrheit ist verborgen.
          Ohne Rueckmeldung zum Ort gaebe es 16^6 = 16 777 216 Kombinationen.
Pruefer   exakt.  Rueckmeldung je Versuch: bestanden, oder der erste falsche Teil (Ort).  Mit Fehlerklasse zusaetzlich,
          ob die Klasse der versuchten Option stimmt (wie "falscher Typ" gegen "richtiger Typ, falscher Wert").
Quellen   12 Quellen schlagen je Teil eine Option vor.  gut: Wahrheit mit 13/16.  schwach: Wahrheit mit 6/16.
          irrig: verbreitet mit 12/16 denselben Irrtum (je Aufgabe und Teil eine feste falsche Option), Wahrheit 2/16.
          Der Schueler kennt die Art einer Quelle nicht.
Welten    sauber 8 gut / 4 schwach / 0 irrig · gemischt 5 / 3 / 4 · vergiftet 3 / 2 / 7 (Mehrheit irrt gemeinsam).
Schueler  blind              kein Lesen, Optionen der Reihe nach, Rueckmeldung nur Ort
          blind_klasse       kein Lesen, Rueckmeldung Ort und Fehlerklasse (Ausschluss ganzer Klassen)
          glauben            Mehrheit der Quellen je Teil, ein einziger Versuch, kein Lernen aus dem Ergebnis
          lesen              Vorschlaege nach Stimmenzahl, Rueckmeldung nur Ort
          lesen_ausschluss   wie lesen, dazu Ausschluss ueber die Fehlerklasse
          lesen_konto        wie lesen_ausschluss, dazu Quellenkonto: bestaetigt b, ausgeschlossen a je Quelle,
                             Vertrauen (b + 7) / (b + a + 13) in 4096 Teilen (Urwert-Vorschuss 7 zu 6)
Folge     20 Aufgaben je Welt mit denselben Quellen; das Quellenkonto bleibt ueber die Aufgaben bestehen.
          Alle Schueler sehen dieselben Welten, Aufgaben und Vorschlaege.

Aufruf: python3 -I feldforschung.py <ausgabe.json> [welten]
"""
import json
import sys
from math import comb

M64 = (1 << 64) - 1
M, K, KL = 6, 16, 4
Q = 12
FOLGE = 20
WELTEN = {"sauber": (8, 4, 0), "gemischt": (5, 3, 4), "vergiftet": (3, 2, 7)}
SCHUELER = {                       # (lesen, fehlerklasse, konto)
    "blind":            (False, False, False),
    "blind_klasse":     (False, True, False),
    "lesen":            (True, False, False),
    "lesen_ausschluss": (True, True, False),
    "lesen_konto":      (True, True, True),
}
KURVE = (1, 2, 3, 5, 10, 20)


class Zufall:                                   # splitmix64, ganzzahlig
    def __init__(self, samen):
        self.s = samen & M64

    def zahl(self):
        self.s = (self.s + 0x9E3779B97F4A7C15) & M64
        z = self.s
        z = ((z ^ (z >> 30)) * 0xBF58476D1CE4E5B9) & M64
        z = ((z ^ (z >> 27)) * 0x94D049BB133111EB) & M64
        return z ^ (z >> 31)

    def unter(self, n):
        return self.zahl() % n


def andere(z, w):
    return (w + 1 + z.unter(K - 1)) % K


def baue_welt(samen, mischung):
    z = Zufall(samen)
    arten = [0] * mischung[0] + [1] * mischung[1] + [2] * mischung[2]
    for i in range(Q - 1, 0, -1):
        j = z.unter(i + 1)
        arten[i], arten[j] = arten[j], arten[i]
    aufgaben = []
    for _ in range(FOLGE):
        wahr = [z.unter(K) for _ in range(M)]
        irr = [andere(z, w) for w in wahr]
        vor = []
        for q in range(Q):
            zeile = []
            for j in range(M):
                r = z.unter(16)
                if arten[q] == 0:
                    o = wahr[j] if r < 13 else andere(z, wahr[j])
                elif arten[q] == 1:
                    o = wahr[j] if r < 6 else andere(z, wahr[j])
                else:
                    o = irr[j] if r < 12 else (wahr[j] if r < 14 else andere(z, wahr[j]))
                zeile.append(o)
            vor.append(zeile)
        aufgaben.append((wahr, vor))
    return aufgaben


def vertrauen(st):
    return (st[0] + 7) * 4096 // (st[0] + st[1] + 13)


def zahl_bits(x):
    return bin(x).count("1")


def spitze(j, kand, vor, lesen, stand):
    g = [0] * K
    if lesen:
        for q in range(Q):
            g[vor[q][j]] += vertrauen(stand[q]) if stand is not None else 1
    best, bg = -1, -1
    for o in range(K):
        if kand[j] >> o & 1 and g[o] > bg:
            best, bg = o, g[o]
    return best


def loese(wahr, vor, lesen, fehlerklasse, stand):
    """Rueckgabe (Versuche, Fehlversuche, dabei ausgeschlossene Optionen)."""
    kand = [(1 << K) - 1] * M
    gez = [[False] * M for _ in range(Q)]
    x = [spitze(j, kand, vor, lesen, stand) for j in range(M)]
    tests = fehl = aus = 0
    j = 0
    while True:
        tests += 1
        f = j
        while f < M and x[f] == wahr[f]:
            if stand is not None:                               # Teil f bestaetigt: alle Vorschlaege dazu verbuchen
                for q in range(Q):
                    if not gez[q][f]:
                        stand[q][0 if vor[q][f] == wahr[f] else 1] += 1
                        gez[q][f] = True
            f += 1
        if f == M:
            return tests, fehl, aus
        o = x[f]
        fehl += 1
        vorher = zahl_bits(kand[f])
        if fehlerklasse:
            maske = 15 << (o // KL * KL)
            if o // KL != wahr[f] // KL:
                kand[f] &= ~maske                               # falsche Klasse: alle vier Optionen der Klasse fallen
            else:
                kand[f] &= maske & ~(1 << o)                    # richtige Klasse: nur ihre drei anderen bleiben
        else:
            kand[f] &= ~(1 << o)
        aus += vorher - zahl_bits(kand[f])
        if stand is not None:
            for q in range(Q):
                if vor[q][f] == o and not gez[q][f]:
                    stand[q][1] += 1
                    gez[q][f] = True
            for g in range(f, M):
                x[g] = spitze(g, kand, vor, lesen, stand)
        else:
            x[f] = spitze(f, kand, vor, lesen, None)
        j = f


def vorzeichen(x, y):
    """Gepaart je Welt: wie oft braucht x weniger Versuche als y."""
    besser = sum(1 for p, q in zip(x, y) if p < q)
    schlechter = sum(1 for p, q in zip(x, y) if p > q)
    n = besser + schlechter
    k = max(besser, schlechter)
    zaehler = min(1 << n, 2 * sum(comb(n, i) for i in range(k, n + 1)))
    return dict(besser=besser, schlechter=schlechter, gleich=len(x) - n, p_unter_1_promille=1000 * zaehler < (1 << n))


def zehntel(summe, n):
    return (20 * summe + n) // (2 * n)


def main():
    ziel = sys.argv[1]
    welten = int(sys.argv[2]) if len(sys.argv) > 2 else 1000
    erg = dict(teile=M, optionen=K, klassen=KL, quellen=Q, folge=FOLGE, welten=welten, kombinationen=K ** M, ergebnis={})
    for name_welt, mischung in WELTEN.items():
        summe = {s: 0 for s in SCHUELER}
        fehl = {s: 0 for s in SCHUELER}
        aus = {s: 0 for s in SCHUELER}
        je_welt = {s: [] for s in SCHUELER}
        kurve = {s: [0] * FOLGE for s in SCHUELER}
        glaube_ganz = glaube_teile = 0
        for w in range(welten):
            aufgaben = baue_welt(1000003 * (w + 1) + 17 * len(name_welt), mischung)
            for wahr, vor in aufgaben:
                kand = [(1 << K) - 1] * M
                mehr = [spitze(j, kand, vor, True, None) for j in range(M)]
                richtig = sum(1 for j in range(M) if mehr[j] == wahr[j])
                glaube_teile += richtig
                glaube_ganz += 1 if richtig == M else 0
            for s, (lesen, fk, konto) in SCHUELER.items():
                stand = [[0, 0] for _ in range(Q)] if konto else None
                gesamt = 0
                for t, (wahr, vor) in enumerate(aufgaben):
                    n, fe, au = loese(wahr, vor, lesen, fk, stand)
                    gesamt += n
                    fehl[s] += fe
                    aus[s] += au
                    kurve[s][t] += n
                summe[s] += gesamt
                je_welt[s].append(gesamt)
        n_auf = welten * FOLGE
        tab = {}
        for s in SCHUELER:
            tab[s] = dict(versuche_je_aufgabe_zehntel=zehntel(summe[s], n_auf),
                          ausgeschlossen_je_fehlversuch_zehntel=zehntel(aus[s], fehl[s]) if fehl[s] else 0,
                          kurve_zehntel={str(k): zehntel(kurve[s][k - 1], welten) for k in KURVE})
        tab["glauben"] = dict(versuche_je_aufgabe_zehntel=10, geloest_promille=1000 * glaube_ganz // n_auf,
                              teile_richtig_promille=1000 * glaube_teile // (n_auf * M))
        tests = {
            "lesen_gegen_blind": vorzeichen(je_welt["lesen"], je_welt["blind"]),
            "blind_klasse_gegen_blind": vorzeichen(je_welt["blind_klasse"], je_welt["blind"]),
            "lesen_ausschluss_gegen_lesen": vorzeichen(je_welt["lesen_ausschluss"], je_welt["lesen"]),
            "lesen_konto_gegen_lesen_ausschluss": vorzeichen(je_welt["lesen_konto"], je_welt["lesen_ausschluss"]),
        }
        erg["ergebnis"][name_welt] = dict(mischung_gut_schwach_irrig=list(mischung), schueler=tab, vorzeichentest_je_welt=tests)
        print(name_welt, mischung)
        for s, v in tab.items():
            print(f"  {s:17s}", v)
    with open(ziel, "w", encoding="utf-8") as f:
        json.dump(erg, f, indent=1, ensure_ascii=False)


if __name__ == "__main__":
    main()
