"""Auswertung der Entzifferungs-Experimente, ganzzahlig.  Aufruf: python3 -I analyse_entz.py <verzeichnis> <aus.json>"""
import hashlib
import json
import sys
from math import comb
from pathlib import Path

d = Path(sys.argv[1])
R = {}
for f in sorted(d.glob("*.json")):
    R[f.stem] = json.loads(f.read_text())["laeufe"]


def kennzahlen(laeufe):
    S = len(laeufe)
    ende = [r["kurve"][-1] for r in laeufe]
    g = [e["geloest"] for e in ende]
    z = [r["zaehl"] for r in laeufe]
    return {"gipfel_ende": g, "quote_promille": sum(g) * 1000 // (16 * S), "spanne": [min(g), max(g)],
            "konzepte_x10": sum(e.get("konzepte", 0) for e in ende) * 10 // S,
            "eintraege_x10": sum(e["bibliothek"] - 5 for e in ende) * 10 // S,
            "expansionen": sum(e["expansionen"] for e in ende) // S,
            "hilfe_symbole": sum(x.get("hilfe_symbole", 0) for x in z) // S,
            "zerlegungen": sum(x.get("zerlegungen", 0) for x in z) // S}


def vorzeichen(a, b):
    pos = sum(1 for x, y in zip(a, b) if x > y)
    neg = sum(1 for x, y in zip(a, b) if x < y)
    n, k = pos + neg, max(pos, neg)
    zaehler = 2 * sum(comb(n, i) for i in range(k, n + 1)) if n else 1
    nenner = 1 << n
    if zaehler > nenner:
        zaehler = nenner
    return {"besser": pos, "schlechter": neg, "gleich": len(a) - n, "p": [zaehler, nenner]}


skript = Path(__file__).resolve().parent.joinpath("sim_lehrer.py")
out = {"skript_sha256": hashlib.sha256(skript.read_bytes()).hexdigest(),
       "bedingungen": {k: kennzahlen(v) for k, v in R.items()}, "paare": {}}
paare = [("lehrer_k8_grund", "lehrer_k8"), ("gipfel_zerlegt_grund", "gipfel_zerlegt"), ("zufall_grund", "zufall"),
         ("lehrer_ohne_gipfel_grund", "lehrer_ohne_gipfel"), ("lehrer_k8_kartusche", "lehrer_k8"),
         ("lehrer_k8_zeigen", "lehrer_k8_kartusche"), ("lehrer_k8_grund_kartusche", "lehrer_k8_kartusche"),
         ("lehrer_k8_zeigen", "lehrer_k8_zeigen_vertauscht"), ("lehrer_k8_zeigen_vertauscht", "lehrer_k8"),
         ("lehrer_k8_allo", "lehrer_k8")]
for a, b in paare:
    if a in R and b in R:
        out["paare"][f"{a} gegen {b}"] = vorzeichen(out["bedingungen"][a]["gipfel_ende"], out["bedingungen"][b]["gipfel_ende"])
Path(sys.argv[2]).write_text(json.dumps(out, indent=1))
for k, v in out["bedingungen"].items():
    print(f"{k:32s} Quote {v['quote_promille']:4d}  Spanne {v['spanne']}  Konzepte {v['konzepte_x10']:3d}/10  "
          f"Eintraege {v['eintraege_x10']:3d}/10  Exp {v['expansionen']:5d}  Hilfe {v['hilfe_symbole']:5d}  Zerl {v['zerlegungen']:4d}")
for k, v in out["paare"].items():
    print(f"{k:58s} {v['besser']}/{v['schlechter']}/{v['gleich']}  p = {v['p'][0]}/{v['p'][1]}")
