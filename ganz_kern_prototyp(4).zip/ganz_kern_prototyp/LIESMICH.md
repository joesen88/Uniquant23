# GANZ Kern-Prototyp (Stand 18.11.2026)

Ganzzahliger Kern zum Konzept „Ganzzahlige Lernarchitektur für Sprache und Programme“.
Im Kern gibt es keine Gleitkommazahl: Klassen, Zählungen und Skalenwerte mit Rest am Ort.

## Dateien

| Datei | Inhalt |
|---|---|
| `kern.py` | Log-Tafel LG = floor(2^24 · log2 i) mit Zertifikat (Quadrierfolge ab- und aufgerundet, genauer Pfad mit Python-int), C1/C2-Summentafeln, Dirichlet-Kodelänge mit Schranke, Übertrag mit Rest, Verteilung nach größtem Rest, arithmetischer Kodierer (Witten/Neal/Cleary, 32 Bit, KT-Häufigkeiten 2n+1) |
| `pruefe_kern.py` | Prüfungen: Tafel gegen exakten Potenzvergleich (E = 12) und gegen unabhängige artanh-Reihe (E = 24), Dirichlet-Formel gegen adaptives Produkt (Fraction), Verteilung und Übertrag, Kodierer gegen Formel und Rückweg |
| `stufe0.py` | Stufe 0, Durchgang 0a: Verschmelzen nach Kodelängengewinn mit Entscheidungsregel, Test auf zurückgehaltenen Seiten |
| `cm.py` | Ganzzahliges Context Mixing, Python-Referenz (Ordnungen 0–4 und 6, Wort, Match, Bias; Lernen mit Rest am Ort) |
| `cm.c` | Derselbe Mischer nativ, bitgleich zu `cm.py`; kodieren und dekodieren |
| `kein_float.py` | Prüfung des Zahlvertrags im Quelltext (AST) |
| `ergebnisse/` | JSON-Ausgaben der Läufe und die Streck-/Stauchtafel `tafeln.bin` |

## Aufruf

```
python3 -I pruefe_kern.py <tldr-Ordner> ergebnisse/pruefe_kern.json
python3 -I stufe0.py <tldr-Ordner> ergebnisse/stufe0.json 40000
python3 -I cm.py tafeln ergebnisse/tafeln.bin
gcc -O2 -std=c11 -o cm cm.c
./cm e ergebnisse/tafeln.bin strom.bin strom.cm 3661225      # Lernseiten, dann Testseiten
./cm d ergebnisse/tafeln.bin strom.cm zurueck.bin 4059435
python3 -I cm.py kodiere ergebnisse/tafeln.bin praefix.bin praefix_py.cm   # Referenz, bitgleich zu ./cm
python3 -I kein_float.py kern.py cm.py stufe0.py
```

tldr: `git clone https://github.com/tldr-pages/tldr` (Stand der Messung: Commit 70eef44 vom 17.11.2026).
Aufteilung: Dateien von pages/common und pages/linux sortiert; jede zehnte (Index mod 10 = 7) ist Test.
Der Strom `strom.bin` ist Lernseiten + Testseiten hintereinander; die Grenze liegt bei Byte 3.661.225.

## Gemessen (2 Kerne)

- Log-Tafel 2^23 Einträge: 4,9 s; 0,78 % über den genauen Pfad; 0 Fehler gegen beide unabhängigen Prüfungen.
- Kodierer Ordnung 0 auf 4.059.435 Byte: 20.409.939 bit, Formel 20.409.937 bit (Überhang 2 bit).
- Stufe 0: 2.347 Verschmelzungen, Test 2,929 bit/Byte gegen 5,030 (Byte-Unigramm).
- Mischer: Testseiten 1,381 bit/Byte (xz -9e mit Vorwissen 1,490; bzip2 1,827); Python und C bitgleich.

## Grenzen

Mischer auf Bytes, noch nicht auf Einheiten mit Klassenpfaden. Stufe 0 ohne Durchgang 0b und ohne harte EM.
Tafeln ohne Schutzbits (Schranke einer Summe über n Terme = n Einheiten von 2^-24 bit).
`pruefe_kern.py` und `stufe0.py` sind Prüf- und Messskripte; `pruefe_kern.py` nutzt Fraction und random (erlaubt in Tests).

## Lernprojekt: Spielwelt Lehrer und Schüler

```
python3 -I kein_float.py sim_lehrer.py analyse_sim.py
for b in nur_gipfel gipfel_zerlegt zufall lehrer_ohne_gipfel lehrer_k4 lehrer_k8 lehrer_k16 lehrer_k8_zeigen lehrer_k8_ohne_schlaf; do
  python3 -I sim_lehrer.py ergebnisse/sim32/$b.json $b 10 800 32      # 10 Samen, 800 Episoden, 32 Schlaf-Kandidaten
done
python3 -I analyse_sim.py ergebnisse/sim32 ergebnisse/sim32_auswertung.json
```

Welt: Permutationen von 8 Symbolen, 5 Primitive, 6 verborgene Konzepte; Gipfel = 3 Konzepte, Mindestabstand 8 (exakt per Breitensuche).
Gemessen (Gipfelquote in Promille nach 800 Episoden, Mittel über 10 Samen, 32 Kandidaten):
nur Gipfel 0 · nur Gipfel + Zerlegung 606 · Zufallsplan 631 · Lehrer ohne Prüfung 337 · k=4 712 · k=8 606 · k=16 475 ·
k=8 + Zeigen 987 · k=8 ohne Schlaf 6. Gegenprobe mit 8 Kandidaten in `ergebnisse/sim8` (gleiche Rangfolge, tieferes Niveau).
Laufzeit: etwa 3 min für alle Bedingungen auf 2 Kernen.

## Entzifferungslogik in der Spielwelt

```
for b in lehrer_k8_kartusche lehrer_k8_zeigen_vertauscht lehrer_k8_grund gipfel_zerlegt_grund zufall_grund \
         lehrer_ohne_gipfel_grund lehrer_k8_grund_kartusche lehrer_k8_allo nichtschrift_lehrer_k8 \
         nichtschrift_lehrer_k8_grund nichtschrift_lehrer_k8_zeigen lehrer_k8 lehrer_k8_zeigen zufall gipfel_zerlegt lehrer_ohne_gipfel; do
  python3 -I sim_lehrer.py ergebnisse/entzifferung/$b.json $b 10 800 32
done
python3 -I analyse_entz.py ergebnisse/entzifferung ergebnisse/entzifferung_auswertung.json
```

Übertragen: Kartusche (nur das erste fehlende Konzept zeigen), vertauschte Anker (Lösungen fremder Aufgaben zeigen),
Grundverteilung in den Suchkosten (g = 3), Allographen (Einträge nach Wirkung), Nicht-Schrift-Welt (Konzepte wiederholen sich nie).
Gemessen (Promille, 10 Samen): Kartusche 893 mit 60 gezeigten Symbolen je Lauf, Zeigen 987 mit 156, vertauschte Anker 962 mit 473;
Grundverteilung: Gipfel + Zerlegung 606 → 781, Zufallsplan 631 → 712, Lehrer k=8 606 → 631; Allographen 606 → 600;
Nicht-Schrift-Welt 0, Bibliothek +0,4 Einträge. Obergrenze mit den sechs wahren Konzepten 1000.
Die alten Bedingungen liefern nach der Erweiterung bitgleich dieselben Kurven wie zuvor (geprüft an lehrer_k8).

## Kurze Codes in Stufen (Zahlvertrag 2)

```
python3 -I kein_float.py stufen.py
python3 -I pruefe_stufen.py <lern.bin> ergebnisse/stufen_13x4096.json 13x4096
python3 -I pruefe_stufen.py <lern.bin> ergebnisse/stufen_2hoch16.json 2^16
```

`stufen.py`: Wahrscheinlichkeit als Leiter (Stufe, Teile, Rest) mit B = 13 · 4096 = 53.248 Teilen je Stufe, Produkt und Summe
linear, Vergleich grob vor fein, zwei Erklärungen (abgerundet/aufgerundet), jede Ziffer zweifach lesbar (Klasse 0–12 plus
4096 Feinteile; Reste mod 13 und mod 4096), Probe mod B − 1, Diagonal-Logik über Seiten- und Diagonalzahlen.
Jede Ziffer unter 2^16, Zwischenprodukte höchstens 64 bit, keine Logarithmen. Vergleichslauf mit 2^16: Argument `2^16`.
`pruefe_stufen.py`: Referenz exakt mit Fraction und Produkten großer ganzer Zahlen (nur in der Prüfung).
Gemessen: 0 Fehler in allen Teilen; Kontextgruppen auf tldr 188 von 192 Entscheidungen schon auf der Stufe, 4 über die Teile.
cm.py und stufe0.py laufen noch auf der alten Einstufen-Tafel mit 2^-24 bit.

## Feldforschung und Urwerte (Spielmodelle)

```
python3 -I kein_float.py feldforschung.py urwerte.py wechsel.py profil.py
python3 -I feldforschung.py ergebnisse/feldforschung.json 1000
python3 -I urwerte.py ergebnisse/urwerte.json 2000 400       # etwa 2,5 Minuten auf 2 Kernen
python3 -I wechsel.py ergebnisse/wechsel.json 2000 400       # etwa 1,5 Minuten, braucht urwerte.py daneben
```

`feldforschung.py`: 6 Teile mit je 16 Optionen, 12 Quellen (gut, schwach, irrig), exakter Prüfer mit Ort und Fehlerklasse,
Quellenkonto mit Vertrauen (b + 7) / (b + a + 13). Versuche je Aufgabe (sauber / gemischt / vergiftet): blind 46,0 / 46,1 / 45,9;
blind mit Fehlerklasse 19,0; lesen 1,0 / 1,7 / 5,9; mit Ausschluss 1,0 / 1,6 / 5,7; mit Quellenkonto 1,0 / 1,1 / 2,0
(vergiftet: 5,1 bei der ersten, 1,4 bei der zwanzigsten Aufgabe). Glauben ohne Prüfer löst 997 / 522 / 0 von 1000 Aufgaben.

`urwerte.py`: Urwert = 12 Fasern, Klasse 0..12, Schätzung (2 (s + a) + 1) / (2 (n + 12) + 2). Bauart Anker: 6 feste und 6 freie
Fasern (je 1/6 positiv), Klasse 6..12, Mittel 7, Rückkehr je Tick 5/6. Teil A prüft Ruheverteilung und Rückkehr exakt.
Teil B (Treffer je 1000 Züge, einzeln ruhend / einzeln Wandel / Gruppe ruhend / Gruppe Wandel): ohne Urwert 734 / 689 / 738 / 697;
fest 6: 741 / 701 / 740 / 701; fest 7: 761 / 725 / 764 / 729; fest 9: 778 / 748 / 790 / 760; 12 freie Fasern um 7 mit Drift
751 / 711 / 787 / 751; Anker mit Drift 759 / 719 / 786 / 749. Bezug: blind 495, allwissend 811.

`wechsel.py`: Vergessen als Fassungswechsel (die letzten 16 Ergebnisse als eigener KT-Block, Schwelle 64, exakter Vergleich über
Kreuzprodukte). Treffer (ruhend / ein Wechsel / Wechsel alle 100 Züge): kein Vergessen 753 / 659 / 612; Halbieren 761 / 725 / 674;
nur Fassungswechsel 754 / 728 / 690; beides 760 / 733 / 696.

## Hieroglyphen, zweite Prüfung an deutschem Text

```
git clone https://github.com/tblock/10kGNAD        # CC BY-NC-SA 4.0; die Daten liegen nicht im Paket
python3 -I profil.py 10kGNAD/train.csv 10kGNAD/test.csv ergebnisse/profil.json
```

`profil.py`, Teil 1: Kategorie als Kontext eines Wortmodells mit Rückfall auf die Grundverteilung (k = 65536, auf zurückgehaltenen
Lernartikeln gewählt): 10,935 → 10,671 bit je Wort; kürzeste Klasse 10,649 und 85,0 % Treffer; L1-Profil der 150 häufigsten Wörter
42,8 % Treffer (größte Klasse 16,3 %) und 10,869 bit; erfundene Klassen 11,051 bit (Gegenprobe).
Teil 2: 280 komplementäre Paare unter 1949 häufigen Zeichenfolgen, alle thematisch, keine Schreibvariante.

## Werkbank: Compiler-Schleife ohne Netz (Arbeitspaket 1)

Im Ordner `werkbank`, mit eigenem LIESMICH: Rust-Kern `stufen.rs` (bitgleich zu `stufen.py` auf 8590 Vektoren),
Prüfstand, Abweichungsprüfung des Prüfers (787 Abweichungen, 755 entdeckt, 32 gleichwertig) und Reparaturschleife
(41 von 48 Episoden ohne, 43 mit gelernten Tafeln; 64,7 gegen 47,5 Prüferläufe je Episode). Braucht Rust und Python 3.

## Werkbank: Funktionen aus Beispielen schreiben

`werkbank/synthese.py` schreibt 11 der 13 Kernfunktionen selbst (Ausdruck, Rückwärtsrechnen, Schablone, Folge,
Fragenkette, Aufruf, Fälle mit Rechnung); der Compiler-Prüfstand bestätigt sie auf drei Vektorsätzen. Nur aus
Beispielen gelernt, bestehen `entscheide` und `mal` alle 17180 Beispiele und sind trotzdem falsch (6456 und 1637
Abweichungen auf 20000 breiten Eingaben); mit zwei Erklärungen und Rückfragen an den Lehrer sind sie richtig.
`werkbank/suchraum.py` zählt den Suchraum je Schritt (Faktor 13 bis 26 je Rechenzeichen). Einzelheiten im LIESMICH
der Werkbank, Schritte 4 und 5.

`werkbank/gipfel.py` setzt die geschriebenen Funktionen zu größeren Programmen zusammen: An der Vorstufe (Bruch
gegen Bruch, blind, 272 Kandidaten) wird die Maske „zwei Faserpaare, ein Urteil" gelernt; mit ihr werden zwei
Gipfelaufgaben gelöst (9 Aufrufe nach 225 Füllungen, 17 Aufrufe nach 1600225 Füllungen), die blind 6,6 · 10^7 und
1,3 · 10^20 Kandidaten hätten. Arbeitsregel ab hier: Alles wird als Faser geführt, als logische Datenkette über
einem Fußpunkt (Schritt 6 im LIESMICH der Werkbank).

## Häufung und Oberthema: ganzer Text gegen kurze Blöcke

```
python3 -I haeufung.py 10kGNAD/train.csv 10kGNAD/test.csv ergebnisse/haeufung.json      # etwa 25 Sekunden
```

`haeufung.py` misst an denselben Artikeln wie `profil.py`, was ein Wortmodell aus dem ganzen Text gewinnt und was in
kurzen Blöcken verloren geht. Kontext ist der Text bis zur Stelle: p(w) = (n_Text(w) · D + k · z0(w)) / ((N_Text + k) · D),
k auf zurückgehaltenen Lernartikeln gewählt (1024). Bit je Wort auf 1028 Testartikeln (375300 Wörter):

| Kontext eines Wortes | bit je Wort |
| --- | --- |
| keiner (Grundverteilung) | 10,935 |
| derselbe Text in Blöcken von 12 Wörtern, Zähler je Block neu | 10,924 |
| der ganze Artikel bis zur Stelle | 10,532 |
| das Oberthema (Kategorie, mitkodiert) | 10,671 |
| Oberthema und ganzer Artikel | 10,364 |
| Oberthema und Blöcke | 10,662 |
| Blöcke über alle Artikel gemischt, ohne Oberthema | 10,952 |
| Blöcke über alle Artikel gemischt, mit dem Oberthema des Artikels | 11,244 |

Gewinn des ganzen Artikels nach Stelle: 0,116 bit in den Wörtern 1 bis 25, dann 0,321 / 0,387 / 0,421 / 0,448 und
0,449 bit ab Wort 401. Wiederkehr: Unter den Artikeln, in denen eines von 4516 Inhaltswörtern steht, steht es in
16,5 % mindestens zweimal; mit einzeln über alle Artikel gemischten Wörtern in 4,1 %.

Folge für den Aufbau: Die Sprachseite lernt und schreibt an ganzen Texten über ein Oberthema (Fußpunkt), von grob
nach fein: Thema, Gliederung, Absatz, Satz, Wort. Feste Satzmuster dienen nur der Bedienung der Werkbank.
