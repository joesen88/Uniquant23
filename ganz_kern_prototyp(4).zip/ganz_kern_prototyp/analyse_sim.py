"""Auswertung der Spielwelt-Simulation, ganzzahlig.  Aufruf: python3 -I analyse_sim.py <verzeichnis> <aus.json>"""
import json
import sys
from math import comb
from pathlib import Path

d = Path(sys.argv[1])
namen = ["nur_gipfel", "gipfel_zerlegt", "zufall", "lehrer_ohne_gipfel", "lehrer_k4", "lehrer_k8", "lehrer_k16",
         "lehrer_k8_zeigen", "lehrer_k8_ohne_schlaf"]
R = {n: json.loads(d.joinpath(f"{n}.json").read_text())["laeufe"] for n in namen}
S = len(R[namen[0]])
out = {"samen": S, "bedingungen": {}, "kurven": {}, "paare": {}}
for n in namen:
    ende = [r["kurve"][-1] for r in R[n]]
    g = [e["geloest"] for e in ende]
    geloeste_bits = [e["bits_milli"] for e in ende if e["geloest"] > 0]
    z = [r["zaehl"] for r in R[n]]
    out["bedingungen"][n] = {
        "gipfel_ende": g,
        "gipfelquote_promille": sum(g) * 1000 // (16 * S),
        "spanne": [min(g), max(g)],
        "expansionen_mittel": sum(e["expansionen"] for e in ende) // S,
        "bits_milli_mittel": sum(geloeste_bits) // max(len(geloeste_bits), 1),
        "bibliothek_mittel_x10": sum(e["bibliothek"] - 5 for e in ende) * 10 // S,
        "pruef_geloest": sum(x["pruef_geloest"] for x in z), "pruefungen": sum(x["pruefungen"] for x in z),
    }
    T = len(R[n][0]["kurve"])
    out["kurven"][n] = [[R[n][0]["kurve"][t]["episode"], sum(r["kurve"][t]["geloest"] for r in R[n]) * 1000 // (16 * S)]
                        for t in range(T)]


def vorzeichen(a, b):
    pos = sum(1 for x, y in zip(a, b) if x > y)
    neg = sum(1 for x, y in zip(a, b) if x < y)
    n = pos + neg
    k = max(pos, neg)
    p_zaehler = 2 * sum(comb(n, i) for i in range(k, n + 1))       # zweiseitig, exakt: p = p_zaehler / 2^n
    return {"besser": pos, "schlechter": neg, "gleich": len(a) - n,
            "p_promille_zweiseitig": min(1000, p_zaehler * 1000 >> n) if n else 1000}


g = {n: out["bedingungen"][n]["gipfel_ende"] for n in namen}
for a, b in [("gipfel_zerlegt", "nur_gipfel"), ("lehrer_k8", "lehrer_ohne_gipfel"), ("lehrer_k4", "lehrer_ohne_gipfel"),
             ("lehrer_k4", "lehrer_k16"), ("lehrer_k8_zeigen", "lehrer_k8"), ("lehrer_k8", "lehrer_k8_ohne_schlaf"),
             ("lehrer_k8", "zufall"), ("gipfel_zerlegt", "lehrer_k8"), ("lehrer_k8_zeigen", "zufall")]:
    out["paare"][f"{a} vs {b}"] = vorzeichen(g[a], g[b])
Path(sys.argv[2]).write_text(json.dumps(out, indent=1))
for n in namen:
    b = out["bedingungen"][n]
    print(f"{n:24s} Quote {b['gipfelquote_promille']:4d} Promille  Spanne {b['spanne']}  Exp {b['expansionen_mittel']:5d}"
          f"  Bits {b["bits_milli_mittel"]:6d}m  Bib+ {b['bibliothek_mittel_x10']}/10  Pruef {b['pruef_geloest']}/{b['pruefungen']}")
for k, v in out["paare"].items():
    print(f"{k:40s} {v}")
print("Kurven:", {n: out["kurven"][n][::4] for n in ("zufall", "lehrer_ohne_gipfel", "lehrer_k8", "lehrer_k8_zeigen")})
