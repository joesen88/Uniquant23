"""Pruefung der Stufenzahlen (stufen.py).  Fraction und grosse Python-int nur hier, als exakte Referenz.

Aufruf: python3 -I pruefe_stufen.py <lern.bin> <ausgabe.json> [13x4096 | 2^16]
1  Leiter: Produkte und Summen gegen Fraction (unten <= exakt <= oben), Ziffern stets 16 Bit
2  Entscheidungen grob vor fein gegen exakten Vergleich, mit absichtlich knappen Faellen
3  zwei Skalen: Rueckrechnung und Probe mit eingestreuten Fehlern
4  Diagonal-Logik: 22,5-Grad-Test ueber Seiten- und Diagonalzahlen gegen exakten Quadrattest
5  Kontextgruppen auf tldr: zerfaellt ein Kontext nach einem Merkmal in zwei Gruppen?  Nur Wahrscheinlichkeiten
   in der Leiter; Referenz exakt ueber Produkte ganzer Zahlen
"""
import json
import random
import sys
from fractions import Fraction
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import stufen as S  # noqa: E402


def wert(w):
    k, m, r = w
    v = Fraction(m * S.BASIS + r, S.QUADRAT)
    return v * Fraction(1, S.BASIS ** k) if k >= 0 else v * S.BASIS ** (-k)


def gueltig(w):
    k, m, r = w
    return 1 <= m < S.BASIS and 0 <= r < S.BASIS


def kette(rnd, laenge):
    return [(rnd.randrange(1, 1 << 16), 0) for _ in range(laenge)]


def zufallsbruch(rnd):
    n = rnd.randrange(2, 1 << 16)
    return rnd.randrange(1, n), n


def produkt_leiter(faktoren):
    lo, hi = S.EINS, S.EINS
    for z, n in faktoren:
        lo = S.mal(lo, S.bruch(z, n))
        hi = S.mal(hi, S.bruch(z, n, oben=True), oben=True)
    return lo, hi


def produktbaum(xs):
    xs = list(xs) or [1]
    while len(xs) > 1:
        xs = [xs[i] * xs[i + 1] if i + 1 < len(xs) else xs[i] for i in range(0, len(xs), 2)]
    return xs[0]


def main():
    lern, aus = Path(sys.argv[1]), Path(sys.argv[2])
    basis = sys.argv[3] if len(sys.argv) > 3 else "13x4096"
    if basis == "2^16":
        S.setze_basis(1, 1 << 16)
    rnd = random.Random(20261118)
    erg = {"basis": basis, "teile_je_stufe": S.BASIS}

    # 1 Leiter gegen Fraction
    fehler = ungueltig = 0
    max_stufe = 0
    for t in range(3000):
        f = [zufallsbruch(rnd) for _ in range(rnd.randrange(1, 300))]
        lo, hi = produkt_leiter(f)
        exakt = Fraction(1)
        for z, n in f:
            exakt *= Fraction(z, n)
        fehler += not (wert(lo) <= exakt <= wert(hi))
        ungueltig += (not gueltig(lo)) + (not gueltig(hi))
        max_stufe = max(max_stufe, hi[0])
        if t % 3 == 0:                               # Summen getrennter Faelle
            a, b = produkt_leiter(f[: len(f) // 2 + 1]), produkt_leiter(f[len(f) // 2:])
            s_lo, s_hi = S.plus(a[0], b[0]), S.plus(a[1], b[1], oben=True)
            ex = Fraction(1)
            for z, n in f[: len(f) // 2 + 1]:
                ex *= Fraction(z, n)
            ex2 = Fraction(1)
            for z, n in f[len(f) // 2:]:
                ex2 *= Fraction(z, n)
            lo_ok = wert(s_lo) <= ex + ex2 if gueltig(s_lo) else False
            fehler += not (lo_ok and ex + ex2 <= wert(s_hi))
    erg["leiter"] = {"ketten": 3000, "fehler": fehler, "ungueltige_ziffern": ungueltig, "groesste_stufe": max_stufe}
    print("1 Leiter", erg["leiter"], flush=True)

    # 2 Entscheidungen grob vor fein, mit knappen Faellen
    arten = ["gleich", "ein Faktor um 1 kleiner", "umgeordnet, exakt gleich", "fremde Kette"]
    ebenen = {a: {"stufe": 0, "teile": 0, "rest": 0, "offen": 0} for a in arten}
    falsch = 0
    for t in range(4000):
        f = [zufallsbruch(rnd) for _ in range(rnd.randrange(5, 200))]
        g = list(f)
        art = t % 4
        if art == 1:                                 # ein Faktor leicht veraendert
            i = rnd.randrange(len(g))
            z, n = g[i]
            g[i] = (max(1, z - 1), n)
        elif art == 2:                               # gleiche Faktoren, andere Reihenfolge: exakt gleich
            rnd.shuffle(g)
        elif art == 3:                               # voellig andere Kette
            g = [zufallsbruch(rnd) for _ in range(rnd.randrange(5, 200))]
        a, b = produkt_leiter(f), produkt_leiter(g)
        s, wo = S.entscheide(a[0], a[1], b[0], b[1])
        ea, eb = Fraction(1), Fraction(1)
        for z, n in f:
            ea *= Fraction(z, n)
        for z, n in g:
            eb *= Fraction(z, n)
        wahr = (ea > eb) - (ea < eb)
        if s != 0 and s != wahr:
            falsch += 1
        ebenen[arten[art]][wo] += 1
    erg["entscheidungen"] = {"faelle": 4000, "falsch": falsch, "ebenen": ebenen}
    print("2 Entscheidungen", erg["entscheidungen"], flush=True)

    # 3 zwei Skalen
    grenze = S.BASIS * S.PROBE
    rueck_falsch = 0
    for _ in range(200000):
        x = rnd.randrange(grenze)
        rueck_falsch += S.zurueck(*S.zwei_skalen(x)) != x
    erkannt = bestaetigt = 0
    for _ in range(2000):
        xs = [rnd.randrange(1 << 16) for _ in range(rnd.randrange(1, 5000))]
        direkt = sum(xs)                             # < 5000 * 2^16, also eindeutig rueckrechenbar
        a = b = 0
        for x in xs:                                 # zwei getrennte Kanaele
            a = (a + x) % S.BASIS
            b = (b + x) % S.PROBE
        bestaetigt += S.zurueck(a, b) == direkt
        if rnd.randrange(2):                         # Fehler in genau einem Kanal
            a = (a + rnd.randrange(1, S.BASIS)) % S.BASIS
        else:
            b = (b + rnd.randrange(1, S.PROBE)) % S.PROBE
        erkannt += S.zurueck(a, b) != direkt
    stich, gleich = 2000, bestaetigt
    erg["zwei_skalen"] = {"rueckrechnungen": 200000, "falsch": rueck_falsch, "summen_ohne_fehler": stich,
                          "davon_bestaetigt": gleich, "eingestreuter_fehler_erkannt": erkannt}
    print("3 zwei Skalen", erg["zwei_skalen"], flush=True)
    if S.KLASSEN == 13:                              # jede Ziffer zweifach lesbar
        f1 = f2 = f3 = 0
        for _ in range(200000):
            m = rnd.randrange(S.BASIS)
            c, f = S.klasse_fein(m)
            f1 += not (0 <= c < 13 and 0 <= f < 4096 and c * 4096 + f == m)
            f2 += S.aus_resten(*S.reste(m)) != m
            x = rnd.randrange(1 << 64)
            f3 += S.klasse_per_quersumme(x) != x % 13
        erg["ziffern"] = {"stichproben": 200000, "grob_fein_falsch": f1, "reste_falsch": f2, "quersumme_falsch": f3}
        print("3b Ziffern", erg["ziffern"], flush=True)

    # 4 Diagonal-Logik
    stufen = [0] * (len(S.PELL) + 1)
    falsch = 0
    for _ in range(300000):
        x = rnd.randrange(1, 1 << 15)
        y = rnd.randrange(0, x + 1)
        e, st = S.unter_22_5(y, x)
        falsch += e != ((x + y) * (x + y) < 2 * x * x)
        stufen[st] += 1
    erg["diagonal"] = {"punkte": 300000, "falsch": falsch, "entschieden_nach_paar": stufen,
                       "paare": [list(p) for p in S.PELL]}
    print("4 Diagonal", erg["diagonal"], flush=True)

    # 5 Kontextgruppen auf tldr
    daten = lern.read_bytes()
    NMAX, KZ = 20000, 48

    def merkmale(c):
        return ((65 <= c <= 90) or (97 <= c <= 122) or c >= 128, c in (32, 10, 9), (48 <= c <= 57) or
                (33 <= c <= 47) or (58 <= c <= 64), 65 <= c <= 90)
    namen = ["Buchstabe", "Leerraum", "Ziffer oder Satzzeichen", "Grossbuchstabe"]
    haeufig = {}
    for c in daten:
        haeufig[c] = haeufig.get(c, 0) + 1
    kontexte = [c for c, _ in sorted(haeufig.items(), key=lambda kv: -kv[1])[:KZ]]
    folgen = {c: [] for c in kontexte}
    for t in range(2, len(daten)):
        c = daten[t - 1]
        f = folgen.get(c)
        if f is not None and len(f) < NMAX:
            f.append((merkmale(daten[t - 2]), daten[t]))
    STRUKTUR = (1, 8)                                 # 1 bit fuer "geteilt", 2 bit fuer welches der 4 Merkmale
    ebenen = {"stufe": 0, "teile": 0, "rest": 0, "offen": 0}
    falsch = 0
    geteilt = [0, 0, 0, 0]
    max_k = 0
    beispiele = []
    for c in kontexte:
        seq = folgen[c]
        # gemeinsame Tafel
        zahl, n = [0] * 256, 0
        fj = []
        for _, x in seq:
            fj.append((2 * zahl[x] + 1, 2 * n + 256))
            zahl[x] += 1
            n += 1
        j_lo, j_hi = produkt_leiter(fj)
        num_j, den_j = produktbaum(z for z, _ in fj), produktbaum(d for _, d in fj)
        for fi in range(4):
            zahl2 = [[0] * 256, [0] * 256]
            n2 = [0, 0]
            fs = []
            for mk, x in seq:
                g = 1 if mk[fi] else 0
                fs.append((2 * zahl2[g][x] + 1, 2 * n2[g] + 256))
                zahl2[g][x] += 1
                n2[g] += 1
            s_lo, s_hi = produkt_leiter(fs + [STRUKTUR])
            max_k = max(max_k, s_lo[0], j_lo[0])
            s, wo = S.entscheide(s_lo, s_hi, j_lo, j_hi)
            links = produktbaum(z for z, _ in fs) * den_j
            rechts = 8 * produktbaum(d for _, d in fs) * num_j
            wahr = (links > rechts) - (links < rechts)
            if s != 0 and s != wahr:
                falsch += 1
            ebenen[wo] += 1
            if s > 0:
                geteilt[fi] += 1
            if len(beispiele) < 6 and wo in ("teile", "rest", "offen"):
                beispiele.append({"kontext": c, "merkmal": namen[fi], "ebene": wo,
                                  "stufen_geteilt_gemeinsam": [s_lo[0], j_lo[0]]})
    erg["kontextgruppen"] = {"kontexte": KZ, "folgen_je_kontext_hoechstens": NMAX, "entscheidungen": KZ * 4,
                             "falsch": falsch, "ebenen": ebenen,
                             "geteilt_je_merkmal": dict(zip(namen, geteilt)), "groesste_stufe": max_k,
                             "knappe_beispiele": beispiele}
    print("5 Kontextgruppen", erg["kontextgruppen"], flush=True)
    aus.write_text(json.dumps(erg, indent=1))


if __name__ == "__main__":
    main()
