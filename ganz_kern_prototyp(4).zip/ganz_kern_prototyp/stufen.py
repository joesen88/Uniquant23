"""Stufenzahlen: kurze Codes in Stufen, zwei Skalen, grob vor fein.  Nur ganze Zahlen.

Basis je Stufe B = 13 * 4096 = 53.248 Teile (umstellbar mit setze_basis; Vergleichswert 2^16).
Jede Ziffer ist kleiner als 2^16; Produkte zweier Ziffern bleiben unter 2^32, Zwischenprodukte unter 2^64.
Zaehler bleiben unter 2^16 (Halbieren wie im Kontextmischer).

Einheitenleiter (aegyptisch: Hekat -> Teile -> Ro)
    Wahrscheinlichkeit w = (k, m, r) mit Wert (m * B + r) * B^-2 * B^-k
    k  Stufe: Klasse der Groessenordnung, kleine ganze Zahl
    m  Teile: 1 <= m < B, sonst eine Stufe tiefer
    r  Rest:  0 <= r < B
    Die Einheit wechselt nur in ganzen Stufen um den festen Faktor B; die Bereiche der Stufen sind disjunkt und
    geordnet: Stufe k liegt in [B^-(k+1), B^-k).
Jede Ziffer zweifach lesbar (zwei Skalen, die sich ergaenzen)
    grob/fein:  m = 4096 * c + f,  Klasse c in 0..12, Feinteil f in 0..4095 (12 bit wie im Mischer)
    Reste:      (m mod 13, m mod 4096) bestimmt m eindeutig, weil 13 und 4096 teilerfremd sind;
                wegen 4096 = 1 (mod 13) gilt m = f' + 4096 ((a - f') mod 13) fuer a = m mod 13, f' = m mod 4096.
                Dasselbe macht aus jeder Zahl in 4096er-Ziffern ihre Klasse mod 13 per Quersumme (Neunerprobe).
Rechnen nur mit Wahrscheinlichkeiten, linear
    UND = Produkt (mal), ODER ueber getrennte Faelle = Summe (plus), beste Wahl = Maximum (vergleiche).
    Keine Logarithmen im Kern; Bit nur als Umrechnung zur Anzeige.
Zwei Erklaerungen
    Jede Wahrscheinlichkeit wird zweimal gefuehrt, abgerundet (unten) und aufgerundet (oben); entschieden ist nur,
    was beide gleich sehen, sonst Klasse "offen".
Grob vor fein
    Vergleich zuerst ueber die Stufe, dann die Teile, dann den Rest.
Probe
    Summen laufen zusaetzlich mod (B - 1); B und B - 1 sind teilerfremd, also x = a + B ((b - a) mod (B - 1))
    fuer x < B (B - 1).
Diagonal-Logik
    Seiten- und Diagonalzahlen (s, d) mit d^2 - 2 s^2 = +-1, s' = s + d, d' = 2 s + d: abwechselnd untere und
    obere Schranken fuer sqrt 2.
"""
KLASSEN = 13
FEIN = 4096
BASIS = KLASSEN * FEIN
QUADRAT = BASIS * BASIS
PROBE = BASIS - 1
EINS = (-1, 1, 0)                                   # Wert 1 = (1 * B + 0) * B^-2 * B^1


def setze_basis(klassen, fein):
    """Nur fuer Vergleiche in der Pruefung (z. B. 1 und 65536 fuer die reine Zweierpotenz)."""
    global KLASSEN, FEIN, BASIS, QUADRAT, PROBE
    KLASSEN, FEIN = klassen, fein
    BASIS = klassen * fein
    QUADRAT = BASIS * BASIS
    PROBE = BASIS - 1


# ---------------------------------------------------------------- Einheitenleiter
def bruch(z, n, oben=False):
    """z/n mit 1 <= z <= n < 2^16 als Leiterwert, abgerundet oder (oben=True) aufgerundet."""
    if z == n:
        return EINS
    k = 0
    d, rest = divmod(z * QUADRAT, n)                # z * B^2 < 2^48
    if d < BASIS:                                   # kleiner als eine Einheit der Stufe 0: eine Stufe tiefer
        k = 1
        d, rest = divmod(z * QUADRAT * BASIS, n)    # < 2^64
    if oben and rest:
        d += 1
        if d == QUADRAT:
            k -= 1
            d = BASIS
    m, r = divmod(d, BASIS)
    return (k, m, r)


def mal(a, b, oben=False):
    """Produkt zweier Leiterwerte (UND).  Zwei Ziffern bleiben, der Rest wird gerundet."""
    ka, ma, ra = a
    kb, mb, rb = b
    p = (ma * BASIS + ra) * (mb * BASIS + rb)       # < B^4 < 2^64
    k = ka + kb
    d, weg = divmod(p, QUADRAT)
    if d < BASIS:                                   # fuehrende Ziffer waere 0: eine Stufe tiefer
        k += 1
        d, weg = divmod(p, BASIS)
    if oben and weg:
        d += 1
        if d == QUADRAT:
            k -= 1
            d = BASIS
    m, r = divmod(d, BASIS)
    return (k, m, r)


def plus(a, b, oben=False):
    """Summe zweier Leiterwerte (ODER ueber getrennte Faelle), ausgerichtet auf die Einheit des groesseren."""
    if vergleiche(a, b)[0] < 0:
        a, b = b, a
    ka, ma, ra = a
    kb, mb, rb = b
    x, y = ma * BASIS + ra, mb * BASIS + rb
    dk = kb - ka
    if dk == 0:
        s, weg = x + y, 0
    elif dk == 1:
        s, weg = x + y // BASIS, y % BASIS
    else:
        s, weg = x, y
    if oben and weg:
        s += 1
    k = ka
    if s >= QUADRAT:                                # Uebertrag in die naechsthoehere Stufe
        s, weg2 = divmod(s, BASIS)
        k -= 1
        if oben and weg2:
            s += 1
    m, r = divmod(s, BASIS)
    return (k, m, r)


def vergleiche(a, b):
    """(+1 | 0 | -1, Ebene): grob vor fein; die kleinere Stufe ist der groessere Wert."""
    if a[0] != b[0]:
        return (1 if a[0] < b[0] else -1), "stufe"
    if a[1] != b[1]:
        return (1 if a[1] > b[1] else -1), "teile"
    if a[2] != b[2]:
        return (1 if a[2] > b[2] else -1), "rest"
    return 0, "gleich"


def entscheide(a_unten, a_oben, b_unten, b_oben):
    """+1: a sicher groesser, -1: a sicher kleiner, 0: offen; dazu die Ebene, auf der entschieden wurde."""
    s, wo = vergleiche(a_unten, b_oben)
    if s > 0:
        return 1, wo
    s, wo = vergleiche(a_oben, b_unten)
    if s < 0:
        return -1, wo
    return 0, "offen"


# ---------------------------------------------------------------- jede Ziffer zweifach lesbar
def klasse_fein(m):
    """Grob und fein: (Klasse 0..KLASSEN-1, Feinteil 0..FEIN-1)."""
    return divmod(m, FEIN)


def reste(m):
    return m % KLASSEN, m % FEIN


def aus_resten(a, f):
    """Umkehrung von reste(); nutzt FEIN = 1 (mod KLASSEN), gilt fuer 13 und 4096."""
    return f + FEIN * ((a - f) % KLASSEN)


def klasse_per_quersumme(x):
    """x mod 13 aus den 4096er-Ziffern von x, ohne Division durch 13 (Neunerprobe zur Basis 4096)."""
    s = 0
    while x:
        s += x & (FEIN - 1)
        x >>= 12
    return s % KLASSEN


# ---------------------------------------------------------------- Probe
def zwei_skalen(x):
    return x % BASIS, x % PROBE


def zurueck(a, b):
    return a + BASIS * ((b - a) % PROBE)


# ---------------------------------------------------------------- Diagonal-Logik
def seiten_diagonal(stufen):
    s, d, out = 1, 1, []
    for _ in range(stufen):
        out.append((s, d))
        s, d = s + d, 2 * s + d
    return out


PELL = seiten_diagonal(9)


def unter_22_5(y, x):
    """0 <= y <= x < 2^15: liegt der Punkt (x, y) unter 22,5 Grad, also y/x < sqrt2 - 1?  Grob vor fein."""
    for i, (s, d) in enumerate(PELL):
        g = d - s
        if d * d < 2 * s * s:
            if y * s < g * x:
                return True, i
        elif y * s >= g * x:
            return False, i
    return (x + y) * (x + y) < 2 * x * x, len(PELL)
